"""Safe, explicit SQLite snapshots for MoOLVa HACCP Easy 1.5.

Backups never invent data, share files, or silently overwrite user-selected files.
"""
from __future__ import annotations
import os
import sqlite3
from datetime import datetime
from pathlib import Path


REQUIRED_TABLES = {'venues', 'journal_records', 'audit_events'}


def _verify(path):
    path = Path(path)
    if not path.is_file() or path.stat().st_size < 1024:
        raise ValueError('Файл резервной копии отсутствует или слишком мал')
    with sqlite3.connect(f'file:{path.as_posix()}?mode=ro', uri=True, timeout=8) as db:
        if db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise ValueError('Резервная копия повреждена')
        names = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not REQUIRED_TABLES <= names:
            raise ValueError('Файл не является базой данных MoOLVa ХАССП')
        return db.execute('SELECT count(*) FROM venues').fetchone()[0]


def create_database_backup(store, destination):
    """Transactional SQLite backup with verification and no replacement of existing files."""
    src, dest = Path(store.path).resolve(), Path(destination).resolve()
    if src == dest:
        raise ValueError('Нельзя сохранять резервную копию поверх рабочей базы')
    if dest.exists():
        raise FileExistsError('Выберите новое имя файла: копия уже существует')
    if dest.suffix.lower() not in {'.db', '.sqlite', '.sqlite3'}:
        raise ValueError('Для резервной копии выберите расширение .sqlite3')
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp = dest.with_name(dest.name + '.partial')
    try:
        with sqlite3.connect(src, timeout=10) as source, sqlite3.connect(temp, timeout=10) as out:
            source.backup(out)
        _verify(temp)
        if dest.exists():
            raise FileExistsError('Копия уже существует')
        os.replace(temp, dest)
        return dest
    finally:
        temp.unlink(missing_ok=True)


def restore_database_backup(store, from_path):
    """Check a selected file and create rollback snapshot before copying it into the live DB.

    Caller must ask for confirmation and require an application restart afterwards.
    """
    source = Path(from_path).resolve()
    target = Path(store.path).resolve()
    if source == target:
        raise ValueError('Выбрана текущая рабочая база вместо резервной копии')
    _verify(source)
    recovery = target.parent / 'easy15_backups'
    recovery.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    safety = create_database_backup(store, recovery / f'before_restore_{stamp}.sqlite3')
    try:
        with sqlite3.connect(source, timeout=10) as old, sqlite3.connect(target, timeout=10) as active:
            old.backup(active)
        _verify(target)
        return safety
    except Exception:
        with sqlite3.connect(safety, timeout=10) as old, sqlite3.connect(target, timeout=10) as active:
            old.backup(active)
        raise
