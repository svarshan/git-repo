"""MoOLVa HACCP Easy 1.5 Smart Workspace — local, auditable UX helpers.

Never synthesize HACCP measurements, actual signatures, temperature values or CCP designations.
Drafts are stored separately from official journal records; draft autosave is not an attestation.
"""
from __future__ import annotations
import hashlib
import json
import shutil
from datetime import datetime, date
from pathlib import Path
from storage import now
from flowchart_core import create_diagram, create_node, add_edge, delete_diagram
from enterprise14_core import list_actions

HELP = {
    'ККТ': ('Критическая контрольная точка — этап, где управление необходимо для предотвращения, '
            'устранения или снижения значимой опасности до приемлемого уровня. Решение подтверждает специалист.'),
    'КП': 'Контрольная точка — этап контроля процесса, который не обязательно является критической контрольной точкой.',
    'Критический предел': 'Измеримый или наблюдаемый критерий для конкретной ККТ. Не назначайте его без обоснования.',
    'Мониторинг': 'Запланированная последовательность наблюдений или измерений для проверки соблюдения критериев.',
    'Корректирующее действие': 'Действия при выявленном отклонении: обеспечение безопасности продукции, устранение причины, запись.',
    'Журнал': 'Документ для фиксации фактически выполненных проверок. Поля измерений заполняются только по факту.',
    'Ознакомление': 'Программа готовит лист для собственноручной подписи. Галочка или ФИО не подтверждает реальное подписание.',
    'Автосохранение': 'Черновик хранится на этом компьютере. Чтобы он стал записью журнала, нажмите «Сохранить запись».',
}
# Templates are starting examples, never official approved hazard analyses.
FLOW_STARTERS = {
    'Горячий цех': ('Приёмка сырья','Хранение','Подготовка сырья','Тепловая обработка','Временное хранение','Отпуск блюд'),
    'Приготовление салатов': ('Приёмка продуктов','Хранение','Мойка / первичная подготовка','Нарезка','Смешивание','Порционирование','Отпуск'),
    'Выпечка': ('Приёмка сырья','Хранение','Дозирование','Замес','Формование','Выпекание','Охлаждение','Упаковка'),
    'Приёмка и склад': ('Приёмка','Проверка сопроводительных документов','Осмотр продукции','Размещение на хранение','Передача в производство'),
    'Доставка': ('Подготовка заказа','Упаковка','Передача курьеру','Транспортирование','Передача получателю'),
}

# Fields safe to carry forward. No result, temperature, signatures, decisions, date/time or measurements.
REUSABLE_HINTS = ('помещение','склад / помещение','оборудование','фритюрница','участок','зона','машина','линия','автомобиль','поставщик','водитель','место хранения')
UNSAFE_HINTS = ('температур','влажност','подпис','результат','допуск','концентрац','измерен',
                'показан','оценк','партия','количество','кол-во','количество','количество',
                'дата','время','час','масса','объём','объем','остаток','расход','приход',
                'отклонен','решени','соответств','срок','действи','исполнител','ответственн',
                'осмотр','примечан','продукц','блюдо','издели','заказ','средств')


def stable_fields(columns, old_record):
    """Carry over only non-safety-critical static descriptors, never a measurement."""
    result={}
    for key,title in columns:
        low=title.lower()
        if any(v in low for v in UNSAFE_HINTS):continue
        if any(v in low for v in REUSABLE_HINTS):
            value=str(old_record.get(key,'')).strip()
            if value:result[key]=value[:240]
    return result


def migrate15(store):
    with store.connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS easy15_drafts (
            venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
            area TEXT NOT NULL, item_key TEXT NOT NULL, payload TEXT NOT NULL,
            updated_at TEXT NOT NULL,PRIMARY KEY(venue_id,area,item_key))''')
        db.execute('''CREATE TABLE IF NOT EXISTS easy15_state (
            key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)''')
        db.execute('''CREATE TABLE IF NOT EXISTS easy15_exports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
            display_name TEXT NOT NULL, original_path TEXT NOT NULL,
            archive_path TEXT NOT NULL, digest TEXT NOT NULL,
            created_at TEXT NOT NULL)''')
        db.execute('CREATE INDEX IF NOT EXISTS ix_easy15_exports ON easy15_exports(venue_id,id)')


def _has_venue(store,venue_id):
    if not store.get_venue(venue_id):raise ValueError('Предприятие не найдено')


def get_setting(store,key,default=None):
    migrate15(store)
    with store.connect() as db:
        r=db.execute('SELECT value FROM easy15_state WHERE key=?',(str(key),)).fetchone()
    try:return json.loads(r['value']) if r else default
    except (TypeError,ValueError):return default


def set_setting(store,key,value):
    if not isinstance(key,str) or len(key)>120:raise ValueError('Недопустимая настройка')
    migrate15(store)
    with store.connect() as db:
        db.execute('''INSERT INTO easy15_state(key,value,updated_at) VALUES(?,?,?)
             ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at''',
             (key,json.dumps(value,ensure_ascii=False),now()))


def save_draft(store,venue_id,area,item_key,payload):
    _has_venue(store,venue_id)
    if area not in ('journal','venue'):raise ValueError('Неизвестный раздел черновика')
    if not isinstance(payload,dict):raise ValueError('Неверный формат черновика')
    if len(json.dumps(payload,ensure_ascii=False))>64000:raise ValueError('Слишком длинный черновик')
    migrate15(store)
    with store.connect() as db:
        db.execute('''INSERT INTO easy15_drafts VALUES(?,?,?,?,?) ON CONFLICT(venue_id,area,item_key)
           DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at''',
           (venue_id,area,str(item_key),json.dumps(payload,ensure_ascii=False),now()))


def load_draft(store,venue_id,area,item_key):
    if not store.get_venue(venue_id):return {}
    migrate15(store)
    with store.connect() as db:
        row=db.execute('SELECT payload FROM easy15_drafts WHERE venue_id=? AND area=? AND item_key=?',
                       (venue_id,area,str(item_key))).fetchone()
    try:
        value=json.loads(row['payload']) if row else {}
        return value if isinstance(value,dict) else {}
    except (ValueError,TypeError):return {}


def clear_draft(store,venue_id,area,item_key):
    migrate15(store)
    with store.connect() as db:
        db.execute('DELETE FROM easy15_drafts WHERE venue_id=? AND area=? AND item_key=?',(venue_id,area,str(item_key)))


def count_drafts(store,venue_id):
    migrate15(store)
    with store.connect() as db:
        return db.execute('SELECT COUNT(*) FROM easy15_drafts WHERE venue_id=?',(venue_id,)).fetchone()[0]


def copy_starter(store,venue_id,kind):
    _has_venue(store,venue_id)
    if kind not in FLOW_STARTERS:raise ValueError('Неизвестная заготовка')
    title='Черновик · '+kind
    d=create_diagram(store,venue_id,title,'Производственный процесс',
        'Пример этапов — подтвердите фактический маршрут производства перед использованием.')
    try:
        previous=None
        for i,name in enumerate(FLOW_STARTERS[kind]):
            node=create_node(store,d,name,x=95+(i%3)*265,y=85+(i//3)*155,
                             node_type='Начало' if i==0 else 'Этап')
            if previous is not None:add_edge(store,d,previous,node)
            previous=node
        return d
    except Exception:
        delete_diagram(store,d)
        raise


def active_reminders(store,venue_id,today=None):
    today=today or date.today()
    result=[]
    for a in list_actions(store,venue_id):
        if a['status']!='Открыто' or not a['due_date']:continue
        try:due=date.fromisoformat(a['due_date'])
        except ValueError:continue
        if due<=today:
            result.append({**a,'urgency':'Просрочено' if due<today else 'Сегодня'})
    return result


def restore_void_record(store,venue_id,record_id,reason):
    _has_venue(store,venue_id)
    reason=str(reason).strip()
    if len(reason)<4:raise ValueError('Укажите причину восстановления не менее 4 символов')
    with store.connect() as db:
        row=db.execute('SELECT voided_at FROM journal_records WHERE id=? AND venue_id=?',(record_id,venue_id)).fetchone()
        if not row or not row['voided_at']:raise ValueError('Аннулированная запись не найдена')
        db.execute('UPDATE journal_records SET voided_at=NULL,void_reason=NULL WHERE venue_id=? AND id=?',(venue_id,record_id))
        store._audit(db,venue_id,'record_restored',{'record_id':record_id,'reason':reason})


def archive_export(store,venue_id,file_path):
    """Keep immutable copy of an exported DOCX/PDF; no system compliance certification."""
    _has_venue(store,venue_id)
    source=Path(file_path)
    if not source.is_file() or source.suffix.lower() not in ('.docx','.pdf','.png'):
        raise ValueError('Можно архивировать только готовые DOCX, PDF и PNG')
    if source.stat().st_size>50_000_000:raise ValueError('Файл превышает лимит архива 50 МБ')
    data=source.read_bytes();digest=hashlib.sha256(data).hexdigest()
    folder=store.path.parent/'easy15_versions'/str(venue_id);folder.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    dest=folder/f'{stamp}_{digest[:12]}{source.suffix.lower()}'
    dest.write_bytes(data)
    migrate15(store)
    try:
        with store.connect() as db:
            db.execute('''INSERT INTO easy15_exports(venue_id,display_name,original_path,archive_path,digest,created_at)
                    VALUES (?,?,?,?,?,?)''',(venue_id,source.name,str(source),str(dest),digest,now()))
            store._audit(db,venue_id,'easy15_export_archive',{'name':source.name,'sha256':digest})
    except Exception:
        dest.unlink(missing_ok=True)
        raise
    return dest


def list_exports(store,venue_id,limit=50):
    migrate15(store)
    with store.connect() as db:
        return [dict(row) for row in db.execute('''SELECT * FROM easy15_exports WHERE venue_id=? ORDER BY id DESC LIMIT ?''',
                         (venue_id,max(1,min(200,limit))))]


def restore_export_copy(store,venue_id,export_id,destination):
    _has_venue(store,venue_id)
    with store.connect() as db:
        row=db.execute('SELECT * FROM easy15_exports WHERE venue_id=? AND id=?',(venue_id,export_id)).fetchone()
    if not row:raise ValueError('Версия документа не найдена')
    source=Path(row['archive_path'])
    if not source.exists() or hashlib.sha256(source.read_bytes()).hexdigest()!=row['digest']:
        raise ValueError('Архивный документ отсутствует или повреждён')
    destination=Path(destination)
    if destination.resolve()==source.resolve():raise ValueError('Выберите другую папку для копии')
    shutil.copy2(source,destination)
    with store.connect() as db:
        store._audit(db,venue_id,'easy15_version_restored',{'version_id':export_id,'destination':str(destination)})
    return destination
