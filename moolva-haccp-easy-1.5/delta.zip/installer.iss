[Setup]
AppId={{7A9687D6-AD47-44D9-A42C-43112E5873C1}
AppName=MoOLVa ХАССП Easy
AppVersion=1.5.0
AppPublisher=MoOLVa
DefaultDirName={localappdata}\Programs\MoOLVaHACCPEasy
DefaultGroupName=MoOLVa ХАССП Easy
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
WizardStyle=modern
Compression=lzma2/max
SolidCompression=yes
SetupIconFile=assets\MoOLVa_HACCP.ico
OutputDir=release
OutputBaseFilename=MoOLVa_HACCP_Easy_1.5.0_Setup
UsePreviousAppDir=yes
[Files]
Source: "dist\MoOLVa_HACCP_Easy_1.5.0_Portable.exe"; DestDir: "{app}"; DestName: "MoOLVa_HACCP_Easy.exe"; Flags: ignoreversion
[Icons]
Name: "{group}\MoOLVa ХАССП Easy"; Filename: "{app}\MoOLVa_HACCP_Easy.exe"
Name: "{autodesktop}\MoOLVa ХАССП Easy"; Filename: "{app}\MoOLVa_HACCP_Easy.exe"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; Flags: unchecked
[Run]
Filename: "{app}\MoOLVa_HACCP_Easy.exe"; Description: "Запустить MoOLVa ХАССП Easy"; Flags: nowait postinstall skipifsilent
