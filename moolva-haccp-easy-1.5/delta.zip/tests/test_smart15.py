"""Functional regression: 1.5 is workflow, not a painted mockup."""
from __future__ import annotations
from datetime import date,timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from easy_core import init_store, make_venue
from enterprise14_core import add_action
from smart15_core import (FLOW_STARTERS, stable_fields, migrate15, save_draft, load_draft,
                          clear_draft, count_drafts, copy_starter, active_reminders,
                          archive_export, list_exports, restore_export_copy, restore_void_record,
                          get_setting, set_setting)
from flowchart_core import list_diagrams, diagram_details
from backup15 import create_database_backup,restore_database_backup

class Smart15Tests(unittest.TestCase):
    def setUp(self):
        d=TemporaryDirectory();self.addCleanup(d.cleanup)
        self.folder=Path(d.name)
        self.store=init_store(self.folder/'database.sqlite3')
        self.first=make_venue(self.store)
        self.second=make_venue(self.store)

    def test_draft_persists_and_isolated_by_enterprise(self):
        save_draft(self.store,self.first,'journal','j1',{'c1':'только первый'})
        self.assertEqual(load_draft(self.store,self.first,'journal','j1')['c1'],'только первый')
        self.assertEqual(load_draft(self.store,self.second,'journal','j1'),{})
        self.assertEqual(count_drafts(self.store,self.first),1)
        clear_draft(self.store,self.first,'journal','j1')
        self.assertEqual(count_drafts(self.store,self.first),0)

    def test_invalid_draft_rejected(self):
        with self.assertRaises(ValueError):save_draft(self.store,self.first,'journal','j1','не словарь')
        with self.assertRaises(ValueError):save_draft(self.store,9898,'journal','j1',{})
        with self.assertRaises(ValueError):save_draft(self.store,self.first,'unexpected','j1',{})

    def test_no_measurements_reused(self):
        data={'a':'Холодильник-1','b':'37','c':'годно','d':'подпись','e':'Склад'}
        fields=[('a','Оборудование'),('b','Температура'),('c','Результат проверки'),
                ('d','Подпись'),('e','Помещение')]
        self.assertEqual(stable_fields(fields,data),{'a':'Холодильник-1','e':'Склад'})

    def test_settings_persist(self):
        set_setting(self.store,'work_mode','simple')
        self.assertEqual(get_setting(self.store,'work_mode'),'simple')
        set_setting(self.store,'work_mode','expert')
        self.assertEqual(get_setting(self.store,'work_mode'),'expert')

    def test_template_creates_editable_diagram_in_one_enterprise(self):
        d=copy_starter(self.store,self.first,'Горячий цех')
        result=diagram_details(self.store,d)
        self.assertTrue(result['nodes'])
        self.assertEqual(len(result['nodes']),len(FLOW_STARTERS['Горячий цех']))
        self.assertNotIn(d,[x['id'] for x in list_diagrams(self.store,self.second)])
        self.assertTrue(any('Черновик' in x['title'] for x in list_diagrams(self.store,self.first)))

    def test_reminders_are_deadlines_not_fabricated(self):
        add_action(self.store,self.first,'Проверить фильтр',(date.today()-timedelta(days=1)).isoformat())
        add_action(self.store,self.first,'Будущий срок',(date.today()+timedelta(days=8)).isoformat())
        result=active_reminders(self.store,self.first)
        self.assertEqual(len(result),1)
        self.assertEqual(result[0]['urgency'],'Просрочено')
        self.assertEqual(active_reminders(self.store,self.second),[])

    def test_restore_only_voided_record_with_audit(self):
        rid=self.store.add_record(self.first,'sample',{'x':'факт'})
        with self.assertRaises(ValueError):restore_void_record(self.store,self.first,rid,'возврат')
        self.store.void_record(self.first,rid,'Ошибка измерения')
        with self.assertRaises(ValueError):restore_void_record(self.store,self.second,rid,'исправление')
        restore_void_record(self.store,self.first,rid,'ошибка отмены')
        self.assertIsNone(self.store.list_records(self.first,'sample')[0]['voided_at'])

    def test_archived_copy_has_hash_and_is_restorable(self):
        src=self.folder/'doc.pdf';src.write_bytes(b'%PDF-1.4\nfixed test bytes\n')
        archive_export(self.store,self.first,src)
        versions=list_exports(self.store,self.first)
        self.assertEqual(len(versions),1)
        self.assertEqual(list_exports(self.store,self.second),[])
        src.write_bytes(b'changed')
        restored=self.folder/'copy.pdf'
        restore_export_copy(self.store,self.first,versions[0]['id'],restored)
        self.assertEqual(restored.read_bytes(),b'%PDF-1.4\nfixed test bytes\n')
        with self.assertRaises(ValueError):restore_export_copy(self.store,self.second,versions[0]['id'],self.folder/'x.pdf')

    def test_sqlite_backup_restore_without_losing_pre_restore_state(self):
        keep=self.folder/'good.sqlite3'
        create_database_backup(self.store,keep)
        with self.assertRaises(FileExistsError):create_database_backup(self.store,keep)
        self.store.add_record(self.first,'sample',{'a':'changed'})
        safeguard=restore_database_backup(self.store,keep)
        self.assertTrue(safeguard.exists())
        self.assertEqual(self.store.list_records(self.first,'sample'),[])
        self.assertEqual([x['data']['a'] for x in self.store.list_records(self.first,'sample')],[])
        restore_database_backup(self.store,safeguard)
        self.assertEqual(len(self.store.list_records(self.first,'sample')),1)

    def test_bad_backup_cannot_replace_database(self):
        bad=self.folder/'invalid.sqlite3';bad.write_bytes(b'broken')
        with self.assertRaises((ValueError,Exception)):restore_database_backup(self.store,bad)
        self.assertIsNotNone(self.store.get_venue(self.first))

if __name__=='__main__':unittest.main()
