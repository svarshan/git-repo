"""MoOLVa 1.7 Smart Quality — task-oriented Russian GUI.
All critical commands call validated core functions, no silent default values.
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from datetime import date
from mature17_core import (
    migrate17, list_suppliers, create_supplier, create_lot, list_lots, consume_lot,
    trace_lot, set_lot_hold, assign_allergen, allergen_warnings, KNOWN_ALLERGENS,
    create_form, list_forms, write_form_entry, list_entries, export_form_docx, void_entry,
    add_equipment_event, list_equipment_events, complete_equipment_event,
    create_document, list_documents, document_action, acknowledge_document, revise_document, document_history, audit_package17,
    create_audit, add_finding, list_audits, list_findings, link_incident_lot,
    global_search17, quality_diagnostics, local_assistant17,
)
from mature16_core import list_capa, list_assets
from mature16_ui import title, text, btn, field, BG, NAV, PANEL, CARD, EDGE, INK, SOFT, MUTED, LIME, CYAN, GREEN, WARN, FONT


class Mature17Mixin:
    def _init17(self):
        migrate17(self.store)
        row=tk.Frame(self.sidebar,bg=NAV);row.pack(fill='x',padx=7,pady=2,before=self.side_meter)
        w=tk.Button(row,text='▣   Центр ХАССП 1.7',anchor='w',command=self.show_center17,
                    bg=NAV,fg=SOFT,activebackground=CARD,activeforeground=INK,
                    relief='flat',bd=0,font=(FONT,9,'bold'),padx=11,pady=7,cursor='hand2')
        w.pack(fill='x');self.primary_buttons['center17']=w

    def _page17(self,heading,subtitle):
        if not self._need_venue():return None
        self._mode='center17';self._activate_nav('center17');self._clear();self._update_metrics()
        self.eyebrow.configure(text='MOOLVA · INTELLIGENT HACCP 1.7')
        self.heading.configure(text=heading);self.subhead.configure(text=subtitle)
        self._set_footer('←  Все инструменты',self.show_center17,'Обязательные поля помечены *',
                         'Мой рабочий день →',self.show_dashboard,0)
        return self.content

    def _card17(self,parent,heading='',description=''):
        outer=tk.Frame(parent,bg=PANEL,highlightbackground=EDGE,highlightthickness=1)
        outer.pack(fill='x',pady=(2,12))
        inner=tk.Frame(outer,bg=PANEL);inner.pack(fill='x',padx=19,pady=17)
        if heading:title(inner,heading,description)
        return inner

    def _info17(self,parent,line,fg=SOFT):
        text(parent,line,fg,850)

    def _with_error17(self,operation,refresh=None):
        try:
            result=operation()
            if refresh:refresh()
            return result
        except (ValueError,FileExistsError,OSError,RuntimeError) as exc:
            messagebox.showerror('Нужно исправить данные',str(exc),parent=self)
            return None

    def _dialog17(self,heading,fields,save):
        """Single compact form. No close-on-error, validate in business layer."""
        win=tk.Toplevel(self);win.title(heading);win.configure(bg=BG)
        win.geometry('640x650');win.minsize(520,420);win.transient(self);win.grab_set()
        body=tk.Frame(win,bg=BG);body.pack(fill='both',expand=True)
        cv=tk.Canvas(body,bg=BG,highlightthickness=0)
        sc=ttk.Scrollbar(body,orient='vertical',command=cv.yview)
        cv.configure(yscrollcommand=sc.set);sc.pack(side='right',fill='y');cv.pack(fill='both',expand=True)
        inner=tk.Frame(cv,bg=BG);cv.create_window((0,0),window=inner,anchor='nw')
        inner.bind('<Configure>',lambda e:cv.configure(scrollregion=cv.bbox('all')))
        tk.Label(inner,text=heading,bg=BG,fg=INK,font=(FONT,15,'bold')).pack(anchor='w',padx=18,pady=(14,8))
        vars={};widgets={};first=None
        for item in fields:
            key,label,mandatory,*options=item
            default=options[0] if len(options)>0 else ''
            choices=options[1] if len(options)>1 else None
            typ=options[2] if len(options)>2 else 'text'
            tk.Label(inner,text=label+('  *' if mandatory else ''),bg=BG,fg=SOFT,font=(FONT,10)).pack(anchor='w',padx=18,pady=(8,4))
            if typ=='multiline':
                w=tk.Text(inner,width=57,height=5,bg='#253B52',fg=INK,insertbackground=INK,relief='flat',wrap='word')
                w.pack(anchor='w',fill='x',padx=18,ipady=3);w.insert('1.0',str(default));widgets[key]=w
            else:
                v=tk.StringVar(value=str(default));vars[key]=v
                if choices is not None:
                    w=ttk.Combobox(inner,values=list(choices),textvariable=v,state='readonly',width=54)
                else:
                    w=tk.Entry(inner,textvariable=v,bg='#253B52',fg=INK,insertbackground=INK,
                               relief='flat',width=57,font=(FONT,10))
                w.pack(anchor='w',fill='x',padx=18,ipady=5);widgets[key]=w
            if first is None:first=w
        buttons=tk.Frame(win,bg=BG);buttons.pack(fill='x',padx=18,pady=13)
        error=tk.Label(buttons,text='',bg=BG,fg='#F0717D',wraplength=540,justify='left');error.pack(fill='x')
        def commit():
            data={k:(w.get('1.0','end-1c') if isinstance(w,tk.Text) else vars[k].get()).strip()
                  for k,w in widgets.items()}
            for key,label,mandatory,*_ in fields:
                if mandatory and not data[key]:
                    error.configure(text='Заполните обязательное поле: '+label)
                    widgets[key].focus_set();return
            try:save(data)
            except (ValueError,OSError,FileExistsError) as ex:
                error.configure(text=str(ex));return
            win.destroy()
        btn(buttons,'Сохранить',commit,True).pack(side='left')
        btn(buttons,'Отмена',win.destroy).pack(side='left',padx=7)
        if first:first.focus_set()
        win.wait_window()

    def show_center17(self):
        body=self._page17('Центр ХАССП','Прослеживаемость · журналы · документы · внутренние проверки · поддержка пользователя')
        if body is None:return
        p=self._card17(body,'Выберите рабочую задачу','Все данные сохраняются локально и отдельно для каждого предприятия')
        items=[('▦  Партии и поставщики',self.show_lots17),('▤  Конструктор журналов',self.show_forms17),
               ('◷  Сроки оборудования',self.show_equipment17),('◇  Аллергены и рецептуры',self.show_allergens17),
               ('▣  Управление документами',self.show_docs17),('▧  Внутренний аудит',self.show_audits17),
               ('!  Связь отклонений с партиями',self.show_incidents17),('⌕  Глобальный поиск',self.show_search17),
               ('✓  Диагностика программы',self.show_quality17),('?  Помощник ХАССП',self.show_helper17)]
        grid=tk.Frame(p,bg=PANEL);grid.pack(fill='x',pady=8)
        for n,(label,action) in enumerate(items):
            b=btn(grid,label,action);b.grid(row=n//2,column=n%2,sticky='ew',padx=5,pady=5)
        grid.grid_columnconfigure(0,weight=1);grid.grid_columnconfigure(1,weight=1)
        note=self._card17(body,'Главный принцип безопасности')
        self._info17(note,'Не пропускаем обязательные поля. Отметки об аллергии и происхождении партии требуют данных от пользователя. Автоматическая проверка не заменяет специалиста по ХАССП.')

    def show_lots17(self):
        body=self._page17('Паспорт партии','Поставщики → сырьё → готовая продукция · поиск связанной партии в обе стороны')
        if body is None:return
        p=self._card17(body,'Партии предприятия')
        commands=tk.Frame(p,bg=PANEL);commands.pack(anchor='w',pady=6)
        btn(commands,'+ Поставщик',self._supplier17,True).pack(side='left')
        btn(commands,'+ Партия',self._lot17).pack(side='left',padx=6)
        btn(commands,'Связать сырьё с выпуском',self._link_lot17).pack(side='left')
        for lot in list_lots(self.store,self.venue_id)[:55]:
            line=tk.Frame(p,bg=CARD);line.pack(fill='x',pady=3)
            self._info17(line,f"#{lot['id']} · {lot['lot_code']} · {lot['name']} · {lot['kind']} · {lot['quantity']:g} {lot['unit']} · {lot['status']}")
            controls=tk.Frame(line,bg=CARD);controls.pack(anchor='w',padx=6,pady=4)
            btn(controls,'Проследить',lambda i=lot['id']:self._show_lot_trace17(i)).pack(side='left')
            btn(controls,'Блокировать / разблокировать',lambda x=lot:self._hold_lot17(x)).pack(side='left',padx=5)
        if not list_lots(self.store,self.venue_id):self._info17(p,'Партий пока нет. Начните с поставщика и партии сырья.')

    def _supplier17(self):
        self._dialog17('Новый поставщик',[('name','Наименование поставщика',True),('contact','Контакт / реквизиты',False)],
                       lambda v:(create_supplier(self.store,self.venue_id,v['name'],v['contact'],self._actor16()),self.show_lots17()))

    def _lot17(self):
        suppliers=list_suppliers(self.store,self.venue_id)
        values=['']+[f"{s['id']} · {s['name']}" for s in suppliers]
        self._dialog17('Паспорт новой партии',[
            ('kind','Тип',True,'Сырьё',['Сырьё','Готовая продукция']),
            ('code','Номер партии',True),('name','Наименование',True),
            ('supplier','Поставщик сырья',False,'',values),
            ('received','Дата поступления / изготовления (ГГГГ-ММ-ДД)',True,date.today().isoformat()),
            ('expiry','Годен до (ГГГГ-ММ-ДД)',False),
            ('quantity','Количество (только фактическое)',True),('unit','Единица',True,'кг'),('storage','Место хранения',False)
        ],lambda v:(create_lot(self.store,self.venue_id,v['code'],v['kind'],v['name'],v['received'],v['quantity'],
                               v['unit'],self._actor16(),int(v['supplier'].split(' · ')[0]) if v['supplier'] else None,
                               v['expiry'],v['storage']),self.show_lots17()))

    def _link_lot17(self):
        raw=list_lots(self.store,self.venue_id,'Сырьё');done=list_lots(self.store,self.venue_id,'Готовая продукция')
        if not raw or not done:
            messagebox.showinfo('Связь партий','Создайте хотя бы одну партию сырья и готовой продукции.',parent=self);return
        self._dialog17('Сырьё → готовая продукция',[
            ('raw','Исходная партия сырья',True,'',[f"{x['id']} · {x['lot_code']}" for x in raw]),
            ('done','Партия готовой продукции',True,'',[f"{x['id']} · {x['lot_code']}" for x in done]),
            ('qty','Фактически использовано',True)],
            lambda v:(consume_lot(self.store,self.venue_id,int(v['done'].split(' · ')[0]),
                    int(v['raw'].split(' · ')[0]),v['qty'],self._actor16()),self.show_lots17()))

    def _show_lot_trace17(self,lot_id):
        t=self._with_error17(lambda:trace_lot(self.store,self.venue_id,lot_id))
        if not t:return
        msg=[f"Партия {t['lot']['lot_code']}: {t['lot']['name']}"]
        msg.extend(['\nИСПОЛЬЗОВАННОЕ СЫРЬЁ:']+[f"• {x['lot_code']}, {x['quantity']:g}" for x in t['inputs']])
        msg.extend(['\nПОЛУЧЕННЫЕ ПАРТИИ:']+[f"• {x['lot_code']}, {x['quantity']:g}" for x in t['outputs']])
        msg.extend(['\nОТМЕЧЕННЫЕ АЛЛЕРГЕНЫ:']+[f"• {x['allergen']}" for x in t['allergens']])
        if t['lot']['kind']=='Готовая продукция':msg.extend(['\nТРЕБУЕТ ПРОВЕРКИ:']+allergen_warnings(self.store,self.venue_id,lot_id))
        messagebox.showinfo('Прослеживаемость партии','\n'.join(msg)[:4500],parent=self)

    def _hold_lot17(self,lot):
        reason=simpledialog.askstring('Изменить статус партии','Укажите причину изменения статуса:',parent=self)
        if reason is None:return
        self._with_error17(lambda:set_lot_hold(self.store,self.venue_id,lot['id'],lot['status']!='Заблокирована',reason,self._actor16()),self.show_lots17)

    def show_allergens17(self):
        body=self._page17('Матрица аллергенов','Отмечайте только подтверждённую информацию о составе и возможном перекрёстном контакте')
        if body is None:return
        p=self._card17(body,'Аллергенный контроль партий')
        btn(p,'+ Отметить аллерген',self._allergen17,True).pack(anchor='w',pady=6)
        for lot in list_lots(self.store,self.venue_id)[:30]:
            from mature17_core import lot_allergens
            rows=lot_allergens(self.store,self.venue_id,lot['id'])
            self._info17(p,f"{lot['lot_code']} · {lot['name']} — "+(', '.join(x['allergen'] for x in rows) if rows else 'не оценено'),
                         SOFT if rows else WARN)
        self._info17(p,'Отсутствие отметки об аллергене НЕ означает отсутствие аллергена. Оценку выполняет ответственный специалист.',WARN)

    def _allergen17(self):
        lots=list_lots(self.store,self.venue_id)
        if not lots:messagebox.showwarning('Нет партий','Сначала зарегистрируйте партию.',parent=self);return
        self._dialog17('Оценить аллерген',[
            ('lot','Партия',True,'',[f"{x['id']} · {x['lot_code']}" for x in lots]),
            ('allergen','Аллерген',True,KNOWN_ALLERGENS[0],KNOWN_ALLERGENS),
            ('source','Основание (документ, рецептура, анализ)',True),
            ('assessor','Кто провёл оценку',True,self._actor16())],
            lambda v:(assign_allergen(self.store,self.venue_id,int(v['lot'].split(' · ')[0]),
                     v['allergen'],v['source'],v['assessor']),self.show_allergens17()))

    def show_forms17(self):
        body=self._page17('Конструктор журналов 4.0','Настраивайте типы, обязательные колонки и ответственного. Записи сохраняются только после проверки.')
        if body is None:return
        p=self._card17(body,'Ваши журналы')
        btn(p,'+ Создать журнал',self._new_form17,True).pack(anchor='w',pady=6)
        for f in list_forms(self.store,self.venue_id):
            row=tk.Frame(p,bg=CARD);row.pack(fill='x',pady=5)
            self._info17(row,f"#{f['id']} · {f['title']} · Полей: {len(f['fields'])} · Ответственный: {f['owner']}")
            buttons=tk.Frame(row,bg=CARD);buttons.pack(anchor='w',padx=8,pady=5)
            btn(buttons,'+ Запись',lambda x=f:self._new_entry17(x)).pack(side='left')
            btn(buttons,'Посмотреть записи',lambda x=f:self._show_entries17(x)).pack(side='left',padx=6)
            btn(buttons,'Экспорт Word',lambda x=f:self._export_form17(x)).pack(side='left')

    def _new_form17(self):
        win=tk.Toplevel(self);win.title('Создать журнал · MoOLVa 1.7');win.configure(bg=BG)
        win.geometry('760x650');win.minsize(620,480);win.grab_set();win.transient(self)
        head=tk.Frame(win,bg=BG);head.pack(fill='x',padx=20,pady=15)
        name=field(head,'Название журнала *');responsible=field(head,'Ответственный *');frequency=field(head,'Периодичность (необязательно)')
        text(head,'Колонки: имя, тип, обязательность, варианты выбора. Можно добавлять сколько нужно (до 40).',SOFT)
        cv=tk.Canvas(win,bg=BG,highlightthickness=0)
        sc=ttk.Scrollbar(win,orient='vertical',command=cv.yview);cv.configure(yscrollcommand=sc.set)
        sc.pack(side='right',fill='y');cv.pack(fill='both',expand=True)
        pane=tk.Frame(cv,bg=BG);cv.create_window((0,0),window=pane,anchor='nw')
        pane.bind('<Configure>',lambda e:cv.configure(scrollregion=cv.bbox('all')))
        rows=[]
        def add_col():
            frame=tk.Frame(pane,bg=PANEL);frame.pack(fill='x',padx=18,pady=5)
            nv=tk.StringVar();tv=tk.StringVar(value='text');rv=tk.BooleanVar(value=True);ov=tk.StringVar()
            tk.Entry(frame,textvariable=nv,width=22,bg=CARD,fg=INK,insertbackground=INK).pack(side='left',padx=4,pady=9)
            ttk.Combobox(frame,values=['text','date','number','choice'],width=9,state='readonly',textvariable=tv).pack(side='left',padx=4)
            tk.Checkbutton(frame,text='Обязательное',variable=rv,bg=PANEL,fg=SOFT,selectcolor=CARD,
                           activebackground=PANEL,activeforeground=INK).pack(side='left',padx=4)
            tk.Entry(frame,textvariable=ov,width=18,bg=CARD,fg=INK,insertbackground=INK).pack(side='left',padx=4)
            rows.append((frame,nv,tv,rv,ov))
        add_col()
        controls=tk.Frame(win,bg=BG);controls.pack(fill='x',padx=20,pady=12)
        error=tk.Label(controls,text='',bg=BG,fg='#F0717D',wraplength=710);error.pack(anchor='w')
        def save():
            fields=[]
            for frame,nv,tv,rv,ov in rows:
                if not nv.get().strip():error.configure(text='Заполните название каждой колонки.');nv.set('');return
                fields.append({'name':nv.get().strip(),'type':tv.get(),'required':rv.get(),
                               'options':[x.strip() for x in ov.get().split(';') if x.strip()]})
            try:create_form(self.store,self.venue_id,name.get(),fields,responsible.get(),frequency.get(),self._actor16())
            except ValueError as e:error.configure(text=str(e));return
            win.destroy();self.show_forms17()
        btn(controls,'+ Добавить колонку',add_col).pack(side='left')
        btn(controls,'Сохранить журнал',save,True).pack(side='right')
        win.wait_window()

    def _new_entry17(self,form):
        f=[]
        for item in form['fields']:
            choices=item['options'] if item['type']=='choice' else None
            f.append((item['name'],item['name'],item['required'],'',choices))
        f.append(('actor','Кто внёс запись',True,self._actor16()))
        self._dialog17('Запись · '+form['title'],f,lambda v:(write_form_entry(
            self.store,self.venue_id,form['id'],{item['name']:v[item['name']] for item in form['fields']},v['actor']),
            self.show_forms17()))

    def _show_entries17(self,form):
        entries=list_entries(self.store,self.venue_id,form['id'])
        txt='\n'.join('#'+str(r['id'])+' · '+r['recorded_at']+' · '+r['recorded_by']+' · '+str(r['values'])+
                      (' [АННУЛИРОВАНО]' if r['voided_at'] else '') for r in entries[:40])
        messagebox.showinfo('Фактические записи · '+form['title'],(txt or 'Записей пока нет')[:4000],parent=self)

    def _export_form17(self,form):
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.docx',filetypes=[('Word','*.docx')],
                                          title='Сохранить журнал Word')
        if path:self._with_error17(lambda:export_form_docx(self.store,self.venue_id,form['id'],path))

    def show_equipment17(self):
        body=self._page17('Сроки оборудования','Калибровка, поверка, обслуживание и документальное подтверждение выполнения')
        if body is None:return
        p=self._card17(body,'Контрольные сроки')
        btn(p,'+ Новый срок',self._equipment_dialog17,True).pack(anchor='w',pady=6)
        for item in list_equipment_events(self.store,self.venue_id):
            status='Выполнено' if item['completed_on'] else ('Просрочено' if item['due_on']<date.today().isoformat() else 'Запланировано')
            self._info17(p,f"#{item['id']} · {item['event']} · {item['equipment'] or 'Общее'} · {item['due_on']} · {status}")
            if not item['completed_on']:btn(p,'Подтвердить №'+str(item['id']),lambda i=item['id']:self._equipment_done17(i)).pack(anchor='w',pady=3)

    def _equipment_dialog17(self):
        assets=list_assets(self.store,self.venue_id)
        self._dialog17('Контроль поверки / обслуживания',[
            ('equipment','Оборудование',False,'',['']+[f"{x['id']} · {x['display_name']}" for x in assets]),
            ('event','Вид мероприятия',True),('due','Срок (ГГГГ-ММ-ДД)',True),
            ('responsible','Ответственный',True,self._actor16())],
            lambda v:(add_equipment_event(self.store,self.venue_id,v['event'],v['due'],v['responsible'],
                      int(v['equipment'].split(' · ')[0]) if v['equipment'] else None,self._actor16()),
                      self.show_equipment17()))

    def _equipment_done17(self,id):
        self._dialog17('Подтвердить выполненную поверку',[
            ('date','Дата выполнения',True,date.today().isoformat()),
            ('evidence','Фактическое подтверждение / документ',True)],
            lambda v:(complete_equipment_event(self.store,self.venue_id,id,v['date'],v['evidence'],self._actor16()),
                      self.show_equipment17()))

    def show_docs17(self):
        body=self._page17('Документы 3.0','Черновик → согласование → утверждение → ознакомление (отметка не заменяет электронную подпись)')
        if body is None:return
        p=self._card17(body,'Документы предприятия')
        btn(p,'+ Новый документ',self._new_doc17,True).pack(anchor='w',pady=5)
        for d in list_documents(self.store,self.venue_id):
            self._info17(p,f"#{d['id']} · Редакция {d['revision']} · {d['title']} · {d['state']}")
            controls=tk.Frame(p,bg=PANEL);controls.pack(anchor='w',pady=3)
            if d['state']=='Черновик':btn(controls,'На согласование',lambda x=d:self._doc_action17(x,'review')).pack(side='left')
            elif d['state']=='На согласовании':btn(controls,'Утвердить',lambda x=d:self._doc_action17(x,'approve')).pack(side='left')
            else:
                btn(controls,'Отметить ознакомление',lambda x=d:self._doc_ack17(x)).pack(side='left')
                btn(controls,'Новая редакция',lambda x=d:self._doc_revision17(x)).pack(side='left',padx=5)

    def _new_doc17(self):
        self._dialog17('Новый документ',[
            ('title','Название документа',True),('author','Разработчик',True,self._actor16()),
            ('content','Содержание',True,'',None,'multiline')],
            lambda v:(create_document(self.store,self.venue_id,v['title'],v['content'],v['author']),self.show_docs17()))

    def _doc_action17(self,doc,action):
        reason=simpledialog.askstring('Ответственное действие','Укажите причину новой редакции:' if action=='revise' else 'Ваши ФИО для записи события:',parent=self,
                                      initialvalue='' if action=='revise' else self._actor16())
        if reason is None:return
        self._with_error17(lambda:document_action(self.store,self.venue_id,doc['id'],action,
                           self._actor16() if action=='revise' else reason,reason if action=='revise' else ''),self.show_docs17)

    def _doc_revision17(self,doc):
        self._dialog17('Новая редакция документа',[
            ('reason','Причина изменения',True),('author','Разработчик новой редакции',True,self._actor16()),
            ('content','Новая редакция текста',True,doc['content'],None,'multiline')],
            lambda v:(revise_document(self.store,self.venue_id,doc['id'],v['content'],v['reason'],v['author']),
                      self.show_docs17()))

    def _doc_ack17(self,doc):
        person=simpledialog.askstring('Ознакомление','ФИО работника (не электронная подпись):',parent=self)
        if person is None:return
        self._with_error17(lambda:acknowledge_document(self.store,self.venue_id,doc['id'],person,self._actor16()),self.show_docs17)

    def show_incidents17(self):
        body=self._page17('Отклонения и партии','Связывайте реальные корректирующие действия с конкретными партиями продукции')
        if body is None:return
        p=self._card17(body,'Инциденты')
        btn(p,'Привязать партию к отклонению',self._incident_lot17,True).pack(anchor='w',pady=6)
        for capa in list_capa(self.store,self.venue_id):
            self._info17(p,f"#{capa['id']} · {capa['problem']} · {capa['status']}")
        btn(p,'Открыть центр корректирующих действий',self.show_capa16).pack(anchor='w',pady=7)

    def _incident_lot17(self):
        caps=list_capa(self.store,self.venue_id);lots=list_lots(self.store,self.venue_id)
        if not caps or not lots:messagebox.showwarning('Нет записей','Нужны зарегистрированные отклонения и партии.',parent=self);return
        self._dialog17('Партия, затронутая отклонением',[
            ('capa','Отклонение',True,'',[f"{x['id']} · {x['problem'][:35]}" for x in caps]),
            ('lot','Партия',True,'',[f"{x['id']} · {x['lot_code']}" for x in lots]),
            ('measures','Принятые меры',True,'',None,'multiline')],
            lambda v:(link_incident_lot(self.store,self.venue_id,int(v['capa'].split(' · ')[0]),
                       int(v['lot'].split(' · ')[0]),v['measures'],self._actor16()),self.show_incidents17()))

    def show_audits17(self):
        body=self._page17('Режим внутреннего аудитора','Фиксируйте критерий, наблюдение, серьёзность, ответственного и срок исправления')
        if body is None:return
        p=self._card17(body,'Аудиты и замечания')
        btn(p,'+ Внутренний аудит',self._new_audit17,True).pack(anchor='w',pady=6)
        btn(p,'+ Замечание',self._finding17).pack(anchor='w',pady=4)
        for a in list_audits(self.store,self.venue_id):self._info17(p,f"Аудит #{a['id']} · {a['subject']} · {a['held_on']} · {a['auditor']}")
        for f in list_findings(self.store,self.venue_id):self._info17(p,f"Замечание #{f['id']} · {f['severity']} · {f['observation']} · {f['owner']}",WARN)
        btn(p,'Сформировать комплект аудита 1.7',self._audit_export17,True).pack(anchor='w',pady=7)
        btn(p,'История проверок 1.6',self.show_audit16).pack(anchor='w',pady=5)

    def _audit_export17(self):
        path=filedialog.asksaveasfilename(parent=self,title='Экспорт аудита 1.7',
                           defaultextension='.zip',filetypes=[('ZIP-архив','*.zip')])
        if path:
            output=self._with_error17(lambda:audit_package17(self.store,self.venue_id,path))
            if output:messagebox.showinfo('Архив сформирован','Создан комплект фактических материалов: '+str(output),parent=self)

    def _new_audit17(self):
        self._dialog17('Зарегистрировать внутренний аудит',[
            ('subject','Тема',True),('auditor','Аудитор',True,self._actor16()),('date','Дата',True,date.today().isoformat())],
            lambda v:(create_audit(self.store,self.venue_id,v['subject'],v['auditor'],v['date']),self.show_audits17()))

    def _finding17(self):
        audits=list_audits(self.store,self.venue_id)
        if not audits:messagebox.showinfo('Нет аудита','Сначала зарегистрируйте внутренний аудит.',parent=self);return
        self._dialog17('Новое замечание',[
            ('audit','Аудит',True,'',[f"{x['id']} · {x['subject']}" for x in audits]),
            ('requirement','Проверяемый критерий',True),('observation','Фактическое наблюдение',True),
            ('severity','Серьёзность',True,'Замечание',['Замечание','Несоответствие','Критичное']),
            ('owner','Ответственный',True),('due','Срок устранения (ГГГГ-ММ-ДД)',False)],
            lambda v:(add_finding(self.store,self.venue_id,int(v['audit'].split(' · ')[0]),
                     v['requirement'],v['observation'],v['severity'],v['owner'],v['due']),self.show_audits17()))

    def show_search17(self):
        body=self._page17('Глобальный поиск 2.0','Поиск по всем основным объектам выбранного предприятия')
        if body is None:return
        p=self._card17(body,'Найти информацию')
        q=field(p,'Фраза поиска *')
        out=tk.Frame(p,bg=PANEL);out.pack(fill='x')
        def find():
            for x in out.winfo_children():x.destroy()
            result=self._with_error17(lambda:global_search17(self.store,self.venue_id,q.get()))
            if result is None:return
            for x in result[:35]:self._info17(out,f"{x['type']} #{x['id']} · {x['title']}")
            if not result:self._info17(out,'Совпадений не найдено')
        btn(p,'Поиск',find,True).pack(anchor='w',pady=8)

    def show_quality17(self):
        body=self._page17('Центр качества','Проверка целостности базы, истории событий, документов и незавершённых действий')
        if body is None:return
        p=self._card17(body,'Диагностика без изменения данных')
        result=self._with_error17(lambda:quality_diagnostics(self.store,self.venue_id))
        if not result:return
        checks=[('Целостность SQLite',result['sqlite_ok']),('Связи базы',result['foreign_keys_ok']),
                ('История действий',result['trace_ok'])]
        for name,ok in checks:self._info17(p,('✓' if ok else 'ВНИМАНИЕ')+'  '+name,GREEN if ok else WARN)
        self._info17(p,f"Партий: {result['lots']} · Неутверждённых документов: {result['unsigned_documents']} · Незакрытых замечаний: {result['unresolved_findings']}")
        btn(p,'Ежедневные резервные копии и настройки',self.show_settings15).pack(anchor='w',pady=7)

    def show_helper17(self):
        body=self._page17('Помощник ХАССП','Локальные справочные подсказки без вымышленной проверки нормативов')
        if body is None:return
        p=self._card17(body,'Задайте вопрос')
        q=field(p,'Например: как заполнить паспорт партии?')
        answer=tk.Label(p,text='',bg=PANEL,fg=INK,wraplength=790,justify='left',font=(FONT,11))
        answer.pack(anchor='w',pady=12)
        btn(p,'Получить подсказку',lambda:answer.configure(text=local_assistant17(q.get())),True).pack(anchor='w')
