"""Safety / migration regression suite for MoOLVa HACCP Easy 1.7."""
import json
import sqlite3
import unittest
from contextlib import closing
from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
from docx import Document
from easy_core import init_store,make_venue
from mature16_core import migrate16,create_capa
from mature17_core import (
  migrate17,validate_venue_fields,create_supplier,create_lot,list_lots,consume_lot,trace_lot,set_lot_hold,
  assign_allergen,allergen_warnings,create_form,list_forms,validate_entry,write_form_entry,list_entries,void_entry,
  export_form_docx,add_equipment_event,complete_equipment_event,list_equipment_events,
  create_document,document_action,acknowledge_document,list_documents,revise_document,document_history,audit_package17,revise_document,document_history,audit_package17,
  link_incident_lot,create_audit,add_finding,list_findings,global_search17,
  quality_diagnostics,local_assistant17,upgrade_safety_backup,mark_upgrade_success)

TODAY=date.today().isoformat()

class Mature17Tests(unittest.TestCase):
    def setUp(self):
        tmp=TemporaryDirectory();self.addCleanup(tmp.cleanup)
        self.tmp=Path(tmp.name)
        self.store=init_store(self.tmp/'db.sqlite3')
        self.vid=make_venue(self.store);self.other=make_venue(self.store)
        migrate16(self.store);migrate17(self.store)

    def vendor(self):return create_supplier(self.store,self.vid,'Мельница',actor='Технолог')

    def lot(self):
        return create_lot(self.store,self.vid,'RAW-01','Сырьё','Мука',TODAY,10,'кг','Технолог',self.vendor())

    def test_existing_v14_15_16_data_not_lost(self):
        from smart15_core import migrate15,save_draft,load_draft
        migrate15(self.store)
        self.store.add_record(self.vid,'sample',{'observed':'Реальная запись'})
        save_draft(self.store,self.vid,'journal','sample',{'c1':'Черновик'})
        from mature16_core import add_schedule, record_check
        sid=add_schedule(self.store,self.vid,'Тест проверки',min_value=1,max_value=9)
        record_check(self.store,self.vid,sid,5,actor='Технолог')
        for _ in range(3):migrate17(self.store)
        self.assertEqual(self.store.list_records(self.vid,'sample')[0]['data']['observed'],'Реальная запись')
        self.assertEqual(load_draft(self.store,self.vid,'journal','sample')['c1'],'Черновик')
        with self.store.connect() as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM easy16_checks WHERE venue_id=?',(self.vid,)).fetchone()[0],1)
            self.assertEqual(db.execute('PRAGMA foreign_key_check').fetchall(),[])

    def test_pre_upgrade_snapshot_and_marker(self):
        self.store.add_record(self.vid,'legacy',{'data':'kept'})
        backup=upgrade_safety_backup(self.store)
        self.assertTrue(backup.is_file())
        with closing(sqlite3.connect(backup)) as db:
            self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
            self.assertEqual(db.execute('SELECT COUNT(*) FROM journal_records').fetchone()[0],1)
        mark_upgrade_success(self.store,backup)
        self.assertIsNone(upgrade_safety_backup(self.store))

    def test_enterprise_mandatory_fields(self):
        with self.assertRaises(ValueError):validate_venue_fields({'venue_name':'Новое заведение'})
        self.assertTrue(validate_venue_fields({'legal_name':'ООО Ромашка','venue_name':'Столовая 1',
                                                'address':'ул. Ленина, 1','responsible':'Специалист'}))

    def test_supplier_mandatory_and_company_isolation(self):
        with self.assertRaises(ValueError):create_supplier(self.store,self.vid,'   ')
        s=self.vendor()
        with self.assertRaises(ValueError):create_lot(self.store,self.other,'X','Сырьё','мука',TODAY,5,'кг','Н',s)
        self.assertEqual(len(list_lots(self.store,self.other)),0)

    def test_lot_requires_all_fields_and_positive_quantity(self):
        s=self.vendor()
        for code,amount in [('X',0),('Y','nan'),('Z','inf'),('A',-7)]:
            with self.subTest(code=code),self.assertRaises(ValueError):create_lot(self.store,self.vid,code,'Сырьё','мука',TODAY,amount,'кг','T',s)
        with self.assertRaises(ValueError):create_lot(self.store,self.vid,'B','Сырьё','мука',TODAY,1,'кг','T')
        with self.assertRaises(ValueError):create_lot(self.store,self.vid,'C','Сырьё','мука',TODAY,1,'кг','T',s,'2000-01-01')
        with self.assertRaises(ValueError):create_lot(self.store,self.vid,'D','Сырьё','',TODAY,1,'кг','T',s)

    def test_ledger_forward_and_backward_trace_and_consumption(self):
        raw=self.lot()
        output=create_lot(self.store,self.vid,'FIN-01','Готовая продукция','Хлеб',TODAY,5,'кг','Пекарь')
        consume_lot(self.store,self.vid,output,raw,4,'Пекарь')
        self.assertEqual(trace_lot(self.store,self.vid,raw)['outputs'][0]['lot_code'],'FIN-01')
        self.assertEqual(trace_lot(self.store,self.vid,output)['inputs'][0]['lot_code'],'RAW-01')
        with self.assertRaises(ValueError):consume_lot(self.store,self.vid,output,raw,7,'Пекарь')
        with self.assertRaises(ValueError):consume_lot(self.store,self.other,output,raw,1,'Пекарь')
        set_lot_hold(self.store,self.vid,raw,True,'На проверке','Специалист')
        with self.assertRaises(ValueError):consume_lot(self.store,self.vid,output,raw,1,'Пекарь')

    def test_allergens_are_warnings_not_fake_certification(self):
        raw=self.lot();output=create_lot(self.store,self.vid,'OUT','Готовая продукция','Булка',TODAY,2,'кг','Пекарь')
        consume_lot(self.store,self.vid,output,raw,1,'Пекарь')
        self.assertIn('Не оценены',allergen_warnings(self.store,self.vid,output)[0])
        assign_allergen(self.store,self.vid,raw,'Злаки с глютеном','Декларация 111','Технолог')
        self.assertIn('Злаки с глютеном',allergen_warnings(self.store,self.vid,output)[0])
        with self.assertRaises(ValueError):assign_allergen(self.store,self.vid,raw,'Неизвестно','Документ','Технолог')

    def test_required_journal_fields_and_choice_date_number(self):
        schema=[{'name':'Дата','type':'date','required':True},
                {'name':'Показание','type':'number','required':True},
                {'name':'Результат','type':'choice','required':True,'options':['Допущено','Отклонено']}]
        fid=create_form(self.store,self.vid,'Мой журнал',schema,'Технолог')
        with self.assertRaises(ValueError):write_form_entry(self.store,self.vid,fid,{'Дата':TODAY},'Технолог')
        with self.assertRaises(ValueError):write_form_entry(self.store,self.vid,fid,{'Дата':'9999','Показание':'3','Результат':'Допущено'},'Технолог')
        with self.assertRaises(ValueError):write_form_entry(self.store,self.vid,fid,{'Дата':TODAY,'Показание':'nan','Результат':'Допущено'},'Технолог')
        with self.assertRaises(ValueError):write_form_entry(self.store,self.vid,fid,{'Дата':TODAY,'Показание':'3','Результат':'Всё хорошо'},'Технолог')
        rid=write_form_entry(self.store,self.vid,fid,{'Дата':TODAY,'Показание':'3,5','Результат':'Допущено'},'Технолог')
        self.assertEqual(list_entries(self.store,self.vid,fid)[0]['values']['Показание'],'3.5')
        self.assertGreater(rid,0)
        with self.assertRaises(ValueError):create_form(self.store,self.vid,'No required',[{'name':'Поле','type':'text'}],'Технолог')

    def test_journal_cannot_save_to_other_enterprise_and_void_is_audited(self):
        fid=create_form(self.store,self.vid,'Журнал',[{'name':'Показание','required':True}],'Технолог')
        with self.assertRaises(ValueError):write_form_entry(self.store,self.other,fid,{'Показание':'5'},'Иванов')
        rid=write_form_entry(self.store,self.vid,fid,{'Показание':'5'},'Иванов')
        with self.assertRaises(ValueError):void_entry(self.store,self.vid,rid,'x','Иванов')
        void_entry(self.store,self.vid,rid,'Исправить ввод','Иванов')
        self.assertTrue(list_entries(self.store,self.vid,fid)[0]['voided_at'])
        self.assertTrue(quality_diagnostics(self.store,self.vid)['trace_ok'])

    def test_word_export_is_valid_and_uses_original_entries(self):
        fid=create_form(self.store,self.vid,'Журнал мойки',[{'name':'Объект','required':True}],'Технолог')
        write_form_entry(self.store,self.vid,fid,{'Объект':'Цех 7'},'Мария')
        target=self.tmp/'journal.docx';export_form_docx(self.store,self.vid,fid,target)
        doc=Document(target)
        self.assertIn('Журнал мойки',doc.paragraphs[0].text)
        self.assertIn('Цех 7',doc.tables[0].rows[1].cells[2].text)
        with self.assertRaises(FileExistsError):export_form_docx(self.store,self.vid,fid,target)

    def test_audit_package17_has_actual_batches_and_docs(self):
        self.lot()
        file=self.tmp/'audit17.zip'
        audit_package17(self.store,self.vid,file)
        with __import__('zipfile').ZipFile(file) as z:
            self.assertIn('RAW-01',z.read('01_Партии.csv').decode('utf-8-sig'))
            self.assertIn('07_Внутренняя_проверка.docx',z.namelist())

    def test_audit_package17_has_actual_batches_and_docs(self):
        self.lot()
        file=self.tmp/'audit17.zip'
        audit_package17(self.store,self.vid,file)
        with __import__('zipfile').ZipFile(file) as z:
            self.assertIn('RAW-01',z.read('01_Партии.csv').decode('utf-8-sig'))
            self.assertIn('07_Внутренняя_проверка.docx',z.namelist())

    def test_equipment_deadline_and_completion_requires_evidence(self):
        event=add_equipment_event(self.store,self.vid,'Поверка',TODAY,'Технолог')
        with self.assertRaises(ValueError):complete_equipment_event(self.store,self.vid,event,TODAY,'','Технолог')
        complete_equipment_event(self.store,self.vid,event,TODAY,'Акт №123','Технолог')
        self.assertEqual(list_equipment_events(self.store,self.vid)[0]['evidence'],'Акт №123')

    def test_document_lifecycle_and_acknowledgement_not_signature(self):
        doc=create_document(self.store,self.vid,'План','Текст','Технолог')
        with self.assertRaises(ValueError):document_action(self.store,self.vid,doc,'approve','Директор')
        document_action(self.store,self.vid,doc,'review','Руководитель')
        document_action(self.store,self.vid,doc,'approve','Директор')
        self.assertEqual(list_documents(self.store,self.vid)[0]['state'],'Утверждён')
        acknowledge_document(self.store,self.vid,doc,'Иванов','Директор')
        with self.assertRaises(ValueError):document_action(self.store,self.vid,doc,'revise','Директор')
        revise_document(self.store,self.vid,doc,'Обновлённый текст','Изменено оборудование','Директор')
        self.assertEqual(document_history(self.store,self.vid,doc)[0]['content'],'Текст')
        self.assertEqual(list_documents(self.store,self.vid)[0]['revision'],2)

    def test_capa_batch_link_and_isolation(self):
        lot=self.lot();capa=create_capa(self.store,self.vid,'Отклонение',actor='Технолог')
        with self.assertRaises(ValueError):link_incident_lot(self.store,self.other,capa,lot,'Проверить','Технолог')
        link_incident_lot(self.store,self.vid,capa,lot,'Изолировали, оценили','Технолог')
        with self.store.connect() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM easy17_incident_lots WHERE venue_id=?',(self.vid,)).fetchone()[0],1)

    def test_auditor_fields_and_findings(self):
        audit=create_audit(self.store,self.vid,'Ежегодная проверка','Мария',TODAY)
        with self.assertRaises(ValueError):add_finding(self.store,self.vid,audit,'Приёмка','','Критичное','Иванов')
        fid=add_finding(self.store,self.vid,audit,'Температура','Превышение','Критичное','Иванов')
        self.assertEqual(list_findings(self.store,self.vid)[0]['id'],fid)
        with self.assertRaises(ValueError):add_finding(self.store,self.other,audit,'Температура','Превышение','Критичное','Иванов')

    def test_search_and_local_helper(self):
        self.lot()
        self.assertTrue(any(x['type']=='Партия' for x in global_search17(self.store,self.vid,'RAW-01')))
        self.assertEqual(global_search17(self.store,self.other,'RAW-01'),[])
        self.assertIn('обязательные',local_assistant17('журнал'))

    def test_quality_detects_intact_and_damaged_audit(self):
        self.lot();self.assertTrue(quality_diagnostics(self.store,self.vid)['trace_ok'])
        with self.store.connect() as db:
            db.execute('DROP TRIGGER easy16_trace_no_update')
            db.execute('UPDATE easy16_trace SET actor="Подмена" WHERE venue_id=?',(self.vid,))
        self.assertFalse(quality_diagnostics(self.store,self.vid)['trace_ok'])

if __name__=='__main__':unittest.main()
