"""Regression checks for roster changes and installer versioning."""
from pathlib import Path
import tempfile, unittest
from easy_core import init_store, make_venue, selected, apply_staff_to_documents
from staff_store import save_employee, get_assignments, list_acknowledgements

ROOT=Path(__file__).resolve().parents[1]

class SignerRegression101(unittest.TestCase):
    def setUp(self):
        d=tempfile.TemporaryDirectory();self.addCleanup(d.cleanup)
        self.store=init_store(Path(d.name)/'db.sqlite')
        self.venue=make_venue(self.store)
        self.codes=[t.code for t in selected(self.store,self.venue)]
        self.a=save_employee(self.store,self.venue,'Петрова Анна Игоревна',position_name='Повар')
        self.b=save_employee(self.store,self.venue,'Кузнецов Иван Павлович',position_name='Повар')

    def test_all_documents_receive_roster(self):
        apply_staff_to_documents(self.store,self.venue,self.codes,self.a,None,(self.a,self.b))
        for code in self.codes:
            key='journal:'+code
            self.assertEqual({x['id'] for x in list_acknowledgements(self.store,self.venue,key)}, {self.a,self.b})
            self.assertEqual(get_assignments(self.store,self.venue,key)['people']['responsible']['id'],self.a)

    def test_roster_remove_one_person(self):
        apply_staff_to_documents(self.store,self.venue,self.codes,self.a,self.b,(self.a,self.b))
        apply_staff_to_documents(self.store,self.venue,self.codes,self.a,self.b,(self.b,))
        for code in self.codes:
            self.assertEqual([x['id'] for x in list_acknowledgements(self.store,self.venue,'journal:'+code)], [self.b])

    def test_no_signature_or_date_auto_recorded(self):
        apply_staff_to_documents(self.store,self.venue,self.codes,None,None,(self.a,))
        key='journal:'+self.codes[0]
        with self.store.connect() as db:
            columns=[row['name'] for row in db.execute('PRAGMA table_info(document_acknowledgements)')]
        self.assertNotIn('signature',columns)
        self.assertNotIn('signed_at',columns)
        self.assertEqual(len(list_acknowledgements(self.store,self.venue,key)),1)

    def test_installer_upgrade_sentinel(self):
        legacy_installer=ROOT/'installer'/'main.go'
        if legacy_installer.is_file():
            src=legacy_installer.read_text(encoding='utf-8')
            self.assertIn('releaseVersion = "1.3.0"',src)
            self.assertIn('strings.TrimSpace(string(versionBytes)) == releaseVersion && appSelfTest(root)',src)
        self.assertEqual((ROOT/'.moolva_easy_version').read_text().strip(),'1.7.0')

    def test_empty_screen_supports_add_button(self):
        src=(ROOT/'easy_app.py').read_text(encoding='utf-8')
        self.assertIn("lambda:self.employee_dialog(for_signer=True)",src)
        self.assertIn('def _roles_snapshot(self)',src)
        self.assertIn('draft[\'ack_ids\'].add(new_id)',src)

if __name__=='__main__':unittest.main()
