"""Smart Workspace 1.5: approachable actions above original full enterprise screens."""
from __future__ import annotations
from datetime import date
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog,filedialog
from catalog import FLAGS
from easy_core import flags_choice,selected,recommended,venue_update
from enterprise14_core import live_snapshot,add_action
from staff_store import ROLES,list_employees,get_assignments,save_assignments,list_acknowledgements,save_acknowledgements
from exports import columns_for
from flowchart_core import list_diagrams
from backup15 import create_database_backup, restore_database_backup
from smart15_core import (HELP,FLOW_STARTERS,load_draft,save_draft,clear_draft,count_drafts,
    get_setting,set_setting,copy_starter,stable_fields,active_reminders,
    list_exports,archive_export,restore_export_copy,restore_void_record)

BG='#111824';NAV='#142031';PANEL='#1A2739';CARD='#22334A';ENTRY='#253B52';EDGE='#31445C'
INK='#F1F6FD';SOFT='#AFBDD0';MUTED='#8297AE';LIME='#D5E744';CYAN='#29BFD1';GREEN='#34C9AB';WARN='#FFBD5C';RED='#F0717D'
FONT='Segoe UI'


def lbl(p,t,size=10,color=INK,bold=False,**kw):
    return tk.Label(p,text=t,bg=p.cget('bg'),fg=color,font=(FONT,size,'bold' if bold else 'normal'),justify='left',anchor='w',**kw)


def btn(p,t,fn,accent=False):
    return tk.Button(p,text=t,command=fn,cursor='hand2',bg=LIME if accent else CARD,fg=NAV if accent else INK,
        activebackground=CYAN,relief='flat',bd=0,padx=15,pady=10,font=(FONT,10,'bold'))


def frame(p,bg=PANEL,pad=18):
    outer=tk.Frame(p,bg=bg,highlightthickness=1,highlightbackground=EDGE)
    inner=tk.Frame(outer,bg=bg)
    inner.pack(fill='both',expand=True,padx=pad,pady=pad)
    return outer,inner


class Smart15Mixin:
    def _mode15(self):
        return get_setting(self.store,'work_mode','simple')

    def _apply_nav15(self):
        simple=self._mode15()=='simple'
        invisible={'enterprises','haccp','analytics'}
        # Keep useful capabilities accessible from the workspace even in simple mode.
        for key,b in self.primary_buttons.items():
            row=b.master
            if simple and key in invisible:row.pack_forget()
            elif not row.winfo_manager():row.pack(fill='x',padx=7,pady=1)
        self.heading.configure(text=self.heading.cget('text'))

    def _work15_start(self,subtitle='Ваши ежедневные действия — без лишних переходов'):
        self._mode='workspace';self._activate_nav('dashboard');self._clear();self._update_metrics()
        self.eyebrow.configure(text='MOOLVA · SMART WORKSPACE 1.5')
        self.heading.configure(text='Мой рабочий день')
        self.subhead.configure(text=subtitle)
        self._set_footer('←  Предприятия',self.show_enterprises_center,'Локально · черновики сохраняются на этом ПК',
                         'Заполнить журнал →',self.show_quick_journals15 if self.venue_id else self.new_venue,0)

    def _header15(self,p,title,sub=''):
        lbl(p,title,15,INK,True).pack(anchor='w')
        if sub:lbl(p,sub,9,SOFT,wraplength=850).pack(anchor='w',pady=(3,12))

    def _action15(self,p,title,subtitle,go,primary=False):
        b=tk.Frame(p,bg=CARD,highlightthickness=1,highlightbackground=EDGE)
        b.pack(fill='x',pady=5)
        left=tk.Frame(b,bg=CARD);left.pack(side='left',fill='both',expand=True,padx=16,pady=12)
        lbl(left,title,12,LIME if primary else INK,True).pack(anchor='w')
        lbl(left,subtitle,9,SOFT,wraplength=690).pack(anchor='w',pady=(4,0))
        btn(b,'Начать →',go,primary).pack(side='right',padx=12)

    def show_workspace15(self):
        self._work15_start()
        top_outer,top=frame(self.content);top_outer.pack(fill='x',pady=(3,13))
        if not self.venue_id:
            self._header15(top,'Начните с предприятия','Сохранённые предприятия будут доступны при следующем запуске.')
            btn(top,'+ Создать предприятие',self.new_venue,True).pack(anchor='w',pady=8)
            for v in self.store.list_venues()[-10:]:
                b=tk.Frame(top,bg=CARD);b.pack(fill='x',pady=4)
                lbl(b,v['venue_name'],11,INK,True).pack(side='left',padx=12,pady=10)
                btn(b,'Открыть',lambda vid=v['id']:self.open_venue(vid)).pack(side='right',padx=7,pady=3)
            return
        v=self.store.get_venue(self.venue_id)
        s=live_snapshot(self.store,self.venue_id)
        self._header15(top,v['venue_name'],'Только данные выбранного предприятия. Заполненность — не заключение о соответствии ХАССП.')
        stats=tk.Frame(top,bg=PANEL);stats.pack(fill='x',pady=(6,7))
        for num,name in [(str(s['completion'])+'%','заполнено'),(str(s['journals']),'журналов'),
                         (str(s['employees']),'сотрудников'),(str(len(s['issues'])),'вопросов')]:
            f=tk.Frame(stats,bg=CARD);f.pack(side='left',fill='x',expand=True,padx=(0,7))
            lbl(f,num,20,CYAN,True).pack(anchor='w',padx=13,pady=(9,0))
            lbl(f,name,9,SOFT).pack(anchor='w',padx=13,pady=(0,10))
        work_outer,work=frame(self.content);work_outer.pack(fill='x',pady=(0,12))
        self._header15(work,'Что хотите сделать?','Три действия для большинства повседневных задач')
        self._action15(work,'00  Мои проверки на сегодня','Открыть реальные плановые проверки, внести факт и обработать отклонения',self.show_day16,True)
        self._action15(work,'01  Заполнить журнал','Данные за дату/смену, черновики и подписанты в одном окне',self.show_quick_journals15,True)
        self._action15(work,'02  Создать комплект','Ответить на вопросы, подобрать формы, проверить и сохранить',self.show_assistant15)
        self._action15(work,'03  Блок-схемы производства','Открыть существующую схему или начать с готовой заготовки',self.show_flow_starters15)
        last=get_setting(self.store,'last_work15',{})
        if last.get('venue_id')==self.venue_id and last.get('code'):
            self._action15(work,'↻  Продолжить работу','Последний журнал: '+last.get('title',''),
                           lambda code=last['code']:self.show_quick_journals15(code))
        review_outer,review=frame(self.content);review_outer.pack(fill='x',pady=(0,12))
        due=active_reminders(self.store,self.venue_id)
        self._header15(review,'Что требует внимания',f'Напоминаний по срокам: {len(due)} · структурных вопросов: {len(s["issues"])}')
        for a in due[:3]:
            lbl(review,a['urgency']+' · '+a['title'],10,WARN).pack(anchor='w',pady=3)
        for issue in s['issues'][:3]:
            lbl(review,'• '+issue['name']+' — '+issue['text'],9,SOFT,wraplength=800).pack(anchor='w',pady=3)
        if not due and not s['issues']:lbl(review,'Сейчас нет вопросов по автоматическим проверкам.',10,GREEN).pack(anchor='w')
        row=tk.Frame(review,bg=PANEL);row.pack(anchor='w',pady=8)
        btn(row,'Все задачи',self.show_alert_center).pack(side='left')
        btn(row,'Создать напоминание',self._new_action15).pack(side='left',padx=8)
        drafts=count_drafts(self.store,self.venue_id)
        lbl(review,f'Черновиков на этом компьютере: {drafts}',9,MUTED).pack(anchor='w',pady=(5,0))

    def show_quick_journals15(self,code=None):
        if not self._need_venue():return
        self._mode='quick_journals';self._activate_nav('journals');self._clear();self._update_metrics()
        self.eyebrow.configure(text='БЫСТРАЯ РАБОТА С ЖУРНАЛАМИ')
        self.heading.configure(text='Заполнить журнал')
        self.subhead.configure(text='Выберите журнал → заполните запись → проверьте → сохраните')
        self._set_footer('← Мой день',self.show_workspace15,'Измерения и подписи — только фактические',
                         'Настроить подбор →',self.show_assistant15,0)
        docs=selected(self.store,self.venue_id)
        if not docs:
            p,body=frame(self.content);p.pack(fill='x')
            lbl(body,'Для предприятия пока не выбраны журналы.',11,SOFT).pack(anchor='w',pady=5)
            btn(body,'Выбрать по вопросам',self.show_assistant15,True).pack(anchor='w')
            return
        lookup={t.code:t for t in docs}
        if code not in lookup:code=docs[0].code
        t=lookup[code]
        set_setting(self.store,'last_work15',{'venue_id':self.venue_id,'code':code,'title':t.title})
        p,body=frame(self.content);p.pack(fill='x',pady=(0,12))
        self._header15(body,'Журнал','Выберите форму — остальные разделы останутся доступны в левом меню')
        sel=tk.StringVar(value=code)
        cb=ttk.Combobox(body,values=[f'{i.title}   [{i.code}]' for i in docs],state='readonly',width=81)
        cb.current(list(lookup).index(code));cb.pack(fill='x',ipady=5,pady=(0,10))
        cb.bind('<<ComboboxSelected>>',lambda e:self.show_quick_journals15(docs[cb.current()].code))
        lbl(body,'Черновик сохраняется во время ввода и не является записью журнала.',9,SOFT).pack(anchor='w')
        row=tk.Frame(body,bg=PANEL);row.pack(anchor='w',pady=(11,0))
        btn(row,'+ Новая запись',lambda:self._record15(t),True).pack(side='left')
        btn(row,'Подписанты',lambda:self._signers15(t)).pack(side='left',padx=8)
        btn(row,'Предпросмотр',lambda:self._preview15(t)).pack(side='left')
        btn(row,'? Справка',lambda:self._help15('Журнал')).pack(side='left',padx=8)
        self._quick_code15=code
        q,inside=frame(self.content);q.pack(fill='x')
        self._header15(inside,'Фактические записи','Отменённые записи сохраняются в истории и могут быть восстановлены с причиной.')
        self._records_tree15=ttk.Treeview(inside,columns=('status','at','value'),show='headings',height=8)
        for name,title,width in (('status','Состояние',115),('at','Создано',155),('value','Данные',610)):
            self._records_tree15.heading(name,text=title)
            self._records_tree15.column(name,width=width,stretch=(name=='value'))
        self._records_tree15.pack(fill='x')
        cols=dict(columns_for(self.store,self.venue_id,t))
        records=self.store.list_records(self.venue_id,code)
        self._records15={r['id']:r for r in records}
        for rec in reversed(records[-50:]):
            desc='; '.join(cols.get(k,k)+': '+str(v) for k,v in rec['data'].items() if str(v).strip())[:230]
            self._records_tree15.insert('','end',iid=str(rec['id']),values=('Отменена' if rec['voided_at'] else 'Сохранена',
                    rec['created_at'][:16].replace('T',' '),desc))
        lbl(inside,f'История записей: {len(records)} · черновик: {"есть" if load_draft(self.store,self.venue_id,"journal",code) else "нет"}',
            9,MUTED).pack(anchor='w',pady=9)
        footer=tk.Frame(inside,bg=PANEL);footer.pack(anchor='w')
        btn(footer,'Аннулировать с причиной',self._void15).pack(side='left')
        btn(footer,'Восстановить с причиной',self._restore15).pack(side='left',padx=9)
        btn(footer,'Параметры журнала',lambda:self._open_roles_for(code)).pack(side='left')

    def _selected_record15(self):
        selected_id=self._records_tree15.selection()
        return self._records15.get(int(selected_id[0])) if selected_id else None

    def _void15(self):
        rec=self._selected_record15()
        if not rec:return messagebox.showinfo('Запись','Сначала выберите запись.',parent=self)
        why=simpledialog.askstring('Аннулирование','Причина аннулирования (фиксируется в истории):',parent=self)
        if why is None:return
        try:self.store.void_record(self.venue_id,rec['id'],why);self.show_quick_journals15(self._quick_code15)
        except Exception as exc:messagebox.showerror('Ошибка',str(exc),parent=self)

    def _restore15(self):
        rec=self._selected_record15()
        if not rec:return messagebox.showinfo('Запись','Сначала выберите запись.',parent=self)
        why=simpledialog.askstring('Восстановление','Причина восстановления (фиксируется в истории):',parent=self)
        if why is None:return
        try:restore_void_record(self.store,self.venue_id,rec['id'],why);self.show_quick_journals15(self._quick_code15)
        except Exception as exc:messagebox.showerror('Ошибка',str(exc),parent=self)

    def _record15(self,t):
        top=tk.Toplevel(self);top.title('Запись · '+t.title);top.configure(bg=BG)
        top.geometry('860x750');top.minsize(600,500);top.transient(self);top.grab_set()
        lbl(top,'Новая запись · '+t.title,15,INK,True,wraplength=790).pack(anchor='w',padx=22,pady=(16,6))
        lbl(top,'Черновик сохраняется автоматически. Для фиксации факта нажмите «Сохранить запись».',9,SOFT,
            wraplength=790).pack(anchor='w',padx=22)
        cv=tk.Canvas(top,bg=BG,highlightthickness=0);scroll=ttk.Scrollbar(top,command=cv.yview)
        cv.configure(yscrollcommand=scroll.set);scroll.pack(side='right',fill='y');cv.pack(fill='both',expand=True,padx=20,pady=9)
        ins=tk.Frame(cv,bg=BG);win=cv.create_window((0,0),window=ins,anchor='nw')
        ins.bind('<Configure>',lambda e:cv.configure(scrollregion=cv.bbox('all')))
        cv.bind('<Configure>',lambda e:cv.itemconfigure(win,width=e.width))
        cols=columns_for(self.store,self.venue_id,t)
        from mature17_core import legacy_required_columns
        required17={key for key,_ in legacy_required_columns(cols)}
        draft=load_draft(self.store,self.venue_id,'journal',t.code)
        vals={};timer=[None];saving=[False]
        status=lbl(top,'Готово к вводу',9,CYAN);status.pack(anchor='w',padx=22)
        def payload():return {k:v.get() for k,v in vals.items() if v.get().strip()}
        def flush():
            timer[0]=None
            if saving[0] or not top.winfo_exists():return
            try:
                if payload():save_draft(self.store,self.venue_id,'journal',t.code,payload());status.configure(text='Черновик сохранён локально')
                else:clear_draft(self.store,self.venue_id,'journal',t.code);status.configure(text='Поля пусты')
            except Exception as exc:status.configure(text='Ошибка черновика: '+str(exc),fg=RED)
        def on_change(*_):
            if saving[0]:return
            if timer[0] is not None:top.after_cancel(timer[0])
            timer[0]=top.after(800,flush)
            status.configure(text='Сохранение черновика…')
        for key,title in cols:
            lbl(ins,title+(' *' if key in required17 else ''),10,SOFT,wraplength=750).pack(anchor='w',pady=(10,3))
            var=tk.StringVar(value=draft.get(key,'') or '')
            vals[key]=var
            input_=tk.Entry(ins,textvariable=var,bg=ENTRY,fg=INK,insertbackground=INK,relief='flat',font=(FONT,11))
            input_.pack(fill='x',ipady=8)
            var.trace_add('write',on_change)
        actions=tk.Frame(top,bg=BG);actions.pack(fill='x',padx=21,pady=12)
        def fill_safe():
            records=self.store.list_records(self.venue_id,t.code,include_voided=False)
            if not records:return messagebox.showinfo('Нет записи','Предыдущих действующих записей нет.',parent=top)
            carry=stable_fields(cols,records[-1]['data'])
            if not carry:return messagebox.showinfo('Нет постоянных реквизитов','Для этого журнала нечего безопасно повторить.',parent=top)
            if not messagebox.askyesno('Повторить реквизиты',
                    'Перенести только постоянные обозначения из предыдущей записи?\nИзмерения, даты, результаты и подписи не копируются.',parent=top):return
            for key,val in carry.items():
                if not vals[key].get().strip():vals[key].set(val)
        btn(actions,'Повторить реквизиты',fill_safe).pack(side='left')
        def close():
            if timer[0] is not None:top.after_cancel(timer[0])
            flush();top.destroy()
            self.show_quick_journals15(t.code)
        def commit():
            saving[0]=True
            if timer[0] is not None:top.after_cancel(timer[0])
            try:
                from mature17_core import validate_legacy_entry
                validate_legacy_entry(cols,payload())
                self.store.add_record(self.venue_id,t.code,payload())
                clear_draft(self.store,self.venue_id,'journal',t.code)
            except Exception as exc:
                saving[0]=False;messagebox.showerror('Не сохранено',str(exc),parent=top);return
            top.destroy();self.show_quick_journals15(t.code)
        btn(actions,'Сохранить запись',commit,True).pack(side='right')
        btn(actions,'Закрыть с черновиком',close).pack(side='right',padx=9)
        top.protocol('WM_DELETE_WINDOW',close)

    def _signers15(self,t):
        staff=list_employees(self.store,self.venue_id)
        if not staff:
            messagebox.showinfo('Подписанты','Сначала добавьте сотрудника в разделе «Сотрудники».',parent=self)
            return self.show_employee_center()
        top=tk.Toplevel(self);top.title('Подписанты · '+t.title);top.configure(bg=BG)
        top.geometry('780x690');top.transient(self);top.grab_set()
        lbl(top,'Назначения · '+t.title,15,INK,True,wraplength=730).pack(anchor='w',padx=20,pady=16)
        lbl(top,'ФИО для документа и список для рукописных подписей. Подписи программа не создаёт.',9,SOFT,
            wraplength=740).pack(anchor='w',padx=20,pady=(0,10))
        key='journal:'+t.code;old=get_assignments(self.store,self.venue_id,key)
        choices=['Не назначено']+[e['full_name']+' · '+e['position_name'] for e in staff]
        cv=tk.Canvas(top,bg=BG,highlightthickness=0);scroll=ttk.Scrollbar(top,command=cv.yview)
        cv.configure(yscrollcommand=scroll.set);scroll.pack(side='right',fill='y');cv.pack(fill='both',expand=True,padx=21)
        area=tk.Frame(cv,bg=BG);wd=cv.create_window((0,0),window=area,anchor='nw')
        area.bind('<Configure>',lambda e:cv.configure(scrollregion=cv.bbox('all')))
        cv.bind('<Configure>',lambda e:cv.itemconfigure(wd,width=e.width))
        vars={}
        for k,title in ROLES:
            lbl(area,title,10,SOFT).pack(anchor='w',pady=(9,3))
            current=old['people'].get(k);index=next((i+1 for i,e in enumerate(staff) if current and e['id']==current['id']),0)
            v=tk.StringVar(value=choices[index]);vars[k]=v
            ttk.Combobox(area,textvariable=v,values=choices,state='readonly',width=70).pack(fill='x')
        acks={x['employee_id'] for x in list_acknowledgements(self.store,self.venue_id,key)}
        lbl(area,'Кто должен расписаться на листе ознакомления?',11,INK,True).pack(anchor='w',pady=(17,8))
        ack_vars={}
        for emp in staff:
            b=tk.BooleanVar(value=emp['id'] in acks);ack_vars[emp['id']]=b
            tk.Checkbutton(area,text=emp['full_name']+' · '+emp['position_name'],variable=b,bg=BG,fg=INK,
                selectcolor=ENTRY,activebackground=BG,activeforeground=INK,anchor='w').pack(fill='x',pady=2)
        duty=tk.BooleanVar(value=old['include_duties']);req=tk.BooleanVar(value=old['include_requirements'])
        for v,tit in ((duty,'Добавлять обязанности должностей'),(req,'Добавлять требования ХАССП')):
            tk.Checkbutton(area,text=tit,variable=v,bg=BG,fg=INK,selectcolor=ENTRY,activebackground=BG,activeforeground=INK).pack(anchor='w',pady=4)
        foot=tk.Frame(top,bg=BG);foot.pack(fill='x',padx=21,pady=13)
        def save():
            try:
                ids={k:staff[choices.index(v.get())-1]['id'] if choices.index(v.get())>0 else None for k,v in vars.items()}
                save_assignments(self.store,self.venue_id,key,ids,duty.get(),req.get())
                save_acknowledgements(self.store,self.venue_id,key,[k for k,v in ack_vars.items() if v.get()])
            except Exception as exc:return messagebox.showerror('Не сохранено',str(exc),parent=top)
            top.destroy();self.show_quick_journals15(t.code)
        btn(foot,'Сохранить назначения',save,True).pack(side='right')
        btn(foot,'Отмена',top.destroy).pack(side='right',padx=7)

    def _preview15(self,t):
        from tkinter import Text
        top=tk.Toplevel(self);top.title('Предпросмотр структуры · '+t.title);top.configure(bg=BG);top.geometry('870x700')
        lbl(top,'Предпросмотр содержания · '+t.title,15,INK,True,wraplength=780).pack(anchor='w',padx=20,pady=15)
        lbl(top,'Это предварительная структура полей, а не точная вёрстка Word/PDF.',9,WARN).pack(anchor='w',padx=20,pady=(0,10))
        paper=tk.Frame(top,bg='#FFFFFF');paper.pack(fill='both',expand=True,padx=90,pady=(5,16))
        text=tk.Text(paper,bg='white',fg='#20252C',font=(FONT,11),wrap='word',relief='flat',padx=26,pady=22)
        text.pack(fill='both',expand=True)
        venue=self.store.get_venue(self.venue_id)
        lines=[venue['venue_name'],t.title,'', 'ГРАФЫ ЖУРНАЛА',*['  • '+name for key,name in columns_for(self.store,self.venue_id,t)],'']
        a=get_assignments(self.store,self.venue_id,'journal:'+t.code)
        lines+=['НАЗНАЧЕНИЯ']+[f'  {title}: {a["people"].get(k)["full_name"] if a["people"].get(k) else "не назначен"}' for k,title in ROLES]
        lines+=['','Фактические записи: '+str(len(self.store.list_records(self.venue_id,t.code,False))),
                'Подписи в экспортируемых листах предусматриваются для собственноручного заполнения.']
        text.insert('1.0','\n'.join(lines));text.configure(state='disabled')
        foot=tk.Frame(top,bg=BG);foot.pack(fill='x',padx=20,pady=(0,12))
        btn(foot,'К редактору Word',lambda:(top.destroy(),self.show_word_editor())).pack(side='left')
        btn(foot,'Перейти к экспорту',lambda:(top.destroy(),self.show(9)),True).pack(side='right')

    def show_assistant15(self):
        if not self._need_venue():return
        v=self.store.get_venue(self.venue_id)
        top=tk.Toplevel(self);top.title('Помощник подбора документов');top.configure(bg=BG)
        top.geometry('840x720');top.minsize(640,480);top.transient(self);top.grab_set()
        lbl(top,'Расскажите, какие процессы есть на предприятии',16,INK,True,wraplength=760).pack(anchor='w',padx=23,pady=(17,8))
        lbl(top,'Программа предложит подходящие журналы. Проверка применимости и окончательный выбор остаются за вами.',
            9,SOFT,wraplength=760).pack(anchor='w',padx=23)
        canvas=tk.Canvas(top,bg=BG,highlightthickness=0);sb=ttk.Scrollbar(top,command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set);sb.pack(side='right',fill='y');canvas.pack(fill='both',expand=True,padx=20,pady=10)
        inside=tk.Frame(canvas,bg=BG);widget=canvas.create_window((0,0),window=inside,anchor='nw')
        inside.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(widget,width=e.width))
        opts={}
        for flag,name in flags_choice():
            state=tk.BooleanVar(value=bool(v['flags'].get(flag)));opts[flag]=state
            tk.Checkbutton(inside,text=name,variable=state,bg=CARD,fg=INK,selectcolor=ENTRY,
                activebackground=CARD,activeforeground=INK,anchor='w',wraplength=730,justify='left',
                font=(FONT,10),padx=12,pady=8).pack(fill='x',pady=3)
        foot=tk.Frame(top,bg=BG);foot.pack(fill='x',padx=22,pady=14)
        def save():
            choice={k:b.get() for k,b in opts.items()}
            if not messagebox.askyesno('Подтвердить процессы',
                    'Сохранить выбранные процессы? Рекомендации журналов будут пересчитаны; ваши ручные исключения сохранятся.',parent=top):return
            try:
                flags=dict(v['flags']);flags.update(choice)
                venue_update(self.store,self.venue_id,flags=flags)
            except Exception as exc:return messagebox.showerror('Ошибка',str(exc),parent=top)
            top.destroy();self.show_quick_journals15()
        btn(foot,'Сохранить и подобрать журналы',save,True).pack(side='right')
        btn(foot,'Отмена',top.destroy).pack(side='right',padx=8)
        btn(foot,'? Как работает подбор',lambda:self._help15('Журнал')).pack(side='left')

    def show_flow_starters15(self):
        if not self._need_venue():return
        top=tk.Toplevel(self);top.title('Блок-схемы из заготовок');top.configure(bg=BG);top.geometry('680x590');top.transient(self)
        lbl(top,'Создать блок-схему по примеру',15,INK,True).pack(anchor='w',padx=22,pady=(19,6))
        lbl(top,'Это черновики этапов без готовой оценки рисков или ККТ. Подтвердите и исправьте маршрут.',9,SOFT,
            wraplength=610).pack(anchor='w',padx=22,pady=(0,13))
        for name,steps in FLOW_STARTERS.items():
            f=tk.Frame(top,bg=PANEL);f.pack(fill='x',padx=20,pady=4)
            desc=tk.Frame(f,bg=PANEL);desc.pack(side='left',fill='x',expand=True,padx=12,pady=10)
            lbl(desc,name,11,INK,True).pack(anchor='w');lbl(desc,' → '.join(steps[:3])+' …',8,SOFT,wraplength=420).pack(anchor='w')
            def use(which=name):
                if not messagebox.askyesno('Новая схема','Создать редактируемый черновик «'+which+'»?',parent=top):return
                try:copy_starter(self.store,self.venue_id,which)
                except Exception as exc:return messagebox.showerror('Схема',str(exc),parent=top)
                top.destroy();self.show_flowcharts()
            btn(f,'Создать',use).pack(side='right',padx=8,pady=8)
        btn(top,'Открыть мои схемы',lambda:(top.destroy(),self.show_flowcharts()),True).pack(anchor='e',padx=21,pady=12)

    def _new_action15(self):
        title=simpledialog.askstring('Напоминание','Что необходимо сделать?',parent=self)
        if not title:return
        due=simpledialog.askstring('Срок','Дата ГГГГ-ММ-ДД (можно оставить пустым):',parent=self)
        if due is None:return
        try:add_action(self.store,self.venue_id,title,due.strip());self.show_workspace15()
        except Exception as exc:messagebox.showerror('Задача',str(exc),parent=self)

    def _help15(self,term=None):
        top=tk.Toplevel(self);top.title('Справочник · ХАССП');top.configure(bg=BG);top.geometry('690x570');top.transient(self)
        lbl(top,'Короткие объяснения',15,INK,True).pack(anchor='w',padx=22,pady=17)
        if term in HELP:
            lbl(top,term,12,CYAN,True).pack(anchor='w',padx=22,pady=(0,4))
            lbl(top,HELP[term],10,SOFT,wraplength=630).pack(anchor='w',padx=22,pady=(0,18))
        for title,description in HELP.items():
            if title==term:continue
            lbl(top,title,10,CYAN,True).pack(anchor='w',padx=22,pady=(6,1))
            lbl(top,description,9,SOFT,wraplength=630).pack(anchor='w',padx=22,pady=(0,5))

    def show_versions15(self):
        if not self._need_venue():return
        self._mode='versions';self._activate_nav('documents');self._clear();self._update_metrics()
        self.eyebrow.configure(text='ИСТОРИЯ ФАЙЛОВ')
        self.heading.configure(text='История экспортированных документов')
        self.subhead.configure(text='Копии Word/PDF/PNG на этом ПК · восстановление в выбранную папку')
        self._set_footer('←  Документы',self.show_documents_center,'Архив не изменяет утверждённые оригиналы',
                         'Сохранить комплект',lambda:self.show(9),0)
        p,body=frame(self.content);p.pack(fill='x')
        lbl(body,'Заархивировать готовый документ',14,INK,True).pack(anchor='w')
        lbl(body,'Выбирайте только нужные версии — они сохраняются в папке данных MoOLVa.',9,SOFT).pack(anchor='w',pady=6)
        def add():
            path=filedialog.askopenfilename(parent=self,filetypes=[('Документы','*.docx *.pdf *.png')])
            if not path:return
            try:archive_export(self.store,self.venue_id,path);self.show_versions15()
            except Exception as exc:messagebox.showerror('Архив',str(exc),parent=self)
        btn(body,'+ Сохранить версию DOCX/PDF/PNG',add,True).pack(anchor='w',pady=8)
        q,rows=frame(self.content);q.pack(fill='x',pady=10)
        versions=list_exports(self.store,self.venue_id)
        lbl(rows,f'Сохранено версий: {len(versions)}',12,INK,True).pack(anchor='w',pady=(0,9))
        for r in versions:
            line=tk.Frame(rows,bg=CARD);line.pack(fill='x',pady=3)
            lbl(line,r['created_at'][:16]+' · '+r['display_name'],9,INK,wraplength=630).pack(side='left',fill='x',expand=True,padx=12,pady=12)
            def restore(rec=r):
                path=filedialog.asksaveasfilename(parent=self,initialfile=rec['display_name'],title='Восстановить копию',
                                                defaultextension=Path(rec['display_name']).suffix)
                if not path:return
                if Path(path).exists() and not messagebox.askyesno('Перезапись','Файл уже существует. Заменить?',parent=self):return
                try:restore_export_copy(self.store,self.venue_id,rec['id'],path)
                except Exception as exc:messagebox.showerror('Архив',str(exc),parent=self)
                else:messagebox.showinfo('Готово','Копия сохранена: '+path,parent=self)
            btn(line,'Сохранить копию',restore).pack(side='right',padx=8,pady=4)

    def show_settings15(self):
        self.show_settings_center()
        p,body=frame(self.content);p.pack(fill='x',pady=(6,12))
        self._header15(body,'Простой или экспертный режим','Настройка влияет на видимость разделов, но не удаляет данные.')
        cur=tk.StringVar(value=self._mode15())
        for key,title in [('simple','Простой режим — только основные действия'),('expert','Экспертный режим — полный набор разделов')]:
            tk.Radiobutton(body,text=title,variable=cur,value=key,bg=PANEL,fg=INK,selectcolor=ENTRY,
                           activebackground=PANEL,activeforeground=INK).pack(anchor='w',pady=4)
        def apply():
            set_setting(self.store,'work_mode',cur.get());self._apply_nav15();self.show_workspace15()
        btn(body,'Применить режим',apply,True).pack(anchor='w',pady=10)
        btn(body,'? Понятия ХАССП',self._help15).pack(anchor='w',pady=7)
        p2,body2=frame(self.content);p2.pack(fill='x',pady=6)
        self._header15(body2,'Резервные копии и архив','Безопасное восстановление через сохранение копии, а не незаметную подмену документа.')
        btn(body2,'История версий документов',self.show_versions15).pack(anchor='w',pady=5)
        btn(body2,'Создать резервную копию всей базы',self._backup_database15).pack(anchor='w',pady=5)
        btn(body2,'Восстановить базу из копии',self._restore_database15).pack(anchor='w',pady=5)

    def _backup_database15(self):
        from datetime import datetime
        name='MoOLVa_ХАССП_'+datetime.now().strftime('%Y-%m-%d_%H-%M')+'.sqlite3'
        path=filedialog.asksaveasfilename(parent=self,title='Сохранить резервную копию',initialfile=name,
             defaultextension='.sqlite3',filetypes=[('База MoOLVa','*.sqlite3')])
        if not path:return
        try:create_database_backup(self.store,path)
        except Exception as exc:messagebox.showerror('Резервная копия',str(exc),parent=self)
        else:messagebox.showinfo('Резервная копия создана','Файл сохранён:\n'+path,parent=self)

    def _restore_database15(self):
        path=filedialog.askopenfilename(parent=self,title='Выберите проверенную резервную копию',
            filetypes=[('База MoOLVa','*.sqlite3 *.db *.sqlite')])
        if not path:return
        if not messagebox.askyesno('Восстановление данных',
            'Все текущие данные будут заменены содержимым выбранной копии.\n'
            'Перед заменой программа сохранит автоматическую аварийную копию.\n'
            'После операции потребуется закрыть и снова открыть MoOLVa. Продолжить?',parent=self):return
        try:safety=restore_database_backup(self.store,path)
        except Exception as exc:messagebox.showerror('Восстановление не удалось',str(exc),parent=self)
        else:
            messagebox.showinfo('База восстановлена',
                'Данные восстановлены. Аварийная копия предыдущей базы:\n'+str(safety)+
                '\n\nЗакройте приложение и запустите его снова.',parent=self)
            self.destroy()

