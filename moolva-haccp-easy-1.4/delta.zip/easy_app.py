"""MoOLVa ХАССП Easy 1.0 — Russian first-run guided desktop UI.
Actual entry point for the normal Windows application. No terminal is required.
"""
from __future__ import annotations
import os
import sys
import threading
import traceback
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from easy_core import (STEPS, FIELD_NAMES, TYPE_FAVOURITES, flags_choice,
    init_store, make_venue, venue_update, venue_delete, selected, toggle_journal, recommended,
    apply_staff_to_documents, overview, export_pack_easy)
from catalog import TYPES, defaults_for_type
from exports import columns_for
from staff_store import list_employees, save_employee, archive_employee, get_employee, get_assignments, list_acknowledgements
from studio_core import audit_enterprise
from roles_catalog import POSITIONS, search_positions, get_position, reference
from word_editor_ui import WordEditorPane
from flowchart_ui import FlowchartPane
from visual_core import completion_summary, journal_cards, risk_summary
from enterprise14_ui import Enterprise14Mixin
from enterprise14_core import live_snapshot, export_manifest_note

BG='#111824'; NAV='#142031'; CARD='#1A2739'; CARD2='#22334A'; EDGE='#31445C'
INK='#F1F6FD'; SOFT='#AFBDD0'; MUTED='#8297AE'; LIME='#D5E744'; CYAN='#29BFD1'
GREEN='#34C9AB'; DANGER='#F0717D'; WARN='#FFBD5C'; ENTRY='#253B52'
FONT='Segoe UI'


def tile(parent, bg=CARD, **kwargs):
    return tk.Frame(parent,bg=bg,highlightthickness=1,highlightbackground=EDGE,**kwargs)


def label(parent,text='',size=11,fg=INK,bg=None,bold=False,**opts):
    return tk.Label(parent,text=text,fg=fg,bg=bg or parent.cget('bg'),font=(FONT,size,'bold' if bold else 'normal'),**opts)


def button(parent,text,command,primary=False,width=None,padx=16,pady=10):
    bg=LIME if primary else CARD2
    fg=NAV if primary else INK
    kw=dict(text=text,command=command,bg=bg,fg=fg,activebackground='#E7F158' if primary else '#46515F',
            activeforeground=fg,relief='flat',bd=0,highlightthickness=0,cursor='hand2',
            font=(FONT,10,'bold'),padx=padx,pady=pady)
    if width: kw['width']=width
    return tk.Button(parent,**kw)


def entry(parent,var=None,width=40):
    kw=dict(bg=ENTRY,fg=INK,insertbackground=INK,relief='flat',bd=0,highlightbackground=EDGE,
            highlightthickness=1,font=(FONT,11),width=width)
    if var is not None:kw['textvariable']=var
    widget=tk.Entry(parent,**kw)
    return widget


class EasyApp(Enterprise14Mixin,tk.Tk):
    def __init__(self, store=None, demo=False):
        super().__init__()
        self.title('MoOLVa ХАССП Easy 1.4.0 — Production Control')
        self.configure(bg=BG)
        self.geometry('1390x870')
        self.minsize(1030,660)
        try:self.iconbitmap(str(Path(__file__).parent/'assets'/'MoOLVa_HACCP.ico'))
        except (tk.TclError,OSError):pass
        self.store=store or init_store()
        self._ttk_style()
        self.venue_id=None
        self.step=0
        self.card_vars={}
        self.flag_vars={}
        self.role_vars={}
        self.check_vars={}
        self.venues=[]
        self._exporting=False
        self._last_folder=None
        self._selection_codes=[]
        self._roles_target='all'
        self._wizard_step=0
        self._mode='wizard'
        self._build_shell()
        self._last_db_stamp=None
        self.after(1400,self._poll14)
        self.bind('<Configure>',self._on_root_resize)
        self.show_dashboard()

    def _ttk_style(self):
        style=ttk.Style(self)
        style.theme_use('clam')
        style.configure('Treeview',background=CARD2,foreground=INK,fieldbackground=CARD2,
                        borderwidth=0,relief='flat',font=(FONT,10),rowheight=27)
        style.configure('Treeview.Heading',background=ENTRY,foreground=SOFT,
                        font=(FONT,10,'bold'),borderwidth=0,padding=(7,10))
        style.map('Treeview',background=[('selected','#37566B')],foreground=[('selected',INK)])
        style.map('Treeview.Heading',background=[('active','#3A4756')])
        style.configure('TCombobox',foreground=INK,fieldbackground=ENTRY,background=ENTRY,
                        arrowcolor=LIME,padding=8)
        style.map('TCombobox',fieldbackground=[('readonly',ENTRY)],foreground=[('readonly',INK)],
                  selectforeground=[('readonly',INK)],selectbackground=[('readonly',ENTRY)])
        style.configure('Vertical.TScrollbar',background=CARD2,arrowcolor=INK,troughcolor=BG)

    def _build_shell(self):
        self.sidebar=tk.Frame(self,bg=NAV,width=215)
        self.sidebar.pack(side='left',fill='y')
        self.sidebar.pack_propagate(False)

        brand=tk.Frame(self.sidebar,bg=NAV)
        brand.pack(fill='x',padx=12,pady=(14,11))
        logo=tk.Frame(brand,bg='#253A50',width=44,height=44)
        logo.pack(side='left'); logo.pack_propagate(False)
        tk.Label(logo,text='m',font=('Georgia',27,'italic'),bg='#253A50',fg=CYAN).pack(expand=True)
        bx=tk.Frame(brand,bg=NAV);bx.pack(side='left',padx=11)
        label(bx,'MoOLVa',size=16,bold=True,bg=NAV).pack(anchor='w')
        label(bx,'ХАССП · EASY 1.4.0',size=8,fg=CYAN,bg=NAV,bold=True).pack(anchor='w',pady=(2,0))

        label(self.sidebar,'РАБОЧИЕ РАЗДЕЛЫ',size=8,fg=MUTED,bg=NAV,bold=True).pack(anchor='w',padx=17,pady=(0,5))
        self.primary_buttons={}
        nav_items=(
            ('dashboard','▦','Обзор',self.show_dashboard),
            ('enterprises','▥','Предприятия',self.show_enterprises_center),
            ('flows','⇄','Блок-схемы',self.show_flowcharts),
            ('haccp','◇','Планы ХАССП',self.show_haccp_plans_center),
            ('journals','▤','Журналы',self.show_journal_center),
            ('documents','▣','Документы',self.show_documents_center),
            ('employees','♙','Сотрудники',self.show_employee_center),
            ('analytics','▥','Аналитика',self.show_analytics_center),
            ('alerts','◉','Уведомления',self.show_alert_center),
            ('settings','⚙','Настройки',self.show_settings_center),
            ('wizard','➜','Мастер заполнения',lambda:self.show(self.step if self.venue_id else 0)),
        )
        for key,ico,title,cmd in nav_items:
            row=tk.Frame(self.sidebar,bg=NAV)
            row.pack(fill='x',padx=7,pady=1)
            b=tk.Button(row,text=f'{ico}   {title}',anchor='w',command=cmd,cursor='hand2',
                        relief='flat',bd=0,highlightthickness=0,bg=NAV,fg=SOFT,
                        activebackground=CARD,activeforeground=INK,font=(FONT,9,'bold'),padx=11,pady=8)
            b.pack(fill='x')
            self.primary_buttons[key]=b

        tk.Frame(self.sidebar,bg=EDGE,height=1).pack(fill='x',padx=13,pady=(10,8))
        self.side_venue=label(self.sidebar,'Предприятие не выбрано',size=10,fg=INK,bg=NAV,bold=True,
                              wraplength=178,justify='left')
        self.side_venue.pack(anchor='w',padx=14)
        self.side_hint=label(self.sidebar,'Создайте новый комплект или откройте сохранённый.',size=9,fg=MUTED,bg=NAV,
                            wraplength=178,justify='left')
        self.side_hint.pack(anchor='w',padx=14,pady=(3,5))
        self.side_meter=tk.Frame(self.sidebar,bg=EDGE,height=5)
        self.side_meter.pack(fill='x',padx=14,pady=(1,3))
        self.side_meter_fill=tk.Frame(self.side_meter,bg=LIME,height=5)
        self.side_meter_fill.place(x=0,y=0,relheight=1,relwidth=0)
        self.side_score=label(self.sidebar,'Заполнено в программе: 0%',size=8,fg=SOFT,bg=NAV)
        self.side_score.pack(anchor='w',padx=14)

        spacer=tk.Frame(self.sidebar,bg=NAV);spacer.pack(fill='both',expand=True)
        label(self.sidebar,'ЛОКАЛЬНО · OFFLINE',size=8,fg=MUTED,bg=NAV,bold=True).pack(anchor='w',padx=14)
        label(self.sidebar,'Данные и журналы остаются на этом ПК.',size=8,fg=MUTED,bg=NAV,
              wraplength=178,justify='left').pack(anchor='w',padx=21,pady=(3,20))

        self.main=tk.Frame(self,bg=BG)
        self.main.pack(side='left',fill='both',expand=True)
        self.header=tk.Frame(self.main,bg=BG,height=99)
        self.header.pack(fill='x',padx=(24,24),pady=(10,0));self.header.pack_propagate(False)
        h=tk.Frame(self.header,bg=BG);h.pack(side='left',fill='both',expand=True)
        self.eyebrow=label(h,'ОБЗОР',size=9,fg=CYAN,bg=BG,bold=True);self.eyebrow.pack(anchor='w',pady=(3,5))
        self.heading=label(h,'MoOLVa ХАССП Easy',size=22,bold=True,bg=BG);self.heading.pack(anchor='w')
        self.subhead=label(h,'Пошаговая подготовка и визуальный контроль документов',size=10,fg=SOFT,bg=BG)
        self.subhead.pack(anchor='w',pady=(6,0))

        self.metrics=tk.Frame(self.header,bg=BG);self.metrics.pack(side='right',anchor='center')
        self.metric_labels=[]
        for caption in ('ЗАПОЛНЕНО','ЖУРНАЛОВ','СОТРУДНИКОВ','ПРОЦЕССОВ'):
            f=tk.Frame(self.metrics,bg=CARD,width=94,height=70,highlightthickness=1,highlightbackground=EDGE)
            f.pack(side='left',padx=3);f.pack_propagate(False)
            txt=label(f,'0',size=20,fg=LIME,bg=CARD,bold=True);txt.pack(anchor='center',pady=(7,0))
            label(f,caption,size=7,fg=SOFT,bg=CARD).pack(anchor='center')
            self.metric_labels.append(txt)

        tk.Frame(self.main,bg=EDGE,height=1).pack(fill='x',padx=34,pady=(4,0))
        body=tk.Frame(self.main,bg=BG);body.pack(fill='both',expand=True,padx=30,pady=(10,8))
        self.canvas=tk.Canvas(body,bg=BG,highlightthickness=0,bd=0)
        self.scrollbar=ttk.Scrollbar(body,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.scrollbar.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True)
        self.content=tk.Frame(self.canvas,bg=BG)
        self.window=self.canvas.create_window((0,0),window=self.content,anchor='nw')
        self.content.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.window,width=e.width))
        self.canvas.bind_all('<MouseWheel>',self._mousewheel)

        self.footer=tk.Frame(self.main,bg=NAV,height=76);self.footer.pack(side='bottom',fill='x');self.footer.pack_propagate(False)
        self.progress_track=tk.Frame(self.footer,bg=EDGE,height=4);self.progress_track.pack(fill='x')
        self.progress_fill=tk.Frame(self.progress_track,bg=LIME,height=4);self.progress_fill.place(x=0,y=0,relheight=1,relwidth=0)
        f=tk.Frame(self.footer,bg=NAV);f.pack(fill='x',padx=30,pady=13)
        self.back=button(f,'←  Обзор',self.show_dashboard);self.back.pack(side='left')
        self.step_status=label(f,'',size=10,fg=SOFT,bg=NAV);self.step_status.pack(side='left',padx=18)
        self.next=button(f,'Продолжить  →',lambda:self.show(0),primary=True);self.next.pack(side='right')

    def _activate_nav(self,key):
        for name,b in self.primary_buttons.items():
            active=name==key
            b.configure(bg=LIME if active else NAV,fg=NAV if active else SOFT,
                        activebackground=LIME if active else CARD,
                        activeforeground=NAV if active else INK)

    def _update_metrics(self):
        info=overview(self.store,self.venue_id)
        complete=completion_summary(self.store,self.venue_id)
        values=(f"{complete['score']}%",info['journals'],info['staff'],info['processes'])
        for t,n in zip(self.metric_labels,values):t.configure(text=str(n))
        if self.venue_id:
            venue=self.store.get_venue(self.venue_id)
            self.side_venue.configure(text=(venue.get('venue_name') or 'Без названия'))
            self.side_hint.configure(text=venue.get('kind') or 'Предприятие')
        else:
            self.side_venue.configure(text='Предприятие не выбрано')
            self.side_hint.configure(text='Создайте новый комплект или откройте сохранённый.')
        self.side_meter_fill.place(relwidth=max(0,min(1,complete['score']/100)))
        self.side_score.configure(text=f"Заполнено в программе: {complete['score']}%")

    def _set_footer(self,left_text,left_cmd,status,right_text,right_cmd,progress=0):
        self.back.configure(text=left_text,command=left_cmd,state='normal' if left_cmd else 'disabled')
        self.step_status.configure(text=status)
        self.next.configure(text=right_text,command=right_cmd,state='normal' if right_cmd else 'disabled')
        self.progress_fill.place(relwidth=max(0,min(1,progress)))

    def _on_root_resize(self,event):
        if event.widget is not self:return
        narrow=event.width<1220
        shown=bool(self.metrics.winfo_manager())
        if narrow and shown:
            self.metrics.pack_forget()
        elif not narrow and not shown:
            self.metrics.pack(side='right',anchor='center')

    def _mousewheel(self,event):
        if self._mode=='word' and hasattr(self,'word_view') and event.widget==self.word_view.preview:
            return
        if self.winfo_exists() and self.canvas.winfo_exists():
            if self.winfo_containing(event.x_root,event.y_root) not in (None,):
                self.canvas.yview_scroll(int(-event.delta/120), 'units')

    def _clear(self):
        for ch in self.content.winfo_children():ch.destroy()
        self.canvas.yview_moveto(0)

    def caption(self,text):
        label(self.content,text,size=11,fg=SOFT).pack(anchor='w',pady=(3,18))

    def panel(self,padx=25,pady=22):
        f=tile(self.content);f.pack(fill='x',padx=6,pady=(0,15))
        body=tk.Frame(f,bg=CARD);body.pack(fill='x',padx=padx,pady=pady)
        return body

    def heading2(self,parent,text,desc=None):
        label(parent,text,size=15,bold=True).pack(anchor='w',pady=(0,5))
        if desc:label(parent,desc,size=10,fg=SOFT,wraplength=770,justify='left').pack(anchor='w',pady=(0,13))

    def _need_venue(self):
        if self.venue_id and self.store.get_venue(self.venue_id):
            return True
        self.show_dashboard()
        messagebox.showinfo('Сначала выберите предприятие','Создайте новый комплект или откройте сохранённое предприятие.')
        return False

    def _metric_card(self,parent,value,title,note='',accent=LIME):
        box=tk.Frame(parent,bg=CARD2,highlightthickness=1,highlightbackground=EDGE,height=104)
        box.pack(side='left',fill='both',expand=True,padx=5);box.pack_propagate(False)
        label(box,str(value),size=25,fg=accent,bg=CARD2,bold=True).pack(anchor='w',padx=14,pady=(12,0))
        label(box,title,size=9,fg=INK,bg=CARD2,bold=True).pack(anchor='w',padx=14,pady=(1,0))
        if note:label(box,note,size=8,fg=MUTED,bg=CARD2,wraplength=180,justify='left').pack(anchor='w',padx=14,pady=(4,0))
        return box

    def show_dashboard(self):
        if self._mode=='word' and hasattr(self,'word_view'):
            if self.word_view.dirty and not messagebox.askyesno('Несохранённые изменения','Вернуться на обзор без сохранения изменений Word?'):
                return
        self._mode='dashboard';self._activate_nav('dashboard');self._clear();self._update_metrics()
        self.eyebrow.configure(text='ОБЗОР ПРЕДПРИЯТИЯ')
        self.heading.configure(text='Центр управления ХАССП')
        self.subhead.configure(text='Что заполнено, что требует внимания и какой следующий шаг')
        if not self.venue_id:
            self._set_footer('Новый комплект',self.new_venue,'Выберите предприятие для продолжения','Открыть мастер  →',lambda:self.show(0),0)
            hero=self.panel(padx=28,pady=26)
            row=tk.Frame(hero,bg=CARD);row.pack(fill='x')
            left=tk.Frame(row,bg=CARD);left.pack(side='left',fill='both',expand=True)
            label(left,'ХАССП БЕЗ ЛИШНИХ ЭКРАНОВ',size=9,fg=CYAN,bold=True).pack(anchor='w')
            label(left,'От предприятия — до Word и PDF.',size=25,bold=True).pack(anchor='w',pady=(8,7))
            label(left,'Выберите сохранённый объект или создайте новый. Дальше программа ведёт по шагам и показывает только то, что нужно сейчас.',
                  size=10,fg=SOFT,wraplength=630,justify='left').pack(anchor='w',pady=(0,16))
            button(left,'+  Создать новый комплект',self.new_venue,primary=True,pady=12).pack(anchor='w')
            can=tk.Canvas(row,width=250,height=145,bg=CARD,highlightthickness=0);can.pack(side='right',padx=(18,0))
            can.create_arc(48,18,176,146,start=90,extent=-292,style='arc',outline=LIME,width=13)
            can.create_arc(48,18,176,146,start=90,extent=-205,style='arc',outline=CYAN,width=5)
            can.create_text(112,73,text='EASY',fill=INK,font=(FONT,22,'bold'))
            can.create_text(112,100,text='пошагово',fill=SOFT,font=(FONT,9))
            p=self.panel();self.heading2(p,'Сохранённые предприятия','Нажмите «Открыть», чтобы увидеть состояние документов и продолжить работу.')
            venues=self.store.list_venues()
            if not venues:
                label(p,'Пока нет сохранённых предприятий.',size=10,fg=SOFT).pack(anchor='w')
            for rowdata in venues[-14:]:
                bar=tk.Frame(p,bg=ENTRY,highlightthickness=1,highlightbackground=EDGE);bar.pack(fill='x',pady=4)
                label(bar,'●',size=12,fg=LIME,bg=ENTRY).pack(side='left',padx=(13,9))
                info=tk.Frame(bar,bg=ENTRY);info.pack(side='left',fill='x',expand=True,pady=8)
                label(info,rowdata['venue_name'],size=11,bg=ENTRY,bold=True).pack(anchor='w')
                label(info,rowdata['kind'],size=8,fg=MUTED,bg=ENTRY).pack(anchor='w')
                button(bar,'Удалить',lambda i=rowdata['id']:self.delete_venue_ui(i),padx=10,pady=7).pack(side='right',padx=(3,9))
                button(bar,'Редактировать',lambda i=rowdata['id']:self.edit_venue(i),padx=10,pady=7).pack(side='right',padx=3)
                button(bar,'Открыть  →',lambda i=rowdata['id']:self.open_venue(i),padx=12,pady=7).pack(side='right',padx=3)
            return

        venue=self.store.get_venue(self.venue_id)
        complete=completion_summary(self.store,self.venue_id)
        info=overview(self.store,self.venue_id)
        try:audit=audit_enterprise(self.store,self.venue_id)
        except Exception:audit={'issues':[],'open_tasks':0}
        self._set_footer('Новый комплект',self.new_venue,f"{venue.get('kind','')} · данные сохраняются локально",
                         'Продолжить мастер  →',lambda:self.show(max(1,self.step)),0)

        top=self.panel(padx=25,pady=23)
        row=tk.Frame(top,bg=CARD);row.pack(fill='x')
        ring=tk.Canvas(row,width=190,height=180,bg=CARD,highlightthickness=0);ring.pack(side='left',padx=(0,24))
        ring.create_arc(22,17,168,163,start=90,extent=-359,style='arc',outline=EDGE,width=15)
        ring.create_arc(22,17,168,163,start=90,extent=-3.59*complete['score'],style='arc',outline=LIME,width=15)
        ring.create_text(95,79,text=f"{complete['score']}%",fill=INK,font=(FONT,28,'bold'))
        ring.create_text(95,108,text='заполнено',fill=SOFT,font=(FONT,9))
        right=tk.Frame(row,bg=CARD);right.pack(side='left',fill='both',expand=True)
        label(right,venue.get('venue_name') or 'Без названия',size=22,bold=True).pack(anchor='w')
        label(right,venue.get('kind') or '',size=10,fg=CYAN,bold=True).pack(anchor='w',pady=(3,10))
        label(right,'Это индикатор заполненности данных в программе, а не сертификат соответствия ХАССП.',
              size=9,fg=MUTED,wraplength=600,justify='left').pack(anchor='w')
        actions=tk.Frame(right,bg=CARD);actions.pack(anchor='w',pady=(16,0))
        button(actions,'Продолжить заполнение  →',lambda:self.show(max(1,self.step)),primary=True,pady=11).pack(side='left')
        button(actions,'Редактировать карточку',lambda:self.edit_venue(self.venue_id),padx=12,pady=11).pack(side='left',padx=7)
        button(actions,'Удалить предприятие',lambda:self.delete_venue_ui(self.venue_id),padx=12,pady=11).pack(side='left')

        cards=tk.Frame(self.content,bg=BG);cards.pack(fill='x',padx=1,pady=(0,15))
        self._metric_card(cards,info['journals'],'Журналов','выбрано в комплекте')
        self._metric_card(cards,info['staff'],'Сотрудников','в справочнике',CYAN)
        self._metric_card(cards,info['processes'],'Процессов','отмечено на объекте',GREEN)
        self._metric_card(cards,len(audit.get('issues',[])),'Вопросов','для предварительной проверки',WARN if audit.get('issues') else GREEN)

        self.update_idletasks();wide=self.winfo_width()>=1220
        grid=tk.Frame(self.content,bg=BG);grid.pack(fill='x',padx=6,pady=(0,15))
        left=tile(grid);left.pack(side='left' if wide else 'top',fill='both' if wide else 'x',expand=wide,padx=(0,7) if wide else 0,pady=(0,0 if wide else 8))
        lb=tk.Frame(left,bg=CARD);lb.pack(fill='both',expand=True,padx=22,pady=20)
        self.heading2(lb,'Что сделать дальше','Программа показывает только незавершённые части.')
        todo=[x for x in complete['items'] if not x['ok']]
        if not todo:
            label(lb,'Основные разделы заполнены. Можно перейти к проверке и экспорту.',size=10,fg=GREEN).pack(anchor='w',pady=10)
            button(lb,'Проверить комплект  →',lambda:self.show(8),primary=True).pack(anchor='w',pady=(8,0))
        for idx,item in enumerate(todo[:4],1):
            b=tk.Button(lb,text=f"{idx:02d}   {item['title']}\n      {item['hint']}",anchor='w',justify='left',wraplength=520,
                        bg=ENTRY,fg=INK,activebackground='#46515B',activeforeground=INK,relief='flat',bd=0,
                        font=(FONT,9),padx=12,pady=10,cursor='hand2',command=lambda st=item['step']:self.show(st))
            b.pack(fill='x',pady=3)

        right=tile(grid);right.pack(side='left' if wide else 'top',fill='both' if wide else 'x',expand=wide,padx=(7,0) if wide else 0)
        rb=tk.Frame(right,bg=CARD);rb.pack(fill='both',expand=True,padx=22,pady=20)
        self.heading2(rb,'Предварительный контроль','Не заменяет внутренний аудит специалиста ХАССП.')
        issues=audit.get('issues',[])
        if not issues:
            label(rb,'По автоматическим признакам срочных вопросов не найдено.',size=10,fg=GREEN,wraplength=430,justify='left').pack(anchor='w',pady=6)
        for issue in issues[:4]:
            box=tk.Frame(rb,bg=ENTRY);box.pack(fill='x',pady=3)
            label(box,issue['text'],size=9,fg=INK,bg=ENTRY,wraplength=420,justify='left').pack(anchor='w',padx=11,pady=(8,2))
            label(box,issue['action'],size=8,fg=CYAN,bg=ENTRY,wraplength=420,justify='left').pack(anchor='w',padx=11,pady=(0,8))
        if issues:button(rb,'Открыть проверку  →',lambda:self.show(8),padx=11,pady=7).pack(anchor='w',pady=(9,0))

    def show_dashboard(self):
        if self._mode=='word' and hasattr(self,'word_view') and self.word_view.dirty:
            if not messagebox.askyesno('Несохранённый Word','Закрыть редактор без сохранения?'):
                return
        return self.show_enterprise_dashboard()

    def _poll14(self):
        """Near real-time LOCAL DB refresh. Never redraw unsaved editors/forms."""
        try:
            if not self.winfo_exists():return
            stamp=self.store.path.stat().st_mtime_ns if self.store.path.exists() else 0
            if self._last_db_stamp is None:self._last_db_stamp=stamp
            elif stamp!=self._last_db_stamp:
                self._last_db_stamp=stamp
                if self._mode in ('dashboard','analytics'):
                    self.after_idle(self.show_dashboard if self._mode=='dashboard' else self.show_analytics_center)
                elif self._mode in ('alerts','employees'):
                    self.after_idle(self.show_alert_center if self._mode=='alerts' else self.show_employee_center)
                else:
                    self._update_metrics()
        except (OSError,tk.TclError):pass
        finally:
            try: self.after(1400,self._poll14)
            except tk.TclError:pass

    def show_journal_center(self):
        if not self._need_venue():return
        if self._mode=='word' and hasattr(self,'word_view') and self.word_view.dirty:
            if not messagebox.askyesno('Несохранённые изменения','Перейти к журналам без сохранения Word?'):return
        self._mode='journals';self._activate_nav('journals');self._clear();self._update_metrics()
        self.eyebrow.configure(text='ВИЗУАЛЬНЫЙ ЦЕНТР')
        self.heading.configure(text='Журналы предприятия')
        self.subhead.configure(text='Статус, подписанты и приложения видны без открытия каждого файла')
        cards=journal_cards(self.store,self.venue_id)
        self._set_footer('←  Обзор',self.show_dashboard,f'Выбрано журналов: {len(cards)}','Изменить подбор  →',lambda:self.show(5),0)
        p=self.panel();self.heading2(p,'Комплект журналов','Карточка показывает только данные, уже сохранённые в программе.')
        if not cards:
            label(p,'Журналы ещё не выбраны.',size=11,fg=SOFT).pack(anchor='w',pady=8)
            button(p,'Перейти к подбору журналов  →',lambda:self.show(5),primary=True).pack(anchor='w',pady=8)
            return
        grid=tk.Frame(p,bg=CARD);grid.pack(fill='x')
        for idx,item in enumerate(cards):
            box=tk.Frame(grid,bg=CARD2,highlightthickness=1,highlightbackground=EDGE)
            box.grid(row=idx//2,column=idx%2,sticky='nsew',padx=5,pady=5)
            top=tk.Frame(box,bg=CARD2);top.pack(fill='x',padx=14,pady=(13,6))
            label(top,item['title'],size=11,bg=CARD2,bold=True,wraplength=350,justify='left').pack(side='left',fill='x',expand=True)
            badge_bg=GREEN if item['state']=='ready' else WARN
            tk.Label(top,text=item['state_text'],bg=badge_bg,fg=NAV,font=(FONT,8,'bold'),padx=8,pady=3).pack(side='right')
            details=[]
            if item['has_responsible']:details.append('ответственный')
            if item['has_approved']:details.append('утверждающий')
            details.append(f"подписантов: {item['ack_count']}")
            label(box,' · '.join(details),size=8,fg=SOFT,bg=CARD2).pack(anchor='w',padx=14)
            tags=tk.Frame(box,bg=CARD2);tags.pack(fill='x',padx=14,pady=(9,8))
            tagtexts=[]
            if item['include_duties']:tagtexts.append('Обязанности')
            if item['include_requirements']:tagtexts.append('Требования ХАССП')
            if not tagtexts:tagtexts=['Без приложений']
            for text in tagtexts:
                tk.Label(tags,text=text,bg=ENTRY,fg=SOFT,font=(FONT,8),padx=7,pady=3).pack(side='left',padx=(0,5))
            if item['missing']:
                label(box,'Нужно: '+', '.join(item['missing']),size=8,fg=DANGER,bg=CARD2,wraplength=360,justify='left').pack(anchor='w',padx=14,pady=(0,5))
            actions=tk.Frame(box,bg=CARD2);actions.pack(fill='x',padx=14,pady=(6,13))
            button(actions,'Подписи',lambda code=item['code']:self._open_roles_for(code),padx=10,pady=6).pack(side='left')
            button(actions,'Записи',lambda:self.show(6),padx=10,pady=6).pack(side='left',padx=5)
        grid.columnconfigure(0,weight=1);grid.columnconfigure(1,weight=1)

    def _open_roles_for(self,code):
        self._roles_target=code
        self.show(7)

    def show_risk_center(self):
        if not self._need_venue():return
        self._mode='risks';self._activate_nav('risks');self._clear();self._update_metrics()
        self.eyebrow.configure(text='ВИЗУАЛИЗАЦИЯ ХАССП')
        self.heading.configure(text='Карта рисков')
        self.subhead.configure(text='Матрица показывает только фактически введённые оценки вероятности и тяжести')
        data=risk_summary(self.store,self.venue_id)
        self._risk_data=data
        self._set_footer('←  Обзор',self.show_dashboard,'Матрица не определяет ККТ автоматически','Проверка комплекта  →',lambda:self.show(8),0)
        cards=tk.Frame(self.content,bg=BG);cards.pack(fill='x',padx=1,pady=(0,15))
        self._metric_card(cards,data['plans'],'Планов ХАССП','сохранено')
        self._metric_card(cards,data['evaluated'],'Оценено рисков','вероятность × тяжесть',CYAN)
        self._metric_card(cards,data['significant'],'Существенных','отмечено специалистом',WARN)
        self._metric_card(cards,data['ccp'],'ККТ','определено вручную',DANGER if data['ccp'] else GREEN)

        p=self.panel();self.heading2(p,'Матрица 5 × 5','Строки — вероятность, столбцы — тяжесть. Число в ячейке — количество введённых опасностей.')
        matrix=tk.Frame(p,bg=CARD);matrix.pack(anchor='w')
        label(matrix,'Вероятность ↓ / Тяжесть →',size=8,fg=MUTED,bg=CARD).grid(row=0,column=0,padx=5,pady=5)
        for sev in range(1,6):label(matrix,str(sev),size=10,fg=SOFT,bg=CARD,bold=True).grid(row=0,column=sev,padx=5,pady=5)
        for r,lik in enumerate(range(5,0,-1),1):
            label(matrix,str(lik),size=10,fg=SOFT,bg=CARD,bold=True).grid(row=r,column=0,padx=8,pady=5)
            for sev in range(1,6):
                score=lik*sev;count=len(data['matrix'].get((lik,sev),[]))
                if score>=20:bg='#6A343A'
                elif score>=12:bg='#6A493A'
                elif score>=7:bg='#625B38'
                else:bg='#365044'
                b=tk.Button(matrix,text=f'{count}',width=6,height=2,bg=bg,fg=INK,activebackground=CYAN,activeforeground=NAV,
                            relief='flat',bd=0,font=(FONT,11,'bold'),cursor='hand2',
                            command=lambda l=lik,s=sev:self._show_risk_cell(l,s))
                b.grid(row=r,column=sev,padx=4,pady=4,sticky='nsew')
        self.risk_detail=tk.Frame(p,bg=ENTRY,highlightthickness=1,highlightbackground=EDGE)
        self.risk_detail.pack(fill='x',pady=(17,0))
        self._show_risk_cell(None,None)
        label(p,'Важно: цвет — удобная визуальная группировка балла L×S. Значимость опасности и решение о ККТ принимает специалист и фиксирует вручную.',
              size=8,fg=MUTED,wraplength=820,justify='left').pack(anchor='w',pady=(10,0))

    def _show_risk_cell(self,likelihood,severity):
        for ch in self.risk_detail.winfo_children():ch.destroy()
        if likelihood is None:
            if not self._risk_data['hazards']:
                label(self.risk_detail,'Пока нет введённых опасностей ХАССП. Матрица останется пустой, пока специалист не внесёт оценки.',
                      size=9,fg=SOFT,bg=ENTRY,wraplength=790,justify='left').pack(anchor='w',padx=14,pady=13)
            else:
                label(self.risk_detail,'Нажмите на ячейку матрицы, чтобы увидеть связанные опасности.',size=9,fg=SOFT,bg=ENTRY).pack(anchor='w',padx=14,pady=13)
            if self._risk_data.get('unevaluated'):
                label(self.risk_detail,f"Не оценено полностью: {self._risk_data['unevaluated']}",size=8,fg=WARN,bg=ENTRY).pack(anchor='w',padx=14,pady=(0,12))
            return
        items=self._risk_data['matrix'].get((likelihood,severity),[])
        label(self.risk_detail,f'Вероятность {likelihood} × тяжесть {severity} = {likelihood*severity} · опасностей: {len(items)}',
              size=10,fg=LIME,bg=ENTRY,bold=True).pack(anchor='w',padx=14,pady=(11,6))
        if not items:
            label(self.risk_detail,'В этой ячейке нет сохранённых оценок.',size=9,fg=SOFT,bg=ENTRY).pack(anchor='w',padx=14,pady=(0,12));return
        for h in items[:8]:
            text=f"• {h.get('step_name','')} — {h.get('description','')}"
            extra=f"{h.get('hazard_type','')} · значимость: {h.get('significant','')} · ККТ: {h.get('ccp_status','')}"
            label(self.risk_detail,text,size=9,fg=INK,bg=ENTRY,wraplength=790,justify='left').pack(anchor='w',padx=14,pady=(3,0))
            label(self.risk_detail,extra,size=8,fg=MUTED,bg=ENTRY,wraplength=790,justify='left').pack(anchor='w',padx=25,pady=(0,4))

    def show_documents_center(self):
        if not self._need_venue():return
        self._mode='documents';self._activate_nav('documents');self._clear();self._update_metrics()
        self.eyebrow.configure(text='ЦЕНТР ДОКУМЕНТОВ')
        self.heading.configure(text='Word, PDF и печать')
        self.subhead.configure(text='Редактирование, проверка и сохранение комплекта в одном месте')
        docs=selected(self.store,self.venue_id)
        self._set_footer('←  Обзор',self.show_dashboard,f'В комплекте: {len(docs)} журналов','Сохранить комплект  →',lambda:self.show(9),0)
        p=self.panel();self.heading2(p,'Что вы хотите сделать?','Выберите действие — сложные настройки останутся внутри соответствующего инструмента.')
        row=tk.Frame(p,bg=CARD);row.pack(fill='x')
        def doc_card(title,big,desc,cmd,accent):
            box=tk.Frame(row,bg=CARD2,highlightthickness=1,highlightbackground=EDGE);box.pack(side='left',fill='both',expand=True,padx=5)
            label(box,big,size=26,fg=accent,bg=CARD2,bold=True).pack(anchor='w',padx=16,pady=(16,3))
            label(box,title,size=12,bg=CARD2,bold=True).pack(anchor='w',padx=16)
            label(box,desc,size=9,fg=SOFT,bg=CARD2,wraplength=245,justify='left').pack(anchor='w',padx=16,pady=(6,12))
            button(box,'Открыть  →',cmd,padx=10,pady=7).pack(anchor='w',padx=16,pady=(0,16))
        doc_card('Редактор Word','DOCX','Открыть готовый Word-файл, изменить текст или таблицу и сохранить копию.',self.show_word_editor,CYAN)
        doc_card('Проверка комплекта','✓','Просмотреть замечания, выбранные журналы и предварительный вид.',lambda:self.show(8),GREEN)
        doc_card('Word + PDF','↓','Сохранить весь комплект в выбранную папку и открыть PDF для печати.',lambda:self.show(9),LIME)
        p2=self.panel();self.heading2(p2,'Документы комплекта')
        if not docs:label(p2,'Журналы ещё не выбраны.',size=10,fg=SOFT).pack(anchor='w')
        for t in docs[:10]:
            bar=tk.Frame(p2,bg=ENTRY);bar.pack(fill='x',pady=3)
            label(bar,'▤',size=11,fg=CYAN,bg=ENTRY).pack(side='left',padx=(12,9))
            label(bar,t.title,size=9,bg=ENTRY,wraplength=650,justify='left').pack(side='left',fill='x',expand=True,pady=9)
        if len(docs)>10:label(p2,f'Ещё документов: {len(docs)-10}',size=8,fg=MUTED).pack(anchor='w',pady=(6,0))
        if self._last_folder:
            p3=self.panel();self.heading2(p3,'Последний экспорт')
            label(p3,str(self._last_folder),size=9,fg=SOFT,wraplength=780,justify='left').pack(anchor='w')
            button(p3,'Открыть папку  ↗',self.open_output,padx=12,pady=7).pack(anchor='w',pady=(10,0))

    def show(self,step):
        self._mode='wizard'
        self._activate_nav('wizard')
        self._wizard_step=step
        self.step=max(0,min(len(STEPS)-1,step))
        self.eyebrow.configure(text=f'МАСТЕР · ШАГ {step+1:02d} / {len(STEPS):02d}')
        self.heading.configure(text=STEPS[step][0]);self.subhead.configure(text=STEPS[step][1])
        self._update_metrics()
        self._set_footer('←  Назад' if step>0 else '←  Обзор',self.previous if step>0 else self.show_dashboard,
                         f'{step+1} из {len(STEPS)} · изменения сохраняются',
                         'Готово  ✓' if step==len(STEPS)-1 else 'Далее  →',
                         self.finish if step==len(STEPS)-1 else self.advance,
                         (step+1)/len(STEPS))
        self._clear()
        try:
            render=(self.page_start,self.page_type,self.page_card,self.page_flags,
                    self.page_staff,self.page_journals,self.page_records,self.page_roles,
                    self.page_review,self.page_export)[step]
            render()
        except Exception as e:
            label(self.content,'Ошибка отображения: '+str(e),size=12,fg=DANGER,wraplength=700).pack(padx=8,pady=20)
            raise

    def jump(self,target):
        if self._mode=='word':
            self.word_view.exit_editor()
            if self._mode=='word':return
        if target==0:self.show(0);return
        if not self.venue_id:return
        if self._save_step():self.show(target)


    def show_flowcharts(self):
        if not self._need_venue():return
        if self._mode=='word' and hasattr(self,'word_view') and self.word_view.dirty:
            if not messagebox.askyesno('Несохранённые изменения','Перейти к блок-схемам без сохранения Word?'):return
        if self.venue_id and self._mode=='wizard' and not self._save_step():return
        self._mode='flows';self._activate_nav('flows');self._clear();self._update_metrics()
        self.eyebrow.configure(text='ВИЗУАЛЬНЫЙ МОДУЛЬ · ХАССП')
        self.heading.configure(text='Индивидуальные блок-схемы')
        self.subhead.configure(text='Несколько схем на предприятие · этапы, риски, ККТ, журналы и ответственные')
        self._set_footer('←  Обзор',self.show_dashboard,'Схемы сохраняются отдельно для выбранного предприятия','Мастер  →',lambda:self.show(max(1,self.step)),0)
        self.flow_view=FlowchartPane(self.content,self.store,self.venue_id,on_change=self._update_metrics)
        self.flow_view.pack(fill='both',expand=True,padx=2,pady=2)

    def show_word_editor(self):
        if self._mode=='word':return
        if self.venue_id and not self._save_step():return
        self._mode='word'
        self._wizard_step=self.step
        self._activate_nav('word')
        self.eyebrow.configure(text='ИНСТРУМЕНТ · WORD')
        self.heading.configure(text='Редактор Word')
        self.subhead.configure(text='Откройте DOCX → измените абзацы и таблицы → сохраните копию')
        self._update_metrics()
        self._set_footer('←  Обзор',self.show_dashboard,'Исходный документ сохраняется','Сохранить Word',self._editor_save,0)
        self._clear()
        self.word_view=WordEditorPane(self.content,on_exit=self._return_from_editor)
        self.word_view.pack(fill='both',expand=True)
        # Word editor has its own large scrollable preview; outer scroll handles small screens.

    def _editor_save(self):
        if self._mode=='word':self.word_view.save_as()

    def _return_from_editor(self):
        self.show(self._wizard_step)

    def return_wizard(self):
        if self._mode=='word':self.word_view.exit_editor()
        else:self.show(self._wizard_step)

    def advance(self):
        if self.step==0:
            if self.venue_id is None:
                messagebox.showinfo('Выберите предприятие','Нажмите «Создать новый комплект» или откройте сохранённый объект.')
                return
        if self._save_step():self.show(self.step+1)

    def previous(self):
        if self._save_step():self.show(self.step-1)

    def _save_step(self):
        if not self.venue_id:return True
        try:
            if self.step==1:
                kind=self.type_var.get()
                existing=self.store.get_venue(self.venue_id)
                if kind !=existing['kind']:
                    venue_update(self.store,self.venue_id,kind=kind,flags=defaults_for_type(kind))
            elif self.step==2:
                venue_update(self.store,self.venue_id,values={key:v.get() for key,v in self.card_vars.items()})
            elif self.step==7 and getattr(self,'_roles_dirty',False):
                if not self.apply_staff(silent=True):return False
            elif self.step==3:
                cur=self.store.get_venue(self.venue_id)
                flags=dict(cur['flags']);flags.update({key:bool(v.get()) for key,v in self.flag_vars.items()})
                venue_update(self.store,self.venue_id,flags=flags)
            return True
        except Exception as ex:
            messagebox.showerror('Проверьте данные',str(ex));return False

    def page_start(self):
        p=self.panel(padx=27,pady=25)
        upper=tk.Frame(p,bg=CARD);upper.pack(fill='x')
        left=tk.Frame(upper,bg=CARD);left.pack(side='left',fill='both',expand=True)
        label(left,'ВАШИ ДОКУМЕНТЫ — БЕЗ СЛОЖНЫХ НАСТРОЕК',size=10,fg=CYAN,bold=True).pack(anchor='w')
        label(left,'ХАССП — по шагам.',size=27,bold=True).pack(anchor='w',pady=(8,5))
        label(left,'Вы выбираете и заполняете, программа собирает журналы.\nДальше — один клик для Word и PDF.',
              size=11,fg=SOFT,justify='left').pack(anchor='w',pady=(0,15))
        button(left,'+  Создать новый комплект',self.new_venue,primary=True).pack(anchor='w')
        self._draw_hero(upper)
        p=self.panel();self.heading2(p,'Ваши предприятия','Откройте ранее созданное предприятие — сотрудники и журналы сохраняются.')
        self.venues=self.store.list_venues()
        if not self.venues:
            label(p,'Пока нет сохранённых предприятий. Начните с кнопки выше.',size=10,fg=SOFT).pack(anchor='w')
        for row in self.venues[-12:]:
            bar=tk.Frame(p,bg=ENTRY);bar.pack(fill='x',pady=3)
            label(bar,'●',size=14,fg=LIME,bg=ENTRY).pack(side='left',padx=(12,9))
            label(bar,row['venue_name']+'   ·   '+row['kind'],size=11,bg=ENTRY).pack(side='left',fill='x',expand=True,pady=10)
            button(bar,'Удалить',lambda i=row['id']:self.delete_venue_ui(i),padx=9,pady=6).pack(side='right',padx=(2,7))
            button(bar,'Редактировать',lambda i=row['id']:self.edit_venue(i),padx=9,pady=6).pack(side='right',padx=2)
            button(bar,'Открыть →',lambda i=row['id']:self.open_venue(i),padx=10,pady=6).pack(side='right',padx=2)

    def _draw_hero(self,parent):
        can=tk.Canvas(parent,width=270,height=176,bg=CARD,highlightthickness=0)
        can.pack(side='right',padx=(10,0))
        dots=[(4,100),(36,90),(70,66),(105,74),(145,82),(179,50),(215,43),(265,29)]
        can.create_text(7,6,anchor='nw',text='МОЙ ПРОГРЕСС',font=(FONT,9,'bold'),fill=CYAN)
        can.create_line([(8+x*.91,42+y*.85) for x,y in dots],smooth=True,fill=CYAN,width=4)
        can.create_line([(8+x*.91,62+y*.85) for x,y in dots],smooth=True,fill=LIME,width=4)
        can.create_oval(222,62,234,74,fill=LIME,outline=CARD)
        can.create_text(255,149,text='ШАГ ЗА ШАГОМ',anchor='e',font=(FONT,9,'bold'),fill=SOFT)

    def new_venue(self):
        try:self.venue_id=make_venue(self.store)
        except Exception as e:messagebox.showerror('Ошибка',str(e));return
        self._roles_target='all'
        self.show(1)

    def open_venue(self,id):
        self.venue_id=id
        self._roles_target='all'
        self.step=1
        self.show_dashboard()

    def edit_venue(self,id):
        if not self.store.get_venue(id):
            messagebox.showerror('Предприятие не найдено','Возможно, оно уже было удалено.')
            self.show_dashboard();return
        self.venue_id=id
        self._roles_target='all'
        # Открываем сразу карточку реквизитов. Тип предприятия доступен кнопкой «Назад».
        self.show(2)

    def delete_venue_ui(self,id):
        venue=self.store.get_venue(id)
        if not venue:
            messagebox.showinfo('Уже удалено','Это предприятие больше не найдено в базе.')
            self.venue_id=None if self.venue_id==id else self.venue_id
            self.show_dashboard();return
        name=venue.get('venue_name') or 'Без названия'
        text=(f'Удалить предприятие «{name}»?\n\n'
              'Будут удалены его сотрудники, журналы, записи, подписанты, настройки, импортированные Word-шаблоны и данные ХАССП.\n\n'
              'Перед удалением программа автоматически создаст резервную копию базы.')
        if not messagebox.askyesno('Подтверждение удаления',text,icon='warning'):
            return
        try:
            backup=venue_delete(self.store,id,make_backup=True)
        except Exception as ex:
            messagebox.showerror('Не удалось удалить',str(ex));return
        if self.venue_id==id:
            self.venue_id=None
            self.step=0
            self._roles_target='all'
        messagebox.showinfo('Предприятие удалено',
            'Предприятие удалено.\n\nРезервная копия перед удалением:\n'+str(backup))
        self.show_dashboard()

    def page_type(self):
        v=self.store.get_venue(self.venue_id)
        self.type_var=tk.StringVar(value=v['kind'])
        p=self.panel();self.heading2(p,'Чем занимается предприятие?','Нажмите на одну карточку. Тип влияет на начальный набор процессов и рекомендуемых журналов.')
        grid=tk.Frame(p,bg=CARD);grid.pack(fill='x')
        options=[x for x in TYPE_FAVOURITES if x in TYPES]
        symbols={'Столовая':'♨','Кафе':'☕','Ресторан':'✦','Пекарня':'◈','Магазин продуктов':'▦'}
        self.type_buttons=[]
        for idx,name in enumerate(options):
            row,col=divmod(idx,3)
            bg=LIME if name==v['kind'] else CARD2
            b=tk.Button(grid,text=(symbols.get(name,'◈')+'   '+name),bg=bg,fg=NAV if name==v['kind'] else INK,
                        anchor='w',wraplength=190,justify='left',font=(FONT,11,'bold'),pady=15,padx=15,
                        relief='flat',bd=0,activebackground=LIME,cursor='hand2',
                        command=lambda s=name:self._choose_type(s))
            b.grid(row=row,column=col,sticky='ew',padx=5,pady=5)
            self.type_buttons.append((name,b))
        for j in range(3):grid.columnconfigure(j,weight=1)
        more=tk.Frame(p,bg=CARD);more.pack(fill='x',pady=(14,0))
        label(more,'Другая категория из каталога:',size=10,fg=SOFT).pack(side='left',padx=(0,12))
        cb=ttk.Combobox(more,values=TYPES,textvariable=self.type_var,state='readonly',width=32,font=(FONT,10))
        cb.pack(side='left');cb.bind('<<ComboboxSelected>>',lambda e:self._choose_type(self.type_var.get()))

    def _choose_type(self,name):
        self.type_var.set(name)
        for title,b in self.type_buttons:
            active=title==name
            b.configure(bg=LIME if active else CARD2,fg=NAV if active else INK)

    def page_card(self):
        v=self.store.get_venue(self.venue_id)
        p=self.panel();self.heading2(p,'Карточка предприятия','Заполните то, что знаете. Дополнительные сведения можно внести позже.')
        grid=tk.Frame(p,bg=CARD);grid.pack(fill='x')
        self.card_vars={}
        for i,(key,name) in enumerate(FIELD_NAMES):
            item=tk.Frame(grid,bg=CARD)
            item.grid(row=i//2,column=i%2,sticky='ew',padx=8,pady=9)
            label(item,name,size=10,fg=SOFT).pack(anchor='w',pady=(0,5))
            value=tk.StringVar(value=v.get(key,'') or '')
            self.card_vars[key]=value
            entry(item,value).pack(fill='x',ipady=8)
        for j in range(2):grid.columnconfigure(j,weight=1)
        label(p,'ИНН и ОГРН проверяются по длине и составу. Пустые поля допустимы.',size=9,fg=MUTED).pack(anchor='w',pady=(10,0))

    def page_flags(self):
        v=self.store.get_venue(self.venue_id)
        p=self.panel();self.heading2(p,'Какие процессы есть на объекте?','Отмечайте только то, что действительно выполняется. От этого зависит подбор документов.')
        grid=tk.Frame(p,bg=CARD);grid.pack(fill='x')
        self.flag_vars={}
        for idx,(code,name) in enumerate(flags_choice()):
            item=tk.Frame(grid,bg=CARD2)
            item.grid(row=idx//2,column=idx%2,sticky='ew',padx=5,pady=5)
            var=tk.BooleanVar(value=bool(v['flags'].get(code)))
            self.flag_vars[code]=var
            tk.Checkbutton(item,text=name,variable=var,bg=CARD2,fg=INK,selectcolor=ENTRY,
                activebackground=CARD2,activeforeground=INK,wraplength=335,justify='left',
                font=(FONT,10),anchor='w',padx=13,pady=14).pack(fill='x')
        for j in range(2):grid.columnconfigure(j,weight=1)
        label(p,'Если нужного процесса нет в списке, его можно добавить в расширенной версии.',
              size=9,fg=SOFT).pack(anchor='w',pady=(12,0))

    def page_staff(self):
        p=self.panel();self.heading2(p,'Кто работает на предприятии?','Сотрудники сохраняются между сеансами. При необходимости можно вернуться и изменить список.')
        bar=tk.Frame(p,bg=CARD);bar.pack(fill='x',pady=(0,15))
        button(bar,'+  Добавить сотрудника',lambda:self.employee_dialog(),primary=True).pack(side='left')
        button(bar,'Редактировать',lambda:self.employee_dialog(edit=True)).pack(side='left',padx=9)
        button(bar,'В архив',self.employee_archive).pack(side='left')
        self.staff_tree=ttk.Treeview(p,columns=('name','position','department'),show='headings',height=11)
        for key,name,width in [('name','ФИО',240),('position','Должность',210),('department','Подразделение',160)]:
            self.staff_tree.heading(key,text=name);self.staff_tree.column(key,width=width,anchor='w')
        self.staff_tree.pack(fill='both',expand=True)
        self.staff_tree.bind('<Double-Button-1>',lambda e:self.employee_dialog(edit=True))
        self.refresh_staff()
        button(p,'📚  Открыть каталог 209 должностей',lambda:self.choose_position_catalog(),padx=11).pack(anchor='w',pady=(11,1))
        label(p,'Чтобы убрать сотрудника из новых документов, перенесите его в архив. Старые документы останутся неизменны.',
              size=9,fg=SOFT,wraplength=760,justify='left').pack(anchor='w',pady=(12,0))

    def refresh_staff(self):
        if not hasattr(self,'staff_tree') or not self.staff_tree.winfo_exists():return
        for item in self.staff_tree.get_children():self.staff_tree.delete(item)
        for person in list_employees(self.store,self.venue_id):
            self.staff_tree.insert('','end',iid=str(person['id']),values=(person['full_name'],person['position_name'],person['department']))

    def employee_dialog(self, edit=False, for_signer=False):
        """Create/edit an employee from either the roster or the signing step.

        When launched from the signing step, preserve unsaved checkboxes and
        automatically tick the newly created employee without inventing a signature.
        """
        emp_id=None
        if edit:
            if not hasattr(self,'staff_tree') or not self.staff_tree.winfo_exists():
                return
            ids=self.staff_tree.selection()
            if not ids:
                messagebox.showinfo('Выберите работника','Выберите строку сотрудника в списке.')
                return
            emp_id=int(ids[0])
        person=get_employee(self.store,self.venue_id,emp_id) if emp_id else {}
        top=tk.Toplevel(self)
        top.title('Новый подписант' if for_signer else 'Карточка сотрудника')
        top.configure(bg=BG)
        top.geometry('650x690');top.minsize(570,590);top.transient(self)
        frm=tk.Frame(top,bg=BG);frm.pack(fill='both',expand=True,padx=26,pady=20)
        label(frm,'Добавить подписанта' if for_signer else 'Сотрудник',size=18,bold=True).pack(anchor='w',pady=(0,12))
        if for_signer:
            label(frm,'Работник сохранится в справочнике и будет отмечен для ознакомления.',
                  size=9,fg=CYAN,wraplength=480,justify='left').pack(anchor='w',pady=(0,6))
        fields=[('full_name','ФИО *'),('position_name','Должность *'),('department','Подразделение'),
                ('phone','Телефон'),('qualification','Примечание / квалификация')]
        vs={}
        self._employee_position_code=tk.StringVar(value=person.get('position_code','') if person else '')
        for key,title in fields:
            label(frm,title,size=10,fg=SOFT).pack(anchor='w',pady=(4,3))
            var=tk.StringVar(value=(person.get(key,'') if person else '') or '')
            vs[key]=var
            line=tk.Frame(frm,bg=BG);line.pack(fill='x')
            entry(line,var,width=55).pack(side='left',fill='x',expand=True,ipady=6)
            if key=='position_name':
                button(line,'Из справочника',lambda:self.choose_position_catalog(vs,self._employee_position_code,top),primary=True,padx=10,pady=7).pack(side='left',padx=(9,0))
        note=label(frm,'Должность из справочника → обязанности и требования ХАССП будут доступны для добавления к журналам.',
            size=9,fg=CYAN,wraplength=580,justify='left')
        note.pack(anchor='w',pady=(9,3))
        self._employee_pos_info=label(frm,'',size=9,fg=SOFT,wraplength=580,justify='left')
        self._employee_pos_info.pack(anchor='w')
        def pos_updated(*_):
            position=get_position(self._employee_position_code.get())
            if position and vs['position_name'].get()==position.title:
                self._employee_pos_info.configure(text=f'{position.sector} · Обязанностей: {len(position.duties)} · Требований: {len(position.requirements)}')
            elif position:
                self._employee_position_code.set('')
                self._employee_pos_info.configure(text='Своя должность: автоматические обязанности не добавляются')
            else:self._employee_pos_info.configure(text='Выберите должность из справочника, чтобы включить типовые требования')
        vs['position_name'].trace_add('write',pos_updated)
        pos_updated()
        bar=tk.Frame(frm,bg=BG);bar.pack(fill='x',pady=16)
        def save():
            try:
                new_id=save_employee(self.store,self.venue_id,vs['full_name'].get(),
                    position_code=self._employee_position_code.get(),position_name=vs['position_name'].get(),department=vs['department'].get(),
                    phone=vs['phone'].get(),qualification=vs['qualification'].get(),employee_id=emp_id)
                if for_signer:
                    draft=self._roles_snapshot()
                    draft['ack_ids'].add(new_id)
                    self._roles_draft=draft
                top.destroy()
                if for_signer:
                    self.show(7)
                else:
                    self.refresh_staff();self.show(self.step)
            except Exception as ex:
                messagebox.showerror('Ошибка',str(ex),parent=top)
        button(bar,'Сохранить и добавить' if for_signer else 'Сохранить',save,primary=True).pack(side='right')
        button(bar,'Отмена',top.destroy).pack(side='right',padx=10)
        top.bind('<Escape>',lambda e:top.destroy())
        top.bind('<Return>',lambda e:save())
        top.grab_set()
        top.after(70,lambda:top.focus_force() if top.winfo_exists() else None)

    def choose_position_catalog(self, form=None, code_var=None, parent=None):
        """Search 209 titles, 17 sectors; inspect duties/HACCP requirements before picking."""
        top=tk.Toplevel(self);top.title('Справочник должностей · пищевая промышленность');top.configure(bg=BG)
        top.geometry('1050x735');top.minsize(840,590);top.transient(parent or self)
        head=tk.Frame(top,bg=BG);head.pack(fill='x',padx=18,pady=(17,8))
        label(head,f'Выбор должности · {len(POSITIONS)} вариантов',size=17,bold=True).pack(anchor='w')
        label(head,'Типовые обязанности и требования ХАССП — рекомендации, которые следует адаптировать к предприятию.',
              size=9,fg=SOFT).pack(anchor='w',pady=(5,0))
        searchbar=tk.Frame(top,bg=BG);searchbar.pack(fill='x',padx=18,pady=10)
        sector=tk.StringVar(value='Все отрасли')
        industries=['Все отрасли']+sorted({p.sector for p in POSITIONS})
        ttk.Combobox(searchbar,textvariable=sector,values=industries,state='readonly',width=24).pack(side='left',padx=(0,9))
        query=tk.StringVar()
        entry(searchbar,query,width=45).pack(side='left',fill='x',expand=True,ipady=5)
        pane=tk.PanedWindow(top,orient='horizontal',bg=BG,sashwidth=7)
        pane.pack(fill='both',expand=True,padx=18)
        left=tk.Frame(pane,bg=CARD);right=tk.Frame(pane,bg=CARD)
        pane.add(left,minsize=280,width=410);pane.add(right,minsize=340)
        tree=ttk.Treeview(left,columns=('sector',),show='tree headings',height=15)
        tree.heading('#0',text='Должность');tree.column('#0',width=270)
        tree.heading('sector',text='Отрасль');tree.column('sector',width=120)
        sb=ttk.Scrollbar(left,command=tree.yview);tree.configure(yscrollcommand=sb.set)
        sb.pack(side='right',fill='y');tree.pack(fill='both',expand=True,padx=8,pady=8)
        info=tk.Text(right,bg=CARD,fg=INK,relief='flat',wrap='word',font=(FONT,11),padx=18,pady=14)
        info.pack(fill='both',expand=True)
        info.tag_configure('heading',foreground=LIME,font=(FONT,13,'bold'),spacing3=8)
        info.tag_configure('sub',foreground=CYAN,font=(FONT,11,'bold'),spacing1=9)
        def redraw():
            for node in tree.get_children():tree.delete(node)
            found=search_positions(query.get(),'' if sector.get()=='Все отрасли' else sector.get())
            for p in found:tree.insert('','end',iid=p.code,text=p.title,values=(p.sector,))
            count.configure(text=f'Найдено: {len(found)}')
            if found:
                tree.selection_set(found[0].code);show_info()
            else:
                info.configure(state='normal');info.delete('1.0','end');info.insert('1.0','Ничего не найдено');info.configure(state='disabled')
        def show_info(ev=None):
            ids=tree.selection()
            if not ids:return
            pos=get_position(ids[0])
            info.configure(state='normal');info.delete('1.0','end')
            info.insert('end',pos.title+'\n','heading')
            info.insert('end',pos.sector+'\n\n')
            info.insert('end','ТИПОВЫЕ ОБЯЗАННОСТИ\n','sub')
            for v in pos.duties:info.insert('end','• '+v+'\n')
            info.insert('end','\nТРЕБОВАНИЯ ПО ХАССП\n','sub')
            for v in pos.requirements:info.insert('end','• '+v+'\n')
            desc,ref=reference(pos)
            info.insert('end','\nИсточник/статус: '+desc+'\n'+ref)
            info.configure(state='disabled')
        def choose():
            ids=tree.selection()
            if not ids:return
            pos=get_position(ids[0])
            if form is not None and code_var is not None:
                # Change title first so change observer cannot mistake new code for an edited title.
                form['position_name'].set(pos.title)
                code_var.set(pos.code)
            top.destroy()
        tree.bind('<<TreeviewSelect>>',show_info)
        tree.bind('<Double-Button-1>',lambda e:choose())
        query.trace_add('write',lambda *_:redraw())
        sector.trace_add('write',lambda *_:redraw())
        footer=tk.Frame(top,bg=BG);footer.pack(fill='x',padx=18,pady=12)
        count=label(footer,'',size=10,fg=SOFT);count.pack(side='left')
        button(footer,'Закрыть' if form is None else 'Отмена',top.destroy,padx=14).pack(side='right')
        if form is not None:button(footer,'✓  Выбрать должность',choose,primary=True).pack(side='right',padx=10)
        redraw()
        top.grab_set()

    def _roles_snapshot(self):
        """Keep temporary selections when the employee dialog rebuilds step 8."""
        if not hasattr(self,'ack_vars'):
            return {'venue_id':self.venue_id,'responsible_id':None,
                    'approved_id':None,'ack_ids':set(),'target':self._roles_target,'duties':False,'requirements':False}
        ids=getattr(self,'_role_ids',{})
        return {'venue_id':self.venue_id,
                'responsible_id':ids.get(self.responsible_var.get()) if hasattr(self,'responsible_var') else None,
                'approved_id':ids.get(self.approved_var.get()) if hasattr(self,'approved_var') else None,
                'ack_ids':{emp_id for emp_id,var in self.ack_vars.items() if var.get()},
                'target':self._roles_target,
                'duties':self.include_duties_var.get() if hasattr(self,'include_duties_var') else False,
                'requirements':self.include_requirements_var.get() if hasattr(self,'include_requirements_var') else False}

    def select_all_signers(self,checked=True):
        for var in getattr(self,'ack_vars',{}).values():
            var.set(bool(checked))

    def _signer_selection_changed(self,*_):
        self._roles_dirty=True
        count=sum(v.get() for v in getattr(self,'ack_vars',{}).values())
        if hasattr(self,'signer_count_label') and self.signer_count_label.winfo_exists():
            self.signer_count_label.configure(text=f'Отмечено сотрудников: {count}')

    def employee_archive(self):
        ids=self.staff_tree.selection()
        if not ids:return
        if messagebox.askyesno('Архив сотрудника','Сотрудник не будет включаться в новые документы. Продолжить?'):
            archive_employee(self.store,self.venue_id,int(ids[0]));self.refresh_staff()

    def page_journals(self):
        p=self.panel();self.heading2(p,'Рекомендуемый комплект журналов','Галочка означает, что журнал войдёт в экспорт. Можно вручную включать и исключать формы.')
        actions=tk.Frame(p,bg=CARD);actions.pack(fill='x',pady=(0,10))
        label(actions,'Поиск:',size=10,fg=SOFT).pack(side='left')
        self.journal_query=tk.StringVar(value='')
        e=entry(actions,self.journal_query,width=38);e.pack(side='left',padx=10,ipady=6)
        self.journal_query.trace_add('write',lambda *a:self.refresh_journals())
        button(actions,'Все рекомендованные',self.reset_recommended,padx=9,pady=8).pack(side='right')
        self.journal_tree=ttk.Treeview(p,columns=('on','title','group'),show='headings',height=13,selectmode='browse')
        self.journal_tree.heading('on',text='В комплекте')
        self.journal_tree.heading('title',text='Название журнала')
        self.journal_tree.heading('group',text='Группа')
        self.journal_tree.column('on',width=120,anchor='center',stretch=False)
        self.journal_tree.column('title',width=430)
        self.journal_tree.column('group',width=155)
        self.journal_tree.pack(fill='both',expand=True)
        self.journal_tree.bind('<Double-Button-1>',lambda e:self.toggle_selected())
        bot=tk.Frame(p,bg=CARD);bot.pack(fill='x',pady=(12,0))
        button(bot,'✓  Включить / исключить',self.toggle_selected,primary=True,padx=12).pack(side='left')
        self.journal_reason=label(bot,'Выберите журнал для просмотра объяснения.',size=9,fg=SOFT,wraplength=590,justify='left')
        self.journal_reason.pack(side='left',padx=18)
        self.journal_tree.bind('<<TreeviewSelect>>',self.set_journal_hint)
        self.refresh_journals()

    def refresh_journals(self):
        if not hasattr(self,'journal_tree') or not self.journal_tree.winfo_exists():return
        self._selection_codes=[]
        for item in self.journal_tree.get_children():self.journal_tree.delete(item)
        for x in recommended(self.store,self.venue_id,self.journal_query.get()):
            t=x['template'];self._selection_codes.append(t.code)
            self.journal_tree.insert('','end',iid=t.code,values=('✓' if x['selected'] else '+',t.title,t.group))
        self.journal_reason.configure(text='Двойной щелчок по журналу — добавить или убрать из комплекта.')

    def toggle_selected(self):
        ids=self.journal_tree.selection()
        if not ids:return
        code=ids[0]
        row=self.store.get_venue(self.venue_id)
        t=next(t for t in recommended(self.store,self.venue_id) if t['template'].code==code)
        toggle_journal(self.store,self.venue_id,code,not t['selected'])
        self.refresh_journals()
        if self.journal_tree.exists(code):self.journal_tree.selection_set(code)
        self.metric_labels[0].configure(text=str(len(selected(self.store,self.venue_id))))

    def set_journal_hint(self,event=None):
        ids=self.journal_tree.selection()
        if not ids:return
        x=next((x for x in recommended(self.store,self.venue_id) if x['template'].code==ids[0]),None)
        if x:self.journal_reason.configure(text=x['reason'][:170])

    def reset_recommended(self):
        for t in recommended(self.store,self.venue_id):self.store.set_override(self.venue_id,t['template'].code,None)
        self.refresh_journals()
        self.metric_labels[0].configure(text=str(len(selected(self.store,self.venue_id))))

    def page_records(self):
        p=self.panel();self.heading2(p,'Фактические записи (необязательно)',
            'Вносите только реальные измерения и действия. Пустые журналы тоже можно сохранить в Word/PDF для заполнения вручную.')
        items=selected(self.store,self.venue_id)
        if not items:label(p,'Сначала включите журналы на предыдущем шаге.',fg=DANGER).pack(anchor='w');return
        self.rec_choice=tk.StringVar(value=items[0].title)
        self._rec_map={t.title:t for t in items}
        box=tk.Frame(p,bg=CARD);box.pack(fill='x')
        label(box,'Журнал:',size=10,fg=SOFT).pack(side='left',padx=(0,10))
        cb=ttk.Combobox(box,textvariable=self.rec_choice,values=list(self._rec_map),state='readonly',width=62)
        cb.pack(side='left',fill='x',expand=True)
        cb.bind('<<ComboboxSelected>>',lambda e:self.refresh_records())
        button(box,'+  Добавить запись',self.new_record,primary=True,padx=11).pack(side='left',padx=10)
        self.rec_count=label(p,'',size=10,fg=SOFT);self.rec_count.pack(anchor='w',pady=(16,8))
        self.rec_tree=ttk.Treeview(p,columns=('date','description'),show='headings',height=11)
        self.rec_tree.heading('date',text='Добавлено')
        self.rec_tree.heading('description',text='Данные')
        self.rec_tree.column('date',width=165,stretch=False)
        self.rec_tree.column('description',width=520)
        self.rec_tree.pack(fill='both',expand=True)
        label(p,'Запись нельзя незаметно удалить или подменить. Ошибки исправляются с фиксацией причины.',size=9,fg=MUTED).pack(anchor='w',pady=(13,0))
        self.refresh_records()

    def refresh_records(self):
        if not hasattr(self,'rec_tree') or not self.rec_tree.winfo_exists():return
        for c in self.rec_tree.get_children():self.rec_tree.delete(c)
        t=self._rec_map.get(self.rec_choice.get())
        if not t:return
        records=self.store.list_records(self.venue_id,t.code)
        self.rec_count.configure(text=f'Внесено записей: {len(records)}')
        cols=dict(columns_for(self.store,self.venue_id,t))
        for r in records:
            info='  ·  '.join(f'{cols.get(k,k)}: {v}' for k,v in r['data'].items() if str(v).strip())[:250]
            if r['voided_at']:info='[ОТМЕНЕНА] '+info
            self.rec_tree.insert('','end',values=(r['created_at'][:16].replace('T',' '),info))

    def new_record(self):
        t=self._rec_map.get(self.rec_choice.get())
        if not t:return
        cols=columns_for(self.store,self.venue_id,t)
        top=tk.Toplevel(self);top.title('Новая запись • '+t.title);top.configure(bg=BG)
        top.geometry('740x670');top.transient(self);top.grab_set()
        label(top,t.title,size=16,bold=True,wraplength=690).pack(anchor='w',padx=25,pady=(18,7))
        label(top,'Оставьте пустыми поля, которые не измеряли. Не вводите вымышленные значения.',size=10,fg=SOFT).pack(anchor='w',padx=25)
        cv=tk.Canvas(top,bg=BG,highlightthickness=0)
        sb=ttk.Scrollbar(top,orient='vertical',command=cv.yview)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side='right',fill='y',padx=7)
        cv.pack(fill='both',expand=True,padx=25,pady=(7,0))
        interior=tk.Frame(cv,bg=BG);wid=cv.create_window((0,0),window=interior,anchor='nw')
        interior.bind('<Configure>',lambda e:cv.configure(scrollregion=cv.bbox('all')))
        cv.bind('<Configure>',lambda e:cv.itemconfigure(wid,width=e.width))
        vals={}
        for key,title in cols:
            label(interior,title,size=10,fg=SOFT,wraplength=640,justify='left').pack(anchor='w',pady=(9,3))
            var=tk.StringVar();vals[key]=var
            entry(interior,var,width=65).pack(fill='x',ipady=6)
        buttons=tk.Frame(top,bg=BG);buttons.pack(fill='x',padx=25,pady=17)
        def save():
            try:self.store.add_record(self.venue_id,t.code,{k:v.get() for k,v in vals.items()})
            except Exception as ex:messagebox.showerror('Не сохранено',str(ex),parent=top);return
            top.destroy();self.refresh_records()
        button(buttons,'Сохранить запись',save,primary=True).pack(side='right')
        button(buttons,'Отмена',top.destroy).pack(side='right',padx=9)

    def _roles_document_keys(self):
        codes=[t.code for t in selected(self.store,self.venue_id)]
        return codes if self._roles_target=='all' else [self._roles_target]

    def switch_roles_journal(self,event=None):
        title=self._role_journal_var.get()
        target=self._role_label_to_code.get(title,'all')
        if target==self._roles_target:return
        if getattr(self,'_roles_dirty',False) and not self.apply_staff(silent=True):
            return
        self._roles_target=target
        self.show(7)

    def page_roles(self):
        p=self.panel()
        self.heading2(p,'Подписанты и сведения о должностях',
            'Можно назначить разных ответственных и разные приложения для каждого журнала.')
        journals=selected(self.store,self.venue_id)
        allowed={x.code for x in journals}
        if self._roles_target!='all' and self._roles_target not in allowed:self._roles_target='all'
        self._role_label_to_code={'Все выбранные журналы':'all'}
        for x in journals:self._role_label_to_code[x.title+'  ['+x.code+']']=x.code
        current=next((k for k,v in self._role_label_to_code.items() if v==self._roles_target),'Все выбранные журналы')
        chooser=tk.Frame(p,bg=CARD);chooser.pack(fill='x',pady=(0,14))
        label(chooser,'Настраиваем:',size=10,fg=CYAN,bold=True).pack(side='left',padx=(0,9))
        self._role_journal_var=tk.StringVar(value=current)
        combo=ttk.Combobox(chooser,textvariable=self._role_journal_var,values=list(self._role_label_to_code),
              state='readonly',width=63)
        combo.pack(side='left',fill='x',expand=True)
        combo.bind('<<ComboboxSelected>>',self.switch_roles_journal)
        label(p,'В режиме «Все выбранные журналы» выбранные настройки копируются во все журналы. '
              'Чтобы изменить один журнал — выберите его выше.',size=9,fg=SOFT,wraplength=790,justify='left').pack(anchor='w',pady=(0,10))
        people=list_employees(self.store,self.venue_id)
        toolbar=tk.Frame(p,bg=CARD);toolbar.pack(fill='x',pady=(1,10))
        button(toolbar,'+ Добавить подписанта',lambda:self.employee_dialog(for_signer=True),primary=True,padx=10).pack(side='left')
        button(toolbar,'Отметить всех',lambda:self.select_all_signers(True),padx=8).pack(side='left',padx=6)
        button(toolbar,'Снять отметки',lambda:self.select_all_signers(False),padx=8).pack(side='left')
        self.signer_count_label=label(p,'',size=10,fg=CYAN,bold=True);self.signer_count_label.pack(anchor='w',pady=(0,8))
        source_code=self._roles_document_keys()[0] if journals else None
        key='journal:'+source_code if source_code else None
        conf=get_assignments(self.store,self.venue_id,key) if key else {'people':{},'include_duties':False,'include_requirements':False}
        prior=conf['people']
        previous_acks={e['id'] for e in list_acknowledgements(self.store,self.venue_id,key)} if key else set()
        draft=getattr(self,'_roles_draft',None)
        use_draft=bool(draft and draft.get('venue_id')==self.venue_id and draft.get('target','all')==self._roles_target)
        if use_draft:previous_acks=set(draft['ack_ids'])
        self._roles_draft=None
        self._role_ids={};names=['— Не выбран —']
        for e in people:
            name=f"{e['full_name']} · {e['position_name']}  (№ {e['id']})"
            names.append(name);self._role_ids[name]=e['id']
        from_id={v:k for k,v in self._role_ids.items()}
        resp=(draft.get('responsible_id') if use_draft else (prior.get('responsible') or {}).get('id'))
        approved=(draft.get('approved_id') if use_draft else (prior.get('approved') or {}).get('id'))
        roles=tk.Frame(p,bg=CARD);roles.pack(fill='x',pady=5)
        self.responsible_var=tk.StringVar(value=from_id.get(resp,names[0]))
        self.approved_var=tk.StringVar(value=from_id.get(approved,names[0]))
        for idx,(title,v) in enumerate((('Ответственный за журнал',self.responsible_var),('Утверждает документ',self.approved_var))):
            b=tk.Frame(roles,bg=CARD);b.grid(row=0,column=idx,sticky='ew',padx=7)
            label(b,title,size=10,fg=SOFT).pack(anchor='w',pady=(0,6))
            ttk.Combobox(b,textvariable=v,values=names,state='readonly',width=35).pack(fill='x',ipady=2)
        roles.columnconfigure(0,weight=1);roles.columnconfigure(1,weight=1)
        label(p,'Сотрудники, которые ознакомятся с журналом:',size=11,bold=True).pack(anchor='w',pady=(14,7))
        self.ack_vars={}
        if not people:
            label(p,'Нажмите «Добавить подписанта» выше.',size=10,fg=SOFT).pack(anchor='w')
        else:
            container=tk.Frame(p,bg=CARD);container.pack(fill='x')
            for idx,person in enumerate(people):
                var=tk.BooleanVar(value=person['id'] in previous_acks)
                self.ack_vars[person['id']]=var
                tk.Checkbutton(container,text=person['full_name']+' · '+person['position_name'],variable=var,
                    fg=INK,bg=CARD,selectcolor=ENTRY,activebackground=CARD,activeforeground=INK,font=(FONT,10),
                    anchor='w',padx=8,pady=5,wraplength=330,justify='left').grid(row=idx//2,column=idx%2,sticky='ew')
            for idx in range(2):container.columnconfigure(idx,weight=1)
        extras=tk.Frame(p,bg=CARD);extras.pack(fill='x',pady=(14,6))
        label(extras,'ДОБАВИТЬ НИЖЕ ОСНОВНОГО ЖУРНАЛА',size=10,fg=CYAN,bold=True).pack(anchor='w',pady=(4,7))
        self.include_duties_var=tk.BooleanVar(value=(draft.get('duties') if use_draft else conf['include_duties']))
        self.include_requirements_var=tk.BooleanVar(value=(draft.get('requirements') if use_draft else conf['include_requirements']))
        for v,title in [(self.include_duties_var,'Приложение: типовые обязанности выбранных должностей'),
                        (self.include_requirements_var,'Приложение: требования к соблюдению ХАССП')]:
            tk.Checkbutton(extras,text=title,variable=v,bg=CARD,fg=INK,activebackground=CARD,
                activeforeground=INK,selectcolor=ENTRY,font=(FONT,11),anchor='w',pady=5).pack(anchor='w')
        label(extras,'Включаются сведения о назначенных ответственных и отмеченных работниках. '
              'Фактические подписи и даты никогда не подставляются. Для собственных должностей сведения не выдумываются.',
              size=9,fg=SOFT,wraplength=750,justify='left').pack(anchor='w',pady=(3,5))
        self._roles_dirty=bool(use_draft)
        for v in (self.responsible_var,self.approved_var,*self.ack_vars.values(),self.include_duties_var,self.include_requirements_var):
            v.trace_add('write',self._signer_selection_changed)
        self._signer_selection_changed();self._roles_dirty=bool(use_draft)
        button(p,'✓  Сохранить настройки выбранного журнала',self.apply_staff,primary=True,padx=12).pack(anchor='w',pady=(10,0))
        label(p,'Или нажмите «Далее» — выбор будет сохранён.',fg=CYAN,size=10).pack(anchor='w',pady=(8,0))

    def apply_staff(self,silent=False):
        try:
            codes=self._roles_document_keys()
            if not codes:
                messagebox.showwarning('Нет журналов','Сначала включите хотя бы один журнал на шаге 6.')
                return False
            resp=self._role_ids.get(self.responsible_var.get())
            approved=self._role_ids.get(self.approved_var.get())
            ack=[key for key,v in self.ack_vars.items() if v.get()]
            apply_staff_to_documents(self.store,self.venue_id,codes,resp,approved,ack,
                include_duties=self.include_duties_var.get(),include_requirements=self.include_requirements_var.get())
            self._roles_dirty=False
            if not silent:messagebox.showinfo('Сохранено',f'Сохранено для {len(codes)} журналов.\nВ листе ознакомления: {len(ack)} сотрудников.')
            return True
        except Exception as ex:messagebox.showerror('Ошибка',str(ex));return False

    def page_review(self):
        info=overview(self.store,self.venue_id)
        p=self.panel()
        self.heading2(p,'Всё почти готово','Проверка помогает заметить незаполненные поля, но не является юридической сертификацией ХАССП.')
        cards=tk.Frame(p,bg=CARD);cards.pack(fill='x',pady=(4,18))
        for key,title in [('journals','Журналов'),('staff','Сотрудников'),('processes','Процессов')]:
            panel=tk.Frame(cards,bg=CARD2,width=205,height=98);panel.pack(side='left',fill='x',expand=True,padx=5)
            panel.pack_propagate(False)
            label(panel,str(info[key]),size=26,fg=LIME,bg=CARD2,bold=True).pack(pady=(11,0))
            label(panel,title,size=10,fg=SOFT,bg=CARD2).pack()
        self.heading2(p,'Предварительная проверка')
        try:
            result=audit_enterprise(self.store,self.venue_id)
            problems=result.get('issues',[])
            if not problems:label(p,'Замечаний в автоматической проверке не найдено.',size=10,fg=GREEN).pack(anchor='w')
            for i,issue in enumerate(problems[:14]):
                box=tk.Frame(p,bg=CARD2);box.pack(fill='x',pady=3)
                label(box,('● ' if i<8 else '○ ')+issue['text'],size=10,fg=SOFT,bg=CARD2,
                      wraplength=755,justify='left').pack(anchor='w',padx=12,pady=(8,3))
                label(box,'Совет: '+issue['action'],size=9,fg=CYAN,bg=CARD2,wraplength=750,justify='left').pack(anchor='w',padx=22,pady=(0,8))
        except Exception as ex:label(p,'Не удалось завершить проверку: '+str(ex),fg=DANGER).pack(anchor='w')
        p=self.panel();self.heading2(p,'Пример выбранного журнала')
        docs=selected(self.store,self.venue_id)
        if docs:
            t=docs[0]
            label(p,t.title,size=12,fg=LIME,bold=True).pack(anchor='w',pady=(0,8))
            header=tk.Frame(p,bg=ENTRY);header.pack(fill='x')
            for name in [x[1] for x in columns_for(self.store,self.venue_id,t)[:5]]:
                label(header,name[:40],size=9,fg=INK,bg=ENTRY,wraplength=120,justify='center').pack(side='left',fill='x',expand=True,padx=5,pady=14)
            label(p,'Предпросмотр граф · больше граф будет в Word/PDF. Пустые ячейки предназначены для реальных записей.',
                  size=9,fg=MUTED).pack(anchor='w',pady=(8,0))
        else:label(p,'Ни один журнал пока не выбран.',fg=DANGER).pack(anchor='w')

    def page_export(self):
        p=self.panel();self.heading2(p,'Куда сохранить комплект?','После создания документы можно открыть в Word, просмотреть в PDF или распечатать.')
        default=Path.home()/'Documents'/'MoOLVa HACCP'
        self.folder_var=tk.StringVar(value=str(default))
        row=tk.Frame(p,bg=CARD);row.pack(fill='x')
        entry(row,self.folder_var,width=58).pack(side='left',fill='x',expand=True,ipady=8)
        button(row,'Выбрать папку',self.pick_folder,padx=12).pack(side='left',padx=(12,0))
        label(p,'Форматы документов',size=12,bold=True).pack(anchor='w',pady=(21,7))
        cbrow=tk.Frame(p,bg=CARD);cbrow.pack(fill='x')
        self.docx_var=tk.BooleanVar(value=True);self.pdf_var=tk.BooleanVar(value=True)
        for v,title in ((self.docx_var,'Word (.docx) · редактируемый'),(self.pdf_var,'PDF (.pdf) · для печати')):
            tk.Checkbutton(cbrow,text=title,variable=v,bg=CARD2,fg=INK,selectcolor=ENTRY,
                activebackground=CARD2,activeforeground=INK,font=(FONT,11,'bold'),padx=15,pady=14).pack(side='left',fill='x',expand=True,padx=5)
        label(p,'Дополнительные документы',size=12,bold=True).pack(anchor='w',pady=(21,5))
        self.passport_var=tk.BooleanVar(value=True);self.audit_var=tk.BooleanVar(value=False)
        for var,text in ((self.passport_var,'Включить паспорт комплекта'),(self.audit_var,'Включить отчёт предварительной проверки')):
            tk.Checkbutton(p,text=text,variable=var,bg=CARD,fg=SOFT,selectcolor=ENTRY,
                activebackground=CARD,activeforeground=INK,font=(FONT,10)).pack(anchor='w',pady=4)
        self.export_start=button(p,'↓  СОХРАНИТЬ КОМПЛЕКТ WORD / PDF',self.run_export,primary=True,pady=15)
        self.export_start.pack(fill='x',pady=(22,5))
        self.export_info=label(p,'',size=10,fg=CYAN,wraplength=790,justify='left')
        self.export_info.pack(anchor='w',pady=8)
        self.open_folder_button=button(p,'Открыть папку с документами  ↗',self.open_output)
        self.open_pdf_button=button(p,'Открыть PDF для печати  ↗',self.open_pdf)
        label(p,'При выгрузке создаётся новая папка. Существующие файлы не перезаписываются.',
              size=9,fg=MUTED).pack(anchor='w',pady=(14,3))

    def pick_folder(self):
        folder=filedialog.askdirectory(title='Папка для сохранения документов')
        if folder:self.folder_var.set(folder)

    def run_export(self):
        if self._exporting:return
        forms=tuple(fmt for fmt,var in [('docx',self.docx_var),('pdf',self.pdf_var)] if var.get())
        if not forms:messagebox.showwarning('Выберите формат','Отметьте Word, PDF или оба формата.');return
        folder=Path(self.folder_var.get()).expanduser()
        if not folder.is_dir():
            if not messagebox.askyesno('Создать папку?',f'Создать папку\n{folder}?'):return
            try:folder.mkdir(parents=True,exist_ok=True)
            except OSError as ex:messagebox.showerror('Ошибка папки',str(ex));return
        self._exporting=True
        self.export_start.configure(state='disabled',text='Подготовка документов…')
        self.export_info.configure(text='Формируем пакет. Большие комплекты могут занять некоторое время…',fg=CYAN)
        args=(self.store,self.venue_id,folder,forms,self.passport_var.get(),self.audit_var.get())
        def work():
            try:res=export_pack_easy(*args)
            except Exception as ex:self.after(0,lambda err=str(ex):self._export_done(error=err))
            else:self.after(0,lambda r=res:self._export_done(result=r))
        threading.Thread(target=work,daemon=True).start()

    def _export_done(self,result=None,error=None):
        self._exporting=False
        if not self.winfo_exists():return
        self.export_start.configure(state='normal',text='↓  СОХРАНИТЬ КОМПЛЕКТ WORD / PDF')
        if error:
            self.export_info.configure(text='Не удалось сохранить: '+error,fg=DANGER)
            messagebox.showerror('Ошибка экспорта',error)
            return
        self._last_folder=result['folder']
        try:export_manifest_note(self.store,self.venue_id,self._last_folder)
        except Exception:pass
        line=f"Создано файлов: {len(result['files'])}. Ошибок: {len(result['errors'])}.\nПапка: {result['folder']}"
        self.export_info.configure(text=line,fg=GREEN if not result['errors'] else DANGER)
        self.open_folder_button.pack(anchor='w',pady=8)
        if any(f.suffix=='.pdf' for f in result['files']):self.open_pdf_button.pack(anchor='w',pady=3)
        self._last_files=result['files']
        if result['errors']:messagebox.showwarning('Часть документов не создана','\n'.join(result['errors'][:8]))
        else:messagebox.showinfo('Готово!','Документы сохранены. Нажмите «Открыть папку с документами».')

    def open_output(self):
        if not self._last_folder:return
        try:
            if os.name=='nt':os.startfile(str(self._last_folder))
            elif sys.platform=='darwin':import subprocess;subprocess.Popen(['open',str(self._last_folder)])
            else:import subprocess;subprocess.Popen(['xdg-open',str(self._last_folder)])
        except Exception as ex:messagebox.showerror('Ошибка открытия',str(ex))

    def open_pdf(self):
        for p in getattr(self,'_last_files',[]):
            if p.suffix=='.pdf':
                try:
                    if os.name=='nt':os.startfile(str(p))
                    else:
                        import subprocess
                        subprocess.Popen(['xdg-open',str(p)])
                except Exception as ex:messagebox.showerror('Не удалось открыть PDF',str(ex))
                return

    def finish(self):
        if self._exporting:return
        if self._last_folder: self.open_output()
        else: self.run_export()


def main():
    if '--ui-smoke' in sys.argv:
        from tempfile import TemporaryDirectory
        from flowchart_core import create_diagram, create_node
        with TemporaryDirectory() as tmp:
            store=init_store(Path(tmp)/'gui-smoke.sqlite3')
            venue=make_venue(store)
            create_node(store,create_diagram(store,venue,'Тестовая схема'),'Приёмка')
            win=EasyApp(store=store)
            win.venue_id=venue
            views=(win.show_dashboard,win.show_enterprises_center,win.show_flowcharts,
                   win.show_haccp_plans_center,win.show_journal_center,win.show_documents_center,
                   win.show_employee_center,win.show_analytics_center,win.show_alert_center,
                   win.show_settings_center)
            for view in views:
                view();win.update_idletasks()
            win.destroy()
        print('MoOLVa HACCP Easy GUI smoke: OK')
        return
    if '--self-test' in sys.argv:
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as tmp:
            store=init_store(Path(tmp)/'easy.sqlite3')
            i=make_venue(store)
            assert store.get_venue(i) and selected(store,i)
            from flowchart_core import create_diagram,create_node,add_edge,render_png
            d=create_diagram(store,i,'Self-test')
            a=create_node(store,d,'Приёмка');b=create_node(store,d,'Выдача');add_edge(store,d,a,b)
            png=render_png(store,d,Path(tmp)/'selftest.png')
            assert png.is_file() and png.stat().st_size>500
            s=live_snapshot(store,i)
            assert s['diagrams']==1 and s['venues']==1
        print('MoOLVa HACCP Easy self-test: OK')
        return
    try:
        root=EasyApp()
        root.mainloop()
    except Exception as ex:
        from storage import app_data_dir
        logfile=app_data_dir()/'easy-crash.log'
        try:
            logfile.parent.mkdir(parents=True,exist_ok=True)
            with logfile.open('a',encoding='utf-8') as log:
                log.write('\n'+datetime.now().isoformat()+'\n'+traceback.format_exc()+'\n')
        except OSError:pass
        try:
            alert=tk.Tk();alert.withdraw()
            messagebox.showerror('MoOLVa ХАССП Easy','Не удалось открыть программу: '+str(ex)+'\nЖурнал ошибки: '+str(logfile))
            alert.destroy()
        except tk.TclError:pass
        raise

if __name__=='__main__': main()
