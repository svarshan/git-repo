import tempfile
import unittest
from pathlib import Path
from easy_core import init_store, make_venue
from enterprise14_core import live_snapshot, activity_by_day, add_action, change_action, delete_action
from flowchart_core import create_diagram,create_node,add_edge,diagram_details,restore_diagram_snapshot,set_edge_label,update_node,list_diagrams

class Enterprise14Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=init_store(Path(self.temp.name)/'14.sqlite3')
        self.venue=make_venue(self.store)
        self.other=make_venue(self.store)
    def tearDown(self):self.temp.cleanup()
    def test_live_counts_isolation(self):
        d=create_diagram(self.store,self.venue,'Схема')
        self.assertEqual(live_snapshot(self.store,self.venue)['diagrams'],1)
        self.assertEqual(live_snapshot(self.store,self.other)['diagrams'],0)
        self.assertNotEqual(live_snapshot(self.store,self.venue)['issues'],[])
    def test_actions_lifecycle(self):
        aid=add_action(self.store,self.venue,'Проверить вентиляцию','2027-01-01')
        self.assertEqual(live_snapshot(self.store,self.venue)['actions'][0]['status'],'Открыто')
        change_action(self.store,self.venue,aid,'Выполнено')
        self.assertEqual(live_snapshot(self.store,self.venue)['actions'][0]['status'],'Выполнено')
        self.assertFalse(live_snapshot(self.store,self.other)['actions'])
        self.assertTrue(delete_action(self.store,self.venue,aid))
        self.assertFalse(live_snapshot(self.store,self.venue)['actions'])
    def test_invalid_action(self):
        with self.assertRaises(ValueError):add_action(self.store,self.venue,'')
        with self.assertRaises(ValueError):add_action(self.store,self.venue,'x','not-a-date')
    def test_snapshot_undo_and_link(self):
        d=create_diagram(self.store,self.venue,'Линия')
        n1=create_node(self.store,d,'Вход',node_type='Начало'); n2=create_node(self.store,d,'Контроль',node_type='Решение')
        edge=add_edge(self.store,d,n1,n2,'Да')
        snap=diagram_details(self.store,d)
        update_node(self.store,d,n2,node_type='ККТ')
        set_edge_label(self.store,d,edge,'Нет')
        restore_diagram_snapshot(self.store,d,snap)
        out=diagram_details(self.store,d)
        self.assertEqual(out['nodes'][1]['node_type'],'Решение')
        self.assertEqual(out['edges'][0]['label'],'Да')
    def test_snapshot_scope(self):
        a=create_diagram(self.store,self.venue,'A');b=create_diagram(self.store,self.other,'B')
        with self.assertRaises(ValueError):restore_diagram_snapshot(self.store,b,diagram_details(self.store,a))
    def test_activity_has_seven_points(self):
        self.assertEqual(len(activity_by_day(self.store,self.venue)),7)
