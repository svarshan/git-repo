"""Enterprise UI 1.4: grounded real-time local dashboard, linked stages and action center."""
from __future__ import annotations
import shutil
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from enterprise14_core import live_snapshot, add_action, change_action, delete_action, recent_events
from flowchart_core import diagram_details, list_diagrams
from haccp_core import HACCPPlans
from staff_store import list_employees
from roles_catalog import get_position
from storage import now

# Unified graphite / navy surfaces, accessible contrasting text.
BG='#111824'; NAV='#142031'; PANEL='#1A2739'; PANEL2='#22334A'; EDGE='#31445C'; INK='#F1F6FD';SOFT='#AFBDD0'; MUTED='#8297AE';CYAN='#29BFD1';LIME='#D5E744';GREEN='#34C9AB';WARN='#FFBD5C';RED='#F0717D';BLUE='#4C9BFF'
FONT='Segoe UI'

def txt(p,t,size=10,fg=INK,bold=False,wrap=None,**kw):
    return tk.Label(p,text=t,bg=p.cget('bg'),fg=fg,font=(FONT,size,'bold' if bold else 'normal'),
                    anchor='w',justify='left',wraplength=wrap or 0,**kw)

def cmd(p,t,fn,accent=False):
    return tk.Button(p,text=t,command=fn,relief='flat',cursor='hand2',bd=0,
                     bg=CYAN if accent else PANEL2,fg='#0C1824' if accent else INK,
                     activebackground='#79E2EC' if accent else EDGE,activeforeground=INK,
                     font=(FONT,10,'bold'),padx=14,pady=10)

class Enterprise14Mixin:
    def _view_start14(self, key, ey, heading, sub):
        self._mode=key;self._activate_nav(key);self._clear();self._update_metrics()
        self.eyebrow.configure(text=ey);self.heading.configure(text=heading);self.subhead.configure(text=sub)
        self._set_footer('←  Обзор',self.show_dashboard,'Локальные данные · обновляются после сохранения',
                         'Мастер заполнения  →',lambda:self.show(self.step if self.venue_id else 0),0)

    def _box14(self, parent=None, bg=PANEL, pad=18):
        w=tk.Frame(parent or self.content,bg=bg,highlightbackground=EDGE,highlightthickness=1)
        w.pack(fill='x',padx=4,pady=(0,11))
        inner=tk.Frame(w,bg=bg);inner.pack(fill='both',expand=True,padx=pad,pady=pad)
        return inner

    def _stat14(self,parent,value,title,note='',color=CYAN,action=None):
        f=tk.Frame(parent,bg=PANEL,highlightthickness=1,highlightbackground=EDGE)
        f.pack(side='left',fill='both',expand=True,padx=5)
        body=tk.Frame(f,bg=PANEL);body.pack(fill='x',padx=15,pady=14)
        txt(body,str(value),24,color,True).pack(anchor='w')
        txt(body,title,10,INK,True).pack(anchor='w')
        txt(body,note,8,MUTED).pack(anchor='w',pady=(5,0))
        if action:
            f.bind('<Button-1>',lambda e:action());body.bind('<Button-1>',lambda e:action())
            for child in body.winfo_children():child.bind('<Button-1>',lambda e:action())
        return f

    def _section14(self,parent,title,subtitle='',bg=PANEL):
        txt(parent,title,14,bold=True).pack(anchor='w',pady=(0,4))
        if subtitle:txt(parent,subtitle,9,MUTED,wrap=780).pack(anchor='w',pady=(0,12))

    def _mini_chart14(self,parent,points,title='Изменения за последние 7 дней'):
        txt(parent,title,11,bold=True).pack(anchor='w',pady=(0,5))
        canvas=tk.Canvas(parent,height=175,bg=parent.cget('bg'),highlightthickness=0)
        canvas.pack(fill='x',expand=True)
        def render(e=None):
            canvas.delete('all');w=max(canvas.winfo_width(),320);h=170
            values=[int(y) for _,y in points] or [0];maximum=max(1,max(values));n=len(values)
            l=34;r=w-14;top=18;bottom=h-36
            for k in range(4):
                y=top+(bottom-top)*k/3
                canvas.create_line(l,y,r,y,fill=EDGE,dash=(2,4))
                canvas.create_text(l-7,y,text=str(round(maximum*(3-k)/3)),fill=MUTED,anchor='e',font=(FONT,8))
            if n:
                coords=[]
                for i,(day,val) in enumerate(points):
                    x=l+(r-l)*(i/(n-1) if n>1 else .5)
                    y=bottom-(bottom-top)*val/maximum
                    coords.extend((x,y));canvas.create_text(x,h-15,text=day,fill=SOFT,font=(FONT,8))
                if len(coords)>=4:canvas.create_line(*coords,fill=CYAN,width=3,smooth=True)
                for i in range(0,len(coords),2):
                    canvas.create_oval(coords[i]-4,coords[i+1]-4,coords[i]+4,coords[i+1]+4,fill=CYAN,outline=PANEL)
            if not any(values):canvas.create_text(w/2,h/2,text='Изменений пока нет',fill=MUTED,font=(FONT,11))
        canvas.bind('<Configure>',render)
        return canvas

    def show_enterprise_dashboard(self):
        self._view_start14('dashboard','FOOD SAFETY INTELLIGENCE','Центр управления ХАССП',
                           'Документы, процессы, контроль и задачи в одном месте')
        if not self.venue_id or not self.store.get_venue(self.venue_id):
            p=self._box14();self._section14(p,'Начните с предприятия','Создайте объект или выберите уже сохранённый.')
            cmd(p,'+ Создать предприятие',self.new_venue,True).pack(anchor='w',pady=5)
            cmd(p,'Сохранённые предприятия  →',self.show_enterprises_center).pack(anchor='w',pady=5)
            return
        s=live_snapshot(self.store,self.venue_id)
        venue=self.store.get_venue(self.venue_id)
        hero=self._box14()
        left=tk.Frame(hero,bg=PANEL);left.pack(side='left',fill='both',expand=True)
        txt(left,'ТЕКУЩЕЕ ПРЕДПРИЯТИЕ',9,CYAN,True).pack(anchor='w')
        txt(left,venue.get('venue_name') or 'Без названия',22,INK,True,wrap=660).pack(anchor='w',pady=(5,7))
        txt(left,venue.get('kind') or 'Предприятие',10,SOFT).pack(anchor='w')
        bar=tk.Frame(left,bg=EDGE,height=8);bar.pack(fill='x',pady=(20,6));bar.pack_propagate(False)
        tk.Frame(bar,bg=GREEN).place(relx=0,y=0,relwidth=max(.001,s['completion']/100),relheight=1)
        txt(left,f"Заполненность данных: {s['completion']}%  ·  не является оценкой соответствия ХАССП",9,MUTED).pack(anchor='w')
        actions=tk.Frame(left,bg=PANEL);actions.pack(anchor='w',pady=(18,0))
        cmd(actions,'Продолжить мастер  →',lambda:self.show(max(1,self.step)),True).pack(side='left')
        cmd(actions,'Блок-схемы',self.show_flowcharts).pack(side='left',padx=8)
        ring=tk.Canvas(hero,width=165,height=165,bg=PANEL,highlightthickness=0)
        ring.pack(side='right',padx=(12,0))
        ring.create_arc(18,18,148,148,start=90,extent=359,outline=EDGE,style='arc',width=13)
        if s['completion']:ring.create_arc(18,18,148,148,start=90,extent=-3.6*s['completion'],outline=CYAN,style='arc',width=13)
        ring.create_text(83,78,text=f"{s['completion']}%",font=(FONT,26,'bold'),fill=INK)
        ring.create_text(83,104,text='заполнено',font=(FONT,9),fill=MUTED)
        st=tk.Frame(self.content,bg=BG);st.pack(fill='x',padx=2,pady=(0,12))
        self._stat14(st,s['journals'],'Журналы','выбрано',CYAN,self.show_journal_center)
        self._stat14(st,s['employees'],'Сотрудники','активные',GREEN,self.show_employee_center)
        self._stat14(st,s['diagrams'],'Блок-схемы','сохранено',BLUE,self.show_flowcharts)
        self._stat14(st,len(s['issues']),'Вопросы','требуют внимания',WARN,self.show_alert_center)
        band=self._box14();self._mini_chart14(band,s['activity'])
        info=self._box14();self._section14(info,'Что сделать дальше','Открывайте замечание — программа переведёт вас в соответствующий раздел.')
        for issue in s['issues'][:4]:
            row=tk.Frame(info,bg=PANEL2);row.pack(fill='x',pady=3)
            txt(row,'●',10,WARN).pack(side='left',padx=9)
            txt(row,issue['name']+' — '+issue['text'],9,INK,wrap=650).pack(side='left',fill='x',expand=True,pady=9)
            cmd(row,'Открыть',lambda key=issue['target']:self._navigate14(key)).pack(side='right',padx=8,pady=4)
        if not s['issues']:txt(info,'Структурных предупреждений не найдено. Проверьте актуальность документов и процедур на месте.',10,GREEN).pack(anchor='w')

    def _navigate14(self,kind):
        mapping={'journals':self.show_journal_center,'flows':self.show_flowcharts,'risks':self.show_risk_center,
                 'employees':self.show_employee_center,'alerts':self.show_alert_center,'documents':self.show_documents_center}
        mapping.get(kind,self.show_dashboard)()

    def show_enterprises_center(self):
        self._view_start14('enterprises','ПРЕДПРИЯТИЯ','Мои предприятия','Редактирование и удаление только выбранного объекта')
        p=self._box14();row=tk.Frame(p,bg=PANEL);row.pack(fill='x')
        self._section14(row,'Сохранённые объекты')
        cmd(row,'+ Добавить предприятие',self.new_venue,True).pack(anchor='w',pady=(5,14))
        for v in self.store.list_venues():
            line=tk.Frame(p,bg=PANEL2);line.pack(fill='x',pady=4)
            txt(line,v['venue_name'],11,INK,True,wrap=330).pack(side='left',fill='x',expand=True,padx=12,pady=15)
            for title,func in (('Удалить',self.delete_venue_ui),('Редактировать',self.edit_venue),('Открыть',self.open_venue)):
                cmd(line,title,lambda id=v['id'],f=func:f(id)).pack(side='right',padx=3,pady=5)

    def show_haccp_plans_center(self):
        if not self._need_venue():return
        self._view_start14('haccp','HACCP PLANS','Планы ХАССП','Опасности, ККТ, технологические этапы и связанные документы')
        s=live_snapshot(self.store,self.venue_id)
        st=tk.Frame(self.content,bg=BG);st.pack(fill='x',pady=(0,12))
        self._stat14(st,s['plans'],'Планы','предприятия')
        self._stat14(st,s['risk']['evaluated'],'Риски','с оценкой',CYAN)
        self._stat14(st,s['risk']['ccp'],'ККТ','указаны вручную',WARN)
        p=self._box14();self._section14(p,'Планы и их этапы','Связанные этапы блок-схем показаны ниже. Решение о ККТ подтверждает специалист.')
        plans=HACCPPlans(self.store).list_plans(self.venue_id)
        if not plans:txt(p,'Сохранённых планов пока нет. Ниже можно открыть существующий редактор ХАССП.',10,MUTED).pack(anchor='w')
        for plan in plans[:35]:
            b=tk.Frame(p,bg=PANEL2);b.pack(fill='x',pady=4)
            txt(b,plan['title'],11,INK,True,wrap=470).pack(side='left',fill='x',expand=True,padx=13,pady=13)
            txt(b,plan.get('state','Черновик'),9,CYAN).pack(side='right',padx=12)
        linked=self._box14();self._section14(linked,'Связь с блок-схемами','Ниже только уже сохранённые связи этапов. Новые ККТ автоматически не назначаются.')
        for r in s['links'][:20]:
            txt(linked,f"{r['diagram']}  /  {r['stage']}  →  {r['journal'] or 'журнал не назначен'}",9,INK,wrap=820).pack(anchor='w',pady=4)
        cmd(linked,'Открыть редактор планов ХАССП',self._open_classic_haccp).pack(anchor='w',pady=(12,0))

    def _open_classic_haccp(self):
        # Reuse the existing well-tested detailed HACCP editor rather than reimplementing regulated forms.
        from app import App
        try:
            win=App()
            win.store=self.store
            win.load_venues(self.venue_id)
            win.tabs.select(win.tab_haccp)
            win.title('MoOLVa · Подробный редактор ХАССП')
        except Exception as exc:
            messagebox.showerror('Редактор ХАССП','Не удалось открыть подробный редактор: '+str(exc),parent=self)

    def show_employee_center(self):
        if not self._need_venue():return
        self._view_start14('employees','TEAM / SIGNOFF','Сотрудники и ознакомление','Должности, обязанности, требования ХАССП и назначенные подписи')
        p=self._box14();self._section14(p,'Команда предприятия')
        cmd(p,'+ Добавить сотрудника',self._add_employee14,True).pack(anchor='w',pady=(0,13))
        staff=list_employees(self.store,self.venue_id)
        if not staff:txt(p,'Сотрудников пока нет — добавьте через кнопку выше.',10,MUTED).pack(anchor='w')
        for e in staff[:120]:
            line=tk.Frame(p,bg=PANEL2);line.pack(fill='x',pady=3)
            txt(line,e['full_name'],10,INK,True).pack(side='left',fill='x',expand=True,padx=12,pady=12)
            txt(line,e['position_name'],9,CYAN,wrap=255).pack(side='left',padx=8)
            cmd(line,'Обязанности',lambda e=e:self._duties14(e)).pack(side='right',padx=8,pady=4)
        q=self._box14();self._section14(q,'Листы ознакомления','Подписанты назначаются отдельно по каждому журналу.')
        cmd(q,'Выбрать подписантов  →',lambda:self.show(7)).pack(anchor='w')

    def _add_employee14(self):
        self.show(4)
        self.employee_dialog()

    def _duties14(self,employee):
        p=get_position(employee.get('position_code') or employee.get('position_name'))
        win=tk.Toplevel(self);win.title('Обязанности и требования ХАССП');win.configure(bg=PANEL);win.geometry('760x530');win.transient(self)
        txt(win,employee['full_name']+' — '+employee['position_name'],14,INK,True,wrap=690).pack(anchor='w',padx=18,pady=15)
        body=tk.Text(win,bg=PANEL2,fg=INK,font=(FONT,11),wrap='word',relief='flat',padx=15,pady=12)
        body.pack(fill='both',expand=True,padx=15,pady=(0,15))
        body.insert('end',('ОБЯЗАННОСТИ\n'+'\n'.join(getattr(p,'duties',()))+'\n\nТРЕБОВАНИЯ ХАССП\n'+'\n'.join(getattr(p,'requirements',()))) if p else 'Для этой должности нет отдельного описания. Откройте каталог должностей.')
        body.configure(state='disabled')

    def show_analytics_center(self):
        if not self._need_venue():return
        self._view_start14('analytics','ANALYTICS','Аналитика предприятия','События базы и заполненность документов — без вымышленных измерений')
        s=live_snapshot(self.store,self.venue_id)
        st=tk.Frame(self.content,bg=BG);st.pack(fill='x',pady=(0,12))
        self._stat14(st,s['completion'],'Заполненность','% полей и назначений',LIME)
        self._stat14(st,s['plans'],'Планы ХАССП','сохранено',CYAN)
        self._stat14(st,s['ccp'],'ККТ','решение специалиста',WARN)
        self._stat14(st,len(s['actions']),'Задачи','включая выполненные',GREEN)
        c=self._box14();self._mini_chart14(c,s['activity'],'Изменения базы данных по дням · 7 дней')
        e=self._box14();self._section14(e,'Последние изменения','Фактические события. График показывает действия пользователя, а не показатели датчиков.')
        for x in s['recent']:
            txt(e,x['created_at'][:19]+'   '+x['event'],9,SOFT).pack(anchor='w',pady=3)
        if not s['recent']:txt(e,'Изменений пока нет',10,MUTED).pack(anchor='w')

    def show_alert_center(self):
        if not self._need_venue():return
        self._view_start14('alerts','ACTION CENTER','Уведомления и задачи','Проверки структуры, открытые и просроченные задачи')
        s=live_snapshot(self.store,self.venue_id)
        p=self._box14();self._section14(p,f"Вопросы для проверки · {len(s['issues'])}",
                                     'Это подсказки, а не результат санитарного аудита.')
        for issue in s['issues'][:60]:
            row=tk.Frame(p,bg=PANEL2);row.pack(fill='x',pady=3)
            txt(row,issue['name']+': '+issue['text'],9,SOFT,wrap=650).pack(side='left',fill='x',expand=True,padx=12,pady=12)
            cmd(row,'Открыть  →',lambda k=issue['target']:self._navigate14(k)).pack(side='right',padx=8,pady=4)
        if not s['issues']:txt(p,'Проверка структуры не выявила замечаний.',10,GREEN).pack(anchor='w')
        p2=self._box14();self._section14(p2,'Корректирующие задачи','Сроки вводит пользователь, программа не подставляет фиктивные даты.')
        cmd(p2,'+ Создать задачу',self._new_action14,True).pack(anchor='w',pady=(0,9))
        for action in s['actions']:
            row=tk.Frame(p2,bg=PANEL2);row.pack(fill='x',pady=3)
            txt(row,action['title']+(' · до '+action['due_date'] if action['due_date'] else ''),9,INK,wrap=580).pack(side='left',fill='x',expand=True,padx=12,pady=12)
            new='Выполнено' if action['status']=='Открыто' else 'Открыто'
            cmd(row,'✓ Выполнено' if new=='Выполнено' else '↶ Вернуть',lambda a=action,n=new:self._change_action14(a['id'],n)).pack(side='right',padx=5,pady=4)
            cmd(row,'Удалить',lambda a=action:self._delete_action14(a['id'],a['title'])).pack(side='right',padx=5,pady=4)

    def _new_action14(self):
        title=simpledialog.askstring('Задача','Что необходимо выполнить?',parent=self)
        if not title:return
        due=simpledialog.askstring('Срок','Дата в формате ГГГГ-ММ-ДД (можно оставить пустым)',parent=self)
        if due is None:return
        try:add_action(self.store,self.venue_id,title,due.strip());self.show_alert_center()
        except Exception as exc:messagebox.showerror('Задача',str(exc),parent=self)
    def _change_action14(self,id,status):
        try:change_action(self.store,self.venue_id,id,status);self.show_alert_center()
        except Exception as exc:messagebox.showerror('Задача',str(exc),parent=self)
    def _delete_action14(self,id,title):
        if messagebox.askyesno('Удалить задачу?',f'Удалить «{title}»?',parent=self):
            delete_action(self.store,self.venue_id,id);self.show_alert_center()

    def show_settings_center(self):
        self._view_start14('settings','НАСТРОЙКИ','Настройки и безопасность','Локальные данные, резервное копирование, режим обновления')
        p=self._box14();self._section14(p,'Данные предприятия и резервные копии')
        txt(p,'Данные хранятся локально. Резервная копия включает предприятия, журналы, схемы и работников.',10,SOFT,wrap=800).pack(anchor='w',pady=5)
        txt(p,str(self.store.path),9,CYAN,wrap=800).pack(anchor='w',pady=5)
        cmd(p,'Создать резервную копию SQLite',self._backup14,True).pack(anchor='w',pady=11)
        q=self._box14();self._section14(q,'Живое обновление')
        txt(q,'Экран автоматически обновляет показатели при изменении локальной базы. Подключение к датчикам и облачная синхронизация не используются.',10,SOFT,wrap=800).pack(anchor='w')
        cmd(q,'Проверить обновление сейчас',self.show_dashboard).pack(anchor='w',pady=12)

    def _backup14(self):
        target=filedialog.asksaveasfilename(parent=self,title='Копия базы SQLite',defaultextension='.sqlite3',filetypes=[('SQLite','*.sqlite3')])
        if not target:return
        try:
            import sqlite3
            with sqlite3.connect(self.store.path) as src, sqlite3.connect(target) as dst:src.backup(dst)
            messagebox.showinfo('Копия готова','База сохранена: '+target,parent=self)
        except Exception as exc:messagebox.showerror('Резервная копия',str(exc),parent=self)
