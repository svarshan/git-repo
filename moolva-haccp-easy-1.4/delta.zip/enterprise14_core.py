"""Read-only live views and optional local action tracking for MoOLVa Easy 1.4.

No fabricated measurements, signatures or automatic regulatory compliance claims.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timedelta
from storage import now
from staff_store import list_employees
from easy_core import selected, overview
from visual_core import completion_summary, journal_cards, risk_summary
from flowchart_core import migrate_flowcharts, list_diagrams, diagram_details, validate_diagram
from haccp_core import HACCPPlans


def migrate_enterprise14(store):
    with store.connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS easy_actions14 (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
            title TEXT NOT NULL, due_date TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Открыто',
            origin TEXT NOT NULL DEFAULT 'Пользователь',
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_easy_actions14 ON easy_actions14(venue_id,status,id)')


def list_actions(store, venue_id):
    if not venue_id: return []
    migrate_enterprise14(store)
    with store.connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM easy_actions14 WHERE venue_id=? ORDER BY status,due_date,id', (venue_id,))]


def add_action(store, venue_id, title, due_date=''):
    title = (title or '').strip()
    if not store.get_venue(venue_id): raise ValueError('Предприятие не найдено')
    if not title or len(title) > 240: raise ValueError('Укажите название задачи (до 240 символов)')
    if due_date:
        datetime.strptime(due_date, '%Y-%m-%d')
    migrate_enterprise14(store)
    with store.connect() as db:
        cur = db.execute('INSERT INTO easy_actions14(venue_id,title,due_date,created_at,updated_at) VALUES(?,?,?,?,?)', (venue_id,title,due_date,now(),now()))
        store._audit(db,venue_id,'easy_action_created',{'action_id':cur.lastrowid,'title':title})
        return cur.lastrowid


def change_action(store, venue_id, action_id, status):
    if status not in ('Открыто','Выполнено'): raise ValueError('Неизвестный статус')
    migrate_enterprise14(store)
    with store.connect() as db:
        cur=db.execute('UPDATE easy_actions14 SET status=?,updated_at=? WHERE id=? AND venue_id=?',(status,now(),action_id,venue_id))
        if not cur.rowcount: raise ValueError('Задача не найдена у выбранного предприятия')
        store._audit(db,venue_id,'easy_action_changed',{'action_id':action_id,'status':status})


def delete_action(store, venue_id, action_id):
    migrate_enterprise14(store)
    with store.connect() as db:
        cur=db.execute('DELETE FROM easy_actions14 WHERE id=? AND venue_id=?',(action_id,venue_id))
        if cur.rowcount:store._audit(db,venue_id,'easy_action_deleted',{'action_id':action_id})
        return bool(cur.rowcount)


def activity_by_day(store, venue_id, days=7, today=None):
    today=today or datetime.now().date()
    days=max(1,min(31,int(days)))
    dates=[today-timedelta(days=i) for i in reversed(range(days))]
    if not venue_id:return [(d.strftime('%d.%m'),0) for d in dates]
    with store.connect() as db:
        data=db.execute('SELECT substr(created_at,1,10) AS d,count(*) AS n FROM audit_events WHERE venue_id=? AND created_at>=? GROUP BY substr(created_at,1,10)',(venue_id,dates[0].isoformat())).fetchall()
    lookup={x['d']:x['n'] for x in data}
    return [(d.strftime('%d.%m'),lookup.get(d.isoformat(),0)) for d in dates]


def recent_events(store, venue_id, limit=8):
    if not venue_id:return []
    with store.connect() as db:
        return [dict(x) for x in db.execute('SELECT id,event,created_at FROM audit_events WHERE venue_id=? ORDER BY id DESC LIMIT ?', (venue_id,min(30,int(limit))))]


def live_snapshot(store, venue_id):
    """One grounded view; no polling of external devices or fake compliance scores."""
    if not venue_id or not store.get_venue(venue_id):
        return {'venues':len(store.list_venues()),'selected':False,'journals':0,'employees':0,'diagrams':0,'plans':0,'issues':[],
                'actions':[],'risk':{'evaluated':0,'ccp':0,'hazards':[]},'activity':[],'completion':0,'documents':[],'links':[]}
    migrate_flowcharts(store)
    migrate_enterprise14(store)
    journal=journal_cards(store,venue_id)
    flows=list_diagrams(store,venue_id)
    risk=risk_summary(store,venue_id)
    people=list_employees(store,venue_id)
    actions=list_actions(store,venue_id)
    warnings=[]
    for j in journal:
        if j['missing']:
            warnings.append({'kind':'journal','name':j['title'],'text':' · '.join(j['missing']),'target':'journals'})
    linkrows=[]
    for f in flows:
        dt=diagram_details(store,f['id'])
        for x in validate_diagram(store,f['id'])[:4]:
            if x.get('level')=='error': warnings.append({'kind':'flow','name':f['title'],'text':x['text'],'target':'flows'})
        for n in dt['nodes']:
            if any(n.get(k) for k in ('journal_code','responsible_employee_id','source_step_id')):
                linkrows.append({'diagram':f['title'],'stage':n['name'],'journal':n.get('journal_code') or '',
                                 'responsible_employee_id':n.get('responsible_employee_id'),
                                 'source_step_id':n.get('source_step_id'), 'ccp':n.get('ccp_status')=='ККТ'})
    if not flows: warnings.append({'kind':'flow','name':'Блок-схемы','text':'Нет схем для выбранного предприятия','target':'flows'})
    if not people: warnings.append({'kind':'staff','name':'Сотрудники','text':'Не добавлены работники','target':'employees'})
    if risk.get('unevaluated'):
        warnings.append({'kind':'risk','name':'План ХАССП','text':f"Не оценено опасностей: {risk['unevaluated']}",'target':'risks'})
    today=datetime.now().date()
    for a in actions:
        if a['status']=='Открыто' and a['due_date']:
            try: is_overdue=datetime.strptime(a['due_date'],'%Y-%m-%d').date()<today
            except ValueError:is_overdue=False
            if is_overdue:warnings.append({'kind':'task','name':a['title'],'text':'Просрочена задача · '+a['due_date'],'target':'alerts'})
    return {'selected':True,'venues':len(store.list_venues()),'journals':len(journal),
            'employees':len(people),'diagrams':len(flows),'plans':risk['plans'],'processes':overview(store,venue_id)['processes'],
            'completion':completion_summary(store,venue_id)['score'], 'issues':warnings, 'risk':risk,
            'ccp':risk['ccp'],'activity':activity_by_day(store,venue_id), 'recent':recent_events(store,venue_id),
            'actions':actions,'documents':journal,'links':linkrows}


def export_manifest_note(store, venue_id, target):
    if not store.get_venue(venue_id):raise ValueError('Предприятие не найдено')
    with store.connect() as db:
        store._audit(db,venue_id,'easy_export14',{'output':str(target)[:240]})
