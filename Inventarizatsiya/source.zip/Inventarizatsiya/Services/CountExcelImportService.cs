using System.IO;
using System.Globalization;
using ClosedXML.Excel;
using Inventarizatsiya.Models;

namespace Inventarizatsiya.Services;

public sealed class CountExcelImportService
{
    public (List<(long ProductId, decimal Fact)> Updates, int EmptyRows) Read(
        string filename, IReadOnlyList<CountLine> current)
    {
        if(current.Count == 0) throw new InvalidDataException("Сначала создайте пересчёт.");
        using var book=new XLWorkbook(filename);
        var sheet=book.Worksheets.FirstOrDefault(x=>x.Name=="Расхождения")
            ?? throw new InvalidDataException("Выберите Excel, сформированный кнопкой «Ведомость Excel» текущего пересчёта (лист «Расхождения»).");
        if(sheet.Cell(4,2).GetString().Trim()!="Наименование" || sheet.Cell(4,5).GetString().Trim()!="Факт")
            throw new InvalidDataException("Неверный формат ведомости. Ожидается строка заголовков №4.");
        var byName=current.ToDictionary(x=>x.Name,StringComparer.OrdinalIgnoreCase);
        var seen=new HashSet<long>();
        var updates=new List<(long ProductId,decimal Fact)>();
        int empty=0;
        var last=sheet.LastRowUsed()?.RowNumber() ?? 4;
        // Validate every populated source row before proposing or persisting changes.
        for(int row=5;row<=last;row++)
        {
            var name=sheet.Cell(row,2).GetString().Trim();
            if(name.Length==0)continue;
            if(!byName.TryGetValue(name,out var line))
            {
                if(name.StartsWith("Итого",StringComparison.OrdinalIgnoreCase) || name.StartsWith("Сдал:") || name.StartsWith("Принял:")) continue;
                throw new InvalidDataException($"Строка {row}: товар «{name}» не входит в этот пересчёт.");
            }
            if(!seen.Add(line.ProductId))throw new InvalidDataException($"Повтор товара «{name}» в строке {row}.");
            if(sheet.Cell(row,3).GetString().Trim()!=line.Unit)
                throw new InvalidDataException($"Строка {row}: единица измерения товара «{name}» изменена.");
            var oldCell=sheet.Cell(row,4);
            if(!decimal.TryParse(oldCell.GetFormattedString(),NumberStyles.Number,CultureInfo.GetCultureInfo("ru-RU"),out var old)
                && !decimal.TryParse(oldCell.GetString(),NumberStyles.Number,CultureInfo.InvariantCulture,out old))
                throw new InvalidDataException($"Строка {row}: неверное учётное количество.");
            if(Math.Abs(old-line.BookQuantity)>0.0001m)
                throw new InvalidDataException($"Строка {row}: учётные остатки «{name}» не соответствуют текущему пересчёту.");
            var cell=sheet.Cell(row,5);
            if(cell.IsEmpty()){empty++;continue;}
            if(!decimal.TryParse(cell.GetFormattedString(),NumberStyles.Number,CultureInfo.GetCultureInfo("ru-RU"),out var fact)
                && !decimal.TryParse(cell.GetString(),NumberStyles.Number,CultureInfo.InvariantCulture,out fact))
                throw new InvalidDataException($"Строка {row}: факт должен быть числом.");
            if(fact<0)throw new InvalidDataException($"Строка {row}: фактическое количество не может быть отрицательным.");
            updates.Add((line.ProductId,fact));
        }
        if(updates.Count==0)throw new InvalidDataException("В графе «Факт» не заполнено ни одной строки.");
        if(seen.Count!=current.Count)
            throw new InvalidDataException($"Файл содержит {seen.Count} из {current.Count} товаров. Экспортируйте текущий пересчёт заново, чтобы избежать смешивания ведомостей.");
        return (updates,empty);
    }
}
