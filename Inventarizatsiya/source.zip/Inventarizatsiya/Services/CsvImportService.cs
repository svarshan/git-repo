using System.IO;
using Inventarizatsiya.Models;
using Microsoft.VisualBasic.FileIO;
using ClosedXML.Excel;
using System.Globalization;

namespace Inventarizatsiya.Services;

public sealed class CsvImportService
{
    public List<Product> Read(string path)
    {
        var rows = Path.GetExtension(path).Equals(".xlsx", StringComparison.OrdinalIgnoreCase)
            ? ReadExcel(path) : ReadCsv(path);
        if (rows.Count == 0) return new List<Product>();
        // Our exported Excel files have a report title and date above the real header.
        var headerRow = rows.FindIndex(row => row.Any(cell =>
            cell.Trim().Equals("Наименование", StringComparison.OrdinalIgnoreCase) ||
            cell.Trim().Equals("Наименование продукта", StringComparison.OrdinalIgnoreCase) ||
            cell.Trim().Equals("Наименование товара", StringComparison.OrdinalIgnoreCase) ||
            cell.Trim().Equals("Name", StringComparison.OrdinalIgnoreCase)));
        if (headerRow < 0) throw new InvalidDataException("Не найден заголовок «Наименование».");
        var headers = rows[headerRow].Select(x => x.Trim().TrimStart('\uFEFF').ToLowerInvariant()).ToList();
        int Index(params string[] names) => names.Select(n => headers.IndexOf(n.ToLowerInvariant())).FirstOrDefault(i => i >= 0, -1);
        var nameIndex = Index("Наименование", "Наименование продукта", "Наименование товара", "Название", "Name");
        if (nameIndex < 0) throw new InvalidDataException("Не найден столбец «Наименование».");
        string Cell(string[] row, params string[] names)
        {
            var idx = Index(names);
            return idx >= 0 && idx < row.Length ? row[idx].Trim() : "";
        }
        var result = new List<Product>();
        foreach (var row in rows.Skip(headerRow+1))
        {
            if (nameIndex >= row.Length || string.IsNullOrWhiteSpace(row[nameIndex])) continue;
            var incomingName=row[nameIndex].Trim();
            // Ignore totals, signature blocks and footers from printable reports.
            if (incomingName.StartsWith("ВСЕГО",StringComparison.OrdinalIgnoreCase) ||
                incomingName.StartsWith("Итого",StringComparison.OrdinalIgnoreCase) ||
                incomingName.StartsWith("Общая стоимость",StringComparison.OrdinalIgnoreCase) ||
                incomingName.StartsWith("Сдал:",StringComparison.OrdinalIgnoreCase) ||
                incomingName.StartsWith("Принял:",StringComparison.OrdinalIgnoreCase)) continue;
            result.Add(new Product
            {
                Name=incomingName,
                Sku=Cell(row,"Артикул","SKU"),
                Category=Cell(row,"Категория","Category") is { Length: > 0 } cat ? cat : "Прочее",
                Unit=Cell(row,"Единица","Единица измерения","Ед. изм.","Unit") is { Length: > 0 } unit ? unit : "кг",
                Quantity=Number(Cell(row,"Количество","Остаток","По учёту","Quantity")),
                MinQuantity=Number(Cell(row,"Минимальный остаток","Мин. остаток","Minimum")),
                Price=Number(Cell(row,"Цена","Цена за единицу","Цена за ед., ₽","Price")),
                Location=Cell(row,"Место хранения","Склад"),
                Supplier=Cell(row,"Поставщик","Supplier"),
                Barcode=Cell(row,"Штрихкод","Barcode"),
                Comment=Cell(row,"Комментарий","Comment")
            });
        }
        return result;
    }

    private static decimal Number(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return 0;
        var normalized = text.Replace('\u00A0',' ').Replace(" ", "").Trim();
        if (decimal.TryParse(normalized, NumberStyles.Number,
            CultureInfo.GetCultureInfo("ru-RU"), out var n)) return n;
        if (decimal.TryParse(normalized, NumberStyles.Number,
            CultureInfo.InvariantCulture, out n)) return n;
        throw new InvalidDataException($"Некорректное число: {text}");
    }

    private static List<string[]> ReadCsv(string path)
    {
        var first = File.ReadLines(path).FirstOrDefault() ?? "";
        using var parser = new TextFieldParser(path, System.Text.Encoding.UTF8)
        {
            TextFieldType=FieldType.Delimited, HasFieldsEnclosedInQuotes=true
        };
        parser.SetDelimiters(first.Count(c => c == ';') >= first.Count(c => c == ',') ? ";" : ",");
        var rows = new List<string[]>();
        while (!parser.EndOfData) rows.Add(parser.ReadFields() ?? Array.Empty<string>());
        return rows;
    }

    private static List<string[]> ReadExcel(string path)
    {
        using var book = new XLWorkbook(path);
        var ws = book.Worksheets.First();
        var result = new List<string[]>();
        var used = ws.RangeUsed();
        if (used is null) return result;
        foreach (var row in used.Rows())
            result.Add(row.Cells().Select(c => c.GetFormattedString()).ToArray());
        return result;
    }
}
