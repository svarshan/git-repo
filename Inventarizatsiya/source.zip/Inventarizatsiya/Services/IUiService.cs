namespace Inventarizatsiya.Services;

public interface IUiService
{
    void Message(string message, string title = "Инвентаризация");
    bool Confirm(string message, string title = "Подтверждение");
    string? SavePath(string title, string filter, string extension, string filename);
    string? OpenPath(string title, string filter);
}
