using System.Globalization;
using Inventarizatsiya.Models;
using Microsoft.Data.Sqlite;

namespace Inventarizatsiya.Services;

/// <summary>All inventory movements occur in a single SQLite transaction, alongside their audit entry.</summary>
public sealed class MovementService(DatabaseService database)
{
    private SqliteConnection Open()
    {
        var conn = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = database.DatabasePath, Mode = SqliteOpenMode.ReadWrite }.ToString());
        conn.Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;";
        cmd.ExecuteNonQuery();
        return conn;
    }

    public StockMovement Apply(long productId, string operation, decimal quantity, string responsible, string reason)
    {
        if (productId <= 0) throw new ArgumentException("Выберите товар.");
        if (operation is not ("Приход" or "Расход" or "Списание"))
            throw new ArgumentException("Выберите приход, расход или списание.");
        if (quantity <= 0 || quantity > 1_000_000_000m || decimal.Round(quantity, 4) != quantity)
            throw new ArgumentException("Укажите положительное количество не более 4 знаков после запятой.");
        if (operation == "Списание" && string.IsNullOrWhiteSpace(reason))
            throw new ArgumentException("Для списания обязательно укажите причину.");
        if (reason.Length > 500 || responsible.Length > 150)
            throw new ArgumentException("Слишком длинный комментарий или ФИО.");

        using var conn = Open();
        using var tx = conn.BeginTransaction();
        string name, unit;
        decimal before, price;
        using (var get = conn.CreateCommand())
        {
            get.Transaction = tx;
            get.CommandText = "SELECT Name, Unit, Quantity, Price FROM Products WHERE Id=@id";
            get.Parameters.AddWithValue("@id", productId);
            using var reader = get.ExecuteReader();
            if (!reader.Read()) throw new InvalidOperationException("Товар отсутствует в каталоге.");
            name = reader.GetString(0); unit = reader.GetString(1);
            before = decimal.Round((decimal)reader.GetDouble(2),4); price = decimal.Round((decimal)reader.GetDouble(3),2);
        }
        decimal after = operation == "Приход" ? before + quantity : before - quantity;
        if (after < 0) throw new InvalidOperationException($"Недостаточный остаток: доступно {before} {unit}.");
        if (after > 1_000_000_000m) throw new InvalidOperationException("Превышен допустимый остаток.");

        var now = DateTimeOffset.UtcNow;
        using (var update = conn.CreateCommand())
        {
            update.Transaction = tx;
            // Guard the balance read by this transaction against accidental lost updates.
            update.CommandText = "UPDATE Products SET Quantity=@after, IsDemo=0, UpdatedAt=@now WHERE Id=@id AND ABS(Quantity-@before)<0.00001";
            update.Parameters.AddWithValue("@after", (double)after);
            update.Parameters.AddWithValue("@before", (double)before);
            update.Parameters.AddWithValue("@now", now.UtcDateTime.ToString("o", CultureInfo.InvariantCulture));
            update.Parameters.AddWithValue("@id", productId);
            if (update.ExecuteNonQuery() != 1)
                throw new InvalidOperationException("Остаток изменился. Обновите список перед новой операцией.");
        }
        long movementId;
        using (var insert = conn.CreateCommand())
        {
            insert.Transaction = tx;
            insert.CommandText = """
                INSERT INTO StockMovements(Timestamp,ProductId,ProductName,Unit,Operation,Quantity,BeforeQuantity,AfterQuantity,UnitPrice,Responsible,Reason)
                VALUES(@ts,@id,@name,@unit,@op,@quantity,@before,@after,@price,@responsible,@reason);
                SELECT last_insert_rowid();
                """;
            insert.Parameters.AddWithValue("@ts", now.UtcDateTime.ToString("o", CultureInfo.InvariantCulture));
            insert.Parameters.AddWithValue("@id", productId);
            insert.Parameters.AddWithValue("@name", name);
            insert.Parameters.AddWithValue("@unit", unit);
            insert.Parameters.AddWithValue("@op", operation);
            insert.Parameters.AddWithValue("@quantity", (double)quantity);
            insert.Parameters.AddWithValue("@before", (double)before);
            insert.Parameters.AddWithValue("@after", (double)after);
            insert.Parameters.AddWithValue("@price", (double)price);
            insert.Parameters.AddWithValue("@responsible", responsible.Trim());
            insert.Parameters.AddWithValue("@reason", reason.Trim());
            movementId = (long)(insert.ExecuteScalar() ?? 0L);
        }
        using (var log = conn.CreateCommand())
        {
            log.Transaction = tx;
            log.CommandText = "INSERT INTO Changes(Timestamp,Action,ProductName,Details) VALUES(@ts,@op,@name,@detail)";
            log.Parameters.AddWithValue("@ts", now.UtcDateTime.ToString("o", CultureInfo.InvariantCulture));
            log.Parameters.AddWithValue("@op", operation);
            log.Parameters.AddWithValue("@name", name);
            log.Parameters.AddWithValue("@detail", $"№{movementId}: {before} → {after} {unit}; количество {quantity}; {reason.Trim()}; {responsible.Trim()}");
            log.ExecuteNonQuery();
        }
        tx.Commit();
        return new StockMovement(movementId, now, productId, name, unit, operation,
            quantity, before, after, price, responsible.Trim(), reason.Trim());
    }

    /// <summary>Idempotent correction: inverse movement, immutable original, all inside one transaction.</summary>
    public StockMovement Reverse(long originalId, string responsible, string reason)
    {
        if(originalId<=0)throw new ArgumentException("Выберите запись движения.");
        if(string.IsNullOrWhiteSpace(reason))throw new ArgumentException("Укажите причину исправления.");
        if(reason.Length>500 || responsible.Length>150)throw new ArgumentException("Слишком длинный комментарий или ФИО.");
        using var conn=Open();using var tx=conn.BeginTransaction();
        long productId;string productName,unit,operation;decimal quantity,price;
        using(var cmd=conn.CreateCommand())
        {
            cmd.Transaction=tx;
            cmd.CommandText="SELECT ProductId,ProductName,Unit,Operation,Quantity,UnitPrice,ReversalOfId FROM StockMovements WHERE Id=@id";
            cmd.Parameters.AddWithValue("@id",originalId);
            using var rd=cmd.ExecuteReader();
            if(!rd.Read())throw new InvalidOperationException("Операция не найдена.");
            if(!rd.IsDBNull(6))throw new InvalidOperationException("Нельзя повторно отменить корректировку.");
            productId=rd.GetInt64(0);productName=rd.GetString(1);unit=rd.GetString(2);operation=rd.GetString(3);
            quantity=decimal.Round((decimal)rd.GetDouble(4),4);price=decimal.Round((decimal)rd.GetDouble(5),2);
        }
        using(var check=conn.CreateCommand())
        {
            check.Transaction=tx;check.CommandText="SELECT COUNT(*) FROM StockMovements WHERE ReversalOfId=@id";
            check.Parameters.AddWithValue("@id",originalId);
            if(Convert.ToInt32(check.ExecuteScalar())>0)throw new InvalidOperationException("Эта операция уже отменена.");
        }
        decimal before;
        using(var get=conn.CreateCommand())
        {
            get.Transaction=tx;get.CommandText="SELECT Quantity FROM Products WHERE Id=@id";
            get.Parameters.AddWithValue("@id",productId);
            var value=get.ExecuteScalar();
            if(value is null)throw new InvalidOperationException("Товар удалён. Восстановите карточку перед корректировкой.");
            before=decimal.Round(Convert.ToDecimal(value,CultureInfo.InvariantCulture),4);
        }
        var inverse=operation=="Приход"?"Расход":"Приход";
        var after=operation=="Приход"?before-quantity:before+quantity;
        if(after<0)throw new InvalidOperationException("Для отмены прихода недостаточно остатка. Сначала исправьте последующие движения.");
        if(after>1000000000m)throw new InvalidOperationException("Превышен допустимый остаток.");
        var timestamp=DateTimeOffset.UtcNow;
        using(var upd=conn.CreateCommand())
        {
            upd.Transaction=tx;
            upd.CommandText="UPDATE Products SET Quantity=@after,IsDemo=0,UpdatedAt=@now WHERE Id=@id AND ABS(Quantity-@before)<0.00001";
            upd.Parameters.AddWithValue("@after",(double)after);upd.Parameters.AddWithValue("@before",(double)before);
            upd.Parameters.AddWithValue("@id",productId);upd.Parameters.AddWithValue("@now",timestamp.UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
            if(upd.ExecuteNonQuery()!=1)throw new InvalidOperationException("Остаток изменился, обновите данные.");
        }
        long correctionId;
        using(var ins=conn.CreateCommand())
        {
            ins.Transaction=tx;
            ins.CommandText="""
                INSERT INTO StockMovements(Timestamp,ProductId,ProductName,Unit,Operation,Quantity,BeforeQuantity,AfterQuantity,UnitPrice,Responsible,Reason,ReversalOfId)
                VALUES(@ts,@pid,@name,@unit,@op,@qty,@before,@after,@price,@resp,@reason,@original);
                SELECT last_insert_rowid();
                """;
            ins.Parameters.AddWithValue("@ts",timestamp.UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
            ins.Parameters.AddWithValue("@pid",productId);ins.Parameters.AddWithValue("@name",productName);
            ins.Parameters.AddWithValue("@unit",unit);ins.Parameters.AddWithValue("@op",inverse);
            ins.Parameters.AddWithValue("@qty",(double)quantity);ins.Parameters.AddWithValue("@before",(double)before);
            ins.Parameters.AddWithValue("@after",(double)after);ins.Parameters.AddWithValue("@price",(double)price);
            ins.Parameters.AddWithValue("@resp",responsible.Trim());ins.Parameters.AddWithValue("@reason","Корректировка №"+originalId+": "+reason.Trim());
            ins.Parameters.AddWithValue("@original",originalId);
            correctionId=(long)(ins.ExecuteScalar()??0L);
        }
        using(var log=conn.CreateCommand())
        {
            log.Transaction=tx;log.CommandText="INSERT INTO Changes(Timestamp,Action,ProductName,Details) VALUES(@ts,'Корректировка',@name,@detail)";
            log.Parameters.AddWithValue("@ts",timestamp.UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
            log.Parameters.AddWithValue("@name",productName);
            log.Parameters.AddWithValue("@detail",$"Корректировка #{correctionId} к операции #{originalId}: {before} → {after}; {reason.Trim()}");
            log.ExecuteNonQuery();
        }
        tx.Commit();
        return new StockMovement(correctionId,timestamp,productId,productName,unit,inverse,quantity,before,after,price,responsible.Trim(),"Корректировка №"+originalId+": "+reason.Trim(),originalId);
    }

    public List<StockMovement> GetByPeriod(DateTime from, DateTime through)
    {
        if(from.Date>through.Date)throw new ArgumentException("Начальная дата больше конечной.");
        using var conn=Open();using var cmd=conn.CreateCommand();
        cmd.CommandText="""
            SELECT Id,Timestamp,ProductId,ProductName,Unit,Operation,Quantity,BeforeQuantity,AfterQuantity,UnitPrice,Responsible,Reason,ReversalOfId
            FROM StockMovements WHERE Timestamp >= @from AND Timestamp < @to ORDER BY Timestamp,Id
            """;
        cmd.Parameters.AddWithValue("@from",new DateTimeOffset(from.Date.ToUniversalTime()).UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
        cmd.Parameters.AddWithValue("@to",new DateTimeOffset(through.Date.AddDays(1).ToUniversalTime()).UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
        return ReadMovements(cmd);
    }

    private static List<StockMovement> ReadMovements(SqliteCommand cmd)
    {
        using var r=cmd.ExecuteReader();var result=new List<StockMovement>();
        while(r.Read())result.Add(new StockMovement(r.GetInt64(0),DateTimeOffset.Parse(r.GetString(1),CultureInfo.InvariantCulture),
            r.GetInt64(2),r.GetString(3),r.GetString(4),r.GetString(5),decimal.Round((decimal)r.GetDouble(6),4),
            decimal.Round((decimal)r.GetDouble(7),4),decimal.Round((decimal)r.GetDouble(8),4),decimal.Round((decimal)r.GetDouble(9),2),
            r.GetString(10),r.GetString(11),r.IsDBNull(12)?null:r.GetInt64(12)));
        return result;
    }

    public List<StockMovement> GetRecent(int limit = 1000)
    {
        using var conn = Open(); using var cmd = conn.CreateCommand();
        cmd.CommandText = """
            SELECT Id,Timestamp,ProductId,ProductName,Unit,Operation,Quantity,BeforeQuantity,AfterQuantity,UnitPrice,Responsible,Reason,ReversalOfId
            FROM StockMovements ORDER BY Id DESC LIMIT @limit
            """;
        cmd.Parameters.AddWithValue("@limit", Math.Clamp(limit, 1, 50000));
        using var r = cmd.ExecuteReader();
        var result = new List<StockMovement>();
        while (r.Read())
            result.Add(new StockMovement(r.GetInt64(0), DateTimeOffset.Parse(r.GetString(1), CultureInfo.InvariantCulture),
                r.GetInt64(2), r.GetString(3), r.GetString(4), r.GetString(5), (decimal)r.GetDouble(6),
                decimal.Round((decimal)r.GetDouble(7),4), decimal.Round((decimal)r.GetDouble(8),4), decimal.Round((decimal)r.GetDouble(9),2), r.GetString(10), r.GetString(11), r.IsDBNull(12)?null:r.GetInt64(12)));
        return result;
    }
}
