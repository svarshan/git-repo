using System.Globalization;
using Inventarizatsiya.Models;
using Microsoft.Data.Sqlite;

namespace Inventarizatsiya.Services;

/// <summary>All inventory movements occur in a single SQLite transaction, alongside their audit entry.</summary>
public sealed class MovementService(DatabaseService database)
{
    private SqliteConnection Open()
    {
        var conn = new SqliteConnection(new SqliteConnectionStringBuilder
        { DataSource = database.DatabasePath, Mode = SqliteOpenMode.ReadWrite }.ToString());
        conn.Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;";
        cmd.ExecuteNonQuery();
        return conn;
    }

    public StockMovement Apply(long productId, string operation, decimal quantity, string responsible, string reason)
    {
        if (productId <= 0) throw new ArgumentException("Выберите товар.");
        if (operation is not ("Приход" or "Расход" or "Списание"))
            throw new ArgumentException("Выберите приход, расход или списание.");
        if (quantity <= 0 || quantity > 1_000_000_000m || decimal.Round(quantity, 4) != quantity)
            throw new ArgumentException("Укажите положительное количество не более 4 знаков после запятой.");
        if (operation == "Списание" && string.IsNullOrWhiteSpace(reason))
            throw new ArgumentException("Для списания обязательно укажите причину.");
        if (reason.Length > 500 || responsible.Length > 150)
            throw new ArgumentException("Слишком длинный комментарий или ФИО.");

        using var conn = Open();
        using var tx = conn.BeginTransaction();
        string name, unit;
        decimal before, price;
        using (var get = conn.CreateCommand())
        {
            get.Transaction = tx;
            get.CommandText = "SELECT Name, Unit, Quantity, Price FROM Products WHERE Id=@id";
            get.Parameters.AddWithValue("@id", productId);
            using var reader = get.ExecuteReader();
            if (!reader.Read()) throw new InvalidOperationException("Товар отсутствует в каталоге.");
            name = reader.GetString(0); unit = reader.GetString(1);
            before = (decimal)reader.GetDouble(2); price = (decimal)reader.GetDouble(3);
        }
        decimal after = operation == "Приход" ? before + quantity : before - quantity;
        if (after < 0) throw new InvalidOperationException($"Недостаточный остаток: доступно {before} {unit}.");
        if (after > 1_000_000_000m) throw new InvalidOperationException("Превышен допустимый остаток.");

        var now = DateTimeOffset.UtcNow;
        using (var update = conn.CreateCommand())
        {
            update.Transaction = tx;
            // Guard the balance read by this transaction against accidental lost updates.
            update.CommandText = "UPDATE Products SET Quantity=@after, IsDemo=0, UpdatedAt=@now WHERE Id=@id AND ABS(Quantity-@before)<0.00001";
            update.Parameters.AddWithValue("@after", (double)after);
            update.Parameters.AddWithValue("@before", (double)before);
            update.Parameters.AddWithValue("@now", now.UtcDateTime.ToString("o", CultureInfo.InvariantCulture));
            update.Parameters.AddWithValue("@id", productId);
            if (update.ExecuteNonQuery() != 1)
                throw new InvalidOperationException("Остаток изменился. Обновите список перед новой операцией.");
        }
        long movementId;
        using (var insert = conn.CreateCommand())
        {
            insert.Transaction = tx;
            insert.CommandText = """
                INSERT INTO StockMovements(Timestamp,ProductId,ProductName,Unit,Operation,Quantity,BeforeQuantity,AfterQuantity,UnitPrice,Responsible,Reason)
                VALUES(@ts,@id,@name,@unit,@op,@quantity,@before,@after,@price,@responsible,@reason);
                SELECT last_insert_rowid();
                """;
            insert.Parameters.AddWithValue("@ts", now.UtcDateTime.ToString("o", CultureInfo.InvariantCulture));
            insert.Parameters.AddWithValue("@id", productId);
            insert.Parameters.AddWithValue("@name", name);
            insert.Parameters.AddWithValue("@unit", unit);
            insert.Parameters.AddWithValue("@op", operation);
            insert.Parameters.AddWithValue("@quantity", (double)quantity);
            insert.Parameters.AddWithValue("@before", (double)before);
            insert.Parameters.AddWithValue("@after", (double)after);
            insert.Parameters.AddWithValue("@price", (double)price);
            insert.Parameters.AddWithValue("@responsible", responsible.Trim());
            insert.Parameters.AddWithValue("@reason", reason.Trim());
            movementId = (long)(insert.ExecuteScalar() ?? 0L);
        }
        using (var log = conn.CreateCommand())
        {
            log.Transaction = tx;
            log.CommandText = "INSERT INTO Changes(Timestamp,Action,ProductName,Details) VALUES(@ts,@op,@name,@detail)";
            log.Parameters.AddWithValue("@ts", now.UtcDateTime.ToString("o", CultureInfo.InvariantCulture));
            log.Parameters.AddWithValue("@op", operation);
            log.Parameters.AddWithValue("@name", name);
            log.Parameters.AddWithValue("@detail", $"№{movementId}: {before} → {after} {unit}; количество {quantity}; {reason.Trim()}; {responsible.Trim()}");
            log.ExecuteNonQuery();
        }
        tx.Commit();
        return new StockMovement(movementId, now, productId, name, unit, operation,
            quantity, before, after, price, responsible.Trim(), reason.Trim());
    }

    public List<StockMovement> GetRecent(int limit = 1000)
    {
        using var conn = Open(); using var cmd = conn.CreateCommand();
        cmd.CommandText = """
            SELECT Id,Timestamp,ProductId,ProductName,Unit,Operation,Quantity,BeforeQuantity,AfterQuantity,UnitPrice,Responsible,Reason
            FROM StockMovements ORDER BY Id DESC LIMIT @limit
            """;
        cmd.Parameters.AddWithValue("@limit", Math.Clamp(limit, 1, 50000));
        using var r = cmd.ExecuteReader();
        var result = new List<StockMovement>();
        while (r.Read())
            result.Add(new StockMovement(r.GetInt64(0), DateTimeOffset.Parse(r.GetString(1), CultureInfo.InvariantCulture),
                r.GetInt64(2), r.GetString(3), r.GetString(4), r.GetString(5), (decimal)r.GetDouble(6),
                (decimal)r.GetDouble(7), (decimal)r.GetDouble(8), (decimal)r.GetDouble(9), r.GetString(10), r.GetString(11)));
        return result;
    }
}
