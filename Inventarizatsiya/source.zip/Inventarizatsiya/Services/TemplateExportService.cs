using System;
using System.IO;
using System.Reflection;

namespace Inventarizatsiya.Services;

/// <summary>Two complete offline Excel books embedded inside the EXE.</summary>
public sealed class TemplateExportService
{
    private const string Prefix = "Inventarizatsiya.Data.";

    public void SaveBlank(string destination) => Copy(Prefix + "blank_template.xlsx", destination);
    public void SaveFilledExample(string destination) => Copy(Prefix + "filled_example_768.xlsx", destination);

    private static void Copy(string resourceName, string destination)
    {
        using var source = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException("Не найден встроенный Excel-шаблон: " + resourceName);
        var directory = Path.GetDirectoryName(Path.GetFullPath(destination))
            ?? throw new IOException("Не удалось определить папку экспорта.");
        Directory.CreateDirectory(directory);
        using var output = new FileStream(destination, FileMode.Create, FileAccess.Write, FileShare.None);
        source.CopyTo(output);
        output.Flush(true);
    }
}
