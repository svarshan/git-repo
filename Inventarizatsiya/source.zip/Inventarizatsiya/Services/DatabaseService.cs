using System.IO;
using Inventarizatsiya.Models;
using Microsoft.Data.Sqlite;
using System.Globalization;
using System.Reflection;

namespace Inventarizatsiya.Services;

public sealed class DatabaseService
{
    public string DatabasePath { get; }
    private readonly string _connectionString;

    public DatabaseService()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Inventarizatsiya");
        Directory.CreateDirectory(dir);
        DatabasePath = Path.Combine(dir, "inventory.db");
        _connectionString = new SqliteConnectionStringBuilder { DataSource=DatabasePath, Mode=SqliteOpenMode.ReadWriteCreate }.ToString();
    }

    private SqliteConnection Open()
    {
        var conn = new SqliteConnection(_connectionString);
        conn.Open();
        using var pragma = conn.CreateCommand();
        pragma.CommandText = "PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON;";
        pragma.ExecuteNonQuery();
        return conn;
    }

    public void Initialize()
    {
        using var conn = Open();
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = """
                CREATE TABLE IF NOT EXISTS Products (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Sku TEXT NOT NULL DEFAULT '',
                    Name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    Category TEXT NOT NULL DEFAULT 'Прочее',
                    Unit TEXT NOT NULL DEFAULT 'кг',
                    Quantity REAL NOT NULL DEFAULT 0 CHECK (Quantity >= 0),
                    MinQuantity REAL NOT NULL DEFAULT 0 CHECK (MinQuantity >= 0),
                    Price REAL NOT NULL DEFAULT 0 CHECK (Price >= 0),
                    Location TEXT NOT NULL DEFAULT '',
                    Supplier TEXT NOT NULL DEFAULT '',
                    Barcode TEXT NOT NULL DEFAULT '',
                    Comment TEXT NOT NULL DEFAULT '',
                    IsFavorite INTEGER NOT NULL DEFAULT 0,
                    IsDemo INTEGER NOT NULL DEFAULT 0,
                    UpdatedAt TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_products_category ON Products(Category);
                CREATE INDEX IF NOT EXISTS idx_products_barcode ON Products(Barcode);
                CREATE INDEX IF NOT EXISTS idx_products_updated ON Products(UpdatedAt);
                CREATE TABLE IF NOT EXISTS Changes (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Timestamp TEXT NOT NULL,
                    Action TEXT NOT NULL,
                    ProductName TEXT NOT NULL,
                    Details TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS Metadata (Key TEXT PRIMARY KEY, Value TEXT NOT NULL);
                """;
            cmd.ExecuteNonQuery();
        }
        // Forward-only migration: preserve the user's existing database and IDs.
        using (var schema = conn.CreateCommand())
        {
            schema.CommandText="PRAGMA table_info(Products)";
            using var columns=schema.ExecuteReader();
            var names=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            while(columns.Read()) names.Add(columns.GetString(1));
            columns.Close();
            foreach(var addition in new [] {
                ("ExpiryDate", "TEXT NULL"),
                ("PackSize", "REAL NOT NULL DEFAULT 1"),
                ("PackUnit", "TEXT NOT NULL DEFAULT 'упак.'")
            })
            {
                if(names.Contains(addition.Item1)) continue;
                using var alter=conn.CreateCommand();
                alter.CommandText=$"ALTER TABLE Products ADD COLUMN {addition.Item1} {addition.Item2}";
                alter.ExecuteNonQuery();
            }
            using var create=conn.CreateCommand();
            create.CommandText="""
                CREATE TABLE IF NOT EXISTS CountSessions (
                  Id INTEGER PRIMARY KEY AUTOINCREMENT, StartedAt TEXT NOT NULL,
                  CompletedAt TEXT NULL, Warehouse TEXT NOT NULL, Status TEXT NOT NULL DEFAULT 'Открыта');
                CREATE TABLE IF NOT EXISTS CountRows (
                  SessionId INTEGER NOT NULL, ProductId INTEGER NOT NULL,
                  ProductName TEXT NOT NULL, Unit TEXT NOT NULL,
                  BookQuantity REAL NOT NULL, Price REAL NOT NULL,
                  ActualQuantity REAL NULL,
                  PRIMARY KEY(SessionId, ProductId),
                  FOREIGN KEY(SessionId) REFERENCES CountSessions(Id));
                CREATE INDEX IF NOT EXISTS idx_count_rows_session ON CountRows(SessionId);
                CREATE TABLE IF NOT EXISTS StockMovements (
                  Id INTEGER PRIMARY KEY AUTOINCREMENT,
                  Timestamp TEXT NOT NULL,
                  ProductId INTEGER NOT NULL,
                  ProductName TEXT NOT NULL,
                  Unit TEXT NOT NULL,
                  Operation TEXT NOT NULL CHECK(Operation IN ('Приход','Расход','Списание')),
                  Quantity REAL NOT NULL CHECK(Quantity > 0),
                  BeforeQuantity REAL NOT NULL CHECK(BeforeQuantity >= 0),
                  AfterQuantity REAL NOT NULL CHECK(AfterQuantity >= 0),
                  UnitPrice REAL NOT NULL CHECK(UnitPrice >= 0),
                  Responsible TEXT NOT NULL DEFAULT '',
                  Reason TEXT NOT NULL DEFAULT '',
                  ReversalOfId INTEGER NULL
                );
                CREATE INDEX IF NOT EXISTS idx_movements_product_time ON StockMovements(ProductId,Timestamp);
                CREATE INDEX IF NOT EXISTS idx_movements_timestamp ON StockMovements(Timestamp);
                """;
            create.ExecuteNonQuery();
            using var movementSchema=conn.CreateCommand();
            movementSchema.CommandText="PRAGMA table_info(StockMovements)";
            using var mreader=movementSchema.ExecuteReader();
            var hasReversal=false;
            while(mreader.Read())if(mreader.GetString(1)=="ReversalOfId")hasReversal=true;
            mreader.Close();
            if(!hasReversal)
            {
                using var migration=conn.CreateCommand();
                migration.CommandText="ALTER TABLE StockMovements ADD COLUMN ReversalOfId INTEGER NULL";
                migration.ExecuteNonQuery();
            }
            using var idx=conn.CreateCommand();
            idx.CommandText="CREATE UNIQUE INDEX IF NOT EXISTS idx_movement_reversal_unique ON StockMovements(ReversalOfId) WHERE ReversalOfId IS NOT NULL";
            idx.ExecuteNonQuery();
        }
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "SELECT Value FROM Metadata WHERE Key = 'seed_v1' LIMIT 1";
            if (cmd.ExecuteScalar() is not null) { AutoBackupDaily(); return; }
        }
        Seed(conn);
        AutoBackupDaily();
    }

    private void Seed(SqliteConnection conn)
    {
        var resource = Assembly.GetExecutingAssembly().GetManifestResourceNames()
            .Single(n => n.EndsWith("seed_products.csv", StringComparison.OrdinalIgnoreCase));
        using var source = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource)
            ?? throw new IOException("Встроенный каталог товаров не найден");
        using var reader = new StreamReader(source, System.Text.Encoding.UTF8);
        using var tx = conn.BeginTransaction();
        var line = reader.ReadLine(); // header, fixed trusted embedded CSV
        int added = 0;
        while ((line = reader.ReadLine()) is not null)
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            // Seed names do not contain ';' or quoted CSV delimiters; validate in build checks.
            var cells = line.Split(';');
            if (cells.Length != 12) throw new InvalidDataException("Неверный формат встроенного каталога товаров");
            var p = new Product
            {
                Sku=cells[0], Name=cells[1], Category=cells[2], Unit=cells[3],
                Quantity=decimal.Parse(cells[4], CultureInfo.InvariantCulture),
                MinQuantity=decimal.Parse(cells[5], CultureInfo.InvariantCulture),
                Price=decimal.Parse(cells[6], CultureInfo.InvariantCulture),
                Location=cells[7], Supplier=cells[8], Barcode=cells[9],
                Comment=cells[10], IsDemo=true
            };
            added += Insert(conn, tx, p, orIgnore:true);
        }
        using (var mark = conn.CreateCommand())
        {
            mark.Transaction=tx;
            mark.CommandText="INSERT INTO Metadata(Key,Value) VALUES('seed_v1',@count)";
            mark.Parameters.AddWithValue("@count", added.ToString(CultureInfo.InvariantCulture));
            mark.ExecuteNonQuery();
        }
        WriteLog(conn,tx,"Первый запуск","Каталог",$"Добавлено {added} демонстрационных товаров");
        tx.Commit();
    }

    private static int Insert(SqliteConnection conn, SqliteTransaction tx, Product p, bool orIgnore = false, bool preserveId = false)
    {
        using var cmd = conn.CreateCommand();
        cmd.Transaction=tx;
        cmd.CommandText = $"""
            INSERT {(orIgnore ? "OR IGNORE" : "")} INTO Products
            ({(preserveId ? "Id," : "")}Sku,Name,Category,Unit,Quantity,MinQuantity,Price,Location,Supplier,Barcode,Comment,IsFavorite,IsDemo,UpdatedAt,ExpiryDate,PackSize,PackUnit)
            VALUES ({(preserveId ? "@id," : "")}@sku,@name,@category,@unit,@qty,@min,@price,@location,@supplier,@barcode,@comment,@favorite,@demo,@date,@expiry,@packsize,@packunit)
            """;
        SetParams(cmd,p);
        if (preserveId) cmd.Parameters.AddWithValue("@id",p.Id);
        return cmd.ExecuteNonQuery();
    }

    private static void SetParams(SqliteCommand cmd, Product p)
    {
        cmd.Parameters.AddWithValue("@sku",p.Sku.Trim());
        cmd.Parameters.AddWithValue("@name",p.Name.Trim());
        cmd.Parameters.AddWithValue("@category",p.Category.Trim());
        cmd.Parameters.AddWithValue("@unit",p.Unit.Trim());
        cmd.Parameters.AddWithValue("@qty",Convert.ToDouble(p.Quantity));
        cmd.Parameters.AddWithValue("@min",Convert.ToDouble(p.MinQuantity));
        cmd.Parameters.AddWithValue("@price",Convert.ToDouble(p.Price));
        cmd.Parameters.AddWithValue("@location",p.Location.Trim());
        cmd.Parameters.AddWithValue("@supplier",p.Supplier.Trim());
        cmd.Parameters.AddWithValue("@barcode",p.Barcode.Trim());
        cmd.Parameters.AddWithValue("@comment",p.Comment.Trim());
        cmd.Parameters.AddWithValue("@favorite",p.IsFavorite ? 1 : 0);
        cmd.Parameters.AddWithValue("@demo",p.IsDemo ? 1 : 0);
        cmd.Parameters.AddWithValue("@date",p.UpdatedAt.UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
        cmd.Parameters.AddWithValue("@expiry",p.ExpiryDate is null ? DBNull.Value : p.ExpiryDate.Value.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture));
        cmd.Parameters.AddWithValue("@packsize",Convert.ToDouble(p.PackSize));
        cmd.Parameters.AddWithValue("@packunit",p.PackUnit);
    }

    private static void Validate(Product p)
    {
        if (string.IsNullOrWhiteSpace(p.Name)) throw new ArgumentException("Введите наименование товара.");
        if (string.IsNullOrWhiteSpace(p.Category) || p.Category=="Все категории")
            throw new ArgumentException("Выберите категорию товара.");
        if (string.IsNullOrWhiteSpace(p.Unit)) throw new ArgumentException("Выберите единицу измерения.");
        if (p.Quantity < 0 || p.MinQuantity < 0 || p.Price < 0 || p.PackSize <= 0)
            throw new ArgumentException("Количество, минимум и цена не могут быть отрицательными.");
        if (p.Name.Trim().Length > 250) throw new ArgumentException("Слишком длинное наименование товара.");
        if (decimal.Round(p.Quantity,4)!=p.Quantity || decimal.Round(p.MinQuantity,4)!=p.MinQuantity)
            throw new ArgumentException("Количество: не более четырёх знаков после запятой.");
        if (decimal.Round(p.Price,2)!=p.Price)
            throw new ArgumentException("Цена: не более двух знаков после запятой.");
    }

    public void Save(Product p)
    {
        Validate(p);
        using var conn=Open();
        EnsureNoDuplicate(conn,p);
        using var tx=conn.BeginTransaction();
        p.UpdatedAt=DateTimeOffset.UtcNow;
        if (p.Id == 0)
        {
            Insert(conn,tx,p);
            using var id = conn.CreateCommand();
            id.Transaction=tx;
            id.CommandText="SELECT last_insert_rowid()";
            p.Id=(long)(id.ExecuteScalar() ?? 0L);
            WriteLog(conn,tx,"Добавлено",p.Name,$"Количество: {p.Quantity} {p.Unit}");
        }
        else
        {
            using(var checkQuantity=conn.CreateCommand())
            {
                checkQuantity.Transaction=tx;
                checkQuantity.CommandText="SELECT Quantity FROM Products WHERE Id=@id";
                checkQuantity.Parameters.AddWithValue("@id",p.Id);
                var current=checkQuantity.ExecuteScalar();
                if(current is null)throw new InvalidOperationException("Товар не найден.");
                if(Math.Abs((decimal)Convert.ToDouble(current)-p.Quantity)>0.00001m)
                    throw new InvalidOperationException("Остаток изменяйте через «Приход / Расход / Списание» или «Пересчёт». Это сохраняет историю операций.");
            }
            using var cmd=conn.CreateCommand();
            cmd.Transaction=tx;
            cmd.CommandText="""
                UPDATE Products SET Sku=@sku, Name=@name, Category=@category, Unit=@unit,
                Quantity=@qty, MinQuantity=@min, Price=@price, Location=@location,
                Supplier=@supplier, Barcode=@barcode, Comment=@comment,
                IsFavorite=@favorite, IsDemo=@demo, UpdatedAt=@date, ExpiryDate=@expiry, PackSize=@packsize, PackUnit=@packunit WHERE Id=@id
                """;
            SetParams(cmd,p);
            cmd.Parameters.AddWithValue("@id",p.Id);
            if (cmd.ExecuteNonQuery()!=1) throw new InvalidOperationException("Товар не найден, обновление не выполнено.");
            WriteLog(conn,tx,"Изменено",p.Name,$"Остаток: {p.Quantity} {p.Unit}; цена: {p.Price}");
        }
        tx.Commit();
    }

    private static void EnsureNoDuplicate(SqliteConnection conn,Product p)
    {
        using var cmd=conn.CreateCommand();
        cmd.CommandText="SELECT Id, Name FROM Products WHERE Id <> @id";
        cmd.Parameters.AddWithValue("@id",p.Id);
        using var r=cmd.ExecuteReader();
        while(r.Read())
            if(string.Equals(r.GetString(1).Trim(),p.Name.Trim(),StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Товар с таким названием уже существует.");
    }

    public List<Product> GetAll()
    {
        using var conn=Open();
        using var cmd=conn.CreateCommand();
        cmd.CommandText="SELECT Id,Sku,Name,Category,Unit,Quantity,MinQuantity,Price,Location,Supplier,Barcode,Comment,IsFavorite,IsDemo,UpdatedAt,ExpiryDate,PackSize,PackUnit FROM Products ORDER BY Name COLLATE NOCASE";
        using var r=cmd.ExecuteReader();
        var list=new List<Product>();
        while(r.Read())
        {
            var stamp = DateTimeOffset.TryParse(r.GetString(14), CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeUniversal, out var parsed) ? parsed : DateTimeOffset.UtcNow;
            list.Add(new Product
            {
                Id=r.GetInt64(0),Sku=r.GetString(1),Name=r.GetString(2),Category=r.GetString(3),
                Unit=r.GetString(4),Quantity=(decimal)r.GetDouble(5),MinQuantity=(decimal)r.GetDouble(6),
                Price=(decimal)r.GetDouble(7),Location=r.GetString(8),Supplier=r.GetString(9),
                Barcode=r.GetString(10),Comment=r.GetString(11),IsFavorite=r.GetInt64(12)==1,
                IsDemo=r.GetInt64(13)==1,UpdatedAt=stamp,
                ExpiryDate=r.IsDBNull(15) ? null : DateTime.ParseExact(r.GetString(15),"yyyy-MM-dd",CultureInfo.InvariantCulture),
                PackSize=(decimal)r.GetDouble(16),PackUnit=r.GetString(17)
            });
        }
        return list;
    }

    public void Delete(IReadOnlyCollection<Product> products)
    {
        using var conn=Open();
        using var tx=conn.BeginTransaction();
        foreach(var p in products)
        {
            using var cmd=conn.CreateCommand();
            cmd.Transaction=tx;
            cmd.CommandText="DELETE FROM Products WHERE Id=@id";
            cmd.Parameters.AddWithValue("@id",p.Id);
            if(cmd.ExecuteNonQuery()==1) WriteLog(conn,tx,"Удалено",p.Name,$"Было {p.Quantity} {p.Unit}");
        }
        tx.Commit();
    }

    public void RestoreDeleted(IReadOnlyCollection<Product> products)
    {
        using var conn=Open();
        using var tx=conn.BeginTransaction();
        foreach(var p in products)
        {
            Insert(conn,tx,p,preserveId:true);
            WriteLog(conn,tx,"Восстановлено",p.Name,"Отмена последнего удаления");
        }
        tx.Commit();
    }

    /// <summary>One atomic update for all selected products: no partly applied edit on failure.</summary>
    public int ApplyBulkAtomic(IReadOnlyCollection<long> ids, string category, string location, string supplier, decimal? minimum)
    {
        var unique=ids.Distinct().ToArray();
        if(unique.Length==0)throw new ArgumentException("Не выбраны товары.");
        if(minimum is < 0 or > 1000000000m || (minimum.HasValue && decimal.Round(minimum.Value,4)!=minimum.Value))
            throw new ArgumentException("Минимальный остаток должен быть неотрицательным с точностью до 4 знаков.");
        if(category.Length>120 || location.Length>120 || supplier.Length>250)
            throw new ArgumentException("Значение массового изменения слишком длинное.");
        using var conn=Open();using var tx=conn.BeginTransaction();
        foreach(var id in unique)
        {
            using var c=conn.CreateCommand();c.Transaction=tx;
            c.CommandText="UPDATE Products SET Category=CASE WHEN @cat='' THEN Category ELSE @cat END, Location=CASE WHEN @location='' THEN Location ELSE @location END, Supplier=CASE WHEN @supplier='' THEN Supplier ELSE @supplier END, MinQuantity=COALESCE(@min,MinQuantity), UpdatedAt=@time WHERE Id=@id";
            c.Parameters.AddWithValue("@id",id);
            c.Parameters.AddWithValue("@cat",category.Trim());
            c.Parameters.AddWithValue("@location",location.Trim());
            c.Parameters.AddWithValue("@supplier",supplier.Trim());
            c.Parameters.AddWithValue("@min",minimum.HasValue?(object)(double)minimum.Value:DBNull.Value);
            c.Parameters.AddWithValue("@time",DateTimeOffset.UtcNow.UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
            if(c.ExecuteNonQuery()!=1)throw new InvalidOperationException($"Товар №{id} не найден: ни одно изменение не сохранено.");
        }
        WriteLog(conn,tx,"Массовое изменение","Каталог",$"Обновлено {unique.Length} позиций одним действием");
        tx.Commit();return unique.Length;
    }

    public IReadOnlyList<string> DescribeImport(IReadOnlyCollection<Product> imported, int maxItems=15)
    {
        var current=GetAll().ToDictionary(x=>x.Name.Trim(),StringComparer.OrdinalIgnoreCase);
        var lines=new List<string>();
        foreach(var item in imported)
        {
            if(!current.TryGetValue(item.Name.Trim(),out var old))
                lines.Add($"НОВЫЙ: {item.Name} · {item.Quantity} {item.Unit}");
            else
            {
                var diffs=new List<string>();
                if(old.Quantity!=item.Quantity)diffs.Add($"кол-во {old.Quantity} → {item.Quantity}");
                if(old.MinQuantity!=item.MinQuantity)diffs.Add($"минимум {old.MinQuantity} → {item.MinQuantity}");
                if(old.Price!=item.Price)diffs.Add($"цена {old.Price} → {item.Price}");
                if(diffs.Count>0)lines.Add($"{item.Name}: "+string.Join(", ",diffs));
            }
            if(lines.Count>=maxItems)break;
        }
        return lines;
    }

    public IReadOnlyList<(string Name, DateTime Modified, long Bytes)> AvailableBackups(int max=20)
    {
        var folder=Path.Combine(Path.GetDirectoryName(DatabasePath)!,"backups");
        return Directory.Exists(folder)
            ? Directory.GetFiles(folder,"*.db").Select(x=>new FileInfo(x))
                .OrderByDescending(x=>x.LastWriteTimeUtc).Take(max)
                .Select(x=>(x.Name,x.LastWriteTime,x.Length)).ToArray()
            : Array.Empty<(string,DateTime,long)>();
    }

    public void AutoBackupDaily()
    {
        var backupDir=Path.Combine(Path.GetDirectoryName(DatabasePath)!,"backups");
        Directory.CreateDirectory(backupDir);
        var dest=Path.Combine(backupDir,"daily-"+DateTime.Now.ToString("yyyy-MM-dd")+".db");
        if(!File.Exists(dest)) Backup(dest);
        foreach(var old in Directory.GetFiles(backupDir,"daily-*.db").OrderByDescending(x=>x).Skip(14))
            try { File.Delete(old); } catch(IOException) { /* Another backup process is using the file. */ }
    }

    public (int New, int Existing) PreviewImport(IReadOnlyCollection<Product> items)
    {
        using var conn=Open();
        using var cmd=conn.CreateCommand();cmd.CommandText="SELECT Name FROM Products";
        var names=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using(var reader=cmd.ExecuteReader())while(reader.Read())names.Add(reader.GetString(0).Trim());
        return (items.Count(p=>!names.Contains(p.Name.Trim())),items.Count(p=>names.Contains(p.Name.Trim())));
    }

    // Updates quantities/prices only when the user explicitly approves; all in one transaction.
    public ImportResult ImportUpdating(IReadOnlyCollection<Product> products)
    {
        using var conn=Open();using var tx=conn.BeginTransaction();
        int inserted=0,updated=0;
        var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var p in products)
        {
            Validate(p);
            if(!seen.Add(p.Name.Trim())) throw new InvalidDataException("В Excel дважды встречается товар: "+p.Name);
            using var get=conn.CreateCommand();get.Transaction=tx;
            get.CommandText="SELECT Id FROM Products WHERE Name=@name COLLATE NOCASE";
            get.Parameters.AddWithValue("@name",p.Name.Trim());
            var id=get.ExecuteScalar();
            p.UpdatedAt=DateTimeOffset.UtcNow;
            if(id is null) {Insert(conn,tx,p);inserted++;}
            else
            {
                using var cmd=conn.CreateCommand();cmd.Transaction=tx;
                cmd.CommandText="UPDATE Products SET Quantity=@qty, MinQuantity=@min, Price=@price, UpdatedAt=@now, IsDemo=0 WHERE Id=@id";
                cmd.Parameters.AddWithValue("@qty",Convert.ToDouble(p.Quantity));
                cmd.Parameters.AddWithValue("@min",Convert.ToDouble(p.MinQuantity));
                cmd.Parameters.AddWithValue("@price",Convert.ToDouble(p.Price));
                cmd.Parameters.AddWithValue("@now",p.UpdatedAt.UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@id",Convert.ToInt64(id));cmd.ExecuteNonQuery();updated++;
            }
        }
        WriteLog(conn,tx,"Импорт Excel","Каталог",$"Добавлено: {inserted}; обновлено: {updated}");
        tx.Commit();return new ImportResult(inserted,updated);
    }

    public ImportResult Import(IReadOnlyCollection<Product> products)
    {
        using var conn=Open();
        using var tx=conn.BeginTransaction();
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        using(var current = conn.CreateCommand())
        {
            current.Transaction=tx;
            current.CommandText="SELECT Name FROM Products";
            using var read = current.ExecuteReader();
            while(read.Read())names.Add(read.GetString(0).Trim());
        }
        int added=0,skipped=0;
        foreach (var p in products)
        {
            Validate(p);
            if(!names.Add(p.Name.Trim())) { skipped++; continue; }
            p.UpdatedAt=DateTimeOffset.UtcNow;
            var count=Insert(conn,tx,p,orIgnore:true);
            added+=count;
            skipped+=1-count;
        }
        WriteLog(conn,tx,"Импорт","Каталог",$"Добавлено {added}, пропущено дубликатов {skipped}");
        tx.Commit();
        return new ImportResult(added,skipped);
    }

    public void ClearDemoQuantities()
    {
        using var conn=Open();
        using var tx=conn.BeginTransaction();
        using var cmd=conn.CreateCommand();
        cmd.Transaction=tx;
        cmd.CommandText="UPDATE Products SET Quantity=0, IsDemo=0, UpdatedAt=@date WHERE IsDemo=1";
        cmd.Parameters.AddWithValue("@date",DateTimeOffset.UtcNow.UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
        var rows=cmd.ExecuteNonQuery();
        WriteLog(conn,tx,"Сброшены демо-остатки","Каталог",$"Товаров: {rows}");
        tx.Commit();
    }

    public List<ChangeEntry> RecentChanges(int limit=120)
    {
        using var conn=Open();
        using var cmd=conn.CreateCommand();
        cmd.CommandText="SELECT Timestamp, Action, ProductName, Details FROM Changes ORDER BY Id DESC LIMIT @limit";
        cmd.Parameters.AddWithValue("@limit",limit);
        using var r=cmd.ExecuteReader();
        var result=new List<ChangeEntry>();
        while(r.Read())
        {
            var ts=DateTimeOffset.Parse(r.GetString(0),CultureInfo.InvariantCulture).LocalDateTime.ToString("dd.MM.yyyy HH:mm");
            result.Add(new ChangeEntry(ts,r.GetString(1),r.GetString(2),r.GetString(3)));
        }
        return result;
    }

    private static void WriteLog(SqliteConnection conn,SqliteTransaction tx,string action,string name,string detail)
    {
        using var cmd=conn.CreateCommand();
        cmd.Transaction=tx;
        cmd.CommandText="INSERT INTO Changes(Timestamp,Action,ProductName,Details) VALUES(@stamp,@action,@name,@details)";
        cmd.Parameters.AddWithValue("@stamp",DateTimeOffset.UtcNow.UtcDateTime.ToString("o",CultureInfo.InvariantCulture));
        cmd.Parameters.AddWithValue("@action",action);
        cmd.Parameters.AddWithValue("@name",name);
        cmd.Parameters.AddWithValue("@details",detail);
        cmd.ExecuteNonQuery();
    }

    public string CheckIntegrity()
    {
        using var conn = Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = "PRAGMA integrity_check";
        var result = cmd.ExecuteScalar()?.ToString() ?? "Неизвестная ошибка проверки";
        if (result != "ok") throw new InvalidDataException("SQLite: " + result);
        cmd.CommandText = "PRAGMA foreign_key_check";
        using var r = cmd.ExecuteReader();
        if (r.Read()) throw new InvalidDataException("Обнаружены нарушения связей базы SQLite.");
        return "ok";
    }

    public void Backup(string target)
    {
        if (Path.GetFullPath(target).Equals(Path.GetFullPath(DatabasePath), StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Выберите другое имя резервной копии.");
        using var source=Open();
        using var dest=new SqliteConnection(new SqliteConnectionStringBuilder { DataSource=target }.ToString());
        dest.Open();
        source.BackupDatabase(dest);
    }

    public void Restore(string source)
    {
        if (Path.GetFullPath(source).Equals(Path.GetFullPath(DatabasePath), StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Нельзя восстановить базу из самой себя.");
        using(var check=new SqliteConnection(new SqliteConnectionStringBuilder {DataSource=source,Mode=SqliteOpenMode.ReadOnly}.ToString()))
        {
            check.Open();
            using var cmd=check.CreateCommand();
            cmd.CommandText="PRAGMA integrity_check;";
            if (!string.Equals(cmd.ExecuteScalar()?.ToString(),"ok",StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Поврежденная резервная копия SQLite.");
            cmd.CommandText="SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='Products'";
            if (Convert.ToInt32(cmd.ExecuteScalar())!=1) throw new InvalidDataException("Файл не содержит таблицу товаров.");
        }
        // Preserve an automatic rollback copy before replacing any existing data.
        var safety=Path.Combine(Path.GetDirectoryName(DatabasePath)!,"before-restore-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".db");
        Backup(safety);
        // Microsoft.Data.Sqlite uses connection pooling; release native file handles
        // before overwriting the database file on Windows.
        SqliteConnection.ClearAllPools();
        File.Copy(source,DatabasePath,true);
        Initialize();
    }
}
