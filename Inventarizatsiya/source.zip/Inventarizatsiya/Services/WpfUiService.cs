using Microsoft.Win32;
using System.Windows;

namespace Inventarizatsiya.Services;

public sealed class WpfUiService : IUiService
{
    public void Message(string message, string title = "Инвентаризация") =>
        MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);

    public bool Confirm(string message, string title = "Подтверждение") =>
        MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Warning,
            MessageBoxResult.No) == MessageBoxResult.Yes;

    public string? SavePath(string title, string filter, string extension, string filename)
    {
        var dlg = new SaveFileDialog { Title=title, Filter=filter, DefaultExt=extension,
            AddExtension=true, FileName=filename, OverwritePrompt=true };
        return dlg.ShowDialog() == true ? dlg.FileName : null;
    }
    public string? OpenPath(string title, string filter)
    {
        var dlg = new OpenFileDialog { Title=title, Filter=filter, CheckFileExists=true };
        return dlg.ShowDialog() == true ? dlg.FileName : null;
    }
}
