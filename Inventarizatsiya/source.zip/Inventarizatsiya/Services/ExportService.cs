using ClosedXML.Excel;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Inventarizatsiya.Models;
using System.Globalization;
using W=DocumentFormat.OpenXml.Wordprocessing;

namespace Inventarizatsiya.Services;

public sealed class ExportService
{
    private static readonly CultureInfo Ru=CultureInfo.GetCultureInfo("ru-RU");
    private static string Money(decimal value)=>value.ToString("N2",Ru);
    private static string Quantity(decimal value)=>value.ToString("0.##",Ru);
    private static readonly string[] Headers =
    {
        "№","Артикул","Наименование","Категория","Единица","Количество",
        "Минимальный остаток","Цена за единицу","Сумма","Место хранения",
        "Поставщик","Штрихкод","Дата изменения","Комментарий","Годен до","В упаковке","Тип упаковки"
    };

    public void ExportExcel(string filename, IReadOnlyList<Product> list)
    {
        using var book=new XLWorkbook();
        var ws=book.AddWorksheet("Инвентаризация");
        ws.Cell(1,1).Value="ИНВЕНТАРИЗАЦИЯ · СПИСОК ТОВАРОВ";
        ws.Range(1,1,1,17).Merge();
        ws.Cell(2,1).Value="Дата формирования: "+DateTime.Now.ToString("dd.MM.yyyy HH:mm",Ru);
        ws.Range(2,1,2,17).Merge();
        for(int j=0;j<Headers.Length;j++)ws.Cell(4,j+1).Value=Headers[j];
        ApplyHeader(ws,4,17);
        for(int i=0;i<list.Count;i++)
        {
            var p=list[i]; int row=i+5;
            object[] data = {i+1,p.Sku,p.Name,p.Category,p.Unit,(double)p.Quantity,(double)p.MinQuantity,
                (double)p.Price,(double)p.Total,p.Location,p.Supplier,p.Barcode,p.UpdatedLocal,p.Comment,
                p.ExpiryDate?.ToString("dd.MM.yyyy") ?? "",(double)p.PackSize,p.PackUnit};
            for(int j=0;j<data.Length;j++) SetValue(ws.Cell(row,j+1),data[j]);
            if(p.IsEmpty) ws.Range(row,1,row,17).Style.Fill.BackgroundColor=XLColor.FromHtml("#FFE1E1");
            else if(p.IsLow) ws.Range(row,1,row,17).Style.Fill.BackgroundColor=XLColor.FromHtml("#FFE9CA");
        }
        var last=4+list.Count;
        var totalRow=last+2;
        ws.Cell(totalRow,3).Value="ВСЕГО (стоимость):";
        ws.Cell(totalRow,9).Value=(double)list.Sum(p=>p.Total);
        ws.Cell(totalRow,9).Style.Font.Bold=true;
        ws.Range(5,8,totalRow,9).Style.NumberFormat.Format="#,##0.00";
        ws.Range(5,6,Math.Max(5,last),7).Style.NumberFormat.Format="#,##0.##";
        FormatSheet(ws,4,Math.Max(last,4),17);
        book.SaveAs(filename);
    }

    public void ExportCountReport(string filename,IReadOnlyList<CountLine> list,string responsible)
    {
        using var book=new XLWorkbook();
        var ws=book.AddWorksheet("Расхождения");
        ws.Cell(1,1).Value="МАЯК · ИТОГИ ПЕРЕСЧЁТА";
        ws.Range(1,1,1,9).Merge();
        ws.Cell(2,1).Value=$"Дата: {DateTime.Now:dd.MM.yyyy HH:mm} · Ответственный: {responsible}";
        ws.Range(2,1,2,9).Merge();
        string[] titles={"№","Наименование","Ед.","По учёту","Факт","Разница","Цена","Излишек / недостача ₽","Статус"};
        for(int j=0;j<titles.Length;j++)ws.Cell(4,j+1).Value=titles[j];
        ApplyHeader(ws,4,9);
        for(int i=0;i<list.Count;i++)
        {
            var x=list[i];int row=i+5;
            ws.Cell(row,1).Value=i+1; ws.Cell(row,2).Value=x.Name; ws.Cell(row,3).Value=x.Unit;
            ws.Cell(row,4).Value=(double)x.BookQuantity;
            if(x.ActualQuantity.HasValue) ws.Cell(row,5).Value=(double)x.ActualQuantity.Value;
            ws.Cell(row,6).FormulaA1=$"IF(E{row}=\"\",\"\",E{row}-D{row})";
            ws.Cell(row,7).Value=(double)x.Price;
            ws.Cell(row,8).FormulaA1=$"IF(F{row}=\"\",\"\",F{row}*G{row})";
            ws.Cell(row,9).FormulaA1=$"IF(E{row}=\"\",\"Не проверено\",IF(F{row}=0,\"Совпадает\",IF(F{row}>0,\"Излишек\",\"Недостача\")))";
            if(x.Variance < 0) ws.Range(row,1,row,9).Style.Fill.BackgroundColor=XLColor.FromHtml("#FEE2E2");
            else if(x.Variance>0) ws.Range(row,1,row,9).Style.Fill.BackgroundColor=XLColor.FromHtml("#FEF3C7");
        }
        int last=4+list.Count;
        ws.Cell(last+2,2).Value="Итого расхождения, ₽";
        ws.Cell(last+2,8).FormulaA1=$"SUM(H5:H{last})";
        ws.Cell(last+4,2).Value="Сдал: ________________________";
        ws.Cell(last+5,2).Value="Принял: ______________________";
        ws.Range(5,4,Math.Max(5,last),8).Style.NumberFormat.Format="#,##0.00";
        FormatSheet(ws,4,Math.Max(4,last),9);
        book.SaveAs(filename);
    }

    public void ExportCategories(string filename, IReadOnlyList<Product> list)
    {
        var categories=list.GroupBy(x=>x.Category).OrderBy(x=>x.Key).ToList();
        using var book=new XLWorkbook();
        var ws=book.AddWorksheet("По категориям");
        ws.Cell(1,1).Value="ОТЧЁТ ПО КАТЕГОРИЯМ · "+DateTime.Now.ToString("dd.MM.yyyy",Ru);
        ws.Range(1,1,1,5).Merge();
        var header=new[]{"Категория","Позиций","Мало","Нет в наличии","Стоимость"};
        for(int j=0;j<header.Length;j++) ws.Cell(3,j+1).Value=header[j];
        ApplyHeader(ws,3,5);
        for(int i=0;i<categories.Count;i++)
        {
            var category=categories[i]; var row=i+4;
            ws.Cell(row,1).Value=category.Key;
            ws.Cell(row,2).Value=category.Count();
            ws.Cell(row,3).Value=category.Count(p=>p.IsLow);
            ws.Cell(row,4).Value=category.Count(p=>p.IsEmpty);
            ws.Cell(row,5).Value=(double)category.Sum(p=>p.Total);
        }
        ws.Column(5).Style.NumberFormat.Format="#,##0.00";
        FormatSheet(ws,3,Math.Max(3,categories.Count+3),5);
        book.SaveAs(filename);
    }

    public void ExportInventoryStatement(string filename, IReadOnlyList<Product> list, string responsible)
    {
        using var book=new XLWorkbook();
        var ws=book.AddWorksheet("Ведомость");
        ws.Cell(1,1).Value="ВЕДОМОСТЬ ИНВЕНТАРИЗАЦИИ ПРОДУКТОВ";
        ws.Range(1,1,1,10).Merge();
        ws.Cell(2,1).Value=$"Дата: {DateTime.Now:dd.MM.yyyy}   Ответственный: {responsible}";
        ws.Range(2,1,2,10).Merge();
        var header=new[]{"№","Наименование","Категория","Ед.","Учётное кол-во","Фактическое кол-во","Разница","Цена","Сумма по учёту","Примечание"};
        for(int j=0;j<header.Length;j++) ws.Cell(4,j+1).Value=header[j];
        ApplyHeader(ws,4,10);
        for(int i=0;i<list.Count;i++)
        {
            var p=list[i];var row=i+5;
            ws.Cell(row,1).Value=i+1;
            ws.Cell(row,2).Value=p.Name;
            ws.Cell(row,3).Value=p.Category;
            ws.Cell(row,4).Value=p.Unit;
            ws.Cell(row,5).Value=(double)p.Quantity;
            ws.Cell(row,7).FormulaA1=$"IF(F{row}=\"\",\"\",F{row}-E{row})";
            ws.Cell(row,8).Value=(double)p.Price;
            ws.Cell(row,9).Value=(double)p.Total;
        }
        int finish=list.Count+6;
        ws.Cell(finish,2).Value="Общая стоимость:";
        ws.Cell(finish,9).Value=(double)list.Sum(p=>p.Total);
        ws.Cell(finish+2,2).Value="Сдал: __________________________";
        ws.Cell(finish+3,2).Value="Принял: _________________________";
        ws.Cell(finish+4,2).Value="Ответственный: __________________";
        ws.Range(5,5,finish,9).Style.NumberFormat.Format="#,##0.##";
        FormatSheet(ws,4,finish+4,10);
        ws.PageSetup.PageOrientation=XLPageOrientation.Landscape;
        ws.PageSetup.FitToPages(1,0);
        book.SaveAs(filename);
    }

    public void ExportOrderList(string filename,IReadOnlyList<Product> list)
    {
        using var book=new XLWorkbook();
        var ws=book.AddWorksheet("К заказу");
        ws.Cell(1,1).Value="СПИСОК ДЛЯ ЗАКАЗА · "+DateTime.Now.ToString("dd.MM.yyyy",Ru);
        ws.Range(1,1,1,8).Merge();
        string[] titles={"№","Товар","Категория","Ед.","Остаток","Минимум","Нужно заказать","Поставщик"};
        for(int j=0;j<titles.Length;j++)ws.Cell(3,j+1).Value=titles[j];
        ApplyHeader(ws,3,8);
        for(int i=0;i<list.Count;i++)
        {
            var p=list[i]; var row=i+4;
            ws.Cell(row,1).Value=i+1;
            ws.Cell(row,2).Value=p.Name;
            ws.Cell(row,3).Value=p.Category;
            ws.Cell(row,4).Value=p.Unit;
            ws.Cell(row,5).Value=(double)p.Quantity;
            ws.Cell(row,6).Value=(double)p.MinQuantity;
            ws.Cell(row,7).Value=(double)Math.Max(0,p.MinQuantity-p.Quantity);
            ws.Cell(row,8).Value=p.Supplier;
        }
        FormatSheet(ws,3,Math.Max(3,list.Count+3),8);
        book.SaveAs(filename);
    }

    public void ExportDailyChanges(string filename,IReadOnlyList<ChangeEntry> changes)
    {
        using var book=new XLWorkbook();
        var ws=book.AddWorksheet("Изменения за день");
        ws.Cell(1,1).Value="ИЗМЕНЕНИЯ ЗА "+DateTime.Now.ToString("dd.MM.yyyy",Ru);
        ws.Range(1,1,1,4).Merge();
        string[] titles={"Дата и время","Действие","Наименование","Подробности"};
        for(int j=0;j<titles.Length;j++)ws.Cell(3,j+1).Value=titles[j];
        ApplyHeader(ws,3,4);
        for(int i=0;i<changes.Count;i++)
        {
            var c=changes[i];var row=i+4;
            ws.Cell(row,1).Value=c.Time;
            ws.Cell(row,2).Value=c.Action;
            ws.Cell(row,3).Value=c.Product;
            ws.Cell(row,4).Value=c.Details;
        }
        FormatSheet(ws,3,Math.Max(3,changes.Count+3),4);
        book.SaveAs(filename);
    }

    private static void SetValue(IXLCell cell,object data)
    {
        switch(data)
        {
            case int integer:cell.Value=integer;break;
            case double number:cell.Value=number;break;
            default:cell.Value=data.ToString() ?? "";break;
        }
    }

    private static void ApplyHeader(IXLWorksheet ws,int row,int cols)
    {
        var rng=ws.Range(row,1,row,cols);
        rng.Style.Fill.BackgroundColor=XLColor.FromHtml("#243446");
        rng.Style.Font.FontColor=XLColor.White;
        rng.Style.Font.Bold=true;
        rng.Style.Alignment.WrapText=true;
        ws.Row(row).Height=32;
    }

    private static void FormatSheet(IXLWorksheet ws,int headerRow,int bottom,int cols)
    {
        ws.SheetView.FreezeRows(headerRow);
        ws.Range(headerRow,1,bottom,cols).SetAutoFilter();
        ws.Range(headerRow,1,bottom,cols).Style.Border.OutsideBorder=XLBorderStyleValues.Thin;
        ws.Range(headerRow,1,bottom,cols).Style.Border.InsideBorder=XLBorderStyleValues.Hair;
        for(int j=1;j<=cols;j++)
        {
            ws.Column(j).AdjustToContents();
            ws.Column(j).Width=Math.Clamp(ws.Column(j).Width,9,40);
        }
        ws.Column(1).Width=7;
        ws.Column(3).Width=Math.Max(ws.Column(3).Width,25);
        ws.PageSetup.PageOrientation=XLPageOrientation.Landscape;
        ws.PageSetup.FitToPages(1,0);
    }

    public void ExportWord(string filename,IReadOnlyList<Product> list,string responsible)
    {
        using var file=WordprocessingDocument.Create(filename,WordprocessingDocumentType.Document);
        var main=file.AddMainDocumentPart();
        main.Document=new W.Document();
        var body=main.Document.AppendChild(new W.Body());
        var section=new SectionProperties(
            new PageSize { Width=15840U,Height=12240U,Orient=PageOrientationValues.Landscape },
            new PageMargin { Top=800,Right=720,Bottom=800,Left=720,Header=360,Footer=360 });
        body.Append(Para("ВЕДОМОСТЬ ИНВЕНТАРИЗАЦИИ ПРОДУКТОВ",true,30));
        body.Append(Para($"Дата формирования: {DateTime.Now:dd.MM.yyyy HH:mm}    Ответственный: {responsible}",false,22));
        body.Append(Para($"Позиций: {list.Count}    Общая стоимость: {Money(list.Sum(p=>p.Total))} руб.",false,22));
        var table=new W.Table();
        table.AppendChild(new TableProperties(
            new TableWidth { Width="0", Type=TableWidthUnitValues.Auto },
            new TableBorders(
                new TopBorder{Val=BorderValues.Single,Size=6},
                new BottomBorder{Val=BorderValues.Single,Size=6},
                new LeftBorder{Val=BorderValues.Single,Size=6},
                new RightBorder{Val=BorderValues.Single,Size=6},
                new InsideHorizontalBorder{Val=BorderValues.Single,Size=4},
                new InsideVerticalBorder{Val=BorderValues.Single,Size=4})));
        var header=new W.TableRow();
        foreach(var h in new[]{"№","Наименование","Ед.","По учёту","Факт","Разница","Цена","Сумма"})
            header.Append(Cell(h,true));
        table.Append(header);
        for(int i=0;i<list.Count;i++)
        {
            var p=list[i];
            var row=new W.TableRow();
            foreach(var field in new[]{(i+1).ToString(),p.Name,p.Unit,Quantity(p.Quantity),"","",Money(p.Price),Money(p.Total)})
                row.Append(Cell(field,false));
            table.Append(row);
        }
        body.Append(table);
        body.Append(Para("Количество считается отдельно по каждой единице измерения (кг, л, шт. и др.).",false,18));
        foreach(var group in list.GroupBy(p=>p.Unit).OrderBy(g=>g.Key))
            body.Append(Para($"{group.Key}: {Quantity(group.Sum(p=>p.Quantity))}",false,18));
        body.Append(Para($"Итого стоимость запасов: {Money(list.Sum(p=>p.Total))} руб.",true,22));
        body.Append(Para("Сдал: _________________________ / _________________________",false,20));
        body.Append(Para("Принял: _______________________ / _________________________",false,20));
        body.Append(Para("Члены комиссии: ___________________________________________________",false,20));
        body.Append(section);
        main.Document.Save();
    }

    private static W.Paragraph Para(string text,bool bold,int size)
    {
        var run=new W.Run();
        run.Append(new W.RunProperties(new W.RunFonts{Ascii="Aptos",HighAnsi="Aptos"},
            new W.FontSize{Val=size.ToString()},bold?new W.Bold():new W.Bold{Val=false}));
        run.Append(new W.Text(text){Space=SpaceProcessingModeValues.Preserve});
        return new W.Paragraph(run);
    }
    private static W.TableCell Cell(string text,bool bold)
    {
        var cell=new W.TableCell(Para(text,bold,17));
        cell.Append(new W.TableCellProperties(new W.TableCellWidth { Type=TableWidthUnitValues.Auto }));
        return cell;
    }
}
