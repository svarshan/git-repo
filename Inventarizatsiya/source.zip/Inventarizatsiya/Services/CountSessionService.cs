using System.Globalization;
using Inventarizatsiya.Models;
using Microsoft.Data.Sqlite;

namespace Inventarizatsiya.Services;
public sealed class CountSessionService(DatabaseService database)
{
    private SqliteConnection Open() { var c=new SqliteConnection(new SqliteConnectionStringBuilder {DataSource=database.DatabasePath}.ToString());c.Open();return c; }
    public long Start(string warehouse)
    {
        using var conn=Open();using var tx=conn.BeginTransaction();
        using var command=conn.CreateCommand();command.Transaction=tx;
        command.CommandText="INSERT INTO CountSessions (StartedAt,Warehouse) VALUES (@ts,@warehouse);SELECT last_insert_rowid();";
        command.Parameters.AddWithValue("@ts",DateTimeOffset.UtcNow.ToString("o"));
        command.Parameters.AddWithValue("@warehouse",warehouse);
        long id=(long)(command.ExecuteScalar() ?? 0L);
        using var add=conn.CreateCommand();add.Transaction=tx;
        add.CommandText="""
            INSERT INTO CountRows(SessionId,ProductId,ProductName,Unit,BookQuantity,Price)
            SELECT @session,Id,Name,Unit,Quantity,Price FROM Products
            WHERE @warehouse = 'Все места' OR Location = @warehouse
            """;
        add.Parameters.AddWithValue("@session",id);add.Parameters.AddWithValue("@warehouse",warehouse);add.ExecuteNonQuery();
        tx.Commit();return id;
    }
    public (long Id, string Warehouse, bool Completed)? Latest()
    {
        using var c=Open();using var cmd=c.CreateCommand();
        cmd.CommandText="SELECT Id,Warehouse,Status FROM CountSessions ORDER BY Id DESC LIMIT 1";
        using var r=cmd.ExecuteReader();return r.Read() ? (r.GetInt64(0),r.GetString(1),r.GetString(2)=="Закрыта") : null;
    }
    public List<CountLine> Lines(long id)
    {
        using var c=Open();using var cmd=c.CreateCommand();
        cmd.CommandText="SELECT ProductId,ProductName,Unit,BookQuantity,Price,ActualQuantity FROM CountRows WHERE SessionId=@id ORDER BY ProductName";
        cmd.Parameters.AddWithValue("@id",id);using var r=cmd.ExecuteReader();var lines=new List<CountLine>();
        while(r.Read())lines.Add(new CountLine {ProductId=r.GetInt64(0),Name=r.GetString(1),Unit=r.GetString(2),BookQuantity=(decimal)r.GetDouble(3),Price=(decimal)r.GetDouble(4),ActualQuantity=r.IsDBNull(5)?null:(decimal)r.GetDouble(5)});
        return lines;
    }
    public void SaveFact(long sessionId, CountLine line)
    {
        using var conn=Open();using var command=conn.CreateCommand();
        command.CommandText="""
            UPDATE CountRows SET ActualQuantity=@fact WHERE SessionId=@sid AND ProductId=@pid
            AND EXISTS(SELECT 1 FROM CountSessions WHERE Id=@sid AND Status='Открыта')
            """;
        command.Parameters.AddWithValue("@fact",line.ActualQuantity.HasValue ? Convert.ToDouble(line.ActualQuantity.Value) : DBNull.Value);
        command.Parameters.AddWithValue("@sid",sessionId);
        command.Parameters.AddWithValue("@pid",line.ProductId);
        if(command.ExecuteNonQuery()!=1)
            throw new InvalidOperationException("Не удалось сохранить факт: пересчёт закрыт или позиция отсутствует.");
    }

    public void SaveFacts(long sessionId, IEnumerable<CountLine> lines)
    {
        using var conn=Open();using var tx=conn.BeginTransaction();
        foreach(var line in lines)
        {
            using var command=conn.CreateCommand();command.Transaction=tx;
            command.CommandText="""
                UPDATE CountRows SET ActualQuantity=@fact WHERE SessionId=@sid AND ProductId=@pid
                AND EXISTS(SELECT 1 FROM CountSessions WHERE Id=@sid AND Status='Открыта')
                """;
            command.Parameters.AddWithValue("@fact",line.ActualQuantity.HasValue ? Convert.ToDouble(line.ActualQuantity.Value) : DBNull.Value);
            command.Parameters.AddWithValue("@sid",sessionId);command.Parameters.AddWithValue("@pid",line.ProductId);
            if(command.ExecuteNonQuery()!=1)throw new InvalidOperationException("Сессия уже закрыта или товар отсутствует.");
        }
        tx.Commit();
    }
    public int Commit(long sessionId)
    {
        using var conn=Open();using var tx=conn.BeginTransaction();
        using var check=conn.CreateCommand();check.Transaction=tx;
        check.CommandText="SELECT COUNT(*) FROM CountRows WHERE SessionId=@sid AND ActualQuantity IS NOT NULL AND EXISTS(SELECT 1 FROM Products p WHERE p.Id=CountRows.ProductId AND abs(p.Quantity-CountRows.BookQuantity)>0.00001)";
        check.Parameters.AddWithValue("@sid",sessionId);
        if(Convert.ToInt32(check.ExecuteScalar())>0)throw new InvalidOperationException("Учётные остатки изменены после начала пересчёта. Создайте новую инвентаризацию: прежние числа сохранены.");
        using var update=conn.CreateCommand();update.Transaction=tx;
        update.CommandText="""
            UPDATE Products SET Quantity=(SELECT ActualQuantity FROM CountRows r WHERE r.ProductId=Products.Id AND r.SessionId=@sid),
            IsDemo=0,UpdatedAt=@now
            WHERE Id IN (SELECT ProductId FROM CountRows WHERE SessionId=@sid AND ActualQuantity IS NOT NULL)
            AND EXISTS(SELECT 1 FROM CountSessions WHERE Id=@sid AND Status='Открыта')
            """;
        update.Parameters.AddWithValue("@sid",sessionId);update.Parameters.AddWithValue("@now",DateTimeOffset.UtcNow.ToString("o"));
        int done=update.ExecuteNonQuery();
        using var close=conn.CreateCommand();close.Transaction=tx;
        close.CommandText="UPDATE CountSessions SET Status='Закрыта',CompletedAt=@ts WHERE Id=@sid AND Status='Открыта'";
        close.Parameters.AddWithValue("@sid",sessionId);close.Parameters.AddWithValue("@ts",DateTimeOffset.UtcNow.ToString("o"));
        if(close.ExecuteNonQuery()!=1)throw new InvalidOperationException("Пересчёт уже завершён.");
        tx.Commit();return done;
    }
}
