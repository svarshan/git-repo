using System.Text;
namespace Inventarizatsiya.Helpers;
public static class SearchNormalizer
{
    const string Eng="qwertyuiop[]asdfghjkl;'zxcvbnm,.";
    const string Rus="йцукенгшщзхъфывапролджэячсмитьбю";
    public static string FixKeyboard(string text)
    {
        var builder=new StringBuilder();
        foreach(var c in text.ToLowerInvariant())
        { var i=Eng.IndexOf(c); builder.Append(i>=0?Rus[i]:c); }
        return builder.ToString();
    }
    // 'ghtrk' keyboard typo and prefix matching. The original query is also preserved.
    public static bool Match(string input,string query)
    {
        if(input.Contains(query,StringComparison.CurrentCultureIgnoreCase)) return true;
        var corrected=FixKeyboard(query);
        if(corrected!=query && input.Contains(corrected,StringComparison.CurrentCultureIgnoreCase))return true;
        return false;
    }
}
