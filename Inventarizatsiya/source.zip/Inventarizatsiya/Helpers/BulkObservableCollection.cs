using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;

namespace Inventarizatsiya.Helpers;

/// <summary>
/// Replaces the data with a single Reset notification. Unlike calling Add
/// within ICollectionView.DeferRefresh, this does not trigger WPF currency
/// updates while the view is deferred.
/// </summary>
public sealed class BulkObservableCollection<T> : ObservableCollection<T>
{
    public void ReplaceAll(IEnumerable<T> values)
    {
        CheckReentrancy();
        Items.Clear();
        foreach (var item in values)
            Items.Add(item);
        OnPropertyChanged(new PropertyChangedEventArgs(nameof(Count)));
        OnPropertyChanged(new PropertyChangedEventArgs("Item[]"));
        OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
    }
}
