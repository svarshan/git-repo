using Inventarizatsiya.Models;
using System.Globalization;
using System.Windows.Data;

namespace Inventarizatsiya.Converters;

public sealed class StockStatusConverter : IValueConverter
{
    public object Convert(object value,Type targetType,object parameter,CultureInfo culture)
    {
        if (value is not Product item) return "";
        if (item.IsEmpty) return "Нет в наличии";
        return item.IsLow ? "Ниже минимума" : "Достаточно";
    }
    public object ConvertBack(object value,Type targetType,object parameter,CultureInfo culture) =>
        throw new NotSupportedException();
}
