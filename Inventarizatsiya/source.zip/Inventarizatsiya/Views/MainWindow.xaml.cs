using Inventarizatsiya.Models;
using Inventarizatsiya.Services;
using Inventarizatsiya.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace Inventarizatsiya.Views;

public partial class MainWindow : Window
{
    private readonly MainViewModel _vm;
    public MainWindow()
    {
        // Initialize the model before building XAML. WPF can raise
        // SelectionChanged during InitializeComponent, so event handlers
        // must never see an uninitialized view model.
        _vm = new MainViewModel(new DatabaseService(), new WpfUiService());
        DataContext = _vm;
        InitializeComponent();
        _vm.FocusSearchRequested+=(_,_)=>FocusSearch();
        _vm.OpenProductsRequested+=(_,_)=>MainTabs.SelectedIndex=1;
    }

    private void Sidebar_Checked(object sender, RoutedEventArgs e)
    {
        if (sender is RadioButton radio && MainTabs != null &&
            int.TryParse(radio.Tag?.ToString(), out var page) && page >= 0 && page < MainTabs.Items.Count)
        {
            MainTabs.SelectedIndex = page;
        }
    }

    private void MainTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!ReferenceEquals(e.OriginalSource, MainTabs)) return;
        var navigation = new[] { NavHome, NavProducts, NavQuick, NavReports, NavData };
        if (MainTabs.SelectedIndex >= 0 && MainTabs.SelectedIndex < navigation.Length)
            navigation[MainTabs.SelectedIndex].IsChecked = true;
    }

    private void FocusSearch()
    {
        MainTabs.SelectedIndex=1;
        Dispatcher.BeginInvoke(() =>
        {
            SearchBox.Focus();
            SearchBox.SelectAll();
        },DispatcherPriority.Input);
    }
    private void OpenProducts_Click(object sender,RoutedEventArgs e) => MainTabs.SelectedIndex=1;
    private void Search_Click(object sender,RoutedEventArgs e) => FocusSearch();
    private void QuickTab_Click(object sender,RoutedEventArgs e)
    {
        MainTabs.SelectedIndex=2;
        Dispatcher.BeginInvoke(()=>QuickNameBox.Focus(),DispatcherPriority.Input);
    }
    private void ProductsGrid_SelectionChanged(object sender,SelectionChangedEventArgs e) =>
        _vm?.SetSelection(ProductsGrid.SelectedItems);

    private void ProductsGrid_MouseDoubleClick(object sender,MouseButtonEventArgs e)
    {
        // Only a row can start editing; header double-click is not a product edit.
        if(e.OriginalSource is DependencyObject element &&
            ItemsControl.ContainerFromElement(ProductsGrid,element) is DataGridRow row && row.Item is Product product)
        {
            _vm.Edit(product);
        }
    }
    private void ProductsGrid_RowEditEnding(object sender,DataGridRowEditEndingEventArgs e)
    {
        if(e.EditAction!=DataGridEditAction.Commit || e.Row.Item is not Product item)return;
        // The binding commits after RowEditEnding: save after the dispatcher processes it.
        Dispatcher.BeginInvoke(()=>_vm.SaveInline(item),DispatcherPriority.Background);
    }
    private void QuickNameBox_KeyDown(object sender,KeyEventArgs e)
    {
        if(e.Key==Key.Enter)
        {
            _vm.QuickAddCommand.Execute(null);
            e.Handled=true;
        }
    }
    private void Window_KeyDown(object sender,KeyEventArgs e)
    {
        if((Keyboard.Modifiers & ModifierKeys.Control)==ModifierKeys.Control && e.Key==Key.Enter)
        {
            _vm.SaveCommand.Execute(null);
            e.Handled=true;
        }
    }
}
