using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Inventarizatsiya.Models;
using Inventarizatsiya.ViewModels;
using Inventarizatsiya.Services;
using Inventarizatsiya.Views;

namespace Inventarizatsiya;

public partial class App : Application
{
    private bool _smokeTest;

    public App()
    {
        var ru = CultureInfo.GetCultureInfo("ru-RU");
        CultureInfo.DefaultThreadCurrentCulture = ru;
        CultureInfo.DefaultThreadCurrentUICulture = ru;
        FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement),
            new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(ru.IetfLanguageTag)));

        DispatcherUnhandledException += (_, e) =>
        {
            var logPath = RecordError(e.Exception);
            if (!_smokeTest)
            {
                MessageBox.Show(
                    "Возникла ошибка: " + e.Exception.GetBaseException().Message +
                    "\n\nЖурнал диагностики:\n" + logPath,
                    "Ошибка приложения", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            e.Handled = true;
            Shutdown(1);
        };
    }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _smokeTest = e.Args.Any(arg => string.Equals(arg, "--smoke-test", StringComparison.OrdinalIgnoreCase));
        try
        {
            var window = new MainWindow();
            MainWindow = window;
            if (_smokeTest)
            {
                // On the real Windows runtime, instantiate and lay out every screen.
                window.Show();
                window.UpdateLayout();
                if (window.DataContext is not MainViewModel vm || vm.TotalCount < 500)
                    throw new InvalidDataException("Начальный каталог содержит меньше 500 товаров.");

                // Test the redesigned left navigation in a real WPF window.
                if (window.NavHome.IsChecked != true || window.NavData is null)
                    throw new InvalidDataException("Левое меню «Маяк» отсутствует или не открылось.");
                if (window.NavQuick.Visibility != Visibility.Collapsed || window.NavData.Visibility != Visibility.Collapsed)
                    throw new InvalidDataException("В главном меню остались дополнительные разделы вместо четырёх основных.");
                window.NavCount.IsChecked = true;
                if (window.MainTabs.SelectedIndex != 5)
                    throw new InvalidDataException("Кнопка «Пересчёт» не открывает инвентаризацию.");
                window.NavReports.IsChecked = true;
                if (window.MainTabs.SelectedIndex != 3)
                    throw new InvalidDataException("Левое меню не переключает страницы.");
                window.MainTabs.SelectedIndex = 0;
                if (window.NavHome.IsChecked != true)
                    throw new InvalidDataException("Навигация не синхронизируется с вкладками.");

                for (var i = 0; i < window.MainTabs.Items.Count; i++)
                {
                    window.MainTabs.SelectedIndex = i;
                    window.UpdateLayout();
                    window.Dispatcher.Invoke(() => { }, DispatcherPriority.Background);
                }
                // A real on-Windows WPF render, archived by the CI workflow.
                window.MainTabs.SelectedIndex = 0;
                window.UpdateLayout();
                window.Dispatcher.Invoke(() => { }, DispatcherPriority.Render);
                var screenshot = Environment.GetEnvironmentVariable("INVENTARIZATSIYA_SCREENSHOT");
                if (!string.IsNullOrWhiteSpace(screenshot))
                {
                    var width = Math.Max(1, (int)Math.Round(window.ActualWidth));
                    var height = Math.Max(1, (int)Math.Round(window.ActualHeight));
                    var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
                    bitmap.Render(window);
                    var png = new PngBitmapEncoder();
                    png.Frames.Add(BitmapFrame.Create(bitmap));
                    Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(screenshot))!);
                    using var file = File.Create(screenshot);
                    png.Save(file);
                    if (new FileInfo(screenshot).Length < 20000) throw new InvalidDataException("Скриншот интерфейса пуст.");
                }
                // Exercise the actual inventory session persistence and confirmation logic.
                var countDb = new DatabaseService();
                var countService = new CountSessionService(countDb);
                long sessionId = countService.Start("Сухой склад");
                var countLines = countService.Lines(sessionId);
                if (countLines.Count == 0) throw new InvalidDataException("Пересчёт не содержит товаров.");
                var checkedItem = countLines[0];
                var unchanged = countDb.GetAll().Single(p => p.Id == checkedItem.ProductId).Quantity;
                checkedItem.ActualQuantity = checkedItem.BookQuantity + 2;
                // New 2.3 autosave stores a single row immediately, but never applies inventory to Products.
                countService.SaveFact(sessionId, checkedItem);
                countService.SaveFacts(sessionId, countLines);
                if (countDb.GetAll().Single(p => p.Id == checkedItem.ProductId).Quantity != unchanged)
                    throw new InvalidDataException("Черновик пересчёта изменил реальные остатки!");
                var reloaded = countService.Lines(sessionId);
                if (reloaded[0].ActualQuantity != checkedItem.ActualQuantity)
                    throw new InvalidDataException("Фактическое количество не пережило перезапись SQLite.");
                int changed = countService.Commit(sessionId);
                if (changed != 1 || countDb.GetAll().Single(p => p.Id == checkedItem.ProductId).Quantity != checkedItem.ActualQuantity)
                    throw new InvalidDataException("Подтверждённые результаты пересчёта не применились.");
                if (!countService.Latest()!.Value.Completed)
                    throw new InvalidDataException("Закрытая сессия пересчёта снова открыта.");
                try { countService.Commit(sessionId); throw new InvalidDataException("Повторное завершение пересчёта разрешено."); }
                catch (InvalidOperationException) { }
                // Verify the actual formatted Excel count report with filters.
                var countReportPath=Path.Combine(Path.GetTempPath(),"count-report-"+Guid.NewGuid().ToString("N")+".xlsx");
                try
                {
                    new ExportService().ExportCountReport(countReportPath,reloaded,"Автотест");
                    using var report=new ClosedXML.Excel.XLWorkbook(countReportPath);
                    if (!report.Worksheets.First().AutoFilter.IsEnabled) throw new InvalidDataException("Нет фильтров в ведомости расхождений.");
                    var importedFact = new CountExcelImportService().Read(countReportPath, reloaded);
                    if (importedFact.Updates.Count != 1 || importedFact.Updates[0].Fact != checkedItem.ActualQuantity)
                        throw new InvalidDataException("Обратная загрузка фактического количества из Excel работает неверно.");
                }
                finally { if(File.Exists(countReportPath)) File.Delete(countReportPath); }
                // Verify that both embedded Excel workbooks can actually be exported
                // from this self-contained EXE, and that the filled one is importable.
                var templates = new TemplateExportService();
                var temp = Path.Combine(Path.GetTempPath(), "inventarizatsiya-mayak-smoke-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(temp);
                try
                {
                    var blankPath = Path.Combine(temp, "blank.xlsx");
                    var fullPath = Path.Combine(temp, "filled.xlsx");
                    templates.SaveBlank(blankPath);
                    templates.SaveFilledExample(fullPath);
                    if (new FileInfo(blankPath).Length < 10000 || new FileInfo(fullPath).Length < 50000)
                        throw new InvalidDataException("Пустой или поврежденный встроенный файл Excel.");
                    var imported = new CsvImportService().Read(fullPath);
                    if (imported.Count != 768 || imported[0].Name != "Гречка ядрица")
                        throw new InvalidDataException($"Excel импортировал {imported.Count} вместо 768 товаров.");

                    // The XLSX format must contain actual Excel autofilter buttons,
                    // not merely styled header cells.
                    foreach (var file in new[] { blankPath, fullPath })
                    {
                        using var workbook = new ClosedXML.Excel.XLWorkbook(file);
                        var dataSheet = workbook.Worksheets.First();
                        var table = dataSheet.Tables.FirstOrDefault();
                        if (table is null || !table.ShowAutoFilter)
                            throw new InvalidDataException("Нет включённых фильтров Excel: " + Path.GetFileName(file));
                    }
                    var currentExport = Path.Combine(temp, "current_stock.xlsx");
                    new ExportService().ExportExcel(currentExport, vm.Products.ToList());
                    using (var currentBook = new ClosedXML.Excel.XLWorkbook(currentExport))
                    {
                        if (!currentBook.Worksheets.First().AutoFilter.IsEnabled)
                            throw new InvalidDataException("Не включены фильтры в выгрузке текущей базы.");
                    }
                }
                finally { Directory.Delete(temp, recursive: true); }
                window.Close();
                Shutdown(0);
                return;
            }
            window.Show();
        }
        catch (Exception ex)
        {
            var root = ex.GetBaseException();
            var logPath = RecordError(ex);
            if (!_smokeTest)
            {
                MessageBox.Show(
                    "Не удалось открыть «Инвентаризацию».\n\nПричина: " + root.Message +
                    "\n\nЖурнал диагностики:\n" + logPath +
                    "\n\nВаши складские данные не удалены.",
                    "Ошибка запуска", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            Shutdown(1);
        }
    }

    private static string RecordError(Exception ex)
    {
        var path = Environment.GetEnvironmentVariable("INVENTARIZATSIYA_DIAGNOSTIC_LOG");
        if (string.IsNullOrWhiteSpace(path))
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Inventarizatsiya", "logs");
            path = Path.Combine(dir, "startup.log");
        }
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
            File.AppendAllText(path,
                "\n--- " + DateTimeOffset.Now.ToString("O") + " ---\n" + ex + "\n",
                Encoding.UTF8);
            return path;
        }
        catch
        {
            // Logging must never replace the original error.
            return "Не удалось сохранить журнал";
        }
    }
}
