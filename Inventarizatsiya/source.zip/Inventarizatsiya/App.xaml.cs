using System.Globalization;
using System.Windows;
using System.Windows.Markup;

namespace Inventarizatsiya;

public partial class App : Application
{
    public App()
    {
        var ru=CultureInfo.GetCultureInfo("ru-RU");
        CultureInfo.DefaultThreadCurrentCulture=ru;
        CultureInfo.DefaultThreadCurrentUICulture=ru;
        FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement),
            new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(ru.IetfLanguageTag)));
        DispatcherUnhandledException += (_,e) =>
        {
            MessageBox.Show(e.Exception.Message,"Ошибка приложения",MessageBoxButton.OK,MessageBoxImage.Error);
            e.Handled=true;
        };
    }
}
