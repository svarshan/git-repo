using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;
using Inventarizatsiya.ViewModels;
using Inventarizatsiya.Services;
using Inventarizatsiya.Views;

namespace Inventarizatsiya;

public partial class App : Application
{
    private bool _smokeTest;

    public App()
    {
        var ru = CultureInfo.GetCultureInfo("ru-RU");
        CultureInfo.DefaultThreadCurrentCulture = ru;
        CultureInfo.DefaultThreadCurrentUICulture = ru;
        FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement),
            new FrameworkPropertyMetadata(XmlLanguage.GetLanguage(ru.IetfLanguageTag)));

        DispatcherUnhandledException += (_, e) =>
        {
            var logPath = RecordError(e.Exception);
            if (!_smokeTest)
            {
                MessageBox.Show(
                    "Возникла ошибка: " + e.Exception.GetBaseException().Message +
                    "\n\nЖурнал диагностики:\n" + logPath,
                    "Ошибка приложения", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            e.Handled = true;
            Shutdown(1);
        };
    }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _smokeTest = e.Args.Any(arg => string.Equals(arg, "--smoke-test", StringComparison.OrdinalIgnoreCase));
        try
        {
            var window = new MainWindow();
            MainWindow = window;
            if (_smokeTest)
            {
                // On the real Windows runtime, instantiate and lay out every screen.
                window.Show();
                window.UpdateLayout();
                if (window.DataContext is not MainViewModel vm || vm.TotalCount < 500)
                    throw new InvalidDataException("Начальный каталог содержит меньше 500 товаров.");

                for (var i = 0; i < window.MainTabs.Items.Count; i++)
                {
                    window.MainTabs.SelectedIndex = i;
                    window.UpdateLayout();
                    window.Dispatcher.Invoke(() => { }, DispatcherPriority.Background);
                }
                // Verify that both embedded Excel workbooks can actually be exported
                // from this self-contained EXE, and that the filled one is importable.
                var templates = new TemplateExportService();
                var temp = Path.Combine(Path.GetTempPath(), "inventarizatsiya-mayak-smoke-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(temp);
                try
                {
                    var blankPath = Path.Combine(temp, "blank.xlsx");
                    var fullPath = Path.Combine(temp, "filled.xlsx");
                    templates.SaveBlank(blankPath);
                    templates.SaveFilledExample(fullPath);
                    if (new FileInfo(blankPath).Length < 10000 || new FileInfo(fullPath).Length < 50000)
                        throw new InvalidDataException("Пустой или поврежденный встроенный файл Excel.");
                    var imported = new CsvImportService().Read(fullPath);
                    if (imported.Count != 768 || imported[0].Name != "Гречка ядрица")
                        throw new InvalidDataException($"Excel импортировал {imported.Count} вместо 768 товаров.");
                }
                finally { Directory.Delete(temp, recursive: true); }
                window.Close();
                Shutdown(0);
                return;
            }
            window.Show();
        }
        catch (Exception ex)
        {
            var root = ex.GetBaseException();
            var logPath = RecordError(ex);
            if (!_smokeTest)
            {
                MessageBox.Show(
                    "Не удалось открыть «Инвентаризацию».\n\nПричина: " + root.Message +
                    "\n\nЖурнал диагностики:\n" + logPath +
                    "\n\nВаши складские данные не удалены.",
                    "Ошибка запуска", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            Shutdown(1);
        }
    }

    private static string RecordError(Exception ex)
    {
        var path = Environment.GetEnvironmentVariable("INVENTARIZATSIYA_DIAGNOSTIC_LOG");
        if (string.IsNullOrWhiteSpace(path))
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Inventarizatsiya", "logs");
            path = Path.Combine(dir, "startup.log");
        }
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
            File.AppendAllText(path,
                "\n--- " + DateTimeOffset.Now.ToString("O") + " ---\n" + ex + "\n",
                Encoding.UTF8);
            return path;
        }
        catch
        {
            // Logging must never replace the original error.
            return "Не удалось сохранить журнал";
        }
    }
}
