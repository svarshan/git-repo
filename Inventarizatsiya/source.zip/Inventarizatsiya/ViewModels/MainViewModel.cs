using Inventarizatsiya.Helpers;
using Inventarizatsiya.Models;
using Inventarizatsiya.Services;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Input;

namespace Inventarizatsiya.ViewModels;

public sealed class MainViewModel : ObservableObject
{
    private readonly DatabaseService _database;
    private readonly ExportService _export = new();
    private readonly CsvImportService _import = new();
    private readonly IUiService _ui;
    private readonly Stack<List<Product>> _deleteUndo = new();
    private readonly List<Product> _selected = new();
    private Product _editor = new();
    private string _editorTitle="Новая позиция";
    private Product? _selectedProduct;
    private string _searchText="";
    private string _categoryFilter="Все категории";
    private string _stockFilter="Все";
    private string _quickName="";
    private string _quickCategory="Крупы";
    private decimal _quickQuantity=1;
    private string _quickUnit="кг";
    private string _responsible="";
    private string _bulkCategory="";
    private string _bulkLocation="";
    private string _bulkSupplier="";
    private string _bulkMin="";
    private int _selectedCount;
    private int _totalCount;
    private int _categoryCount;
    private int _emptyCount;
    private int _lowCount;
    private decimal _totalAmount;
    private string _status="Готово к работе";
    private string _dbPath="";

    public MainViewModel(DatabaseService database,IUiService ui)
    {
        _database=database;_ui=ui;
        _database.Initialize();
        DbPath=_database.DatabasePath;
        Products=new ObservableCollection<Product>();
        Categories=new ObservableCollection<string>();
        Suppliers=new ObservableCollection<string>();
        RecentProducts=new ObservableCollection<Product>();
        History=new ObservableCollection<ChangeEntry>();
        Summaries=new ObservableCollection<CategorySummary>();
        FilteredProducts=CollectionViewSource.GetDefaultView(Products);
        FilteredProducts.Filter=Matches;
        FilteredProducts.SortDescriptions.Add(new SortDescription(nameof(Product.Name),ListSortDirection.Ascending));

        AddNewCommand=new RelayCommand(New);
        SaveCommand=new RelayCommand(()=>Safe(SaveEditor));
        DeleteCommand=new RelayCommand(()=>Safe(DeleteSelected));
        UndoCommand=new RelayCommand(()=>Safe(UndoDelete));
        CopyCommand=new RelayCommand(()=>Safe(CopySelected));
        RefreshCommand=new RelayCommand(()=>Safe(Refresh));
        QuickAddCommand=new RelayCommand(()=>Safe(QuickAdd));
        BulkCommand=new RelayCommand(()=>Safe(ApplyBulk));
        ImportCommand=new RelayCommand(()=>Safe(Import));
        ExcelAllCommand=new RelayCommand(()=>Safe(()=>Excel(false)));
        ExcelFilteredCommand=new RelayCommand(()=>Safe(()=>Excel(true)));
        ExcelCategoriesCommand=new RelayCommand(()=>Safe(ExportCategory));
        ExcelStatementCommand=new RelayCommand(()=>Safe(ExportStatement));
        OrderListCommand=new RelayCommand(()=>Safe(ExportOrderList));
        DailyChangesCommand=new RelayCommand(()=>Safe(ExportDailyChanges));
        WordCommand=new RelayCommand(()=>Safe(ExportWord));
        BackupCommand=new RelayCommand(()=>Safe(Backup));
        RestoreCommand=new RelayCommand(()=>Safe(Restore));
        ResetDemoCommand=new RelayCommand(()=>Safe(ResetDemo));
        FocusSearchCommand=new RelayCommand(()=>FocusSearchRequested?.Invoke(this,EventArgs.Empty));
        EditSelectedCommand=new RelayCommand(()=> { if(SelectedProduct is not null) Edit(SelectedProduct); });
        Refresh();
    }

    public event EventHandler? FocusSearchRequested;
    public event EventHandler? OpenProductsRequested;
    public ObservableCollection<Product> Products {get;}
    public ICollectionView FilteredProducts {get;}
    public ObservableCollection<string> Categories {get;}
    public ObservableCollection<string> Suppliers {get;}
    public ObservableCollection<Product> RecentProducts {get;}
    public ObservableCollection<ChangeEntry> History {get;}
    public ObservableCollection<CategorySummary> Summaries {get;}
    public IReadOnlyList<string> Units {get;}=new[]{"кг","л","шт.","упак.","банка","пачка","десяток","упаковка","г","мл","рулон","комплект"};
    public IReadOnlyList<string> StockFilters {get;}=new[]{"Все","Мало","Нет в наличии","Недавние","Избранное"};
    public IReadOnlyList<string> Locations {get;}=new[]{"Склад","Холодильник","Морозильник","Сухой склад","Посудомойка","Хозяйственный блок"};

    public Product Editor {get=>_editor;private set=>Set(ref _editor,value);}
    public string EditorTitle {get=>_editorTitle;private set=>Set(ref _editorTitle,value);}
    public Product? SelectedProduct {get=>_selectedProduct;set=>Set(ref _selectedProduct,value);}
    public string SearchText {get=>_searchText;set { if(Set(ref _searchText,value)) FilteredProducts.Refresh(); }}
    public string CategoryFilter {get=>_categoryFilter;set {if(Set(ref _categoryFilter,value)) FilteredProducts.Refresh();}}
    public string StockFilter {get=>_stockFilter;set {if(Set(ref _stockFilter,value)) FilteredProducts.Refresh();}}
    public string QuickName {get=>_quickName;set=>Set(ref _quickName,value);}
    public string QuickCategory {get=>_quickCategory;set=>Set(ref _quickCategory,value);}
    public decimal QuickQuantity {get=>_quickQuantity;set=>Set(ref _quickQuantity,value);}
    public string QuickUnit {get=>_quickUnit;set=>Set(ref _quickUnit,value);}
    public string Responsible {get=>_responsible;set=>Set(ref _responsible,value);}
    public string BulkCategory {get=>_bulkCategory;set=>Set(ref _bulkCategory,value);}
    public string BulkLocation {get=>_bulkLocation;set=>Set(ref _bulkLocation,value);}
    public string BulkSupplier {get=>_bulkSupplier;set=>Set(ref _bulkSupplier,value);}
    public string BulkMin {get=>_bulkMin;set=>Set(ref _bulkMin,value);}
    public int SelectedCount {get=>_selectedCount;private set=>Set(ref _selectedCount,value);}
    public int TotalCount {get=>_totalCount;private set=>Set(ref _totalCount,value);}
    public int CategoryCount {get=>_categoryCount;private set=>Set(ref _categoryCount,value);}
    public int EmptyCount {get=>_emptyCount;private set=>Set(ref _emptyCount,value);}
    public int LowCount {get=>_lowCount;private set=>Set(ref _lowCount,value);}
    public decimal TotalAmount {get=>_totalAmount;private set=>Set(ref _totalAmount,value);}
    public string Status {get=>_status;private set=>Set(ref _status,value);}
    public string DbPath {get=>_dbPath;private set=>Set(ref _dbPath,value);}

    public ICommand AddNewCommand {get;}
    public ICommand SaveCommand {get;}
    public ICommand DeleteCommand {get;}
    public ICommand UndoCommand {get;}
    public ICommand CopyCommand {get;}
    public ICommand RefreshCommand {get;}
    public ICommand QuickAddCommand {get;}
    public ICommand BulkCommand {get;}
    public ICommand ImportCommand {get;}
    public ICommand ExcelAllCommand {get;}
    public ICommand ExcelFilteredCommand {get;}
    public ICommand ExcelCategoriesCommand {get;}
    public ICommand ExcelStatementCommand {get;}
    public ICommand OrderListCommand {get;}
    public ICommand DailyChangesCommand {get;}
    public ICommand WordCommand {get;}
    public ICommand BackupCommand {get;}
    public ICommand RestoreCommand {get;}
    public ICommand ResetDemoCommand {get;}
    public ICommand FocusSearchCommand {get;}
    public ICommand EditSelectedCommand {get;}

    private static readonly string[] StandardCategories =
    {
        "Бобовые","Бытовая химия","Детское питание","Диетическое питание","Жиры","Консервы","Кондитерские изделия",
        "Кофе","Крупы","Макаронные изделия","Масла растительные","Молочные продукты","Морепродукты","Мука",
        "Мясо","Напитки","Одноразовая посуда","Орехи","Овощи","Полуфабрикаты","Приправы","Прочее",
        "Птица","Расходные материалы","Рыба","Сахар","Сладости","Соки","Соль","Соусы","Специи",
        "Сухофрукты","Сыры","Фрукты","Хлеб","Хлебобулочные изделия","Чай","Ягоды","Яйца","Какао","Колбасные изделия"
    };

    private bool Matches(object obj)
    {
        if(obj is not Product p) return false;
        if(CategoryFilter!="Все категории" && p.Category!=CategoryFilter) return false;
        if(!string.IsNullOrWhiteSpace(SearchText))
        {
            var q=SearchText.Trim();
            if(!new[]{p.Name,p.Sku,p.Barcode,p.Category,p.Supplier,p.Location}.Any(x=>x.Contains(q,StringComparison.CurrentCultureIgnoreCase)))
                return false;
        }
        return StockFilter switch
        {
            "Мало" => p.IsLow,
            "Нет в наличии" => p.IsEmpty,
            "Недавние" => p.UpdatedAt >= DateTimeOffset.Now.AddDays(-7),
            "Избранное" => p.IsFavorite,
            _ => true
        };
    }

    public void SetSelection(IList selected)
    {
        _selected.Clear();
        foreach(var obj in selected)
            if(obj is Product p) _selected.Add(p);
        SelectedCount=_selected.Count;
        SelectedProduct=_selected.FirstOrDefault();
    }

    private void Safe(Action action)
    {
        try { action(); }
        catch(Exception ex)
        {
            var message=ex is Microsoft.Data.Sqlite.SqliteException e && e.SqliteErrorCode==19
                ? "Товар с таким наименованием уже существует. Выберите другое имя."
                : ex.Message;
            Status="Ошибка: "+message;
            _ui.Message(message,"Не удалось выполнить операцию");
        }
    }

    public void New()
    {
        Editor=new Product{Category="Крупы",Unit="кг",Location="Сухой склад"};
        EditorTitle="Новая позиция";
        OpenProductsRequested?.Invoke(this,EventArgs.Empty);
    }

    public void Edit(Product product)
    {
        Editor=product.Copy();
        EditorTitle="Редактирование: "+product.Name;
        Status="Измените поля справа и нажмите «Сохранить»";
    }

    private void SaveEditor()
    {
        if(string.IsNullOrWhiteSpace(Editor.Name))
            throw new ArgumentException("Введите название продукта.");
        var edited=Editor.Copy();
        _database.Save(edited);
        var cat=edited.Category; var unit=edited.Unit; var loc=edited.Location; var supplier=edited.Supplier;
        Refresh();
        Editor=new Product{Category=cat,Unit=unit,Location=loc,Supplier=supplier};
        EditorTitle="Новая позиция";
        Status="✓ Сохранено: "+edited.Name+". Можно сразу добавить следующий товар.";
    }

    public void SaveInline(Product product)
    {
        try
        {
            _database.Save(product);
            RefreshMetrics();
            FilteredProducts.Refresh();
            Status="✓ Остаток / изменения сохранены: "+product.Name;
        }
        catch(Exception ex)
        {
            Refresh(); // Recover the actual persisted values after a failed inline edit.
            Status="Ошибка изменения: "+ex.Message;
            _ui.Message(ex.Message,"Изменение не сохранено");
        }
    }

    private void DeleteSelected()
    {
        var items=_selected.Count>0 ? _selected.ToList() :
            SelectedProduct is not null ? new List<Product>{SelectedProduct} : new List<Product>();
        if(items.Count==0) { _ui.Message("Сначала выберите один или несколько товаров."); return; }
        if(!_ui.Confirm($"Удалить выбранные позиции: {items.Count}?\nУдаление можно отменить до закрытия программы."))return;
        _database.Delete(items);
        _deleteUndo.Push(items.Select(x=>x.Copy()).ToList());
        _selected.Clear();
        Refresh();
        Status=$"Удалено: {items.Count}. Нажмите «Отменить удаление», если ошиблись.";
    }

    private void UndoDelete()
    {
        if(_deleteUndo.Count==0){_ui.Message("Нет удаления для отмены в этой сессии.");return;}
        var list=_deleteUndo.Peek();
        _database.RestoreDeleted(list);
        _deleteUndo.Pop();
        Refresh();
        Status=$"✓ Восстановлено: {list.Count}";
    }

    private void CopySelected()
    {
        var item=SelectedProduct;
        if(item is null){_ui.Message("Выберите товар для копирования.");return;}
        Editor=item.Copy();
        Editor.Id=0;
        Editor.Name=item.Name+" (копия)";
        Editor.Sku="";
        Editor.Barcode="";
        Editor.IsDemo=false;
        EditorTitle="Копия товара";
        Status="При необходимости измените название копии и сохраните.";
    }

    private void QuickAdd()
    {
        var name=QuickName.Trim();
        if(name.Length==0)throw new ArgumentException("Введите наименование для быстрого внесения.");
        if(QuickQuantity <=0)throw new ArgumentException("Укажите положительное количество.");
        if(QuickCategory=="Все категории")throw new ArgumentException("Выберите категорию товара.");
        var found=Products.FirstOrDefault(p=>string.Equals(p.Name,name,StringComparison.CurrentCultureIgnoreCase));
        if(found is not null)
        {
            found.Quantity+=QuickQuantity;
            _database.Save(found);
            Status=$"✓ {found.Name}: добавлено {QuickQuantity} {found.Unit}";
        }
        else
        {
            var p=new Product{Name=name,Category=QuickCategory,Unit=QuickUnit,Quantity=QuickQuantity,Location="Сухой склад"};
            _database.Save(p);
            Status=$"✓ Новая позиция: {name} — {QuickQuantity} {QuickUnit}";
        }
        QuickName="";
        QuickQuantity=1;
        Refresh();
    }

    private void ApplyBulk()
    {
        if(_selected.Count==0)throw new ArgumentException("Выделите несколько строк в таблице (Ctrl или Shift). ");
        if(string.IsNullOrWhiteSpace(BulkCategory) && string.IsNullOrWhiteSpace(BulkLocation) &&
           string.IsNullOrWhiteSpace(BulkSupplier) && string.IsNullOrWhiteSpace(BulkMin))
            throw new ArgumentException("Укажите хотя бы одно поле массового изменения.");
        decimal? min=null;
        if(!string.IsNullOrWhiteSpace(BulkMin))
        {
            if(!decimal.TryParse(BulkMin,NumberStyles.Number,CultureInfo.GetCultureInfo("ru-RU"),out var parsed) || parsed<0)
                throw new ArgumentException("Некорректное минимальное количество.");
            min=parsed;
        }
        if(!_ui.Confirm($"Применить выбранные изменения к {_selected.Count} позициям?"))return;
        foreach(var p in _selected.ToList())
        {
            if(!string.IsNullOrWhiteSpace(BulkCategory))p.Category=BulkCategory;
            if(!string.IsNullOrWhiteSpace(BulkLocation))p.Location=BulkLocation;
            if(!string.IsNullOrWhiteSpace(BulkSupplier))p.Supplier=BulkSupplier;
            if(min.HasValue)p.MinQuantity=min.Value;
            _database.Save(p);
        }
        int count=_selected.Count;
        BulkCategory=BulkLocation=BulkSupplier=BulkMin="";
        Refresh();
        Status=$"✓ Массово обновлено: {count}";
    }

    public void Refresh()
    {
        var all=_database.GetAll();
        using(FilteredProducts.DeferRefresh())
        {
            Products.Clear();
            int rowNo=0;
            foreach(var product in all)
            {
                product.RowNumber=++rowNo;
                Products.Add(product);
            }
        }
        var preferred=CategoryFilter;
        Categories.Clear();
        Categories.Add("Все категории");
        foreach(var category in StandardCategories.Concat(all.Select(x=>x.Category)).Distinct().OrderBy(x=>x))
            Categories.Add(category);
        if(!Categories.Contains(preferred))CategoryFilter="Все категории";
        Suppliers.Clear();
        foreach(var supplier in all.Select(x=>x.Supplier).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x=>x))
            Suppliers.Add(supplier);
        FilteredProducts.Refresh();
        RefreshMetrics();
        History.Clear();
        foreach(var entry in _database.RecentChanges())History.Add(entry);
        Status=Status.StartsWith("Ошибка:")?"Готово к работе":Status;
    }

    private void RefreshMetrics()
    {
        TotalCount=Products.Count;
        CategoryCount=Products.Select(p=>p.Category).Distinct().Count();
        EmptyCount=Products.Count(p=>p.IsEmpty);
        LowCount=Products.Count(p=>p.IsLow);
        TotalAmount=Products.Sum(p=>p.Total);
        RecentProducts.Clear();
        foreach(var p in Products.OrderByDescending(p=>p.UpdatedAt).Take(12))RecentProducts.Add(p);
        Summaries.Clear();
        foreach(var group in Products.GroupBy(p=>p.Category).OrderBy(g=>g.Key))
            Summaries.Add(new CategorySummary(group.Key,group.Count(),group.Count(p=>p.IsLow),
                group.Count(p=>p.IsEmpty),group.Sum(p=>p.Total)));
    }

    private void Import()
    {
        var path=_ui.OpenPath("Импорт из Excel или CSV","Excel (*.xlsx)|*.xlsx|CSV (*.csv)|*.csv");
        if(path is null)return;
        var list=_import.Read(path);
        var result=_database.Import(list);
        Refresh();
        Status=$"✓ Импортировано {result.Added}; совпадающих названий пропущено {result.Skipped}";
        _ui.Message(Status);
    }

    private List<Product> Visible()=>FilteredProducts.Cast<Product>().ToList();
    private string DefaultName(string type)=>type+"_"+DateTime.Now.ToString("yyyyMMdd_HHmm") ;

    private void Excel(bool filtered)
    {
        var path=_ui.SavePath("Экспорт в Excel","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName(filtered?"Отбор":"Инвентаризация"));
        if(path is null)return;
        _export.ExportExcel(path,filtered?Visible():Products.ToList());
        Status="✓ Excel сформирован: "+path;
    }
    private void ExportCategory()
    {
        var path=_ui.SavePath("Отчёт по категориям","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("По_категориям"));
        if(path is null)return;
        _export.ExportCategories(path,Products.ToList());
        Status="✓ Отчёт по категориям сохранён";
    }
    private void ExportStatement()
    {
        var path=_ui.SavePath("Ведомость инвентаризации","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("Ведомость"));
        if(path is null)return;
        _export.ExportInventoryStatement(path,Visible(),Responsible);
        Status="✓ Ведомость инвентаризации сохранена";
    }
    private void ExportOrderList()
    {
        var path=_ui.SavePath("Список для заказа","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("К_заказу"));
        if(path is null)return;
        _export.ExportOrderList(path,Products.Where(p=>p.IsEmpty || p.IsLow).ToList());
        Status="✓ Список для заказа сохранён";
    }
    private void ExportDailyChanges()
    {
        var path=_ui.SavePath("Изменения за сегодня","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("Изменения_за_день"));
        if(path is null)return;
        var today=DateTime.Now.ToString("dd.MM.yyyy");
        _export.ExportDailyChanges(path,_database.RecentChanges(50000).Where(c=>c.Time.StartsWith(today)).ToList());
        Status="✓ Отчёт изменений за сегодня сохранён";
    }
    private void ExportWord()
    {
        var path=_ui.SavePath("Ведомость Word","Документ Word (*.docx)|*.docx",".docx",DefaultName("Ведомость"));
        if(path is null)return;
        _export.ExportWord(path,Visible(),Responsible);
        Status="✓ Документ Word сохранён";
    }
    private void Backup()
    {
        var path=_ui.SavePath("Резервная копия","SQLite база (*.db)|*.db",".db",DefaultName("Инвентаризация_копия"));
        if(path is null)return;
        _database.Backup(path);
        Status="✓ Резервная копия сохранена: "+path;
    }
    private void Restore()
    {
        var path=_ui.OpenPath("Восстановить базу","SQLite база (*.db)|*.db");
        if(path is null)return;
        if(!_ui.Confirm("Восстановление ЗАМЕНИТ текущие данные данными из копии.\nПеред заменой будет создана автоматическая страховочная копия. Продолжить?"))return;
        _database.Restore(path);
        _deleteUndo.Clear();
        Refresh();
        Status="✓ База восстановлена из резервной копии";
    }
    private void ResetDemo()
    {
        if(!_ui.Confirm("Очистить демонстрационные количества и пометки, оставив справочник товаров?\nРеальные новые позиции не затрагиваются."))return;
        _database.ClearDemoQuantities();
        Refresh();
        Status="✓ Демо-остатки очищены. Теперь вносите фактические количества.";
    }
}
