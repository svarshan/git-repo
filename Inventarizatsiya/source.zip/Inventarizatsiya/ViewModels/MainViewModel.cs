using System.IO;
using Inventarizatsiya.Helpers;
using Inventarizatsiya.Models;
using Inventarizatsiya.Services;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Input;

namespace Inventarizatsiya.ViewModels;

public sealed class MainViewModel : ObservableObject
{
    private readonly DatabaseService _database;
    private readonly ExportService _export = new();
    private readonly TemplateExportService _excelTemplates = new();
    private readonly CsvImportService _import = new();
    private readonly IUiService _ui;
    private readonly Stack<List<Product>> _deleteUndo = new();
    private readonly CountSessionService _countService;
    private readonly CountExcelImportService _countExcelImporter = new();
    private readonly MovementService _movements;
    private string _movementOperation="Приход";
    private decimal _movementQuantity=1;
    private string _movementReason="";
    private string _movementResponsible="";
    private StockMovement? _selectedMovement;
    private DateTime? _reportStartDate=DateTime.Today.AddDays(-30);
    private DateTime? _reportEndDate=DateTime.Today;
    private string _backupSummary="Копии ещё не просмотрены";
    private string _integrityStatus="Проверка базы ещё не запускалась";
    private string _countSavedStatus="Изменения факта сохраняются автоматически";
    private long _countSessionId;
    private bool _countClosed=true;
    private string _countWarehouse="Все места";
    private string _countTitle="Инвентаризация ещё не начата";
    private decimal _quickPackCount=1;
    private bool _usePacks;
    private int _expiryAlertCount;
    private readonly List<Product> _selected = new();
    private Product _editor = new();
    private string _editorTitle="Новая позиция";
    private Product? _selectedProduct;
    private string _searchText="";
    private string _categoryFilter="Все категории";
    private string _stockFilter="Все";
    private string _quickName="";
    private string _quickCategory="Крупы";
    private decimal _quickQuantity=1;
    private string _quickUnit="кг";
    private string _responsible="";
    private string _bulkCategory="";
    private string _bulkLocation="";
    private string _bulkSupplier="";
    private string _bulkMin="";
    private int _selectedCount;
    private int _totalCount;
    private int _categoryCount;
    private int _emptyCount;
    private int _lowCount;
    private decimal _totalAmount;
    private string _status="Готово к работе";
    private string _dbPath="";

    public MainViewModel(DatabaseService database,IUiService ui)
    {
        _database=database;_ui=ui;
        _database.Initialize();
        _countService=new CountSessionService(_database);
        _movements=new MovementService(_database);
        DbPath=_database.DatabasePath;
        Products=new BulkObservableCollection<Product>();
        Categories=new ObservableCollection<string>();
        Suppliers=new ObservableCollection<string>();
        RecentProducts=new BulkObservableCollection<Product>();
        History=new ObservableCollection<ChangeEntry>();
        Summaries=new ObservableCollection<CategorySummary>();
        CountLines=new BulkObservableCollection<CountLine>();
        Movements=new ObservableCollection<StockMovement>();
        FilteredProducts=CollectionViewSource.GetDefaultView(Products);
        FilteredProducts.Filter=Matches;
        FilteredProducts.SortDescriptions.Add(new SortDescription(nameof(Product.Name),ListSortDirection.Ascending));

        AddNewCommand=new RelayCommand(New);
        SaveCommand=new RelayCommand(()=>Safe(SaveEditor));
        DeleteCommand=new RelayCommand(()=>Safe(DeleteSelected));
        UndoCommand=new RelayCommand(()=>Safe(UndoDelete));
        CopyCommand=new RelayCommand(()=>Safe(CopySelected));
        RefreshCommand=new RelayCommand(()=>Safe(Refresh));
        QuickAddCommand=new RelayCommand(()=>Safe(QuickAdd));
        BulkCommand=new RelayCommand(()=>Safe(ApplyBulk));
        ImportCommand=new RelayCommand(()=>Safe(Import));
        ExcelAllCommand=new RelayCommand(()=>Safe(()=>Excel(false)));
        ExcelBlankTemplateCommand=new RelayCommand(()=>Safe(ExportBlankTemplate));
        ExcelFilledExampleCommand=new RelayCommand(()=>Safe(ExportFilledExample));
        ExcelFilteredCommand=new RelayCommand(()=>Safe(()=>Excel(true)));
        ExcelCategoriesCommand=new RelayCommand(()=>Safe(ExportCategory));
        ExcelStatementCommand=new RelayCommand(()=>Safe(ExportStatement));
        OrderListCommand=new RelayCommand(()=>Safe(ExportOrderList));
        DailyChangesCommand=new RelayCommand(()=>Safe(ExportDailyChanges));
        WordCommand=new RelayCommand(()=>Safe(ExportWord));
        BackupCommand=new RelayCommand(()=>Safe(Backup));
        RestoreCommand=new RelayCommand(()=>Safe(Restore));
        ResetDemoCommand=new RelayCommand(()=>Safe(ResetDemo));
        FocusSearchCommand=new RelayCommand(()=>FocusSearchRequested?.Invoke(this,EventArgs.Empty));
        EditSelectedCommand=new RelayCommand(()=> { if(SelectedProduct is not null) Edit(SelectedProduct); });
        BeginCountCommand=new RelayCommand(()=>Safe(BeginCount));
        SaveCountCommand=new RelayCommand(()=>Safe(SaveCount));
        CompleteCountCommand=new RelayCommand(()=>Safe(CompleteCount));
        CountReportCommand=new RelayCommand(()=>Safe(ExportCountReport));
        ImportCountFactsCommand=new RelayCommand(()=>Safe(ImportCountFacts));
        ApplyMovementCommand=new RelayCommand(()=>Safe(ApplyMovement));
        ExportMovementsCommand=new RelayCommand(()=>Safe(ExportMovements));
        ReverseMovementCommand=new RelayCommand(()=>Safe(ReverseMovement));
        ShowBackupsCommand=new RelayCommand(()=>Safe(ShowBackups));
        VerifyDatabaseCommand=new RelayCommand(()=>Safe(VerifyDatabase));
        Refresh();
        LoadCount();
    }

    public event EventHandler? FocusSearchRequested;
    public event EventHandler? OpenProductsRequested;
    public BulkObservableCollection<Product> Products {get;}
    public ICollectionView FilteredProducts {get;}
    public ObservableCollection<string> Categories {get;}
    public ObservableCollection<string> Suppliers {get;}
    public ObservableCollection<Product> RecentProducts {get;}
    public ObservableCollection<ChangeEntry> History {get;}
    public ObservableCollection<CategorySummary> Summaries {get;}
    public BulkObservableCollection<CountLine> CountLines {get;}
    public ObservableCollection<StockMovement> Movements {get;}
    public IReadOnlyList<string> MovementOperations {get;}=new[]{"Приход","Расход","Списание"};
    public string MovementOperation {get=>_movementOperation;set=>Set(ref _movementOperation,value);}
    public decimal MovementQuantity {get=>_movementQuantity;set=>Set(ref _movementQuantity,value);}
    public string MovementReason {get=>_movementReason;set=>Set(ref _movementReason,value);}
    public string MovementResponsible {get=>_movementResponsible;set=>Set(ref _movementResponsible,value);}
    public string IntegrityStatus {get=>_integrityStatus;private set=>Set(ref _integrityStatus,value);}
    public string CountWarehouse {get=>_countWarehouse;set=>Set(ref _countWarehouse,value);}
    public string CountTitle {get=>_countTitle;private set=>Set(ref _countTitle,value);}
    public bool CountClosed {get=>_countClosed;private set=>Set(ref _countClosed,value);}
    public string CountSavedStatus {get=>_countSavedStatus;private set=>Set(ref _countSavedStatus,value);}
    public int ExpiryAlertCount {get=>_expiryAlertCount;private set=>Set(ref _expiryAlertCount,value);}
    public decimal QuickPackCount {get=>_quickPackCount;set=>Set(ref _quickPackCount,value);}
    public bool UsePacks {get=>_usePacks;set=>Set(ref _usePacks,value);}
    public IReadOnlyList<string> Units {get;}=new[]{"кг","л","шт.","упак.","банка","пачка","десяток","упаковка","г","мл","рулон","комплект"};
    public IReadOnlyList<string> StockFilters {get;}=new[]{"Все","Мало","Нет в наличии","Недавние","Избранное"};
    public IReadOnlyList<string> CountWarehouses {get;}=new[]{"Все места","Склад","Холодильник","Морозильник","Сухой склад","Посудомойка","Хозяйственный блок"};
    public IReadOnlyList<string> Locations {get;}=new[]{"Склад","Холодильник","Морозильник","Сухой склад","Посудомойка","Хозяйственный блок"};

    public Product Editor {get=>_editor;private set=>Set(ref _editor,value);}
    public string EditorTitle {get=>_editorTitle;private set=>Set(ref _editorTitle,value);}
    public Product? SelectedProduct {get=>_selectedProduct;set=>Set(ref _selectedProduct,value);}
    public string SearchText {get=>_searchText;set { if(Set(ref _searchText,value)) FilteredProducts.Refresh(); }}
    public string CategoryFilter {get=>_categoryFilter;set {if(Set(ref _categoryFilter,value)) FilteredProducts.Refresh();}}
    public string StockFilter {get=>_stockFilter;set {if(Set(ref _stockFilter,value)) FilteredProducts.Refresh();}}
    public string QuickName {get=>_quickName;set=>Set(ref _quickName,value);}
    public string QuickCategory {get=>_quickCategory;set=>Set(ref _quickCategory,value);}
    public decimal QuickQuantity {get=>_quickQuantity;set=>Set(ref _quickQuantity,value);}
    public string QuickUnit {get=>_quickUnit;set=>Set(ref _quickUnit,value);}
    public string Responsible {get=>_responsible;set=>Set(ref _responsible,value);}
    public string BulkCategory {get=>_bulkCategory;set=>Set(ref _bulkCategory,value);}
    public string BulkLocation {get=>_bulkLocation;set=>Set(ref _bulkLocation,value);}
    public string BulkSupplier {get=>_bulkSupplier;set=>Set(ref _bulkSupplier,value);}
    public string BulkMin {get=>_bulkMin;set=>Set(ref _bulkMin,value);}
    public int SelectedCount {get=>_selectedCount;private set=>Set(ref _selectedCount,value);}
    public int TotalCount {get=>_totalCount;private set=>Set(ref _totalCount,value);}
    public int CategoryCount {get=>_categoryCount;private set=>Set(ref _categoryCount,value);}
    public int EmptyCount {get=>_emptyCount;private set=>Set(ref _emptyCount,value);}
    public int LowCount {get=>_lowCount;private set=>Set(ref _lowCount,value);}
    public decimal TotalAmount {get=>_totalAmount;private set=>Set(ref _totalAmount,value);}
    public string Status {get=>_status;private set=>Set(ref _status,value);}
    public string DbPath {get=>_dbPath;private set=>Set(ref _dbPath,value);}

    public ICommand AddNewCommand {get;}
    public ICommand SaveCommand {get;}
    public ICommand DeleteCommand {get;}
    public ICommand UndoCommand {get;}
    public ICommand CopyCommand {get;}
    public ICommand RefreshCommand {get;}
    public ICommand QuickAddCommand {get;}
    public ICommand BulkCommand {get;}
    public ICommand ImportCommand {get;}
    public ICommand ExcelAllCommand {get;}
    public ICommand ExcelBlankTemplateCommand {get;}
    public ICommand ExcelFilledExampleCommand {get;}
    public ICommand ExcelFilteredCommand {get;}
    public ICommand ExcelCategoriesCommand {get;}
    public ICommand ExcelStatementCommand {get;}
    public ICommand OrderListCommand {get;}
    public ICommand DailyChangesCommand {get;}
    public ICommand WordCommand {get;}
    public ICommand BackupCommand {get;}
    public ICommand RestoreCommand {get;}
    public ICommand ResetDemoCommand {get;}
    public ICommand FocusSearchCommand {get;}
    public ICommand EditSelectedCommand {get;}
    public ICommand BeginCountCommand {get;}
    public ICommand SaveCountCommand {get;}
    public ICommand CompleteCountCommand {get;}
    public ICommand CountReportCommand {get;}
    public ICommand ImportCountFactsCommand {get;}
    public ICommand ApplyMovementCommand {get;}
    public ICommand ExportMovementsCommand {get;}
    public ICommand ReverseMovementCommand {get;}
    public ICommand ShowBackupsCommand {get;}
    public StockMovement? SelectedMovement {get=>_selectedMovement;set=>Set(ref _selectedMovement,value);}
    public DateTime? ReportStartDate {get=>_reportStartDate;set=>Set(ref _reportStartDate,value);}
    public DateTime? ReportEndDate {get=>_reportEndDate;set=>Set(ref _reportEndDate,value);}
    public string BackupSummary {get=>_backupSummary;private set=>Set(ref _backupSummary,value);}
    public ICommand VerifyDatabaseCommand {get;}

    private static readonly string[] StandardCategories =
    {
        "Бобовые","Бытовая химия","Детское питание","Диетическое питание","Жиры","Консервы","Кондитерские изделия",
        "Кофе","Крупы","Макаронные изделия","Масла растительные","Молочные продукты","Морепродукты","Мука",
        "Мясо","Напитки","Одноразовая посуда","Орехи","Овощи","Полуфабрикаты","Приправы","Прочее",
        "Птица","Расходные материалы","Рыба","Сахар","Сладости","Соки","Соль","Соусы","Специи",
        "Сухофрукты","Сыры","Фрукты","Хлеб","Хлебобулочные изделия","Чай","Ягоды","Яйца","Какао","Колбасные изделия"
    };

    private bool Matches(object obj)
    {
        if(obj is not Product p) return false;
        if(CategoryFilter!="Все категории" && p.Category!=CategoryFilter) return false;
        if(!string.IsNullOrWhiteSpace(SearchText))
        {
            var q=SearchText.Trim();
            if(!new[]{p.Name,p.Sku,p.Barcode,p.Category,p.Supplier,p.Location}.Any(x=>SearchNormalizer.Match(x,q)))
                return false;
        }
        return StockFilter switch
        {
            "Мало" => p.IsLow,
            "Нет в наличии" => p.IsEmpty,
            "Недавние" => p.UpdatedAt >= DateTimeOffset.Now.AddDays(-7),
            "Избранное" => p.IsFavorite,
            _ => true
        };
    }

    public void SetSelection(IList selected)
    {
        _selected.Clear();
        foreach(var obj in selected)
            if(obj is Product p) _selected.Add(p);
        SelectedCount=_selected.Count;
        SelectedProduct=_selected.FirstOrDefault();
    }

    private void Safe(Action action)
    {
        try { action(); }
        catch(Exception ex)
        {
            var message=ex is Microsoft.Data.Sqlite.SqliteException e && e.SqliteErrorCode==19
                ? "Товар с таким наименованием уже существует. Выберите другое имя."
                : ex.Message;
            Status="Ошибка: "+message;
            _ui.Message(message,"Не удалось выполнить операцию");
        }
    }

    public void New()
    {
        Editor=new Product{Category="Крупы",Unit="кг",Location="Сухой склад"};
        EditorTitle="Новая позиция";
        OpenProductsRequested?.Invoke(this,EventArgs.Empty);
    }

    public void Edit(Product product)
    {
        Editor=product.Copy();
        EditorTitle="Редактирование: "+product.Name;
        Status="Измените поля справа и нажмите «Сохранить»";
    }

    private void SaveEditor()
    {
        if(string.IsNullOrWhiteSpace(Editor.Name))
            throw new ArgumentException("Введите название продукта.");
        var edited=Editor.Copy();
        _database.Save(edited);
        var cat=edited.Category; var unit=edited.Unit; var loc=edited.Location; var supplier=edited.Supplier;
        Refresh();
        Editor=new Product{Category=cat,Unit=unit,Location=loc,Supplier=supplier};
        EditorTitle="Новая позиция";
        Status="✓ Сохранено: "+edited.Name+". Можно сразу добавить следующий товар.";
    }

    public void SaveInline(Product product)
    {
        try
        {
            _database.Save(product);
            RefreshMetrics();
            FilteredProducts.Refresh();
            Status="✓ Остаток / изменения сохранены: "+product.Name;
        }
        catch(Exception ex)
        {
            Refresh(); // Recover the actual persisted values after a failed inline edit.
            Status="Ошибка изменения: "+ex.Message;
            _ui.Message(ex.Message,"Изменение не сохранено");
        }
    }

    private void DeleteSelected()
    {
        var items=_selected.Count>0 ? _selected.ToList() :
            SelectedProduct is not null ? new List<Product>{SelectedProduct} : new List<Product>();
        if(items.Count==0) { _ui.Message("Сначала выберите один или несколько товаров."); return; }
        if(!_ui.Confirm($"Удалить выбранные позиции: {items.Count}?\nУдаление можно отменить до закрытия программы."))return;
        _database.Delete(items);
        _deleteUndo.Push(items.Select(x=>x.Copy()).ToList());
        _selected.Clear();
        Refresh();
        Status=$"Удалено: {items.Count}. Нажмите «Отменить удаление», если ошиблись.";
    }

    private void UndoDelete()
    {
        if(_deleteUndo.Count==0){_ui.Message("Нет удаления для отмены в этой сессии.");return;}
        var list=_deleteUndo.Peek();
        _database.RestoreDeleted(list);
        _deleteUndo.Pop();
        Refresh();
        Status=$"✓ Восстановлено: {list.Count}";
    }

    private void CopySelected()
    {
        var item=SelectedProduct;
        if(item is null){_ui.Message("Выберите товар для копирования.");return;}
        Editor=item.Copy();
        Editor.Id=0;
        Editor.Name=item.Name+" (копия)";
        Editor.Sku="";
        Editor.Barcode="";
        Editor.IsDemo=false;
        EditorTitle="Копия товара";
        Status="При необходимости измените название копии и сохраните.";
    }

    private void QuickAdd()
    {
        var name=QuickName.Trim();
        if(name.Length==0)throw new ArgumentException("Введите наименование для быстрого внесения.");
        if(QuickQuantity <=0)throw new ArgumentException("Укажите положительное количество.");
        if(QuickCategory=="Все категории")throw new ArgumentException("Выберите категорию товара.");
        var found=Products.FirstOrDefault(p=>string.Equals(p.Name,name,StringComparison.CurrentCultureIgnoreCase));
        if(found is not null)
        {
            var incoming=UsePacks ? QuickPackCount*found.PackSize : QuickQuantity;
            if(incoming<=0)throw new ArgumentException("Введите положительное количество упаковок.");
            CreateSafetyBackup("quick-receipt");
            var movement=_movements.Apply(found.Id,"Приход",incoming,"Быстрый ввод","Оприходование через быстрый ввод");
            Status=$"✓ {found.Name}: приход {incoming} {found.Unit}; остаток {movement.AfterQuantity}";
        }
        else
        {
            if(UsePacks) throw new ArgumentException("Сначала добавьте новый товар и задайте размер упаковки. Затем можно вносить его упаковками.");
            CreateSafetyBackup("quick-new");
            var p=new Product{Name=name,Category=QuickCategory,Unit=QuickUnit,Quantity=0,Location="Сухой склад"};
            _database.Save(p);
            _movements.Apply(p.Id,"Приход",QuickQuantity,"Быстрый ввод","Первая поставка нового товара");
            Status=$"✓ Новая позиция: {name} — приход {QuickQuantity} {QuickUnit}";
        }
        QuickName="";
        QuickQuantity=1;
        Refresh();
    }

    private void ApplyBulk()
    {
        if(_selected.Count==0)throw new ArgumentException("Выделите несколько строк в таблице (Ctrl или Shift). ");
        if(string.IsNullOrWhiteSpace(BulkCategory) && string.IsNullOrWhiteSpace(BulkLocation) &&
           string.IsNullOrWhiteSpace(BulkSupplier) && string.IsNullOrWhiteSpace(BulkMin))
            throw new ArgumentException("Укажите хотя бы одно поле массового изменения.");
        decimal? min=null;
        if(!string.IsNullOrWhiteSpace(BulkMin))
        {
            if(!decimal.TryParse(BulkMin,NumberStyles.Number,CultureInfo.GetCultureInfo("ru-RU"),out var parsed) || parsed<0)
                throw new ArgumentException("Некорректное минимальное количество.");
            min=parsed;
        }
        if(!_ui.Confirm($"Применить выбранные изменения к {_selected.Count} позициям?"))return;
        CreateSafetyBackup("bulk");
        int count=_database.ApplyBulkAtomic(_selected.Select(x=>x.Id).ToList(),BulkCategory,BulkLocation,BulkSupplier,min);
        BulkCategory=BulkLocation=BulkSupplier=BulkMin="";
        Refresh();
        Status=$"✓ Массово обновлено: {count}";
    }

    public void Refresh()
    {
        var all=_database.GetAll();
        // Do not mutate a sorted WPF CollectionView with DeferRefresh active.
        // Such mutations attempt to move its CurrentItem and throw at startup.
        int rowNo = 0;
        foreach (var product in all)
            product.RowNumber = ++rowNo;
        Products.ReplaceAll(all);
        var preferred=CategoryFilter;
        Categories.Clear();
        Categories.Add("Все категории");
        foreach(var category in StandardCategories.Concat(all.Select(x=>x.Category)).Distinct().OrderBy(x=>x))
            Categories.Add(category);
        if(!Categories.Contains(preferred))CategoryFilter="Все категории";
        Suppliers.Clear();
        foreach(var supplier in all.Select(x=>x.Supplier).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x=>x))
            Suppliers.Add(supplier);
        FilteredProducts.Refresh();
        RefreshMetrics();
        History.Clear();
        foreach(var entry in _database.RecentChanges())History.Add(entry);
        Movements.Clear();
        foreach(var item in _movements.GetRecent(200))Movements.Add(item);
        Status=Status.StartsWith("Ошибка:")?"Готово к работе":Status;
    }

    private void RefreshMetrics()
    {
        TotalCount=Products.Count;
        CategoryCount=Products.Select(p=>p.Category).Distinct().Count();
        EmptyCount=Products.Count(p=>p.IsEmpty);
        LowCount=Products.Count(p=>p.IsLow);
        TotalAmount=Products.Sum(p=>p.Total);
        ExpiryAlertCount=Products.Count(p=>p.ExpiryDate.HasValue && p.ExpiryDate.Value.Date <= DateTime.Today.AddDays(3));
        RecentProducts.Clear();
        foreach(var p in Products.OrderByDescending(p=>p.UpdatedAt).Take(12))RecentProducts.Add(p);
        Summaries.Clear();
        foreach(var group in Products.GroupBy(p=>p.Category).OrderBy(g=>g.Key))
            Summaries.Add(new CategorySummary(group.Key,group.Count(),group.Count(p=>p.IsLow),
                group.Count(p=>p.IsEmpty),group.Sum(p=>p.Total)));
    }

    private void Import()
    {
        var path=_ui.OpenPath("Импорт из Excel или CSV","Excel (*.xlsx)|*.xlsx|CSV (*.csv)|*.csv");
        if(path is null)return;
        var list=_import.Read(path);
        if(list.Count==0)throw new InvalidDataException("В файле нет товаров для загрузки.");
        var preview=_database.PreviewImport(list);
        var details=_database.DescribeImport(list,12);
        var sample=details.Count==0?"Все значения совпадают.":string.Join("\n",details.Select(x=>"• "+x));
        if(!_ui.Confirm($"ПРЕДВАРИТЕЛЬНАЯ ПРОВЕРКА EXCEL\n\nНовых товаров: {preview.New}\nСуществующих: {preview.Existing}\n\nИЗМЕНЕНИЯ (до 12 строк):\n{sample}\n\nПродолжить? Данные пока НЕ изменялись."))return;
        bool updateExisting=preview.Existing>0 && _ui.Confirm($"Обновить ОСТАТКИ, ЦЕНЫ и минимальные количества существующих {preview.Existing} товаров?\n\nДа — обновить указанные поля.\nНет — оставить существующие данные без изменений.");
        _database.AutoBackupDaily();
        var backupPath=Path.Combine(Path.GetDirectoryName(_database.DatabasePath)!,"before-import-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".db");
        _database.Backup(backupPath);
        var result=updateExisting?_database.ImportUpdating(list):_database.Import(list);
        Refresh();
        Status=updateExisting?$"✓ Добавлено {result.Added}, обновлено {result.Skipped}. Сохранена страховочная копия.":$"✓ Добавлено {result.Added}, совпадений пропущено {result.Skipped}.";
        _ui.Message(Status);
    }

    private void LoadCount()
    {
        var latest=_countService.Latest();
        CountLines.Clear();
        if(latest is null) {CountClosed=true;CountTitle="Начните инвентаризацию: выберите место хранения и нажмите «Начать»";return;}
        _countSessionId=latest.Value.Id;
        CountWarehouse=latest.Value.Warehouse;
        CountClosed=latest.Value.Completed;
        CountLines.ReplaceAll(_countService.Lines(_countSessionId));
        CountSavedStatus=CountClosed?"Результаты подтверждены":"Черновик сохраняется автоматически при переходе к следующей строке";
        CountTitle=$"Пересчёт №{_countSessionId}: {CountWarehouse} · {(CountClosed ? "завершён" : "в работе")} · заполнено {CountLines.Count(x=>x.IsCounted)} из {CountLines.Count}";
    }
    private void BeginCount()
    {
        if(!CountClosed && _countSessionId!=0 && !_ui.Confirm("Текущая инвентаризация ещё открыта. Создать новую? Несохранённые изменения в таблице будут потеряны."))return;
        var warehouse=string.IsNullOrWhiteSpace(CountWarehouse)?"Все места":CountWarehouse;
        if(warehouse!="Все места" && !Products.Any(p=>p.Location==warehouse)) throw new ArgumentException("В выбранном месте хранения нет товаров.");
        _countSessionId=_countService.Start(warehouse);
        LoadCount();Status="✓ Создан пересчёт. Учётные остатки не изменены. Заполняйте «Факт».";
    }
    public void AutoSaveCountLine(CountLine line)
    {
        if(CountClosed || _countSessionId==0) return;
        try
        {
            _countService.SaveFact(_countSessionId,line);
            CountTitle=$"Пересчёт №{_countSessionId}: {CountWarehouse} · заполнено {CountLines.Count(x=>x.IsCounted)} из {CountLines.Count}";
            CountSavedStatus="✓ Черновик автоматически сохранён в "+DateTime.Now.ToString("HH:mm:ss");
        }
        catch(Exception ex)
        {
            CountSavedStatus="⚠ Ошибка сохранения: "+ex.Message;
            _ui.Message("Не удалось сохранить фактическое количество. Попробуйте вручную нажать «Сохранить черновик».\n"+ex.Message,"Ошибка автосохранения");
        }
    }

    private void ImportCountFacts()
    {
        if(CountClosed || _countSessionId==0)
            throw new InvalidOperationException("Сначала начните новый пересчёт.");
        var path=_ui.OpenPath("Загрузить фактические остатки","Книга Excel (*.xlsx)|*.xlsx");
        if(path is null)return;
        var preview=_countExcelImporter.Read(path,CountLines.ToList());
        var names=CountLines.ToDictionary(x=>x.ProductId);
        var sample=string.Join("\n",preview.Updates.Take(12).Select(change=>
            $"• {names[change.ProductId].Name}: {names[change.ProductId].ActualQuantity?.ToString()??"не заполнено"} → {change.Fact}"));
        if(!_ui.Confirm($"СТРОК С ФАКТОМ: {preview.Updates.Count}\nНезаполненных: {preview.EmptyRows}\n\nПРЕДПРОСМОТР (до 12 позиций):\n{sample}\n\nПрименить к ЧЕРНОВИКУ? Учётные остатки НЕ изменятся."))return;
        var byId=CountLines.ToDictionary(x=>x.ProductId);
        // Do not mutate current rows until parsing and all validations have succeeded.
        foreach(var (productId,fact) in preview.Updates)byId[productId].ActualQuantity=fact;
        _countService.SaveFacts(_countSessionId,CountLines);
        LoadCount();
        CountSavedStatus=$"✓ Загружено {preview.Updates.Count} строк из Excel; сохранён черновик";
        Status=CountSavedStatus;
    }

    private void SaveCount()
    {
        if(CountClosed)throw new InvalidOperationException("Откройте новую инвентаризацию перед редактированием.");
        _countService.SaveFacts(_countSessionId,CountLines);
        LoadCount();Status="✓ Фактические количества сохранены как черновик. Учётные остатки не изменились.";
    }
    private void CompleteCount()
    {
        if(CountClosed)throw new InvalidOperationException("Пересчёт уже завершён.");
        if(!CountLines.Any(x=>x.IsCounted)) throw new InvalidOperationException("Вы ещё не ввели фактические количества.");
        int filled=CountLines.Count(x=>x.IsCounted);
        if(!_ui.Confirm($"ПОДТВЕРДИТЬ ИНВЕНТАРИЗАЦИЮ?\n\nЗаполнено: {filled} из {CountLines.Count}.\nБудут изменены ТОЛЬКО позиции с введённым фактом.\nВсе остальные учётные остатки останутся прежними.\nПеред изменением будет создана резервная копия."))return;
        SaveCount();
        var path=Path.Combine(Path.GetDirectoryName(_database.DatabasePath)!,"before-count-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".db");
        _database.Backup(path);
        int count=_countService.Commit(_countSessionId);
        Refresh();LoadCount();Status=$"✓ Инвентаризация завершена. Обновлено {count} товаров. Резервная копия сохранена.";
    }
    private void ExportCountReport()
    {
        if(_countSessionId==0)throw new ArgumentException("Сначала создайте пересчёт.");
        if(!CountClosed)SaveCount();
        var path=_ui.SavePath("Экспорт результатов пересчёта","Книга Excel (*.xlsx)|*.xlsx",".xlsx","Маяк_Расхождения_"+_countSessionId);
        if(path is null)return;
        _export.ExportCountReport(path,CountLines.ToList(),Responsible);
        Status="✓ Ведомость расхождений сохранена: "+path;
    }

    private List<Product> Visible()=>FilteredProducts.Cast<Product>().ToList();
    private string DefaultName(string type)=>type+"_"+DateTime.Now.ToString("yyyyMMdd_HHmm") ;

    private string CreateSafetyBackup(string operation)
    {
        _database.CheckIntegrity();
        var folder=Path.Combine(Path.GetDirectoryName(_database.DatabasePath)!,"backups");
        Directory.CreateDirectory(folder);
        var file=Path.Combine(folder,$"before-{operation}-{DateTime.Now:yyyyMMdd-HHmmss-fff}-{Guid.NewGuid():N}.db");
        _database.Backup(file);
        // Retain the latest 40 safety snapshots per operation; never delete a just-created backup.
        foreach(var old in Directory.GetFiles(folder,$"before-{operation}-*.db")
                    .OrderByDescending(x=>new FileInfo(x).CreationTimeUtc).Skip(40))
            try{File.Delete(old);}catch(IOException){}
        return file;
    }

    private void ApplyMovement()
    {
        if(SelectedProduct is null)throw new ArgumentException("Выберите строку товара в таблице слева.");
        if(MovementQuantity<=0)throw new ArgumentException("Количество должно быть больше нуля.");
        var product=_database.GetAll().FirstOrDefault(x=>x.Id==SelectedProduct.Id)
                    ?? throw new InvalidOperationException("Товар не найден. Обновите список.");
        var after=MovementOperation=="Приход"?product.Quantity+MovementQuantity:product.Quantity-MovementQuantity;
        if(after<0)throw new ArgumentException($"Недостаточно товара: на складе {product.Quantity} {product.Unit}.");
        if(!_ui.Confirm($"{MovementOperation.ToUpperInvariant()} · {product.Name}\n\nСейчас: {product.Quantity} {product.Unit}\nКоличество операции: {MovementQuantity}\nПосле: {after} {product.Unit}\n\nПодтвердить запись в журнале?"))return;
        CreateSafetyBackup("movement");
        var done=_movements.Apply(product.Id,MovementOperation,MovementQuantity,MovementResponsible,MovementReason);
        MovementQuantity=1;MovementReason="";
        Refresh();
        Status=$"✓ {done.Operation} №{done.Id}: {done.ProductName}, новый остаток {done.AfterQuantity} {done.Unit}. Записано в журнал.";
    }

    private void ReverseMovement()
    {
        var old=SelectedMovement??throw new ArgumentException("Выберите запись движения в Настройках → История.");
        if(string.IsNullOrWhiteSpace(MovementReason))throw new ArgumentException("Укажите основание отмены в поле «Основание» на вкладке Товары.");
        if(!_ui.Confirm($"ИСПРАВИТЬ ОПЕРАЦИЮ №{old.Id}?\n{old.ProductName} · {old.Operation} {old.Quantity} {old.Unit}\n\nБудет создано ОБРАТНОЕ движение с отдельным номером. Оригинал останется в журнале. Продолжить?"))return;
        CreateSafetyBackup("reverse");
        var correction=_movements.Reverse(old.Id,MovementResponsible,MovementReason);
        MovementReason="";
        Refresh();Status=$"✓ Создана корректировка №{correction.Id} к операции №{old.Id}. Остаток {correction.AfterQuantity} {old.Unit}.";
    }

    private void ShowBackups()
    {
        _database.CheckIntegrity();
        var backups=_database.AvailableBackups();
        BackupSummary=backups.Count==0?"Автоматических копий пока нет.":
            "Последние копии ("+backups.Count+"):\n"+string.Join("\n",backups.Take(12).Select(x=>$"{x.Modified:dd.MM.yyyy HH:mm} · {x.Bytes/1024:N0} КБ · {x.Name}"));
        _ui.Message(BackupSummary,"Резервные копии");
    }

    private void ExportMovements()
    {
        var path=_ui.SavePath("Журнал прихода, расхода и списаний","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("Движения_товаров"));
        if(path is null)return;
        if(!ReportStartDate.HasValue || !ReportEndDate.HasValue)throw new ArgumentException("Укажите начало и конец периода.");
        if(ReportStartDate.Value>DateTime.Today.AddYears(1) || ReportStartDate.Value.Date>ReportEndDate.Value.Date)
            throw new ArgumentException("Проверьте даты отчёта.");
        _export.ExportMovements(path,_movements.GetByPeriod(ReportStartDate.Value,ReportEndDate.Value),MovementResponsible);
        Status="✓ Журнал движений Excel сформирован: "+path;
    }
    private void VerifyDatabase()
    {
        _database.CheckIntegrity();
        var testPath=Path.Combine(Path.GetTempPath(),"mayak-check-"+Guid.NewGuid().ToString("N")+".db");
        try
        {
            _database.Backup(testPath);
            using var conn=new Microsoft.Data.Sqlite.SqliteConnection(new Microsoft.Data.Sqlite.SqliteConnectionStringBuilder {DataSource=testPath,Mode=Microsoft.Data.Sqlite.SqliteOpenMode.ReadOnly}.ToString());
            conn.Open();using var cmd=conn.CreateCommand();cmd.CommandText="PRAGMA integrity_check";
            if(cmd.ExecuteScalar()?.ToString()!="ok")throw new InvalidDataException("Резервная копия не прошла проверку.");
            IntegrityStatus="✓ База и тестовая резервная копия исправны · "+DateTime.Now.ToString("dd.MM.yyyy HH:mm");
        }
        finally {try {File.Delete(testPath);}catch(IOException){}}
        Status=IntegrityStatus;
    }

    private void ExportBlankTemplate()
    {
        var path = _ui.SavePath("Сохранить пустой Excel-бланк", "Книга Excel (*.xlsx)|*.xlsx", ".xlsx", "Инвентаризация_Пустой_бланк");
        if (path is null) return;
        _excelTemplates.SaveBlank(path);
        Status = "✓ Пустой бланк Excel сохранён: " + path;
    }
    private void ExportFilledExample()
    {
        var path = _ui.SavePath("Сохранить заполненный пример Excel (768 товаров)", "Книга Excel (*.xlsx)|*.xlsx", ".xlsx", "Инвентаризация_Пример_768_товаров");
        if (path is null) return;
        _excelTemplates.SaveFilledExample(path);
        Status = "✓ Пример с 768 товарами сохранён: " + path;
    }

    private void Excel(bool filtered)
    {
        var path=_ui.SavePath("Экспорт в Excel","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName(filtered?"Отбор":"Инвентаризация"));
        if(path is null)return;
        _export.ExportExcel(path,filtered?Visible():Products.ToList());
        Status="✓ Excel сформирован: "+path;
    }
    private void ExportCategory()
    {
        var path=_ui.SavePath("Отчёт по категориям","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("По_категориям"));
        if(path is null)return;
        _export.ExportCategories(path,Products.ToList());
        Status="✓ Отчёт по категориям сохранён";
    }
    private void ExportStatement()
    {
        var path=_ui.SavePath("Ведомость инвентаризации","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("Ведомость"));
        if(path is null)return;
        _export.ExportInventoryStatement(path,Visible(),Responsible);
        Status="✓ Ведомость инвентаризации сохранена";
    }
    private void ExportOrderList()
    {
        var path=_ui.SavePath("Список для заказа","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("К_заказу"));
        if(path is null)return;
        _export.ExportOrderList(path,Products.Where(p=>p.IsEmpty || p.IsLow).ToList());
        Status="✓ Список для заказа сохранён";
    }
    private void ExportDailyChanges()
    {
        var path=_ui.SavePath("Изменения за сегодня","Книга Excel (*.xlsx)|*.xlsx",".xlsx",DefaultName("Изменения_за_день"));
        if(path is null)return;
        var today=DateTime.Now.ToString("dd.MM.yyyy");
        _export.ExportDailyChanges(path,_database.RecentChanges(50000).Where(c=>c.Time.StartsWith(today)).ToList());
        Status="✓ Отчёт изменений за сегодня сохранён";
    }
    private void ExportWord()
    {
        var path=_ui.SavePath("Ведомость Word","Документ Word (*.docx)|*.docx",".docx",DefaultName("Ведомость"));
        if(path is null)return;
        _export.ExportWord(path,Visible(),Responsible);
        Status="✓ Документ Word сохранён";
    }
    private void Backup()
    {
        var path=_ui.SavePath("Резервная копия","SQLite база (*.db)|*.db",".db",DefaultName("Инвентаризация_копия"));
        if(path is null)return;
        _database.Backup(path);
        Status="✓ Резервная копия сохранена: "+path;
    }
    private void Restore()
    {
        var path=_ui.OpenPath("Восстановить базу","SQLite база (*.db)|*.db");
        if(path is null)return;
        if(!_ui.Confirm("Восстановление ЗАМЕНИТ текущие данные данными из копии.\nПеред заменой будет создана автоматическая страховочная копия. Продолжить?"))return;
        _database.Restore(path);
        _deleteUndo.Clear();
        Refresh();
        Status="✓ База восстановлена из резервной копии";
    }
    private void ResetDemo()
    {
        if(!_ui.Confirm("Очистить демонстрационные количества и пометки, оставив справочник товаров?\nРеальные новые позиции не затрагиваются."))return;
        _database.ClearDemoQuantities();
        Refresh();
        Status="✓ Демо-остатки очищены. Теперь вносите фактические количества.";
    }
}
