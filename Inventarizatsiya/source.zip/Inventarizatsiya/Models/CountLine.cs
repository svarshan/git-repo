using System.Globalization;
namespace Inventarizatsiya.Models;
public sealed class CountLine : ObservableObject
{
    private decimal? _actualQuantity;
    public long ProductId {get;set;}
    public string Name {get;set;}="";
    public string Unit {get;set;}="";
    public decimal BookQuantity {get;set;}
    public decimal Price {get;set;}
    public decimal? ActualQuantity {get=>_actualQuantity;set { if(value < 0) throw new ArgumentException("Факт не может быть отрицательным"); if(Set(ref _actualQuantity,value)) {Changed(nameof(Variance));Changed(nameof(VarianceAmount));} }}
    public decimal? Variance=>ActualQuantity is null ? null : ActualQuantity - BookQuantity;
    public decimal? VarianceAmount=>Variance * Price;
    public bool IsCounted=>ActualQuantity.HasValue;
}
