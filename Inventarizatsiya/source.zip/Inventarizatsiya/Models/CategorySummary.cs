namespace Inventarizatsiya.Models;

public sealed record CategorySummary(string Category, int Count, int Low, int Empty, decimal Amount);
public sealed record ChangeEntry(string Time, string Action, string Product, string Details);
public sealed record ImportResult(int Added, int Skipped);
