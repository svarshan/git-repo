using System.Globalization;

namespace Inventarizatsiya.Models;

public sealed class Product : ObservableObject
{
    private long _id;
    private int _rowNumber;
    private string _sku = "";
    private string _name = "";
    private string _category = "Прочее";
    private string _unit = "кг";
    private decimal _quantity;
    private decimal _minQuantity;
    private decimal _price;
    private string _location = "Сухой склад";
    private string _supplier = "";
    private string _barcode = "";
    private string _comment = "";
    private bool _isFavorite;
    private bool _isDemo;
    private DateTimeOffset _updatedAt = DateTimeOffset.Now;

    public long Id { get => _id; set => Set(ref _id, value); }
    public int RowNumber { get => _rowNumber; set => Set(ref _rowNumber, value); }
    public string Sku { get => _sku; set => Set(ref _sku, value); }
    public string Name { get => _name; set => Set(ref _name, value); }
    public string Category { get => _category; set => Set(ref _category, value); }
    public string Unit { get => _unit; set => Set(ref _unit, value); }
    public decimal Quantity { get => _quantity; set { if (Set(ref _quantity, value)) { Changed(nameof(Total)); Changed(nameof(IsEmpty)); Changed(nameof(IsLow)); } } }
    public decimal MinQuantity { get => _minQuantity; set { if (Set(ref _minQuantity, value)) Changed(nameof(IsLow)); } }
    public decimal Price { get => _price; set { if (Set(ref _price, value)) Changed(nameof(Total)); } }
    public string Location { get => _location; set => Set(ref _location, value); }
    public string Supplier { get => _supplier; set => Set(ref _supplier, value); }
    public string Barcode { get => _barcode; set => Set(ref _barcode, value); }
    public string Comment { get => _comment; set => Set(ref _comment, value); }
    public bool IsFavorite { get => _isFavorite; set => Set(ref _isFavorite, value); }
    public bool IsDemo { get => _isDemo; set => Set(ref _isDemo, value); }
    public DateTimeOffset UpdatedAt { get => _updatedAt; set { if (Set(ref _updatedAt, value)) Changed(nameof(UpdatedLocal)); } }

    public decimal Total => Quantity * Price;
    public bool IsEmpty => Quantity <= 0;
    public bool IsLow => Quantity > 0 && Quantity < MinQuantity;
    public string UpdatedLocal => UpdatedAt.LocalDateTime.ToString("dd.MM.yyyy HH:mm", CultureInfo.GetCultureInfo("ru-RU"));

    public Product Copy() => new()
    {
        Id=Id, RowNumber=RowNumber, Sku=Sku, Name=Name, Category=Category, Unit=Unit,
        Quantity=Quantity, MinQuantity=MinQuantity, Price=Price, Location=Location,
        Supplier=Supplier, Barcode=Barcode, Comment=Comment, IsFavorite=IsFavorite,
        IsDemo=IsDemo, UpdatedAt=UpdatedAt
    };
}
