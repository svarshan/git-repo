namespace Inventarizatsiya.Models;

public sealed record StockMovement(long Id, DateTimeOffset Timestamp, long ProductId,
    string ProductName, string Unit, string Operation, decimal Quantity,
    decimal BeforeQuantity, decimal AfterQuantity, decimal UnitPrice,
    string Responsible, string Reason)
{
    public decimal Amount => Quantity * UnitPrice;
    public string LocalTime => Timestamp.LocalDateTime.ToString("dd.MM.yyyy HH:mm");
}
