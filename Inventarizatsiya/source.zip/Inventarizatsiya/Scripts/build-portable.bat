@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish-portable.ps1"
if errorlevel 1 (echo Build failed. & pause & exit /b 1)
echo Build complete.
pause
