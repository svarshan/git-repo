"""Lightweight offline structural/fixture checks, not a WPF compilation test."""
from pathlib import Path
from collections import Counter
from decimal import Decimal
import csv
import sqlite3
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
REQUIRED = [
    'Inventarizatsiya.csproj','App.xaml','App.xaml.cs','Views/MainWindow.xaml',
    'Views/MainWindow.xaml.cs','Models/Product.cs','Models/ObservableObject.cs',
    'Models/CategorySummary.cs','ViewModels/MainViewModel.cs','Services/DatabaseService.cs',
    'Services/ExportService.cs','Services/CsvImportService.cs', 'Services/IUiService.cs',
    'Services/WpfUiService.cs','Helpers/RelayCommand.cs','Converters/StockStatusConverter.cs',
    'Assets/inventory.ico','Data/seed_products.csv',
    'Scripts/publish-portable.ps1','Scripts/build-installer.ps1','Scripts/Installer.iss',
    '.github/workflows/build-windows.yml'
]
for file in REQUIRED:
    assert (ROOT/file).is_file(), f'Нет файла: {file}'
for file in ['App.xaml','Views/MainWindow.xaml','Inventarizatsiya.csproj']:
    ET.parse(ROOT/file)

with (ROOT/'Data/seed_products.csv').open(encoding='utf-8-sig',newline='') as fh:
    rows = list(csv.DictReader(fh,delimiter=';'))
assert len(rows) >= 500, f'Товаров меньше 500: {len(rows)}'
names = [r['Наименование'].strip().casefold() for r in rows]
assert len(set(names)) == len(names), 'Найдены повторяющиеся наименования'
assert len(set(r['Категория'] for r in rows)) >= 30, 'Не хватает категорий'
required_names = ['Гречка ядрица','Рис круглозерный','Мука пшеничная в/с','Куриное филе',
                  'Картофель','Сгущенное молоко с сахаром','Перчатки одноразовые нитриловые']
for name in required_names:
    assert name.casefold() in names, f'Нет важного продукта: {name}'
units={'кг','л','шт.','упак.','банка','пачка','десяток','упаковка','г','мл','рулон','комплект'}
for row in rows:
    assert row['Единица'] in units, f'Некорректная единица: {row}'
    assert row['Демо'] == '1'
    for field in ['Количество','Минимальный остаток','Цена']:
        assert Decimal(row[field]) >= 0, f'Отрицательное число: {row}'
    code = row['Штрихкод']
    assert len(code)==13 and code.startswith('20') and code.isdigit(), f'Штрихкод: {code}'
    bits=list(map(int,code))
    assert (sum(bits[:12:2])+3*sum(bits[1:12:2])+bits[-1])%10==0, f'Контрольная цифра EAN: {code}'

# Simulate selected SQLite operations without writing a file or altering data.
con=sqlite3.connect(':memory:')
con.execute('CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, category TEXT, quantity REAL CHECK(quantity>=0), price REAL CHECK(price>=0))')
con.executemany('INSERT INTO products(name,category,quantity,price) VALUES(?,?,?,?)',
                [(r['Наименование'],r['Категория'],float(r['Количество']),float(r['Цена'])) for r in rows])
assert con.execute('SELECT count(*) FROM products').fetchone()[0] == len(rows)
assert con.execute('SELECT count(distinct category) FROM products').fetchone()[0] >= 30
con.execute('UPDATE products SET quantity=quantity+5 WHERE name=?',('Гречка ядрица',))
assert con.execute('SELECT quantity FROM products WHERE name=?',('Гречка ядрица',)).fetchone()[0] >= 5
con.execute('DELETE FROM products WHERE name=?',('Гречка ядрица',))
assert con.execute('SELECT count(*) FROM products').fetchone()[0] == len(rows)-1
con.execute('INSERT INTO products(name,category,quantity,price) VALUES(?,?,?,?)',('Гречка ядрица','Крупы',5,100))
assert con.execute('SELECT count(*) FROM products').fetchone()[0] == len(rows)
con.close()
print('OK: структура, XML, уникальность, единицы, числа, штрихкоды, SQLite-операции')
print(f'ТОВАРОВ: {len(rows)} | КАТЕГОРИЙ: {len(set(r["Категория"] for r in rows))} | НУЛЕВЫХ: {sum(Decimal(r["Количество"])==0 for r in rows)}')
print('ПРИМЕЧАНИЕ: это НЕ проверка компиляции WPF; соберите проект на Windows (.NET 8).')
