#define MyAppName "Инвентаризация"
#define MyAppVersion "1.0.3"
#define MyAppExeName "Inventarizatsiya.exe"

[Setup]
AppId={{C13862E4-56C9-4FA7-8AC4-DA92C8C8502A}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={localappdata}\Programs\Inventarizatsiya
DefaultGroupName={#MyAppName}
OutputDir=..\dist\installer
OutputBaseFilename=Inventarizatsiya_Setup_1.0.3
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
WizardStyle=modern
SetupIconFile=..\Assets\inventory.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
DisableProgramGroupPage=yes

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Files]
Source: "..\dist\portable\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Инвентаризация"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Инвентаризация"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Создать значок на рабочем столе"; GroupDescription: "Значки:"; Flags: unchecked

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Открыть приложение"; Flags: nowait postinstall skipifsilent unchecked

[UninstallDelete]
; User data is stored separately under %LOCALAPPDATA%\Inventarizatsiya and is NOT deleted.
