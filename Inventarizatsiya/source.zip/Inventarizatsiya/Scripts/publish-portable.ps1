# Run in Windows PowerShell or PowerShell 7 from any directory.
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Установите .NET 8 SDK (https://dotnet.microsoft.com/download/dotnet/8.0)' }
Set-Location $root
Write-Host '== Проверка и сборка Windows EXE ==' -ForegroundColor Cyan
dotnet restore '.\Inventarizatsiya.csproj'
if ($LASTEXITCODE -ne 0) { throw 'Не удалось восстановить пакеты NuGet' }
dotnet publish '.\Inventarizatsiya.csproj' -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o '.\dist\portable'
if ($LASTEXITCODE -ne 0) { throw 'Ошибка публикации' }
Write-Host "ГОТОВО: $root\dist\portable\Inventarizatsiya.exe" -ForegroundColor Green
Write-Host 'База создается при первом запуске в %LOCALAPPDATA%\Inventarizatsiya\inventory.db'
