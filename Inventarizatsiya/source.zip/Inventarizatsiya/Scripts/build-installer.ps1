$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
& (Join-Path $PSScriptRoot 'publish-portable.ps1')
if ($LASTEXITCODE -ne 0) { throw 'Сначала исправьте ошибку сборки EXE' }
$iscc = @(
  "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
  "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { throw 'Установите Inno Setup 6: https://jrsoftware.org/isinfo.php' }
& $iscc (Join-Path $root 'Scripts\Installer.iss')
if ($LASTEXITCODE -ne 0) { throw 'Ошибка формирования установщика' }
Write-Host "ГОТОВО: $root\dist\installer\Inventarizatsiya_Setup_1.0.0.exe" -ForegroundColor Green
