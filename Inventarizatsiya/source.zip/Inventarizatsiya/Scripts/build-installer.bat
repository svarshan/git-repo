@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-installer.ps1"
if errorlevel 1 (echo Installer build failed. & pause & exit /b 1)
echo Installer complete.
pause
