"""MoOLVa 1.8 Professional Control: keyboard-friendly Russian workspace and contextual training.
Uses business-layer validation for every final save; keeps the 1.7 screens intact.
"""
from __future__ import annotations
import csv, json, tkinter as tk
from tkinter import ttk,filedialog,messagebox,simpledialog
from pathlib import Path
from datetime import date
from mature16_ui import BG,NAV,PANEL,CARD,EDGE,INK,SOFT,MUTED,LIME,CYAN,GREEN,WARN,FONT,btn,text,title
from mature17_core import list_forms,list_entries,list_documents, list_lots
from mature16_core import list_assets,list_schedules,list_capa,read_table,import_employees_preview,make_asset_qr
from mature18_core import (
  migrate18, GUIDES, FIELD_HINTS,field_hint,guide_progress18,set_form_rules,get_form_rules,validate18,
  append_entry18,bulk_entries18,preview_csv18,inventory18,move_lot18,list_movements18,
  create_recipe18,add_ingredient18,list_recipes18,recipe_details18,search18,
  diagnostics18,export_diagnostics18,verify_local_installer18,export_document18)

class Mature18Mixin:
    def _init18(self):
        migrate18(self.store)
        row=tk.Frame(self.sidebar,bg=NAV);row.pack(fill='x',padx=7,pady=2,before=self.side_meter)
        w=tk.Button(row,text='✦   Professional Control 1.8',anchor='w',command=self.show_center18,
          relief='flat',bd=0,bg=NAV,fg=CYAN,activebackground=CARD,activeforeground=INK,
          font=(FONT,9,'bold'),padx=11,pady=8,cursor='hand2')
        w.pack(fill='x');self.primary_buttons['professional18']=w

    def _page18(self,heading,subtitle=''):
        if not self._need_venue():return None
        self._mode='professional18';self._activate_nav('professional18');self._clear();self._update_metrics()
        self.eyebrow.configure(text='MOOLVA · PROFESSIONAL CONTROL 1.8')
        self.heading.configure(text=heading);self.subhead.configure(text=subtitle)
        self._set_footer('←  Инструменты 1.8',self.show_center18,
                         'Все данные локальные · Показания только фактические','?  Обучение →',
                         lambda:self.show_training18('main'),0)
        return self.content

    def _section18(self,parent,header,subtitle=''):
        card=tk.Frame(parent,bg=PANEL,highlightthickness=1,highlightbackground=EDGE)
        card.pack(fill='x',pady=(3,12))
        inner=tk.Frame(card,bg=PANEL);inner.pack(fill='x',padx=19,pady=16)
        title(inner,header,subtitle)
        return inner

    def _actions18(self,parent,choices):
        frame=tk.Frame(parent,bg=PANEL);frame.pack(fill='x',pady=7)
        for caption,handler in choices:btn(frame,caption,handler).pack(side='left',padx=(0,8),pady=3)

    def _guard18(self,fun,refresh=None):
        try:
            result=fun()
            if refresh:refresh()
            return result
        except (ValueError,RuntimeError,OSError,FileExistsError,PermissionError) as exc:
            messagebox.showerror('Проверьте введённые данные',str(exc),parent=self)
            return None

    def _help_button18(self,parent,topic='journal',step=None):
        btn(parent,'?  Пояснить',lambda:self.show_training18(topic),False).pack(side='right',padx=(4,0))

    def show_center18(self):
        body=self._page18('Рабочий центр · 1.8','Задачи, журналы, партии, документы, оборудование и обучение в одном месте')
        if body is None:return
        header=self._section18(body,'Выберите действие','Все действия сохраняются для выбранного предприятия. Ничего не записывается автоматически вместо пользователя.')
        grid=tk.Frame(header,bg=PANEL);grid.pack(fill='x')
        sections=[
            ('▤  Журналы 5.0',self.show_journals18),('✦  Обучающий помощник',lambda:self.show_training18('main')),
            ('▣  Документы 4.0',self.show_documents18),('▦  Партии и движение',self.show_lots18),
            ('◈  Рецептуры / аллергены',self.show_recipes18),('◷  Оборудование / QR',self.show_equipment18),
            ('◉  Задачи и сроки',self.show_tasks18),('⌕  Быстрый поиск',self.show_search18),
            ('⇄  Импорт CSV / XLSX',self.show_import18),('⟳  Обновление 1.7 → 1.8',self.show_updates18),
            ('✓  Проверка и диагностика',self.show_diagnostics18),('▧  Старый центр ХАССП',self.show_center17)]
        for i,(caption,handler) in enumerate(sections):
            b=btn(grid,caption,handler);b.grid(row=i//2,column=i%2,padx=5,pady=5,sticky='ew')
        grid.columnconfigure(0,weight=1);grid.columnconfigure(1,weight=1)
        note=self._section18(body,'Первые шаги')
        for line in ['1. Начните с «Обучающий помощник»: он показывает действия по очереди.',
                     '2. Заполните журнал и проверьте обязательные поля, отмеченные *.',
                     '3. Проверьте фактические записи и сохраните Word/PDF.',
                     '4. Перед обновлением сделайте резервную копию базы.']:
            text(note,line,SOFT)

    def show_training18(self,topic='main'):
        body=self._page18('Обучающий помощник · 1.8','Понятные шаги и подсказки прямо возле полей · работает без интернета')
        if body is None:return
        card=self._section18(body,'Выберите тему')
        row=tk.Frame(card,bg=PANEL);row.pack(fill='x')
        for i,key in enumerate(GUIDES):
            btn(row,GUIDES[key][0],lambda k=key:self.show_training18(k)).grid(row=i//2,column=i%2,sticky='ew',padx=3,pady=3)
        row.columnconfigure(0,weight=1);row.columnconfigure(1,weight=1)
        current=guide_progress18(self.store,self.venue_id,topic)
        header,steps=GUIDES[topic]
        panel=self._section18(body,header,f'Шаг {min(current+1,len(steps))} из {len(steps)}. Отметка сохраняется отдельно для предприятия.')
        if current>=len(steps):
            text(panel,'Обучение пройдено. Можете повторить без потери данных.',GREEN)
            btn(panel,'Повторить с начала',lambda:self._step18(topic,0)).pack(anchor='w',pady=6)
        else:
            for i,(heading,explain) in enumerate(steps):
                color=GREEN if i<current else (LIME if i==current else SOFT)
                label=('✓  ' if i<current else '→  ' if i==current else '○  ')+heading
                tk.Label(panel,text=label,bg=PANEL,fg=color,font=(FONT,11,'bold')).pack(anchor='w',pady=(10,2))
                if i==current:text(panel,explain,SOFT,720)
            row=tk.Frame(panel,bg=PANEL);row.pack(anchor='w',pady=10)
            btn(row,'← Назад',lambda:self._step18(topic,max(0,current-1))).pack(side='left')
            btn(row,'Понятно, дальше →',lambda:self._step18(topic,current+1),True).pack(side='left',padx=10)
        tips=self._section18(body,'Словарь полей')
        for kind in ('text','date','number','choice','condition','signature','ccp'):
            text(tips,f'{kind}: {field_hint(kind)}',SOFT,790)

    def _step18(self,topic,step):
        self._guard18(lambda:guide_progress18(self.store,self.venue_id,topic,step))
        self.show_training18(topic)

    def _entry_dialog18(self,form):
        win=tk.Toplevel(self);win.title('Фактическая запись · '+form['title']);win.configure(bg=BG)
        win.geometry('750x700');win.minsize(580,480);win.transient(self);win.grab_set()
        canvas=tk.Canvas(win,bg=BG,highlightthickness=0)
        scroll=ttk.Scrollbar(win,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');canvas.pack(side='top',fill='both',expand=True)
        inside=tk.Frame(canvas,bg=BG)
        window=canvas.create_window((0,0),window=inside,anchor='nw')
        inside.bind('<Configure>',lambda _:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
        tk.Label(inside,text=form['title'],bg=BG,fg=INK,font=(FONT,16,'bold')).pack(anchor='w',padx=20,pady=(18,6))
        tk.Label(inside,text='Поля со * обязательны. Подсказки открываются нажатием «?».',bg=BG,fg=SOFT,font=(FONT,9)).pack(anchor='w',padx=20)
        rules=get_form_rules(self.store,self.venue_id,form['id'])
        vars={};widgets={};groups={}
        for f in form['fields']:
            key=f['name'];rule=rules.get(key,{})
            panel=tk.Frame(inside,bg=PANEL,highlightbackground=EDGE,highlightthickness=1)
            panel.pack(fill='x',padx=20,pady=(10,0))
            labelbar=tk.Frame(panel,bg=PANEL);labelbar.pack(fill='x',padx=11,pady=(9,3))
            needed=rule.get('required_when_visible',f['required'])
            tk.Label(labelbar,text=key+(' *' if needed else ''),bg=PANEL,fg=INK,font=(FONT,10,'bold')).pack(side='left')
            tip=rule.get('hint') or field_hint(f['type'])
            btn(labelbar,'?',lambda d=tip:messagebox.showinfo('Подсказка к полю',d,parent=win)).pack(side='right')
            var=tk.StringVar();vars[key]=var
            if f['type']=='choice':
                widget=ttk.Combobox(panel,textvariable=var,values=['']+f['options'],state='readonly')
            else:
                widget=tk.Entry(panel,textvariable=var,bg='#253B52',fg=INK,insertbackground=INK,
                          relief='flat',font=(FONT,11))
            widget.pack(fill='x',padx=11,pady=(2,11),ipady=5)
            widgets[key]=widget;groups[key]=panel
        actor=tk.StringVar(value=self._actor16())
        tk.Label(inside,text='Кто внёс запись *',bg=BG,fg=INK,font=(FONT,11,'bold')).pack(anchor='w',padx=20,pady=(14,4))
        tk.Entry(inside,textvariable=actor,bg='#253B52',fg=INK,insertbackground=INK,relief='flat').pack(fill='x',padx=20,ipady=6)
        def update_visibility(*_):
            for f in form['fields']:
                key=f['name'];rule=rules.get(key,{});condition=rule.get('when')
                visible=not condition or vars[condition['field']].get().strip()==condition['equals']
                widget=groups[key]
                if visible and not widget.winfo_manager():widget.pack(fill='x',padx=20,pady=(10,0))
                if not visible:
                    if vars[key].get():vars[key].set('')
                    widget.pack_forget()
        for var in vars.values():var.trace_add('write',update_visibility)
        update_visibility()
        footer=tk.Frame(win,bg=BG);footer.pack(fill='x',padx=20,pady=12)
        err=tk.Label(footer,text='',bg=BG,fg='#F0717D',wraplength=610,justify='left')
        err.pack(fill='x')
        def commit():
            values={k:v.get() for k,v in vars.items()}
            try:
                append_entry18(self.store,self.venue_id,form['id'],values,actor.get())
            except ValueError as ex:
                err.configure(text=str(ex));messagebox.showwarning('Проверьте форму',str(ex),parent=win);return
            win.destroy();self.show_journals18()
        btn(footer,'Сохранить фактическую запись',commit,True).pack(side='left')
        btn(footer,'Отмена',win.destroy).pack(side='left',padx=8)
        btn(footer,'? Пошаговая справка',lambda:messagebox.showinfo('Порядок заполнения','\n\n'.join(h+'\n'+d for h,d in GUIDES['journal'][1]),parent=win)).pack(side='right')
        win.wait_window()

    def _new_entry17(self,form):
        # Replace the old plain form only for this 1.8 instance, keep legacy storage compatible.
        return self._entry_dialog18(form)

    def show_journals18(self):
        body=self._page18('Журналы 5.0 · быстрые таблицы','Фактические записи, массовый CSV-импорт, условные поля и контекстная помощь')
        if body is None:return
        card=self._section18(body,'Журналы предприятия','Поля и ограничения устанавливает специалист. Измерения автоматически не дублируются.')
        actions=[('Добавить журнал',self._new_form17),('Создать обычную запись',self.show_forms17),
                 ('? Как заполнить',lambda:self.show_training18('journal'))]
        self._actions18(card,actions)
        forms=list_forms(self.store,self.venue_id)
        if not forms:text(card,'Форм пока нет. Создайте первый журнал, затем настройте обязательные поля.',SOFT)
        for form in forms:
            row=tk.Frame(card,bg=CARD);row.pack(fill='x',pady=4)
            label=tk.Label(row,text=form['title']+'  ·  Ответственный: '+form['owner'],font=(FONT,10,'bold'),bg=CARD,fg=INK,anchor='w')
            label.pack(fill='x',padx=11,pady=8)
            controls=tk.Frame(row,bg=CARD);controls.pack(fill='x',padx=10,pady=(0,8))
            for caption,fn in [('+ Запись',lambda f=form:self._entry_dialog18(f)),
                  ('Таблица',lambda f=form:self._table18(f)),('CSV',lambda f=form:self._import_csv18(f)),
                  ('Правила',lambda f=form:self._rules_dialog18(f)),('Word',lambda f=form:self._export_form17(f))]:
                btn(controls,caption,fn).pack(side='left',padx=(0,5))

    def _table18(self,form):
        win=tk.Toplevel(self);win.title('Журнал · '+form['title']);win.geometry('1100x600');win.configure(bg=BG)
        tk.Label(win,text=form['title']+' · История записей',bg=BG,fg=INK,font=(FONT,14,'bold')).pack(anchor='w',padx=12,pady=12)
        fields=[x['name'] for x in form['fields']];headers=['ID','Дата','Кто записал',*fields,'Статус']
        holder=tk.Frame(win);holder.pack(fill='both',expand=True,padx=12,pady=10)
        tree=ttk.Treeview(holder,columns=headers,show='headings')
        for head in headers:tree.heading(head,text=head);tree.column(head,width=105 if head not in ('Кто записал',) else 155,minwidth=80,stretch=True)
        sx=ttk.Scrollbar(holder,orient='horizontal',command=tree.xview)
        sy=ttk.Scrollbar(holder,orient='vertical',command=tree.yview)
        tree.configure(xscrollcommand=sx.set,yscrollcommand=sy.set)
        tree.grid(row=0,column=0,sticky='nsew');sx.grid(row=1,column=0,sticky='ew');sy.grid(row=0,column=1,sticky='ns')
        holder.rowconfigure(0,weight=1);holder.columnconfigure(0,weight=1)
        for item in list_entries(self.store,self.venue_id,form['id']):
            tree.insert('', 'end',values=[item['id'],item['recorded_at'][:16],item['recorded_by'],
                *[item['values'].get(f,'') for f in fields], 'АННУЛИРОВАНО' if item['voided_at'] else 'Записано'])
        row=tk.Frame(win,bg=BG);row.pack(fill='x',padx=12,pady=10)
        btn(row,'+ Добавить запись',lambda:(win.destroy(),self._entry_dialog18(form)),True).pack(side='left')
        btn(row,'CSV с проверкой',lambda:(win.destroy(),self._import_csv18(form))).pack(side='left',padx=7)
        btn(row,'Закрыть',win.destroy).pack(side='right')

    def _rules_dialog18(self,form):
        rows=[x for x in form['fields']]
        names=[x['name'] for x in rows]
        rules=get_form_rules(self.store,self.venue_id,form['id'])
        selected=simpledialog.askstring('Настройка условий','Какое поле настраиваем?\n'+', '.join(names),parent=self)
        if not selected:return
        if selected not in names:messagebox.showwarning('Настройки','Выберите существующее поле',parent=self);return
        f=next(x for x in rows if x['name']==selected)
        original=rules.get(selected,{})
        if messagebox.askyesno('Помощь','Создать условие отображения поля?\nЕсли ответ «Нет», поле будет показываться всегда.',parent=self):
            when_field=simpledialog.askstring('Условное поле','Показывать, когда заполнено какое поле?\n'+', '.join(n for n in names if n!=selected),parent=self)
            if when_field is None:return
            if when_field not in names or when_field==selected:messagebox.showerror('Условие','Неверное поле',parent=self);return
            value=simpledialog.askstring('Условие','При каком точном значении поля «'+when_field+'» показывать?',parent=self)
            if value is None:return
            original['when']={'field':when_field,'equals':value}
        else:original.pop('when',None)
        original['required_when_visible']=messagebox.askyesno('Обязательно','Сделать поле «'+selected+'» обязательным при отображении?',parent=self)
        if f['type']=='number':
            for key,name in [('min','Минимум'),('max','Максимум')]:
                v=simpledialog.askstring('Диапазон','Введите '+name+' (или оставьте пустым):',initialvalue=str(original.get(key,'')),parent=self)
                if v is None:return
                if v.strip():original[key]=v
                else:original.pop(key,None)
        hint=simpledialog.askstring('Подсказка','Пояснение новичку рядом с полем:',initialvalue=original.get('hint') or field_hint(f['type']),parent=self)
        if hint is None:return
        original['hint']=hint;rules[selected]=original
        self._guard18(lambda:set_form_rules(self.store,self.venue_id,form['id'],rules,self._actor16()),self.show_journals18)

    def _import_csv18(self,form):
        path=filedialog.askopenfilename(parent=self,title='Выберите CSV с заголовками как в журнале',filetypes=[('CSV UTF-8','*.csv')])
        if not path:return
        def do():
            rows=preview_csv18(path,[f['name'] for f in form['fields']])
            if not rows:raise ValueError('В файле нет записей')
            rules=get_form_rules(self.store,self.venue_id,form['id'])
            for no,row in enumerate(rows,1):
                try:validate18(form['fields'],row,rules)
                except ValueError as ex:raise ValueError(f'Строка {no}: {ex}') from ex
            preview='\n'.join(str({key:row.get(key,'') for key in list(row)[:3]}) for row in rows[:4])
            if not messagebox.askyesno('Предпросмотр импорта',f'Строк: {len(rows)}\n\n{preview}\n\nИмпортировать все строки как реальные записи?',parent=self):return 0
            return bulk_entries18(self.store,self.venue_id,form['id'],rows,self._actor16())
        saved=self._guard18(do,self.show_journals18)
        if saved:messagebox.showinfo('Импорт','Сохранено записей: '+str(saved),parent=self)

    def show_lots18(self):
        body=self._page18('Паспорт партии 2.0','Прослеживаемость и остатки: списание и возврат только с указанием причины')
        if body is None:return
        card=self._section18(body,'Партии предприятия','Движения не изменяют исходные зарегистрированные данные; все операции остаются в истории.')
        self._actions18(card,[('Новая партия',self._lot17),('Поставщики',self._supplier17),
                              ('Связать сырьё с продуктом',self._link_lot17),('? Инструкция',lambda:self.show_training18('lot'))])
        for lot in list_lots(self.store,self.venue_id):
            inv=self._guard18(lambda i=lot['id']:inventory18(self.store,self.venue_id,i))
            if not inv:continue
            row=tk.Frame(card,bg=CARD);row.pack(fill='x',pady=4)
            text(row,f"{lot['lot_code']} · {lot['name']} · {lot['kind']} · Остаток: {inv['available']} {lot['unit']}",INK,840)
            c=tk.Frame(row,bg=CARD);c.pack(fill='x',padx=10,pady=6)
            btn(c,'Списание / возврат',lambda l=lot:self._movement_dialog18(l)).pack(side='left')
            btn(c,'История',lambda l=lot:self._lot_history18(l)).pack(side='left',padx=7)
            btn(c,'Цепочка сырья',lambda l=lot:self._show_lot_trace17(l['id'])).pack(side='left')

    def _movement_dialog18(self,lot):
        self._dialog17('Операция по партии '+lot['lot_code'],[
            ('kind','Вид операции',True,'Списание',['Списание','Возврат']),
            ('qty','Фактическое количество',True),('reason','Основание операции',True),
            ('actor','Ответственный',True,self._actor16())],
            lambda data:(move_lot18(self.store,self.venue_id,lot['id'],data['kind'],data['qty'],data['reason'],data['actor']),self.show_lots18()))

    def _lot_history18(self,lot):
        operations=list_movements18(self.store,self.venue_id,lot['id'])
        display='\n'.join(f"{x['created_at']} · {x['kind']} · {x['quantity']} · {x['reason']} · {x['actor']}" for x in operations)
        messagebox.showinfo('Движения партии · '+lot['lot_code'],display or 'Операций нет',parent=self)

    def show_recipes18(self):
        body=self._page18('Рецептуры и аллергены','Состав блюда, производственные этапы, основания оценки аллергенов')
        if body is None:return
        card=self._section18(body,'Рецепты предприятия','Аллергены проверяются по документации сырья специалистом. Ничего не считается безопасным автоматически.')
        self._actions18(card,[('+ Новый рецепт',self._recipe18),('? Как заполнить',lambda:self.show_training18('lot'))])
        for recipe in list_recipes18(self.store,self.venue_id):
            row=tk.Frame(card,bg=CARD);row.pack(fill='x',pady=4)
            text(row,recipe['name']+' · '+recipe['output_unit'],INK)
            buttons=tk.Frame(row,bg=CARD);buttons.pack(fill='x',padx=12,pady=6)
            btn(buttons,'Добавить ингредиент',lambda r=recipe:self._ingredient18(r)).pack(side='left')
            btn(buttons,'Показать состав',lambda r=recipe:self._show_recipe18(r)).pack(side='left',padx=8)

    def _recipe18(self):
        self._dialog17('Новый рецепт',[
            ('name','Название блюда',True),('unit','Единица готовой продукции',True,'кг'),
            ('procedure','Технологические этапы (текст)',True,'',None,'multiline'),
            ('author','Разработчик',True,self._actor16())],
            lambda d:(create_recipe18(self.store,self.venue_id,d['name'],d['unit'],d['procedure'],d['author']),self.show_recipes18()))

    def _ingredient18(self,recipe):
        allergens='; '.join(__import__('mature17_core').KNOWN_ALLERGENS)
        self._dialog17('Ингредиент для '+recipe['name'],[
            ('name','Название ингредиента',True),('quantity','Количество',True),
            ('allergens','Аллергены через ; (или пусто)',False),
            ('source','Основание (спецификация, маркировка)',True),
            ('author','Проверил',True,self._actor16())],
            lambda d:(add_ingredient18(self.store,self.venue_id,recipe['id'],d['name'],d['quantity'],[x.strip() for x in d['allergens'].split(';') if x.strip()],d['source'],d['author']),self.show_recipes18()))

    def _show_recipe18(self,recipe):
        item=recipe_details18(self.store,self.venue_id,recipe['id'])
        lines=[f"{x['ingredient']}: {x['quantity']} · {', '.join(x['allergens']) or 'Не указаны'} · {x['source']}" for x in item['ingredients']]
        messagebox.showinfo('Состав · '+recipe['name'],'\n'.join(lines)+'\n\nАллергены: '+', '.join(item['allergens'])+'\n\n'+item['warning'],parent=self)

    def show_equipment18(self):
        body=self._page18('Контроль оборудования 2.0','QR-код открывает карточку оборудования, а журнал фиксирует фактическую проверку')
        if body is None:return
        card=self._section18(body,'Оборудование и сроки обслуживания')
        self._actions18(card,[('Добавить оборудование',self._asset_dialog16),('Назначить проверку',self._schedule_dialog16),
                              ('Поверка / обслуживание',self._equipment_dialog17),('? Помощь',lambda:self.show_training18('equipment'))])
        for asset in list_assets(self.store,self.venue_id):
            r=tk.Frame(card,bg=CARD);r.pack(fill='x',pady=4)
            text(r,f"{asset['id']} · {asset['display_name']} · {asset.get('location','')}",INK)
            btn(r,'Создать QR',lambda a=asset:self._asset_qr16(a)).pack(anchor='w',padx=10,pady=(0,8))

    def show_tasks18(self):
        body=self._page18('Задачи и сроки 3.0','Плановые проверки и корректирующие действия связаны с предприятием')
        if body is None:return
        card=self._section18(body,'Сегодня и предстоящие действия')
        self._actions18(card,[('Создать расписание',self._schedule_dialog16),('Корректирующие действия',self.show_capa16),
                              ('Заполнить проверку',self.show_day16)])
        for s in list_schedules(self.store,self.venue_id):
            text(card,f"{s['title']} · {s['next_due']} · {s['responsible']}",INK)
        for c in list_capa(self.store,self.venue_id):
            text(card,f"Отклонение #{c['id']} · {c['problem']} · {c.get('status','')}",WARN)

    def show_search18(self):
        body=self._page18('Глобальный поиск 3.0','Поиск по партиям, журналам, документам, оборудованию и рецептам')
        if body is None:return
        panel=self._section18(body,'Что найти?','Учитываются слова и небольшие опечатки. Результаты — только выбранного предприятия.')
        term=tk.StringVar();e=tk.Entry(panel,textvariable=term,bg='#253B52',fg=INK,insertbackground=INK,relief='flat',font=(FONT,12))
        e.pack(fill='x',ipady=8,pady=6)
        output=tk.Frame(panel,bg=PANEL);output.pack(fill='x')
        def find():
            for item in output.winfo_children():item.destroy()
            records=self._guard18(lambda:search18(self.store,self.venue_id,term.get()))
            if records is not None:
                for x in records:text(output,f"{x['type']} #{x['id']} · {x['label']}",INK)
                if not records:text(output,'Ничего не найдено. Попробуйте часть названия.',SOFT)
        btn(panel,'Найти',find,True).pack(anchor='w',pady=5);e.bind('<Return>',lambda _:find());e.focus_set()

    def show_import18(self):
        body=self._page18('Импорт и экспорт 3.0','Предпросмотр CSV, проверка обязательных полей, XLSX сотрудников')
        if body is None:return
        card=self._section18(body,'Выберите источник')
        self._actions18(card,[('CSV в журнал 5.0',self.show_journals18),('Сотрудники CSV / XLSX',self._import_staff16),
                              ('Документы Word / PDF',self.show_documents18)])
        text(card,'Записи импортируются только после предварительного просмотра и явного подтверждения.\nЕсли одна строка CSV неверна — весь импорт отменяется.',SOFT)

    def show_documents18(self):
        body=self._page18('Документы 4.0 · A4 и PDF','Оформление без потери кириллицы · версии утверждённых документов не изменяются автоматически')
        if body is None:return
        card=self._section18(body,'Документы предприятия')
        self._actions18(card,[('+ Создать',self._new_doc17),('История и утверждение',self.show_docs17),('Комплект ZIP (Word + PDF)',self._batch_docs18),('? Печать и подписи',lambda:self.show_training18('document'))])
        for doc in list_documents(self.store,self.venue_id):
            row=tk.Frame(card,bg=CARD);row.pack(fill='x',pady=4)
            text(row,doc['title']+f" · ред. {doc['revision']} · {doc['state']}",INK)
            actions=tk.Frame(row,bg=CARD);actions.pack(fill='x',padx=8,pady=(0,6))
            for fmt in ('docx','pdf'):
                btn(actions,'Экспорт '+fmt.upper(),lambda d=doc,k=fmt:self._export_doc18(d,k)).pack(side='left',padx=4)
            btn(actions,'Предпросмотр',lambda d=doc:self._preview_doc18(d)).pack(side='left',padx=4)

    def _batch_docs18(self):
        destination=filedialog.asksaveasfilename(parent=self,defaultextension='.zip',filetypes=[('Архив ZIP','*.zip')],title='Экспорт комплекта Word / PDF')
        if destination:
            from mature18_core import batch_export_documents18
            result=self._guard18(lambda:batch_export_documents18(self.store,self.venue_id,destination))
            if result:messagebox.showinfo('Документы','Комплект подготовлен: '+str(result),parent=self)

    def _preview_doc18(self,doc):
        win=tk.Toplevel(self);win.title('Предпросмотр A4 · '+doc['title']);win.configure(bg='#3E4853');win.geometry('820x740')
        wrapper=tk.Frame(win,bg='white',width=595,height=650);wrapper.pack(padx=34,pady=24,fill='both',expand=True)
        tk.Label(wrapper,text=doc['title'],bg='white',fg='#192333',font=(FONT,15,'bold'),wraplength=520).pack(anchor='w',padx=33,pady=(28,10))
        tk.Label(wrapper,text='Редакция: '+str(doc['revision'])+' · '+doc['state'],bg='white',fg='#45536A').pack(anchor='w',padx=33)
        textbody=tk.Text(wrapper,bg='white',fg='#172333',relief='flat',font=(FONT,10),wrap='word',height=27)
        textbody.pack(fill='both',expand=True,padx=30,pady=(12,8))
        textbody.insert('1.0',doc['content']);textbody.configure(state='disabled')
        tk.Label(wrapper,text='Место для собственноручной подписи: _____________________',bg='white',fg='#45536A').pack(padx=30,pady=10)
        tk.Label(wrapper,text='Эскиз чтения текста. Итоговая пагинация зависит от Word/PDF.',bg='white',fg='#45536A',font=(FONT,8)).pack(pady=5)
        btn(win,'Закрыть',win.destroy).pack(pady=(0,10))

    def _export_doc18(self,doc,kind):
        target=filedialog.asksaveasfilename(parent=self,defaultextension='.'+kind,
                     filetypes=[(kind.upper(),'*.'+kind)],title='Сохранить документ '+kind.upper())
        if target:self._guard18(lambda:export_document18(self.store,self.venue_id,doc['id'],target,kind))

    def show_updates18(self):
        body=self._page18('Центр обновлений 2.0','Безопасная установка поверх старой версии · с сохранением пользовательских баз')
        if body is None:return
        card=self._section18(body,'Текущая версия: 1.8.0','Программа не скачивает и не запускает случайные EXE из интернета.')
        for line in ['1. Создайте резервную копию базы в «Настройках».',
                     '2. Скачайте новый Setup.exe только из проверенного источника.',
                     '3. Узнайте официальную SHA-256 независимо от самого EXE.',
                     '4. Проверьте цифровую подпись издателя в свойствах Windows.',
                     '5. Закройте приложение и запустите установщик самостоятельно.',
                     '6. После обновления проверьте предприятие, журналы и документы.']:
            text(card,line,SOFT)
        btn(card,'Проверить SHA-256 локального Setup.exe',self._verify_setup18).pack(anchor='w',pady=8)
        btn(card,'? Порядок обновления',lambda:self.show_training18('upgrade')).pack(anchor='w',pady=5)
        text(card,'Контрольная сумма сама по себе не доказывает подлинность издателя. Без проверенной подписи автоустановка отключена.',WARN)

    def _verify_setup18(self):
        path=filedialog.askopenfilename(parent=self,title='Выберите проверяемый установщик',filetypes=[('Windows Setup','*.exe')])
        if not path:return
        expected=simpledialog.askstring('SHA-256','Вставьте официальную контрольную сумму из независимого источника:',parent=self)
        if not expected:return
        result=self._guard18(lambda:verify_local_installer18(path,expected))
        if result:messagebox.showinfo('Проверка файла','SHA-256 совпала.\n\n'+result['warning'],parent=self)

    def show_diagnostics18(self):
        body=self._page18('Центр качества 1.8','Целостность базы · проверка связей · история · отчёт без персональных данных')
        if body is None:return
        panel=self._section18(body,'Проверка локальной базы')
        result=self._guard18(lambda:diagnostics18(self.store,self.venue_id))
        if result:
            for key,value in result.items():text(panel,f'{key}: {value}',GREEN if value in ('ok',0) else SOFT)
        btn(panel,'Экспорт технического отчёта ZIP',self._export_diagnostics18).pack(anchor='w',pady=8)

    def _export_diagnostics18(self):
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.zip',filetypes=[('ZIP','*.zip')])
        if path:self._guard18(lambda:export_diagnostics18(self.store,self.venue_id,path))
