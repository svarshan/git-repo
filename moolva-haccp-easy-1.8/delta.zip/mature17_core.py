"""MoOLVa HACCP Easy 1.7 — additive, local and auditable operational modules.

Records represent user-entered facts only. This module neither determines HACCP
compliance nor automatically signs, approves, or fabricates physical measurements.
"""
from __future__ import annotations
import csv
import hashlib
import io
import json
import math
import re
import sqlite3
import zipfile
from datetime import date, datetime
from pathlib import Path
from storage import now
from mature16_core import migrate16, _trace, _venue, trace_integrity

REQUIRED_VENUE=('legal_name','venue_name','address','responsible')
VALID_TYPES=('text','date','number','choice')
KNOWN_ALLERGENS=('Злаки с глютеном','Ракообразные','Яйца','Рыба','Арахис','Соя','Молоко',
                'Орехи','Сельдерей','Горчица','Кунжут','Диоксид серы и сульфиты',
                'Люпин','Моллюски')


def required(value,name):
    value=str(value if value is not None else '').strip()
    if not value:raise ValueError(f'Заполните обязательное поле «{name}»')
    if len(value)>1000:raise ValueError(f'Слишком длинное значение поля «{name}»')
    return value


def check_date(value,name):
    value=required(value,name)
    try:return date.fromisoformat(value).isoformat()
    except ValueError:raise ValueError(f'Дата «{name}» должна быть в формате ГГГГ-ММ-ДД')


def positive(value,name):
    try:
        number=float(str(value).replace(',','.'))
        if not math.isfinite(number) or number<=0:raise ValueError()
        return number
    except (ValueError,TypeError):raise ValueError(f'«{name}»: требуется положительное число')


def validate_venue_fields(data):
    names={'legal_name':'Полное наименование','venue_name':'Название предприятия',
           'address':'Фактический адрес','responsible':'Ответственный за ХАССП'}
    missing=[names[k] for k in REQUIRED_VENUE if not str(data.get(k,'')).strip()]
    if str(data.get('venue_name','')).strip()=='Новое заведение':missing.append('Название предприятия (вместо «Новое заведение»)')
    if missing:raise ValueError('Заполните обязательные поля: '+', '.join(missing))
    return True


def migrate17(store):
    """No destructive statements; safe to call on old SQLite 1.4–1.6 files."""
    if getattr(store,"_m17_ready",False):return
    migrate16(store)
    with store.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS easy17_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS easy17_suppliers (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          name TEXT NOT NULL,contact TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,
          UNIQUE(venue_id,name));
        CREATE TABLE IF NOT EXISTS easy17_lots (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          lot_code TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('Сырьё','Готовая продукция')),
          name TEXT NOT NULL,supplier_id INTEGER REFERENCES easy17_suppliers(id),
          received_on TEXT NOT NULL,expires_on TEXT NOT NULL DEFAULT '',quantity REAL NOT NULL CHECK(quantity>0),
          unit TEXT NOT NULL,storage TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'В обращении',
          created_at TEXT NOT NULL, UNIQUE(venue_id,lot_code));
        CREATE INDEX IF NOT EXISTS easy17_lots_by_venue ON easy17_lots(venue_id,kind,id);
        CREATE TABLE IF NOT EXISTS easy17_lot_inputs (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          output_lot_id INTEGER NOT NULL REFERENCES easy17_lots(id) ON DELETE CASCADE,
          input_lot_id INTEGER NOT NULL REFERENCES easy17_lots(id),
          quantity REAL NOT NULL CHECK(quantity>0),operator TEXT NOT NULL,created_at TEXT NOT NULL,
          CHECK(output_lot_id<>input_lot_id));
        CREATE TABLE IF NOT EXISTS easy17_allergens (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          lot_id INTEGER NOT NULL REFERENCES easy17_lots(id) ON DELETE CASCADE,
          allergen TEXT NOT NULL,source TEXT NOT NULL,assessed_by TEXT NOT NULL,created_at TEXT NOT NULL,
          UNIQUE(venue_id,lot_id,allergen));
        CREATE TABLE IF NOT EXISTS easy17_journal_forms (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          title TEXT NOT NULL,schema_json TEXT NOT NULL,owner TEXT NOT NULL,
          frequency TEXT NOT NULL DEFAULT '',revision INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS easy17_journal_entries (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          form_id INTEGER NOT NULL REFERENCES easy17_journal_forms(id) ON DELETE CASCADE,
          values_json TEXT NOT NULL,recorded_by TEXT NOT NULL,recorded_at TEXT NOT NULL,
          void_reason TEXT NOT NULL DEFAULT '',voided_at TEXT NOT NULL DEFAULT '');
        CREATE TABLE IF NOT EXISTS easy17_equipment_due (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          asset_id INTEGER REFERENCES easy16_assets(id),event TEXT NOT NULL,due_on TEXT NOT NULL,
          responsible TEXT NOT NULL,completed_on TEXT NOT NULL DEFAULT '',evidence TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS easy17_documents (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          title TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,state TEXT NOT NULL DEFAULT 'Черновик',
          content TEXT NOT NULL,author TEXT NOT NULL,reviewer TEXT NOT NULL DEFAULT '',
          approved_by TEXT NOT NULL DEFAULT '',approved_at TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS easy17_doc_versions (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          document_id INTEGER NOT NULL REFERENCES easy17_documents(id) ON DELETE CASCADE,
          revision INTEGER NOT NULL,content TEXT NOT NULL,previous_state TEXT NOT NULL,
          archived_by TEXT NOT NULL,reason TEXT NOT NULL,archived_at TEXT NOT NULL,
          UNIQUE(venue_id,document_id,revision));
        CREATE TABLE IF NOT EXISTS easy17_doc_events (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          document_id INTEGER NOT NULL REFERENCES easy17_documents(id) ON DELETE CASCADE,
          action TEXT NOT NULL,actor TEXT NOT NULL,details TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS easy17_incident_lots (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          capa_id INTEGER NOT NULL REFERENCES easy16_capa(id),lot_id INTEGER NOT NULL REFERENCES easy17_lots(id),
          measures TEXT NOT NULL, linked_at TEXT NOT NULL, UNIQUE(venue_id,capa_id,lot_id));
        CREATE TABLE IF NOT EXISTS easy17_audits (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          subject TEXT NOT NULL,auditor TEXT NOT NULL,held_on TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS easy17_findings (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          audit_id INTEGER NOT NULL REFERENCES easy17_audits(id) ON DELETE CASCADE,
          requirement TEXT NOT NULL,observation TEXT NOT NULL,severity TEXT NOT NULL,
          owner TEXT NOT NULL,due_on TEXT NOT NULL DEFAULT '',resolved_at TEXT NOT NULL DEFAULT '',
          resolution TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL);
        ''')
        db.execute("INSERT OR REPLACE INTO easy17_meta(key,value) VALUES('schema','1.7.0')")
    store._m17_ready=True


def _rows(store,sql,params=()):
    with store.connect() as db:return [dict(r) for r in db.execute(sql,params)]


def _log(db,vid,actor,event,details):
    _trace(db,vid,required(actor,'Кто выполнил действие'),event,details)


def create_supplier(store,vid,name,contact='',actor='Пользователь'):
    _venue(store,vid);migrate17(store);name=required(name,'Поставщик')
    with store.connect() as db:
        c=db.execute('INSERT INTO easy17_suppliers(venue_id,name,contact,created_at) VALUES(?,?,?,?)',
                     (vid,name,str(contact).strip(),now()))
        _log(db,vid,actor,'supplier_created',{'id':c.lastrowid,'name':name})
        return c.lastrowid


def list_suppliers(store,vid):
    _venue(store,vid);migrate17(store)
    return _rows(store,'SELECT * FROM easy17_suppliers WHERE venue_id=? ORDER BY name',(vid,))


def create_lot(store,vid,lot_code,kind,name,received_on,quantity,unit,actor,supplier_id=None,expires_on='',storage=''):
    _venue(store,vid);migrate17(store)
    lot_code=required(lot_code,'Номер партии');name=required(name,'Наименование продукции')
    unit=required(unit,'Единица измерения');received_on=check_date(received_on,'Дата поступления/изготовления')
    quantity=positive(quantity,'Количество');actor=required(actor,'Ответственный')
    if kind not in ('Сырьё','Готовая продукция'):raise ValueError('Выберите вид партии')
    if kind=='Сырьё' and not supplier_id:raise ValueError('Укажите поставщика партии сырья')
    if expires_on:
        expires_on=check_date(expires_on,'Годен до')
        if expires_on<received_on:raise ValueError('Срок годности не может быть раньше даты поступления')
    if supplier_id:
        if not _rows(store,'SELECT id FROM easy17_suppliers WHERE id=? AND venue_id=?',(supplier_id,vid)):
            raise ValueError('Поставщик принадлежит другому предприятию')
    with store.connect() as db:
        try:
            c=db.execute('''INSERT INTO easy17_lots(venue_id,lot_code,kind,name,supplier_id,received_on,expires_on,
                           quantity,unit,storage,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                         (vid,lot_code,kind,name,supplier_id,received_on,expires_on,quantity,unit,str(storage).strip(),now()))
        except sqlite3.IntegrityError as e:raise ValueError('Такой номер партии уже используется или данные неверны') from e
        _log(db,vid,actor,'lot_created',{'id':c.lastrowid,'code':lot_code,'kind':kind})
        return c.lastrowid


def list_lots(store,vid,kind=None):
    _venue(store,vid);migrate17(store)
    sql='SELECT l.*,s.name AS supplier_name FROM easy17_lots l LEFT JOIN easy17_suppliers s ON l.supplier_id=s.id WHERE l.venue_id=?'
    params=[vid]
    if kind:
        sql+=' AND l.kind=?';params.append(kind)
    return _rows(store,sql+' ORDER BY l.id DESC',params)


def consume_lot(store,vid,output_id,input_id,quantity,operator):
    _venue(store,vid);migrate17(store)
    quantity=positive(quantity,'Количество использованного сырья');operator=required(operator,'Оператор')
    with store.connect() as db:
        output=db.execute('SELECT * FROM easy17_lots WHERE id=? AND venue_id=?',(output_id,vid)).fetchone()
        input_row=db.execute('SELECT * FROM easy17_lots WHERE id=? AND venue_id=?',(input_id,vid)).fetchone()
        if not output or output['kind']!='Готовая продукция':raise ValueError('Укажите готовую продукцию своего предприятия')
        if not input_row or input_row['kind']!='Сырьё':raise ValueError('Укажите исходную партию сырья своего предприятия')
        if input_row['status']!='В обращении':raise ValueError('Использование блокированной партии запрещено')
        already=db.execute('SELECT COALESCE(SUM(quantity),0) FROM easy17_lot_inputs WHERE venue_id=? AND input_lot_id=?',
                           (vid,input_id)).fetchone()[0]
        # 1.8: account for manually written-off and returned lots before consumption.
        movement_table=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='easy18_lot_movements'").fetchone()
        movement=0
        if movement_table:
            movement=db.execute("SELECT COALESCE(SUM(CASE WHEN kind='Списание' THEN quantity ELSE -quantity END),0) FROM easy18_lot_movements WHERE venue_id=? AND lot_id=?",(vid,input_id)).fetchone()[0]
        if quantity+already+movement>input_row['quantity']+1e-8:raise ValueError('Используемое количество превышает остаток партии сырья')
        c=db.execute('INSERT INTO easy17_lot_inputs(venue_id,output_lot_id,input_lot_id,quantity,operator,created_at) VALUES(?,?,?,?,?,?)',
                     (vid,output_id,input_id,quantity,operator,now()))
        _log(db,vid,operator,'lot_input_linked',{'output':output_id,'input':input_id,'quantity':quantity})
        return c.lastrowid


def trace_lot(store,vid,lot_id):
    _venue(store,vid);migrate17(store)
    lot=_rows(store,'SELECT * FROM easy17_lots WHERE id=? AND venue_id=?',(lot_id,vid))
    if not lot:raise ValueError('Партия не найдена на этом предприятии')
    forward=_rows(store,'''SELECT l.id,l.lot_code,l.name,x.quantity FROM easy17_lot_inputs x
        JOIN easy17_lots l ON l.id=x.output_lot_id WHERE x.venue_id=? AND x.input_lot_id=?''',(vid,lot_id))
    backward=_rows(store,'''SELECT l.id,l.lot_code,l.name,x.quantity FROM easy17_lot_inputs x
        JOIN easy17_lots l ON l.id=x.input_lot_id WHERE x.venue_id=? AND x.output_lot_id=?''',(vid,lot_id))
    return {'lot':lot[0],'inputs':backward,'outputs':forward,'allergens':lot_allergens(store,vid,lot_id)}


def set_lot_hold(store,vid,lot_id,hold,reason,actor):
    _venue(store,vid);migrate17(store);reason=required(reason,'Причина блокировки/снятия блокировки')
    with store.connect() as db:
        c=db.execute('UPDATE easy17_lots SET status=? WHERE id=? AND venue_id=?',
                     ('Заблокирована' if hold else 'В обращении',lot_id,vid))
        if c.rowcount!=1:raise ValueError('Партия не найдена')
        _log(db,vid,actor,'lot_hold_changed',{'lot_id':lot_id,'blocked':bool(hold),'reason':reason})


def assign_allergen(store,vid,lot_id,allergen,source,assessed_by):
    _venue(store,vid);migrate17(store)
    if allergen not in KNOWN_ALLERGENS:raise ValueError('Аллерген должен быть из справочника')
    source=required(source,'Основание отметки об аллергене');assessed_by=required(assessed_by,'Кто оценил')
    with store.connect() as db:
        if not db.execute('SELECT 1 FROM easy17_lots WHERE id=? AND venue_id=?',(lot_id,vid)).fetchone():
            raise ValueError('Партия не найдена')
        db.execute('''INSERT INTO easy17_allergens(venue_id,lot_id,allergen,source,assessed_by,created_at)
            VALUES(?,?,?,?,?,?) ON CONFLICT(venue_id,lot_id,allergen) DO UPDATE SET
            source=excluded.source,assessed_by=excluded.assessed_by''',(vid,lot_id,allergen,source,assessed_by,now()))
        _log(db,vid,assessed_by,'allergen_assessed',{'lot':lot_id,'allergen':allergen,'source':source})


def lot_allergens(store,vid,lot_id):
    _venue(store,vid);migrate17(store)
    return _rows(store,'SELECT allergen,source,assessed_by FROM easy17_allergens WHERE venue_id=? AND lot_id=?',(vid,lot_id))


def allergen_warnings(store,vid,output_lot_id):
    """Warnings only; unassessed materials do not mean allergen-free."""
    inputs=trace_lot(store,vid,output_lot_id)['inputs']
    product={a['allergen'] for a in lot_allergens(store,vid,output_lot_id)}
    warnings=[]
    for raw in inputs:
        records=lot_allergens(store,vid,raw['id'])
        if not records:
            warnings.append('Не оценены аллергены партии '+raw['lot_code'])
        for a in records:
            if a['allergen'] not in product:warnings.append(f"Сверьте маркировку: {a['allergen']} из сырья {raw['lot_code']}")
    return warnings


def _normalise_schema(fields):
    if not isinstance(fields,list) or not fields or len(fields)>40:raise ValueError('Добавьте от 1 до 40 колонок')
    result=[];seen=set()
    for item in fields:
        if not isinstance(item,dict):raise ValueError('Неверное описание колонки')
        name=required(item.get('name'),'Название колонки')
        if len(name)>90:raise ValueError('Название колонки слишком длинное')
        if name.casefold() in seen:raise ValueError('Колонки не должны повторяться: '+name)
        seen.add(name.casefold())
        kind=item.get('type','text')
        if kind not in VALID_TYPES:raise ValueError('Некорректный тип поля '+name)
        options=item.get('options',[])
        if kind=='choice' and (not isinstance(options,list) or not options or any(not str(v).strip() for v in options)):
            raise ValueError(f'Поле «{name}»: укажите варианты выбора')
        result.append({'name':name,'type':kind,'required':bool(item.get('required',False)),
                       'options':[str(x).strip() for x in options] if kind=='choice' else []})
    if not any(x['required'] for x in result):raise ValueError('Отметьте хотя бы одно обязательное поле журнала')
    return result


def create_form(store,vid,title,fields,owner,frequency='',actor='Пользователь'):
    _venue(store,vid);migrate17(store)
    title=required(title,'Название журнала');owner=required(owner,'Ответственный за журнал')
    fields=_normalise_schema(fields)
    with store.connect() as db:
        c=db.execute('INSERT INTO easy17_journal_forms(venue_id,title,schema_json,owner,frequency,updated_at) VALUES(?,?,?,?,?,?)',
                     (vid,title,json.dumps(fields,ensure_ascii=False),owner,str(frequency).strip(),now()))
        _log(db,vid,actor,'journal_form_created',{'id':c.lastrowid,'title':title})
        return c.lastrowid


def list_forms(store,vid):
    _venue(store,vid);migrate17(store)
    out=_rows(store,'SELECT * FROM easy17_journal_forms WHERE venue_id=? ORDER BY id DESC',(vid,))
    for f in out:f['fields']=json.loads(f.pop('schema_json'))
    return out


def validate_entry(fields,values):
    schema=_normalise_schema(fields)
    if not isinstance(values,dict):raise ValueError('Форма заполнена неверно')
    accepted={}
    for f in schema:
        name=f['name'];value=str(values.get(name,'')).strip()
        if f['required']:required(value,name)
        if value:
            if f['type']=='date':value=check_date(value,name)
            elif f['type']=='number':
                try:
                    n=float(value.replace(',','.'))
                    if not math.isfinite(n):raise ValueError()
                    value=str(n)
                except ValueError:raise ValueError(f'Поле «{name}» должно быть числом')
            elif f['type']=='choice' and value not in f['options']:
                raise ValueError(f'Поле «{name}»: выберите допустимый вариант')
        accepted[name]=value
    return accepted


def write_form_entry(store,vid,form_id,values,actor):
    _venue(store,vid);migrate17(store);actor=required(actor,'Кто внёс запись')
    with store.connect() as db:
        f=db.execute('SELECT schema_json FROM easy17_journal_forms WHERE id=? AND venue_id=?',(form_id,vid)).fetchone()
        if not f:raise ValueError('Журнал не найден на выбранном предприятии')
        data=validate_entry(json.loads(f['schema_json']),values)
        c=db.execute('INSERT INTO easy17_journal_entries(venue_id,form_id,values_json,recorded_by,recorded_at) VALUES(?,?,?,?,?)',
                     (vid,form_id,json.dumps(data,ensure_ascii=False),actor,now()))
        _log(db,vid,actor,'journal_entry_created',{'form_id':form_id,'entry_id':c.lastrowid})
        return c.lastrowid


def list_entries(store,vid,form_id):
    _venue(store,vid);migrate17(store)
    out=_rows(store,'SELECT * FROM easy17_journal_entries WHERE venue_id=? AND form_id=? ORDER BY id DESC',(vid,form_id))
    for item in out:item['values']=json.loads(item.pop('values_json'))
    return out


def void_entry(store,vid,entry_id,reason,actor):
    _venue(store,vid);migrate17(store);reason=required(reason,'Причина отмены записи')
    if len(reason)<5:raise ValueError('Причина должна содержать не менее пяти символов')
    with store.connect() as db:
        c=db.execute('UPDATE easy17_journal_entries SET void_reason=?,voided_at=? WHERE id=? AND venue_id=? AND voided_at=""',
                     (reason,now(),entry_id,vid))
        if c.rowcount!=1:raise ValueError('Запись не найдена или уже аннулирована')
        _log(db,vid,actor,'journal_entry_voided',{'entry':entry_id,'reason':reason})


def export_form_docx(store,vid,form_id,destination):
    """Simple faithful A4 Word table, empty records not generated."""
    from docx import Document
    from docx.shared import Cm,Pt
    forms=[f for f in list_forms(store,vid) if f['id']==form_id]
    if not forms:raise ValueError('Журнал не найден')
    form=forms[0];records=list_entries(store,vid,form_id)
    doc=Document();section=doc.sections[0];section.page_width=Cm(29.7);section.page_height=Cm(21)
    section.left_margin=section.right_margin=Cm(1.5)
    doc.add_heading(form['title'],0)
    v=store.get_venue(vid)
    doc.add_paragraph('Предприятие: '+v['venue_name'])
    doc.add_paragraph('Ответственный: '+form['owner'])
    names=[f['name'] for f in form['fields']]
    table=doc.add_table(rows=1,cols=len(names)+2);table.style='Table Grid'
    for cell,label in zip(table.rows[0].cells,['Дата/время','Исполнитель']+names):cell.text=label
    for record in records:
        row=table.add_row().cells
        row[0].text=record['recorded_at'];row[1].text=record['recorded_by']
        for i,name in enumerate(names,2):row[i].text=record['values'].get(name,'')
    doc.add_paragraph('Записи без выдуманных подписей и измерений. Аннулированные записи учитываются в истории.')
    destination=Path(destination)
    if destination.suffix.lower()!='.docx':raise ValueError('Выберите файл .docx')
    if destination.exists():raise FileExistsError('Документ существует. Выберите другое имя.')
    doc.save(destination)
    return destination


def add_equipment_event(store,vid,event,due_on,responsible,asset_id=None,actor='Пользователь'):
    _venue(store,vid);migrate17(store)
    event=required(event,'Вид обслуживания/поверки');due_on=check_date(due_on,'Срок')
    responsible=required(responsible,'Ответственный')
    if asset_id and not _rows(store,'SELECT id FROM easy16_assets WHERE id=? AND venue_id=?',(asset_id,vid)):
        raise ValueError('Оборудование не принадлежит предприятию')
    with store.connect() as db:
        c=db.execute('INSERT INTO easy17_equipment_due(venue_id,asset_id,event,due_on,responsible,created_at) VALUES(?,?,?,?,?,?)',
                     (vid,asset_id,event,due_on,responsible,now()))
        _log(db,vid,actor,'equipment_due_created',{'id':c.lastrowid,'event':event})
        return c.lastrowid


def list_equipment_events(store,vid):
    _venue(store,vid);migrate17(store)
    return _rows(store,'''SELECT e.*,a.display_name AS equipment FROM easy17_equipment_due e
        LEFT JOIN easy16_assets a ON a.id=e.asset_id WHERE e.venue_id=? ORDER BY e.completed_on,e.due_on''',(vid,))


def complete_equipment_event(store,vid,event_id,completed_on,evidence,actor):
    _venue(store,vid);migrate17(store)
    completed_on=check_date(completed_on,'Дата исполнения');evidence=required(evidence,'Подтверждение исполнения')
    with store.connect() as db:
        c=db.execute('UPDATE easy17_equipment_due SET completed_on=?,evidence=? WHERE id=? AND venue_id=? AND completed_on=""',
                     (completed_on,evidence,event_id,vid))
        if c.rowcount!=1:raise ValueError('Мероприятие не найдено или уже выполнено')
        _log(db,vid,actor,'equipment_due_done',{'id':event_id,'evidence':evidence})


def create_document(store,vid,title,content,author):
    _venue(store,vid);migrate17(store)
    title=required(title,'Название документа');content=required(content,'Текст документа')
    author=required(author,'Разработчик')
    with store.connect() as db:
        c=db.execute('INSERT INTO easy17_documents(venue_id,title,content,author,created_at) VALUES(?,?,?,?,?)',
                     (vid,title,content,author,now()))
        _log(db,vid,author,'document_created',{'id':c.lastrowid,'title':title})
        return c.lastrowid


def list_documents(store,vid):
    _venue(store,vid);migrate17(store)
    return _rows(store,'SELECT * FROM easy17_documents WHERE venue_id=? ORDER BY id DESC',(vid,))


def document_action(store,vid,document_id,action,actor,comment=''):
    _venue(store,vid);migrate17(store);actor=required(actor,'Кто согласовал/утвердил')
    allowed={'review':('Черновик','На согласовании'), 'approve':('На согласовании','Утверждён'),
             'revise':('Утверждён','Черновик')}
    if action not in allowed:raise ValueError('Неверное действие с документом')
    old,new=allowed[action]
    if action=='revise':raise ValueError('Новая редакция требует новый текст документа. Используйте revise_document().')
    with store.connect() as db:
        row=db.execute('SELECT * FROM easy17_documents WHERE id=? AND venue_id=?',(document_id,vid)).fetchone()
        if not row or row['state']!=old:raise ValueError('Документ нельзя перевести в этот статус')
        revision=row['revision']+(1 if action=='revise' else 0)
        db.execute('''UPDATE easy17_documents SET state=?,revision=?,reviewer=?,approved_by=?,approved_at=?
            WHERE id=? AND venue_id=?''',(new,revision,actor if action=='review' else row['reviewer'],
            actor if action=='approve' else ('' if action=='revise' else row['approved_by']),
            now() if action=='approve' else ('' if action=='revise' else row['approved_at']),document_id,vid))
        db.execute('INSERT INTO easy17_doc_events(venue_id,document_id,action,actor,details,created_at) VALUES(?,?,?,?,?,?)',
                   (vid,document_id,action,actor,comment,now()))
        _log(db,vid,actor,'document_transition',{'id':document_id,'from':old,'to':new,'note':comment})


def revise_document(store,vid,document_id,new_content,reason,actor):
    """Keep previous approved text and change the current revision to a new draft."""
    _venue(store,vid);migrate17(store)
    new_content=required(new_content,'Новый текст редакции')
    reason=required(reason,'Основание новой редакции')
    actor=required(actor,'Разработчик')
    with store.connect() as db:
        old=db.execute('SELECT * FROM easy17_documents WHERE id=? AND venue_id=?',(document_id,vid)).fetchone()
        if not old or old['state']!='Утверждён':
            raise ValueError('Новая редакция возможна только из утверждённого документа')
        if old['content'].strip()==new_content:
            raise ValueError('Новый текст не отличается от утверждённого')
        db.execute('INSERT INTO easy17_doc_versions(venue_id,document_id,revision,content,previous_state,archived_by,reason,archived_at) VALUES(?,?,?,?,?,?,?,?)',
                   (vid,document_id,old['revision'],old['content'],old['state'],actor,reason,now()))
        db.execute('UPDATE easy17_documents SET revision=?,content=?,state=?,reviewer=?,approved_by=?,approved_at=?,author=? WHERE venue_id=? AND id=?',
                   (old['revision']+1,new_content,'Черновик','','','',actor,vid,document_id))
        db.execute('INSERT INTO easy17_doc_events(venue_id,document_id,action,actor,details,created_at) VALUES(?,?,?,?,?,?)',
                   (vid,document_id,'revise',actor,reason,now()))
        _log(db,vid,actor,'document_revised',{'id':document_id,'from_revision':old['revision'],'reason':reason})


def document_history(store,vid,document_id):
    _venue(store,vid);migrate17(store)
    return _rows(store,'SELECT * FROM easy17_doc_versions WHERE venue_id=? AND document_id=? ORDER BY revision DESC',
                 (vid,document_id))


def acknowledge_document(store,vid,document_id,employee,actor):
    _venue(store,vid);migrate17(store)
    employee=required(employee,'ФИО ознакомленного');actor=required(actor,'Кто внёс отметку')
    with store.connect() as db:
        r=db.execute('SELECT state FROM easy17_documents WHERE id=? AND venue_id=?',(document_id,vid)).fetchone()
        if not r or r['state']!='Утверждён':raise ValueError('Ознакомление регистрируется после утверждения документа')
        db.execute('INSERT INTO easy17_doc_events(venue_id,document_id,action,actor,details,created_at) VALUES(?,?,?,?,?,?)',
                   (vid,document_id,'acknowledge',actor,employee,now()))
        _log(db,vid,actor,'document_acknowledged',{'id':document_id,'employee':employee,'note':'Запись оператора, не ЭП'})


def link_incident_lot(store,vid,capa_id,lot_id,measures,actor):
    _venue(store,vid);migrate17(store);measures=required(measures,'Меры в отношении партии')
    with store.connect() as db:
        if not db.execute('SELECT 1 FROM easy16_capa WHERE id=? AND venue_id=?',(capa_id,vid)).fetchone():
            raise ValueError('Отклонение не найдено')
        if not db.execute('SELECT 1 FROM easy17_lots WHERE id=? AND venue_id=?',(lot_id,vid)).fetchone():
            raise ValueError('Партия не найдена')
        try:db.execute('INSERT INTO easy17_incident_lots(venue_id,capa_id,lot_id,measures,linked_at) VALUES(?,?,?,?,?)',
                       (vid,capa_id,lot_id,measures,now()))
        except sqlite3.IntegrityError as e:raise ValueError('Партия уже привязана к этому отклонению') from e
        _log(db,vid,actor,'incident_lot_linked',{'capa':capa_id,'lot':lot_id,'measures':measures})


def create_audit(store,vid,subject,auditor,held_on):
    _venue(store,vid);migrate17(store)
    subject=required(subject,'Тема аудита');auditor=required(auditor,'Аудитор')
    held_on=check_date(held_on,'Дата аудита')
    with store.connect() as db:
        c=db.execute('INSERT INTO easy17_audits(venue_id,subject,auditor,held_on,created_at) VALUES(?,?,?,?,?)',
                     (vid,subject,auditor,held_on,now()))
        _log(db,vid,auditor,'audit_created',{'id':c.lastrowid,'subject':subject})
        return c.lastrowid


def add_finding(store,vid,audit_id,requirement,observation,severity,owner,due_on=''):
    _venue(store,vid);migrate17(store)
    requirement=required(requirement,'Критерий проверки');observation=required(observation,'Фактическое замечание')
    owner=required(owner,'Ответственный')
    if severity not in ('Замечание','Несоответствие','Критичное'):raise ValueError('Выберите серьёзность')
    if due_on:due_on=check_date(due_on,'Срок устранения')
    with store.connect() as db:
        if not db.execute('SELECT 1 FROM easy17_audits WHERE id=? AND venue_id=?',(audit_id,vid)).fetchone():
            raise ValueError('Аудит не найден')
        c=db.execute('''INSERT INTO easy17_findings(venue_id,audit_id,requirement,observation,severity,owner,due_on,created_at)
            VALUES(?,?,?,?,?,?,?,?)''',(vid,audit_id,requirement,observation,severity,owner,due_on,now()))
        _log(db,vid,owner,'finding_created',{'id':c.lastrowid,'audit':audit_id,'severity':severity})
        return c.lastrowid


def list_audits(store,vid):
    _venue(store,vid);migrate17(store)
    return _rows(store,'SELECT * FROM easy17_audits WHERE venue_id=? ORDER BY id DESC',(vid,))


def list_findings(store,vid):
    _venue(store,vid);migrate17(store)
    return _rows(store,'SELECT * FROM easy17_findings WHERE venue_id=? ORDER BY id DESC',(vid,))


def global_search17(store,vid,query,limit=70):
    _venue(store,vid);migrate17(store);query=required(query,'Поисковый запрос').casefold()
    items=[]
    for table,label,field in [('easy17_lots','Партия','lot_code'),('easy17_journal_forms','Журнал','title'),
                              ('easy17_documents','Документ','title'),('easy17_suppliers','Поставщик','name'),
                              ('easy17_equipment_due','Оборудование/срок','event'),('easy17_audits','Аудит','subject'),
                              ('easy17_findings','Замечание','observation')]:
        rows=_rows(store,f'SELECT id,"{field}" AS label FROM "{table}" WHERE venue_id=? ORDER BY id DESC LIMIT 500',(vid,))
        items.extend({'type':label,'id':r['id'],'title':r['label']} for r in rows if query in str(r['label']).casefold())
    from mature16_core import search_all
    items.extend({'type':r.get('kind','Данные'),'id':r.get('id'),'title':str(r.get('title',''))}
                 for r in search_all(store,vid,query))
    return items[:limit]


def quality_diagnostics(store,vid):
    _venue(store,vid);migrate17(store)
    with store.connect() as db:
        check=db.execute('PRAGMA quick_check').fetchone()[0]
        foreign=db.execute('PRAGMA foreign_key_check').fetchall()
    integrity=trace_integrity(store,vid)
    lots=list_lots(store,vid);incomplete=[l['lot_code'] for l in lots if l['kind']=='Сырьё' and not l['supplier_id']]
    docs=list_documents(store,vid)
    return {'sqlite_ok':check=='ok','foreign_keys_ok':not foreign,'trace_ok':integrity['valid'],
            'unsigned_documents':sum(d['state']!='Утверждён' for d in docs),
            'lots':len(lots),'missing_supplier':incomplete,'unresolved_findings':sum(not f['resolved_at'] for f in list_findings(store,vid))}


def local_assistant17(query):
    """Auditable offline helper, no network API or purported professional validation."""
    q=str(query).strip().casefold()
    if not q:return 'Напишите вопрос или выберите интересующий раздел.'
    lookup=(('парт','В разделе «Партии» заполняются поставщик, номер партии, дата и количество. Связывайте фактически использованное сырьё с выпуском.'),
            ('журнал','В «Конструкторе журналов» создайте поля, укажите обязательные и ответственного. Пустые обязательные поля не сохраняются.'),
            ('аллерг','Отмечайте аллергены только по подтверждённой информации поставщика или проверенной рецептуре. Неоценённый состав — не значит отсутствие аллергена.'),
            ('поверк','Добавьте оборудование, дату следующей поверки/обслуживания и ответственного. Отмечайте выполнение только по документу.'),
            ('аудит','Внутренний аудит фиксирует реальные замечания, исполнителей и сроки. Автоматическая проверка не заменяет специалиста.'),
            ('подпис','Отметка ознакомления не является электронной подписью работника.'),
            ('ктт','Определение критических контрольных точек подтверждает специалист по ХАССП.'),
            ('ккт','ККТ выбирает специалист по анализу опасностей и утверждённому плану.'),
            ('докумен','Документ проходит стадии черновик → согласование → утверждение. Утверждение вводится ответственным вручную.'))
    return next((answer for key,answer in lookup if key in q),
                'Уточните задачу или откройте нужный раздел. Не заменяйте реальные проверки автоматическими предположениями.')


def upgrade_safety_backup(store,version_tag='1.7.0'):
    """Create an immutable pre-migration SQLite backup when first upgrading a DB.

    Important: called BEFORE migrate17, after normal Store initialization. On a
    fresh DB it is still safe. Fails closed if backup/integrity check fails.
    """
    folder=store.path.parent/'upgrade_backups'
    marker=folder/f'.migration_{version_tag.replace(".","_")}.done'
    if marker.exists():
        with store.connect() as db:
            table=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='easy17_meta'").fetchone()
            if table and db.execute("SELECT value FROM easy17_meta WHERE key='schema'").fetchone():
                return None
    folder.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    destination=folder/f'Before_{version_tag}_{stamp}.sqlite3'
    store.backup(destination)
    from contextlib import closing
    with closing(sqlite3.connect(destination)) as db:
        if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
            destination.unlink(missing_ok=True)
            raise RuntimeError('Резервная копия перед обновлением повреждена. Обновление остановлено.')
    return destination


def mark_upgrade_success(store,backup=None,version_tag='1.7.0'):
    # Called only after the GUI has successfully completed all migrations.
    folder=store.path.parent/'upgrade_backups';folder.mkdir(parents=True,exist_ok=True)
    marker=folder/f'.migration_{version_tag.replace(".","_")}.done'
    if not marker.exists():marker.write_text(str(backup or 'fresh database'),encoding='utf-8')


def legacy_required_columns(columns):
    """Conservative safety gate for built-in journals with no formal schema.

    We do not require handwritten signature columns in digital entries.
    Custom 1.7 journal forms instead rely on their explicit `required` flags.
    """
    required_fields=[]
    for key,label in columns:
        desc=str(label).casefold()
        if 'подпис' in desc or 'примечан' in desc or 'корректирующ' in desc:
            continue
        if any(token in desc for token in ('дата', 'фио работника', 'блюдо / изделие',
                                           'продукция и партия', 'оборудование', 'температура,',
                                           'температура продукта', 'результат / решение')):
            required_fields.append((key,label))
    return required_fields[:5]


def validate_legacy_entry(columns,data):
    for key,label in legacy_required_columns(columns):
        if not str(data.get(key,'')).strip():raise ValueError('Заполните обязательное поле журнала: '+label)
    return True

def audit_package17(store,vid,destination):
    """Verified local export with factual rows only and no compliance certificate."""
    from docx import Document
    _venue(store,vid);migrate17(store)
    destination=Path(destination)
    if destination.suffix.lower()!='.zip':raise ValueError('Выберите ZIP-архив')
    if destination.exists():raise FileExistsError('Файл уже существует; выберите другое имя')
    batches=list_lots(store,vid);forms=list_forms(store,vid)
    docs=list_documents(store,vid);audits=list_audits(store,vid)
    findings=list_findings(store,vid);equip=list_equipment_events(store,vid)
    integrity=trace_integrity(store,vid)
    def csv_bytes(rows):
        output=io.StringIO();cols=list(rows[0]) if rows else ['Нет записей']
        writer=csv.DictWriter(output,fieldnames=cols,delimiter=';')
        writer.writeheader()
        for row in rows:
            writer.writerow({k:("'"+str(v) if str(v).startswith(('=','+','-','@')) else v) for k,v in row.items()})
        return ('\ufeff'+output.getvalue()).encode('utf-8')
    doc=Document()
    doc.add_heading('Материалы для внутреннего аудита ХАССП',0)
    doc.add_paragraph('Предприятие: '+store.get_venue(vid)['venue_name'])
    doc.add_paragraph('Дата подготовки: '+date.today().isoformat())
    doc.add_paragraph('Только фактические записи, без автоматического заключения о соответствии.')
    for caption,rows in [('Партии',batches),('Журналы 1.7',forms),('Документы',docs),
                         ('Внутренние аудиты',audits),('Замечания',findings),('Оборудование',equip)]:
        doc.add_heading(caption,level=1);doc.add_paragraph('Записей: '+str(len(rows)))
    doc.add_paragraph('Целостность цепочки: '+('прошла проверку' if integrity['valid'] else 'ОБНАРУЖЕНО НАРУШЕНИЕ'))
    buf=io.BytesIO();doc.save(buf)
    meta={'version':'MoOLVa HACCP Easy 1.7.0','venue_id':vid,'created_at':now(),
          'trace_integrity':integrity,'disclaimer':'Материалы не являются заключением о соответствии.'}
    with zipfile.ZipFile(destination,'x',zipfile.ZIP_DEFLATED) as z:
        z.writestr('00_Информация.json',json.dumps(meta,ensure_ascii=False,indent=2))
        z.writestr('01_Партии.csv',csv_bytes(batches))
        z.writestr('02_Конструктор_журналов.csv',csv_bytes([{'id':f['id'],'title':f['title'],
                   'fields':json.dumps(f['fields'],ensure_ascii=False)} for f in forms]))
        z.writestr('03_Документы.csv',csv_bytes(docs))
        z.writestr('04_Аудиты.csv',csv_bytes(audits))
        z.writestr('05_Замечания.csv',csv_bytes(findings))
        z.writestr('06_Сроки_оборудования.csv',csv_bytes(equip))
        z.writestr('07_Внутренняя_проверка.docx',buf.getvalue())
    return destination
