"""MoOLVa 1.8: validated operational enhancements, offline help and reversible data.
No synthetic readings, signatures, regulation-compliance or untrusted auto-update.
"""
from __future__ import annotations
import csv, difflib, hashlib, io, json, math, os, sqlite3, subprocess, sys, zipfile
from datetime import date
from pathlib import Path
from contextlib import closing
from storage import now
from mature17_core import (migrate17,required,check_date,positive,validate_entry,list_forms,
    _normalise_schema,_venue,_log,create_form,list_lots,lot_allergens,KNOWN_ALLERGENS)

GUIDES = {
 'main': ('Ваш рабочий день', [
    ('1. Выберите предприятие', 'Проверьте название слева. Записи другого предприятия недоступны.'),
    ('2. Откройте журнал', 'Используйте «Журналы 5.0»; не копируйте прежние измерения.'),
    ('3. Запишите факт', 'Укажите дату, измеренное значение и сотрудника; поля со * обязательны.'),
    ('4. Проверьте отклонения', 'Отклонения требуют решения и повторной проверки ответственным.'),
    ('5. Сформируйте документ', 'Проверьте предпросмотр и сохраните Word/PDF.')]),
 'journal': ('Как заполнять журнал', [
    ('1. Выберите форму', 'Название, ответственный и колонки задаются специалистом.'),
    ('2. Заполните обязательные поля', 'Поля со * нельзя пропускать. Черновик не считается измерением.'),
    ('3. Проверьте условные поля', 'Некоторые поля становятся обязательными, например при ответе «Отклонение».'),
    ('4. Сохраните запись', 'Проверьте факты. Изменения фиксируются в истории; ошибку можно аннулировать.'),
    ('5. Печать', 'Предпросмотр → Word или PDF; не подставляйте фиктивную подпись.')]),
 'lot': ('Как вести партию', [
    ('1. Зарегистрируйте партию', 'Укажите номер, поставщика, дату и фактическое количество.'),
    ('2. Подтвердите движение', 'Списание и возврат фиксируются отдельными неизменяемыми строками.'),
    ('3. Назначьте рецепт', 'Ингредиенты и аллергены необходимо подтвердить по документам.'),
    ('4. Проверьте остаток', 'Остаток нельзя сделать отрицательным.'),
    ('5. При проблеме заблокируйте', 'Блокировка партии требует причины и решения специалиста.')]),
 'document': ('Как подготовить документ', [
    ('1. Откройте документ', 'Проверьте предприятие, название, дату и ответственного.'),
    ('2. Просмотрите страницы', 'Посмотрите перенос таблиц и строки для подписей.'),
    ('3. Выберите экспорт', 'Word можно редактировать. PDF предназначен для просмотра и печати.'),
    ('4. Согласуйте', 'Утверждение и реальная подпись — действия уполномоченного сотрудника.')]),
 'equipment': ('Как проверить оборудование', [
    ('1. Выберите прибор', 'Отсканируйте его QR или найдите в списке по инвентарному номеру.'),
    ('2. Выполните проверку', 'Запишите реально измеренное значение, если оно требуется.'),
    ('3. Закройте работу', 'Укажите дату и подтверждающее основание, а не автоматическую отметку.')]),
 'upgrade': ('Как безопасно обновить программу', [
    ('1. Сделайте резервную копию', 'Используйте «Настройки → Резервная копия».'),
    ('2. Проверьте издателя', 'Самоподписанный EXE не становится доверенным без установленного доверия на ПК.'),
    ('3. Проверьте контрольную сумму', 'Для локального файла можно сверить SHA-256 с независимо полученной суммой.'),
    ('4. Закройте программу', 'Для обновления используйте Setup.exe от проверенного источника.'),
    ('5. Проверьте предприятие', 'После установки проверьте сохранённые журналы и документы.')]),
}

FIELD_HINTS={
 'date':'Введите дату в формате ГГГГ-ММ-ДД. Запись не должна изображать проверку задним числом.',
 'number':'Введите фактически полученное число; запятая допустима. Никаких придуманных измерений.',
 'choice':'Выберите один из разрешённых вариантов, а не произвольный текст.',
 'text':'Укажите реальные сведения. Если * — поле обязательно при окончательном сохранении.',
 'condition':'Поле заполняется только при выбранном условии; условное обязательное поле нельзя пропустить.',
 'signature':'Запись ФИО не является электронной или собственноручной подписью.',
 'ccp':'ККТ и критические пределы подтверждаются группой ХАССП, не автоматически.'}

def field_hint(kind='text',name=''):
    return f'{name}: {FIELD_HINTS.get(kind,FIELD_HINTS["text"])}' if name else FIELD_HINTS.get(kind,FIELD_HINTS['text'])

def migrate18(store):
    if getattr(store,'_m18_ready',False):return
    migrate17(store)
    with store.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS easy18_form_rules (
          venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          form_id INTEGER NOT NULL REFERENCES easy17_journal_forms(id) ON DELETE CASCADE,
          rules_json TEXT NOT NULL, updated_at TEXT NOT NULL,
          PRIMARY KEY(venue_id,form_id));
        CREATE TABLE IF NOT EXISTS easy18_lot_movements (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          lot_id INTEGER NOT NULL REFERENCES easy17_lots(id) ON DELETE CASCADE,
          kind TEXT NOT NULL CHECK(kind IN ('Списание','Возврат')),
          quantity REAL NOT NULL CHECK(quantity>0), reason TEXT NOT NULL,
          actor TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS easy18_recipes (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          name TEXT NOT NULL,output_unit TEXT NOT NULL,procedure TEXT NOT NULL,
          created_by TEXT NOT NULL,created_at TEXT NOT NULL,
          UNIQUE(venue_id,name));
        CREATE TABLE IF NOT EXISTS easy18_recipe_ingredients (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          recipe_id INTEGER NOT NULL REFERENCES easy18_recipes(id) ON DELETE CASCADE,
          ingredient TEXT NOT NULL,quantity REAL NOT NULL CHECK(quantity>0),
          allergens_json TEXT NOT NULL, source TEXT NOT NULL,
          UNIQUE(venue_id,recipe_id,ingredient));
        CREATE TABLE IF NOT EXISTS easy18_help_progress (
          venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          topic TEXT NOT NULL,step INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL,PRIMARY KEY(venue_id,topic));
        CREATE TABLE IF NOT EXISTS easy18_bulk_imports (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          form_id INTEGER NOT NULL REFERENCES easy17_journal_forms(id) ON DELETE CASCADE,
          rows_saved INTEGER NOT NULL,actor TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_m18_lot_mov ON easy18_lot_movements(venue_id,lot_id,id);
        ''')
    store._m18_ready=True

def _rows(store,sql,p=()):
    with store.connect() as db:return [dict(x) for x in db.execute(sql,p)]

def set_form_rules(store,vid,form_id,rules,actor):
    _venue(store,vid);migrate18(store);actor=required(actor,'Кто меняет настройки')
    forms=[f for f in list_forms(store,vid) if f['id']==form_id]
    if not forms:raise ValueError('Журнал не найден на выбранном предприятии')
    fields={f['name']:f for f in forms[0]['fields']}
    if not isinstance(rules,dict):raise ValueError('Требуются правила в виде словаря')
    clean={}
    for name,rule in rules.items():
        if name not in fields or not isinstance(rule,dict):raise ValueError('Неизвестное поле или правило')
        cfg={}
        condition=rule.get('when')
        if condition:
            if not isinstance(condition,dict) or condition.get('field') not in fields:
                raise ValueError('Для условия выберите поле этой же формы')
            if condition['field']==name:raise ValueError('Поле не может зависеть от самого себя')
            cfg['when']={'field':condition['field'],'equals':str(condition.get('equals','')).strip()}
            if not cfg['when']['equals']:raise ValueError('Укажите значение условия')
        for bound in ('min','max'):
            if rule.get(bound) not in (None,''):
                if fields[name]['type']!='number':raise ValueError('Числовые пределы только для чисел')
                number=float(str(rule[bound]).replace(',','.'))
                if not math.isfinite(number):raise ValueError('Предел должен быть конечным числом')
                cfg[bound]=number
        if 'min' in cfg and 'max' in cfg and cfg['min']>cfg['max']:
            raise ValueError('Минимум больше максимума')
        cfg['required_when_visible']=bool(rule.get('required_when_visible',fields[name]['required']))
        cfg['hint']=str(rule.get('hint','')).strip()[:500]
        clean[name]=cfg
    with store.connect() as db:
        db.execute('''INSERT INTO easy18_form_rules(venue_id,form_id,rules_json,updated_at) VALUES(?,?,?,?)
        ON CONFLICT(venue_id,form_id) DO UPDATE SET rules_json=excluded.rules_json,updated_at=excluded.updated_at''',
        (vid,form_id,json.dumps(clean,ensure_ascii=False),now()))
        _log(db,vid,actor,'form_rules_changed',{'id':form_id,'fields':list(clean)})
    return clean

def get_form_rules(store,vid,form_id):
    _venue(store,vid);migrate18(store)
    if not _rows(store,'SELECT 1 FROM easy17_journal_forms WHERE venue_id=? AND id=?',(vid,form_id)):raise ValueError('Журнал не найден в предприятии')
    rows=_rows(store,'SELECT rules_json FROM easy18_form_rules WHERE venue_id=? AND form_id=?',(vid,form_id))
    return json.loads(rows[0]['rules_json']) if rows else {}

def validate18(fields,values,rules=None):
    fields=_normalise_schema(fields)
    rules=rules or {}
    if not isinstance(values,dict):raise ValueError('Внесите значения формы')
    out={}
    for f in fields:
        key=f['name'];val=str(values.get(key,'') if values.get(key) is not None else '').strip()
        rule=rules.get(key,{})
        when=rule.get('when')
        visible=not when or str(values.get(when['field'],'')).strip()==when['equals']
        if not visible:
            if val:raise ValueError('Поле «'+key+'» скрыто условием, значение вводить нельзя')
            out[key]='';continue
        if (rule.get('required_when_visible',f['required']) or f['required'] and not when) and not val:
            raise ValueError('Заполните обязательное поле «'+key+'»')
        if val:
            if f['type']=='date':val=check_date(val,key)
            elif f['type']=='number':
                try:
                    num=float(val.replace(',','.'))
                    if not math.isfinite(num):raise ValueError()
                except (ValueError,TypeError):raise ValueError('Нужно число: '+key)
                for bound in ('min','max'):
                    if bound in rule and (num<rule[bound] if bound=='min' else num>rule[bound]):
                        raise ValueError(f'Поле «{key}» выходит за заданный предел {bound}: {rule[bound]}')
                val=str(num)
            elif f['type']=='choice' and val not in f['options']:
                raise ValueError('Недопустимое значение поля «'+key+'»')
        out[key]=val
    return out

def append_entry18(store,vid,form_id,values,actor):
    _venue(store,vid);migrate18(store);actor=required(actor,'Ответственный')
    with store.connect() as db:
        row=db.execute('SELECT schema_json FROM easy17_journal_forms WHERE id=? AND venue_id=?',(form_id,vid)).fetchone()
        if not row:raise ValueError('Журнал не найден')
        rules=get_form_rules(store,vid,form_id)
        data=validate18(json.loads(row['schema_json']),values,rules)
        c=db.execute('INSERT INTO easy17_journal_entries(venue_id,form_id,values_json,recorded_by,recorded_at) VALUES (?,?,?,?,?)',
          (vid,form_id,json.dumps(data,ensure_ascii=False),actor,now()))
        _log(db,vid,actor,'journal18_entry',{'form':form_id,'entry_id':c.lastrowid})
        return c.lastrowid

def bulk_entries18(store,vid,form_id,rows,actor):
    """All-or-nothing; validation done before transaction; no invented defaults."""
    _venue(store,vid);migrate18(store);actor=required(actor,'Оператор импорта')
    if not isinstance(rows,list) or not 1<=len(rows)<=1000:raise ValueError('От 1 до 1000 строк за раз')
    with store.connect() as db:
        row=db.execute('SELECT schema_json FROM easy17_journal_forms WHERE id=? AND venue_id=?',(form_id,vid)).fetchone()
        if not row:raise ValueError('Журнал не найден')
        schema=json.loads(row['schema_json']);rules=get_form_rules(store,vid,form_id)
        prepared=[]
        for n,v in enumerate(rows,1):
            try:prepared.append(validate18(schema,v,rules))
            except ValueError as ex:raise ValueError(f'Строка {n}: {ex}') from ex
        for data in prepared:
            db.execute('INSERT INTO easy17_journal_entries(venue_id,form_id,values_json,recorded_by,recorded_at) VALUES(?,?,?,?,?)',
                (vid,form_id,json.dumps(data,ensure_ascii=False),actor,now()))
        db.execute('INSERT INTO easy18_bulk_imports(venue_id,form_id,rows_saved,actor,created_at) VALUES(?,?,?,?,?)',
                   (vid,form_id,len(prepared),actor,now()))
        _log(db,vid,actor,'journal18_bulk',{'form':form_id,'rows':len(prepared)})
    return len(prepared)

def preview_csv18(path,expected_headers=None,max_rows=1000):
    path=Path(path)
    if path.suffix.lower()!='.csv':raise ValueError('Для таблиц выберите CSV UTF-8')
    if path.stat().st_size>3_000_000:raise ValueError('CSV слишком большой')
    with path.open(encoding='utf-8-sig',newline='') as stream:
        content=stream.read(2048);stream.seek(0)
        try:delimiter=csv.Sniffer().sniff(content,delimiters=';,\t').delimiter
        except csv.Error:delimiter=';'
        reader=csv.DictReader(stream,delimiter=delimiter)
        if not reader.fieldnames:raise ValueError('В CSV нет заголовков колонок')
        headers=[str(h).strip() for h in reader.fieldnames]
        if len(headers)!=len(set(headers)) or not all(headers):raise ValueError('Проверьте уникальные названия колонок')
        if expected_headers and set(headers)!=set(expected_headers):
            raise ValueError('Колонки CSV не совпадают с журналом. Ожидаются: '+', '.join(expected_headers))
        rows=[]
        for n,row in enumerate(reader,1):
            if n>max_rows:raise ValueError('Максимум '+str(max_rows)+' строк')
            if None in row:raise ValueError('Лишние значения в строке '+str(n))
            rows.append({k.strip():v or '' for k,v in row.items()})
    return rows

def inventory18(store,vid,lot_id):
    _venue(store,vid);migrate18(store)
    with store.connect() as db:
        lot=db.execute('SELECT * FROM easy17_lots WHERE venue_id=? AND id=?',(vid,lot_id)).fetchone()
        if not lot:raise ValueError('Партия не найдена')
        used=db.execute('SELECT COALESCE(SUM(quantity),0) FROM easy17_lot_inputs WHERE venue_id=? AND input_lot_id=?',(vid,lot_id)).fetchone()[0]
        ledger=db.execute("SELECT COALESCE(SUM(CASE WHEN kind='Возврат' THEN quantity ELSE -quantity END),0) FROM easy18_lot_movements WHERE venue_id=? AND lot_id=?",(vid,lot_id)).fetchone()[0]
    return {'lot':dict(lot),'used':used,'movements':ledger,'available':round(lot['quantity']-used+ledger,6)}

def move_lot18(store,vid,lot_id,kind,quantity,reason,actor):
    _venue(store,vid);migrate18(store)
    if kind not in ('Списание','Возврат'):raise ValueError('Вид операции: Списание или Возврат')
    amount=positive(quantity,'Количество');reason=required(reason,'Основание');actor=required(actor,'Кто провёл операцию')
    with store.connect() as db:
        lot=db.execute('SELECT * FROM easy17_lots WHERE id=? AND venue_id=?',(lot_id,vid)).fetchone()
        if not lot:raise ValueError('Партия не найдена')
        if lot['status']!='В обращении':raise ValueError('Операции с заблокированной партией запрещены')
        used=db.execute('SELECT COALESCE(SUM(quantity),0) FROM easy17_lot_inputs WHERE input_lot_id=? AND venue_id=?',(lot_id,vid)).fetchone()[0]
        ops=db.execute("SELECT COALESCE(SUM(CASE WHEN kind='Возврат' THEN quantity ELSE -quantity END),0) FROM easy18_lot_movements WHERE lot_id=? AND venue_id=?",(lot_id,vid)).fetchone()[0]
        # Returns may only reverse previously written-off quantities; not materials already consumed.
        written=db.execute("SELECT COALESCE(SUM(CASE WHEN kind='Списание' THEN quantity ELSE -quantity END),0) FROM easy18_lot_movements WHERE lot_id=? AND venue_id=?",(lot_id,vid)).fetchone()[0]
        if kind=='Списание' and amount>lot['quantity']-used+ops+1e-8:raise ValueError('Недостаточно остатка для списания')
        if kind=='Возврат' and amount>written+1e-8:raise ValueError('Возврат не может превышать ранее списанное количество')
        c=db.execute('INSERT INTO easy18_lot_movements(venue_id,lot_id,kind,quantity,reason,actor,created_at) VALUES(?,?,?,?,?,?,?)',
                     (vid,lot_id,kind,amount,reason,actor,now()))
        _log(db,vid,actor,'lot_movement18',{'id':c.lastrowid,'lot':lot_id,'kind':kind,'quantity':amount})
        return c.lastrowid

def list_movements18(store,vid,lot_id):
    _venue(store,vid);migrate18(store)
    return _rows(store,'SELECT * FROM easy18_lot_movements WHERE venue_id=? AND lot_id=? ORDER BY id DESC',(vid,lot_id))

def create_recipe18(store,vid,name,unit,procedure,actor):
    _venue(store,vid);migrate18(store)
    name=required(name,'Название блюда');unit=required(unit,'Единица');procedure=required(procedure,'Этапы технологии')
    actor=required(actor,'Разработчик')
    with store.connect() as db:
        try:
            c=db.execute('INSERT INTO easy18_recipes(venue_id,name,output_unit,procedure,created_by,created_at) VALUES(?,?,?,?,?,?)',
                        (vid,name,unit,procedure,actor,now()))
        except sqlite3.IntegrityError as ex:raise ValueError('Такой рецепт уже есть') from ex
        _log(db,vid,actor,'recipe18_created',{'id':c.lastrowid,'name':name})
        return c.lastrowid

def add_ingredient18(store,vid,recipe_id,name,quantity,allergens,source,actor):
    _venue(store,vid);migrate18(store);name=required(name,'Ингредиент')
    quantity=positive(quantity,'Количество');source=required(source,'Основание списка аллергенов')
    actor=required(actor,'Ответственный')
    if not isinstance(allergens,list) or any(a not in KNOWN_ALLERGENS for a in allergens):
        raise ValueError('Укажите оценённые аллергены из справочника')
    with store.connect() as db:
        if not db.execute('SELECT id FROM easy18_recipes WHERE venue_id=? AND id=?',(vid,recipe_id)).fetchone():
            raise ValueError('Рецепт не найден в предприятии')
        try:
            c=db.execute('INSERT INTO easy18_recipe_ingredients(venue_id,recipe_id,ingredient,quantity,allergens_json,source) VALUES(?,?,?,?,?,?)',
                         (vid,recipe_id,name,quantity,json.dumps(allergens,ensure_ascii=False),source))
        except sqlite3.IntegrityError as ex:raise ValueError('Ингредиент уже добавлен') from ex
        _log(db,vid,actor,'recipe18_ingredient',{'recipe':recipe_id,'ingredient':name})
        return c.lastrowid

def list_recipes18(store,vid):
    _venue(store,vid);migrate18(store)
    return _rows(store,'SELECT * FROM easy18_recipes WHERE venue_id=? ORDER BY id DESC',(vid,))

def recipe_details18(store,vid,recipe_id):
    _venue(store,vid);migrate18(store)
    result=_rows(store,'SELECT * FROM easy18_recipes WHERE venue_id=? AND id=?',(vid,recipe_id))
    if not result:raise ValueError('Рецепт не найден')
    ingredients=_rows(store,'SELECT * FROM easy18_recipe_ingredients WHERE venue_id=? AND recipe_id=? ORDER BY id',(vid,recipe_id))
    union=set()
    for row in ingredients:
        row['allergens']=json.loads(row['allergens_json']);union.update(row['allergens'])
    return {'recipe':result[0],'ingredients':ingredients,'allergens':sorted(union),
            'warning':'Сведения об аллергенах требуют подтверждения по спецификациям сырья и фактической технологии'}

def search18(store,vid,query,limit=80):
    _venue(store,vid);migrate18(store)
    query=required(query,'Поисковый запрос').casefold();result=[]
    tables=[('easy17_lots',('lot_code','name'),'Партия'),('easy17_journal_forms',('title',),'Журнал'),
        ('easy17_documents',('title','content'),'Документ'),('easy16_assets',('display_name',),'Оборудование'),
        ('easy18_recipes',('name','procedure'),'Рецепт')]
    for tab,keys,tag in tables:
        for row in _rows(store,f'SELECT id,{",".join(keys)} FROM {tab} WHERE venue_id=? ORDER BY id DESC LIMIT 400',(vid,)):
            label=' · '.join(str(row[k])[:140] for k in keys)
            norm=label.casefold()
            if query in norm or any(difflib.SequenceMatcher(None,query,k.casefold()).ratio()>.75 for k in [str(row[keys[0]])]):
                result.append({'type':tag,'id':row['id'],'label':label})
                if len(result)>=limit:return result
    return result

def guide_progress18(store,vid,topic,step=None):
    _venue(store,vid);migrate18(store)
    if topic not in GUIDES:raise ValueError('Тема инструкций не найдена')
    maxstep=len(GUIDES[topic][1]);record=_rows(store,'SELECT step FROM easy18_help_progress WHERE venue_id=? AND topic=?',(vid,topic))
    if step is not None:
        if type(step) is not int or step<0 or step>maxstep:raise ValueError('Неверный шаг помощника')
        with store.connect() as db:
            db.execute('INSERT INTO easy18_help_progress(venue_id,topic,step,updated_at) VALUES(?,?,?,?) ON CONFLICT(venue_id,topic) DO UPDATE SET step=excluded.step,updated_at=excluded.updated_at',(vid,topic,step,now()))
        return step
    return record[0]['step'] if record else 0

def diagnostics18(store,vid):
    _venue(store,vid);migrate18(store)
    with closing(sqlite3.connect(store.path)) as db:
        ok=db.execute('PRAGMA quick_check').fetchone()[0]
        foreign=db.execute('PRAGMA foreign_key_check').fetchall()
    from mature16_core import trace_integrity
    return {'sqlite':ok,'foreign_keys':len(foreign),'audit_chain':trace_integrity(store,vid),
            'journal_forms':len(list_forms(store,vid)),'recipes':len(list_recipes18(store,vid)),
            'note':'Диагностика техническая; она не подтверждает соблюдение ХАССП.'}

def export_diagnostics18(store,vid,destination):
    result=diagnostics18(store,vid);destination=Path(destination)
    if destination.exists():raise FileExistsError('Укажите новый файл')
    if destination.suffix.lower()!='.zip':raise ValueError('Выберите ZIP')
    with zipfile.ZipFile(destination,'x',zipfile.ZIP_DEFLATED) as z:
        z.writestr('quality.json',json.dumps(result,ensure_ascii=False,indent=2))
        z.writestr('README.txt','Без персональных данных и содержимого документов. Проверьте файл перед передачей.')
    return destination

def verify_local_installer18(path,expected_sha256):
    """Offline SHA-256 comparison only, NOT publisher authentication."""
    path=Path(path)
    if not path.is_file() or path.suffix.lower()!='.exe':raise ValueError('Выберите Setup.exe')
    if not isinstance(expected_sha256,str) or len(expected_sha256)!=64 or any(c not in '0123456789abcdefABCDEF' for c in expected_sha256):
        raise ValueError('Укажите полную контрольную сумму SHA-256 из доверенного источника')
    sha=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):sha.update(chunk)
    if sha.hexdigest().lower()!=expected_sha256.lower():raise ValueError('Контрольная сумма файла не совпала')
    return {'path':str(path),'sha256':sha.hexdigest(),'warning':'SHA-256 проверяет целостность, но не подлинность издателя. Перед запуском проверьте цифровую подпись Windows.'}

def export_document18(store,vid,document_id,destination,kind='docx'):
    from mature17_core import list_documents
    _venue(store,vid);migrate18(store)
    rows=[x for x in list_documents(store,vid) if x['id']==document_id]
    if not rows:raise ValueError('Документ не найден')
    doc=rows[0];dest=Path(destination)
    if dest.exists():raise FileExistsError('Файл уже существует')
    if kind not in ('docx','pdf') or dest.suffix.lower()!='.'+kind:raise ValueError('Выберите DOCX или PDF')
    if kind=='docx':
        from docx import Document
        from docx.shared import Cm,Pt
        d=Document();s=d.sections[0];s.top_margin=Cm(1.9);s.bottom_margin=Cm(1.9)
        d.add_heading(doc['title'],0)
        d.add_paragraph('Предприятие: '+store.get_venue(vid)['venue_name'])
        d.add_paragraph(f"Редакция: {doc['revision']} · Статус: {doc['state']}")
        for line in doc['content'].splitlines():d.add_paragraph(line)
        d.add_paragraph('Разработчик: '+doc['author'])
        if doc['approved_by']:d.add_paragraph('Утверждено: '+doc['approved_by']+' · '+doc['approved_at'])
        d.add_paragraph('Подпись: ________________________   Дата: __________________')
        s.footer.paragraphs[0].text='MoOLVa ХАССП Easy · копия из локальной базы'
        d.save(dest)
    else:
        from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,KeepTogether
        from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
        from reportlab.lib.enums import TA_LEFT
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from xml.sax.saxutils import escape
        fonts=[Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'/'arial.ttf',Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')]
        font=next((str(x) for x in fonts if x.exists()),None)
        if not font:raise RuntimeError('Не найден шрифт кириллицы для PDF')
        font_name='MoOLVaRussian'
        if font_name not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(font_name,font))
        style=ParagraphStyle('moolva18',fontName=font_name,fontSize=10,leading=15,spaceAfter=5,wordWrap='CJK')
        big=ParagraphStyle('moolva18_title',parent=style,fontSize=15,leading=20,spaceAfter=15)
        story=[Paragraph(escape(doc['title']),big),Paragraph('Предприятие: '+escape(store.get_venue(vid)['venue_name']),style),
               Paragraph('Редакция: '+str(doc['revision'])+' · '+escape(doc['state']),style),Spacer(1,13)]
        for line in doc['content'].splitlines():story.append(Paragraph(escape(line or ' '),style))
        story.append(Spacer(1,15));story.append(Paragraph('Разработчик: '+escape(doc['author']),style))
        story.append(Paragraph('Подпись: _________________________    Дата: __________',style))
        pdf=SimpleDocTemplate(str(dest),pagesize=A4,leftMargin=40,rightMargin=40,topMargin=48,bottomMargin=48)
        def footer(canvas,d):
            canvas.setFont(font_name,8)
            canvas.drawString(40,24,'MoOLVa ХАССП Easy · копия из локальной базы')
            canvas.drawRightString(A4[0]-40,24,str(d.page))
        pdf.build(story,onFirstPage=footer,onLaterPages=footer)
    with store.connect() as db:_log(db,vid,'Локальный пользователь','document18_export',{'document':document_id,'format':kind})
    return dest


def batch_export_documents18(store,vid,destination):
    """Create actual Word/PDF files for each current document in one verified ZIP."""
    from mature17_core import list_documents
    from tempfile import TemporaryDirectory
    _venue(store,vid);migrate18(store)
    destination=Path(destination)
    if destination.suffix.lower()!='.zip':raise ValueError('Архив должен быть ZIP')
    if destination.exists():raise FileExistsError('Архив уже существует')
    documents=list_documents(store,vid)
    if not documents:raise ValueError('Нет документов для комплекта')
    with TemporaryDirectory() as temp:
        folder=Path(temp)
        names=[]
        for row in documents:
            for kind in ('docx','pdf'):
                path=folder/f"Документ_{row['id']}_редакция_{row['revision']}.{kind}"
                export_document18(store,vid,row['id'],path,kind)
                names.append(path)
        with zipfile.ZipFile(destination,'x',zipfile.ZIP_DEFLATED) as z:
            for path in names:z.write(path,arcname=path.name)
            z.writestr('README.txt','Комплект текущих редакций. Прошлые редакции сохраняются в базе; запись не подтверждает соответствие требованиям ХАССП.')
    return destination
