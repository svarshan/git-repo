"""Version 1.8 regression suite: real records, strict validation and novice guidance."""
import csv, hashlib, json, sqlite3, unittest, zipfile
from contextlib import closing
from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
from docx import Document
from easy_core import init_store,make_venue
from mature17_core import create_form,create_supplier,create_lot,consume_lot,create_document,list_entries
from mature18_core import *

class Professional18Tests(unittest.TestCase):
    def setUp(self):
        d=TemporaryDirectory();self.addCleanup(d.cleanup)
        self.root=Path(d.name);self.store=init_store(self.root/'db.sqlite3')
        self.vid=make_venue(self.store);self.other=make_venue(self.store)
        migrate18(self.store)
        self.fields=[{'name':'Дата','type':'date','required':True},
                     {'name':'Измерение','type':'number','required':True},
                     {'name':'Результат','type':'choice','required':True,'options':['Норма','Отклонение']},
                     {'name':'Причина','type':'text','required':False}]
        self.form=create_form(self.store,self.vid,'Журнал испытаний',self.fields,'Технолог')
        self.val={'Дата':date.today().isoformat(),'Измерение':'4,5','Результат':'Норма','Причина':''}

    def test_upgrade_preserves_legacy_rows_and_is_idempotent(self):
        self.store.add_record(self.vid,'old',{'value':'Не удалять'})
        for _ in range(3):migrate18(self.store)
        self.assertEqual(self.store.list_records(self.vid,'old')[0]['data']['value'],'Не удалять')
        with self.store.connect() as db:
            self.assertEqual(db.execute('PRAGMA foreign_key_check').fetchall(),[])

    def test_conditional_required_field_and_live_measurement(self):
        set_form_rules(self.store,self.vid,self.form,{'Причина':{'when':{'field':'Результат','equals':'Отклонение'},'required_when_visible':True}},'Технолог')
        self.assertEqual(get_form_rules(self.store,self.vid,self.form)['Причина']['when']['equals'],'Отклонение')
        append_entry18(self.store,self.vid,self.form,self.val,'Оператор')
        bad=dict(self.val,Результат='Отклонение')
        with self.assertRaises(ValueError):append_entry18(self.store,self.vid,self.form,bad,'Оператор')
        with self.assertRaises(ValueError):append_entry18(self.store,self.vid,self.form,dict(self.val,Причина='Неверное скрытое значение'),'Оператор')
        self.assertEqual(append_entry18(self.store,self.vid,self.form,dict(bad,Причина='Сбой прибора'),'Оператор'),2)

    def test_number_bounds_and_nan_rejection(self):
        set_form_rules(self.store,self.vid,self.form,{'Измерение':{'min':0,'max':6}},'Технолог')
        for value in ['-1','nan','inf','нет','7']:
            with self.subTest(v=value),self.assertRaises(ValueError):append_entry18(self.store,self.vid,self.form,dict(self.val,Измерение=value),'Оператор')
        append_entry18(self.store,self.vid,self.form,self.val,'Оператор')
        self.assertEqual(list_entries(self.store,self.vid,self.form)[0]['values']['Измерение'],'4.5')

    def test_rules_reject_cross_venue(self):
        with self.assertRaises(ValueError):set_form_rules(self.store,self.other,self.form,{},'Админ')
        with self.assertRaises(ValueError):get_form_rules(self.store,self.other,999)

    def test_bulk_atomic_and_no_fake_default(self):
        with self.assertRaisesRegex(ValueError,'Строка 2'):
            bulk_entries18(self.store,self.vid,self.form,[self.val,dict(self.val,Дата='НЕДОПУСТИМО')],'Оператор')
        self.assertEqual(list_entries(self.store,self.vid,self.form),[])
        self.assertEqual(bulk_entries18(self.store,self.vid,self.form,[self.val,dict(self.val,Измерение='4')],'Оператор'),2)
        self.assertEqual(len(list_entries(self.store,self.vid,self.form)),2)

    def test_csv_preview_and_header_mapping(self):
        f=self.root/'test.csv'
        f.write_text('Дата;Измерение;Результат;Причина\n2026-10-09;4,2;Норма;\n',encoding='utf-8-sig')
        rows=preview_csv18(f,list(self.val))
        self.assertEqual(rows[0]['Измерение'],'4,2')
        with self.assertRaises(ValueError):preview_csv18(f,['ЗАГОЛОВОК'])
        g=self.root/'bad.csv';g.write_text('Дата;Дата\n1;2\n',encoding='utf-8')
        with self.assertRaises(ValueError):preview_csv18(g)

    def create_lot(self):
        supplier=create_supplier(self.store,self.vid,'Поставщик','Договор','Технолог')
        raw=create_lot(self.store,self.vid,'RAW','Сырьё','Сырье',date.today().isoformat(),10,'кг','Технолог',supplier)
        final=create_lot(self.store,self.vid,'FINAL','Готовая продукция','Блюдо',date.today().isoformat(),3,'кг','Технолог')
        return raw,final

    def test_lot_writeoff_consumption_and_return(self):
        raw,final=self.create_lot()
        move_lot18(self.store,self.vid,raw,'Списание',4,'Порча','Технолог')
        with self.assertRaises(ValueError):consume_lot(self.store,self.vid,final,raw,7,'Пекарь')
        consume_lot(self.store,self.vid,final,raw,5,'Пекарь')
        self.assertEqual(inventory18(self.store,self.vid,raw)['available'],1)
        with self.assertRaises(ValueError):move_lot18(self.store,self.vid,raw,'Списание',2,'Порча','Технолог')
        with self.assertRaises(ValueError):move_lot18(self.store,self.vid,raw,'Возврат',5,'Возврат','Технолог')
        move_lot18(self.store,self.vid,raw,'Возврат',3,'Ошибка списания','Технолог')
        self.assertEqual(inventory18(self.store,self.vid,raw)['available'],4)
        self.assertEqual(len(list_movements18(self.store,self.vid,raw)),2)

    def test_lot_cross_venue_blocks_adjustment(self):
        raw,final=self.create_lot()
        with self.assertRaises(ValueError):move_lot18(self.store,self.other,raw,'Списание',1,'Списание','Другой')
        with self.assertRaises(ValueError):inventory18(self.store,self.other,raw)

    def test_recipe_requires_evidence_and_allergen_lookup(self):
        r=create_recipe18(self.store,self.vid,'Омлет','порция','Перемешать и приготовить','Технолог')
        add_ingredient18(self.store,self.vid,r,'Яйца',2,['Яйца'],'Декларация №1','Технолог')
        item=recipe_details18(self.store,self.vid,r)
        self.assertEqual(item['allergens'],['Яйца'])
        with self.assertRaises(ValueError):add_ingredient18(self.store,self.vid,r,'Мука',1,['Это не аллерген'],'Декларация','Технолог')
        with self.assertRaises(ValueError):add_ingredient18(self.store,self.other,r,'Яйца',1,['Яйца'],'Документ','Технолог')

    def test_help_progress_and_field_tips(self):
        self.assertTrue(GUIDES['journal'][1]);self.assertIn('фактически',field_hint('number').lower())
        self.assertEqual(guide_progress18(self.store,self.vid,'journal'),0)
        guide_progress18(self.store,self.vid,'journal',3)
        self.assertEqual(guide_progress18(self.store,self.vid,'journal'),3)
        self.assertEqual(guide_progress18(self.store,self.other,'journal'),0)
        with self.assertRaises(ValueError):guide_progress18(self.store,self.vid,'journal',300)

    def test_search_is_scoped_to_one_enterprise(self):
        create_recipe18(self.store,self.vid,'Вишнёвый пирог','кг','Выпечь','Пекарь')
        self.assertTrue(any(x['type']=='Рецепт' for x in search18(self.store,self.vid,'вишнёвый')))
        self.assertFalse(search18(self.store,self.other,'вишнёвый'))

    def test_diagnostics_and_report_without_user_data(self):
        report=diagnostics18(self.store,self.vid)
        self.assertEqual(report['sqlite'],'ok');self.assertEqual(report['foreign_keys'],0)
        archive=export_diagnostics18(self.store,self.vid,self.root/'diagnostic.zip')
        with zipfile.ZipFile(archive) as z:
            self.assertEqual(z.namelist(),['quality.json','README.txt'])
            self.assertNotIn('Технолог',z.read('quality.json').decode())

    def test_update_checksum_and_not_unsigned_trust(self):
        p=self.root/'update.exe';p.write_bytes(b'sample-unsigned-file')
        sha=hashlib.sha256(p.read_bytes()).hexdigest()
        result=verify_local_installer18(p,sha)
        self.assertIn('не подлинность',result['warning'])
        with self.assertRaises(ValueError):verify_local_installer18(p,'f'*64)

    def test_documents_pdf_docx_and_cross_venue(self):
        doc=create_document(self.store,self.vid,'Программа контроля','Русские данные и отчёты\nНовая страница', 'Технолог')
        word=export_document18(self.store,self.vid,doc,self.root/'first.docx','docx')
        pdf=export_document18(self.store,self.vid,doc,self.root/'first.pdf','pdf')
        self.assertIn('Русские данные', '\n'.join(x.text for x in Document(word).paragraphs))
        self.assertTrue(pdf.read_bytes().startswith(b'%PDF-'))
        with self.assertRaises(ValueError):export_document18(self.store,self.other,doc,self.root/'second.pdf','pdf')

    def test_batch_document_export_contains_both_formats(self):
        doc=create_document(self.store,self.vid,'Журнал отчётности','Реальная документация','Технолог')
        zip_path=batch_export_documents18(self.store,self.vid,self.root/'export.zip')
        with zipfile.ZipFile(zip_path) as z:
            names=z.namelist()
            self.assertTrue(any(x.endswith('.docx') for x in names))
            self.assertTrue(any(x.endswith('.pdf') for x in names))
            self.assertIn('README.txt',names)

    def test_all_help_topics_and_version_contract(self):
        self.assertEqual(len(GUIDES),6)
        self.assertTrue((Path(__file__).resolve().parents[1]/'LICENSE_RU.txt').is_file())
        from mature18_ui import Mature18Mixin
        self.assertTrue(callable(Mature18Mixin.show_training18))
        self.assertEqual((Path(__file__).resolve().parents[1]/'.moolva_easy_version').read_text().strip(),'1.8.0')

if __name__=='__main__':unittest.main()
