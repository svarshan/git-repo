"""Локальное хранилище без сетевых запросов. Изменения фиксируются в аудите."""
from pathlib import Path
from contextlib import contextmanager, closing
from datetime import datetime
import json
import os
import sqlite3
import shutil
from catalog import TYPES, defaults_for_type


def app_data_dir():
    if os.name == 'nt':
        root = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local')))
    else:
        root = Path(os.environ.get('XDG_DATA_HOME', str(Path.home() / '.local' / 'share')))
    return root / 'MoOLVaHACCPStudio'


def now():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def _parse(text, fallback):
    try:
        result = json.loads(text)
        return result if isinstance(result, type(fallback)) else fallback
    except (TypeError, ValueError):
        return fallback


class Store:
    def __init__(self, path=None):
        self.path = Path(path) if path else app_data_dir() / 'haccp.sqlite3'
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    @contextmanager
    def connect(self):
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        connection.execute('PRAGMA foreign_keys=ON')
        connection.execute('PRAGMA busy_timeout=5000')
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _init(self):
        with self.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS venues (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                legal_name TEXT NOT NULL DEFAULT '', venue_name TEXT NOT NULL DEFAULT '',
                kind TEXT NOT NULL DEFAULT 'Столовая', inn TEXT NOT NULL DEFAULT '',
                ogrn TEXT NOT NULL DEFAULT '', legal_address TEXT NOT NULL DEFAULT '',
                address TEXT NOT NULL DEFAULT '', director TEXT NOT NULL DEFAULT '',
                responsible TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '',
                email TEXT NOT NULL DEFAULT '', extra TEXT NOT NULL DEFAULT '{}',
                flags TEXT NOT NULL DEFAULT '{}', updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS journal_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                venue_id INTEGER NOT NULL REFERENCES venues(id),
                template_code TEXT NOT NULL,
                data TEXT NOT NULL, created_at TEXT NOT NULL,
                voided_at TEXT, void_reason TEXT);
            CREATE INDEX IF NOT EXISTS idx_records ON journal_records(venue_id, template_code, id);
            CREATE TABLE IF NOT EXISTS manual_selection (
                venue_id INTEGER NOT NULL REFERENCES venues(id),
                template_code TEXT NOT NULL, selected INTEGER NOT NULL,
                PRIMARY KEY(venue_id, template_code));
            CREATE TABLE IF NOT EXISTS column_labels (
                venue_id INTEGER NOT NULL REFERENCES venues(id),
                template_code TEXT NOT NULL, labels_json TEXT NOT NULL,
                PRIMARY KEY(venue_id, template_code));
            CREATE TABLE IF NOT EXISTS custom_templates (
                code TEXT PRIMARY KEY, title TEXT NOT NULL,
                group_name TEXT NOT NULL DEFAULT 'Мои журналы',
                columns_json TEXT NOT NULL, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, venue_id INTEGER,
                event TEXT NOT NULL, details TEXT NOT NULL,
                created_at TEXT NOT NULL);
            ''')

    def _audit(self, db, venue_id, event, details):
        db.execute('INSERT INTO audit_events(venue_id,event,details,created_at) VALUES (?,?,?,?)',
                   (venue_id, event, json.dumps(details, ensure_ascii=False), now()))

    def list_venues(self):
        with self.connect() as db:
            return [dict(x) for x in db.execute('SELECT id, venue_name, legal_name, kind FROM venues ORDER BY id')]

    def get_venue(self, venue_id):
        with self.connect() as db:
            item = db.execute('SELECT * FROM venues WHERE id=?', (venue_id,)).fetchone()
            if item is None:
                return None
            result = dict(item)
            result['flags'] = _parse(result['flags'], {})
            result['extra'] = _parse(result['extra'], {})
            return result

    def create_venue(self, kind='Столовая'):
        if kind not in TYPES:
            kind = 'Другое'
        venue_name = 'Новое заведение'
        with self.connect() as db:
            cur = db.execute('''INSERT INTO venues(venue_name,kind,flags,updated_at) VALUES(?,?,?,?)''',
                             (venue_name, kind, json.dumps(defaults_for_type(kind)), now()))
            venue_id = cur.lastrowid
            self._audit(db, venue_id, 'venue_created', {'kind': kind})
            return venue_id

    def delete_venue(self, venue_id, make_backup=True):
        """Permanently delete one enterprise and all data scoped to it.

        A transactional full-database backup is created immediately before deletion
        by default so an accidental deletion can still be recovered manually.
        Shared custom journal templates are intentionally retained.
        """
        current = self.get_venue(venue_id)
        if not current:
            raise ValueError('Предприятие не найдено')

        backup_path = None
        if make_backup:
            stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            backup_path = self.path.parent / 'delete_backups' / f'before_delete_{venue_id}_{stamp}.sqlite3'
            self.backup(backup_path)

        template_files = []
        with self.connect() as db:
            # Imported Word templates have external files that are removed after
            # the database transaction commits. Keep the names first.
            table_names = {row['name'] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if 'word_templates' in table_names:
                template_files = [r['file_name'] for r in db.execute(
                    'SELECT file_name FROM word_templates WHERE venue_id=?', (venue_id,))]

            # Legacy HACCP event rows are linked by plan_id rather than venue_id.
            if 'haccp_plan_events' in table_names and 'haccp_plans' in table_names:
                db.execute('DELETE FROM haccp_plan_events WHERE plan_id IN (SELECT id FROM haccp_plans WHERE venue_id=?)',
                           (venue_id,))

            # Child tables that also reference employees must be cleared first.
            ordered = (
                'document_acknowledgements', 'document_staff', 'document_staff_options',
                'employees', 'word_templates', 'studio_layouts', 'control_tasks',
                'doc_reviews', 'journal_records', 'manual_selection', 'column_labels',
                'haccp_plans', 'audit_events',
            )
            handled = set()
            for table in ordered:
                if table in table_names:
                    cols = {r['name'] for r in db.execute(f'PRAGMA table_info("{table}")')}
                    if 'venue_id' in cols:
                        db.execute(f'DELETE FROM "{table}" WHERE venue_id=?', (venue_id,))
                        handled.add(table)

            # Future-proofing: clear any newer table explicitly scoped by venue_id.
            # Foreign-key checks are deferred until commit; all scoped rows are gone
            # before the enterprise row itself is deleted.
            db.execute('PRAGMA defer_foreign_keys=ON')
            for table in sorted(table_names - handled - {'venues', 'custom_templates', 'sqlite_sequence'}):
                safe = table.replace('"', '""')
                cols = {r['name'] for r in db.execute(f'PRAGMA table_info("{safe}")')}
                if 'venue_id' in cols:
                    db.execute(f'DELETE FROM "{safe}" WHERE venue_id=?', (venue_id,))

            deleted = db.execute('DELETE FROM venues WHERE id=?', (venue_id,))
            if deleted.rowcount != 1:
                raise ValueError('Не удалось удалить предприятие')
            self._audit(db, None, 'venue_deleted', {
                'venue_id': venue_id,
                'venue_name': current.get('venue_name', ''),
                'backup': str(backup_path) if backup_path else '',
            })

        for file_name in template_files:
            try:
                (self.path.parent / 'word_templates' / file_name).unlink(missing_ok=True)
            except OSError:
                # Database deletion must not be rolled back because a stale copy of
                # an imported file could not be removed. It is no longer referenced.
                pass
        return backup_path

    def update_venue(self, venue_id, data):
        editable = ('legal_name', 'venue_name', 'kind', 'inn', 'ogrn', 'legal_address',
                    'address', 'director', 'responsible', 'phone', 'email', 'extra', 'flags')
        previous = self.get_venue(venue_id)
        if not previous:
            raise ValueError('Заведение не найдено')
        incoming = {key: data.get(key, previous[key]) for key in editable}
        if incoming['kind'] not in TYPES:
            raise ValueError('Неизвестный тип заведения')
        if not isinstance(incoming['flags'], dict) or not isinstance(incoming['extra'], dict):
            raise ValueError('Неверный формат дополнительных полей')
        if incoming['inn'] and (not incoming['inn'].isdigit() or len(incoming['inn']) not in (10, 12)):
            raise ValueError('ИНН должен состоять из 10 или 12 цифр')
        if incoming['ogrn'] and (not incoming['ogrn'].isdigit() or len(incoming['ogrn']) not in (13, 15)):
            raise ValueError('ОГРН/ОГРНИП должен состоять из 13 или 15 цифр')
        incoming['venue_name'] = str(incoming['venue_name']).strip() or 'Без названия'
        with self.connect() as db:
            parameters = []
            for key in editable:
                v = incoming[key]
                parameters.append(json.dumps(v, ensure_ascii=False) if isinstance(v, dict) else str(v))
            updates = ','.join(f'{key}=?' for key in editable)
            db.execute(f'UPDATE venues SET {updates}, updated_at=? WHERE id=?', (*parameters, now(), venue_id))
            changed = sorted(key for key in editable if previous[key] != incoming[key])
            self._audit(db, venue_id, 'venue_updated', {'changed_fields': changed})

    def get_override(self, venue_id, code):
        with self.connect() as db:
            value = db.execute('SELECT selected FROM manual_selection WHERE venue_id=? AND template_code=?', (venue_id, code)).fetchone()
            return None if value is None else bool(value['selected'])

    def set_override(self, venue_id, code, selected):
        with self.connect() as db:
            if selected is None:
                db.execute('DELETE FROM manual_selection WHERE venue_id=? AND template_code=?', (venue_id, code))
            else:
                db.execute('INSERT INTO manual_selection VALUES(?,?,?) ON CONFLICT(venue_id,template_code) DO UPDATE SET selected=excluded.selected',
                           (venue_id, code, int(selected)))
            self._audit(db, venue_id, 'journal_selection_changed', {'code': code, 'selected': selected})

    def add_record(self, venue_id, code, data):
        if not isinstance(data, dict):
            raise ValueError('Данные записи должны быть словарём')
        if not any(str(v).strip() for v in data.values()):
            raise ValueError('Нельзя сохранить полностью пустую запись')
        with self.connect() as db:
            cur = db.execute('INSERT INTO journal_records(venue_id,template_code,data,created_at) VALUES (?,?,?,?)',
                             (venue_id, code, json.dumps(data, ensure_ascii=False), now()))
            self._audit(db, venue_id, 'record_added', {'code': code, 'record_id': cur.lastrowid})
            return cur.lastrowid

    def list_records(self, venue_id, code, include_voided=True):
        with self.connect() as db:
            query = 'SELECT * FROM journal_records WHERE venue_id=? AND template_code=?'
            if not include_voided:
                query += ' AND voided_at IS NULL'
            query += ' ORDER BY id'
            rows = [dict(r) for r in db.execute(query, (venue_id, code))]
            for row in rows:
                row['data'] = _parse(row['data'], {})
            return rows

    def void_record(self, venue_id, record_id, reason):
        reason = reason.strip()
        if len(reason) < 3:
            raise ValueError('Укажите причину исправления (не менее 3 символов)')
        with self.connect() as db:
            current = db.execute('SELECT id,template_code,voided_at FROM journal_records WHERE id=? AND venue_id=?',
                                 (record_id, venue_id)).fetchone()
            if not current:
                raise ValueError('Запись не найдена')
            if current['voided_at']:
                raise ValueError('Запись уже отмечена как отменённая')
            db.execute('UPDATE journal_records SET voided_at=?,void_reason=? WHERE id=?', (now(), reason, record_id))
            self._audit(db, venue_id, 'record_voided', {'record_id': record_id, 'reason': reason})

    def get_labels(self, venue_id, code):
        with self.connect() as db:
            item = db.execute('SELECT labels_json FROM column_labels WHERE venue_id=? AND template_code=?',
                              (venue_id, code)).fetchone()
            return _parse(item['labels_json'], {}) if item else {}

    def set_labels(self, venue_id, code, labels):
        if not isinstance(labels, dict):
            raise ValueError('Некорректные настройки граф')
        with self.connect() as db:
            db.execute('INSERT INTO column_labels VALUES(?,?,?) ON CONFLICT(venue_id,template_code) DO UPDATE SET labels_json=excluded.labels_json',
                       (venue_id, code, json.dumps(labels, ensure_ascii=False)))
            self._audit(db, venue_id, 'columns_changed', {'code': code, 'keys': list(labels)})

    def list_custom_templates(self):
        with self.connect() as db:
            return [dict(row) for row in db.execute('SELECT * FROM custom_templates ORDER BY title')]

    def add_custom_template(self, title, names):
        import uuid
        title = title.strip()
        names = [n.strip() for n in names if n.strip()]
        if len(title) < 3 or not (2 <= len(names) <= 18):
            raise ValueError('Название от 3 символов, от 2 до 18 граф')
        code = 'custom_' + uuid.uuid4().hex[:12]
        columns = [(f'c{i+1}', val) for i, val in enumerate(names)]
        with self.connect() as db:
            db.execute('INSERT INTO custom_templates(code,title,columns_json,created_at) VALUES(?,?,?,?)',
                       (code, title, json.dumps(columns, ensure_ascii=False), now()))
            self._audit(db, None, 'custom_journal_created', {'code': code, 'title': title})
        return code

    def backup(self, target):
        """Транзакционный sqlite backup, включая WAL если появится."""
        target = Path(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.resolve() == self.path.resolve():
            raise ValueError('Нельзя копировать БД поверх самой себя')
        with closing(sqlite3.connect(self.path)) as source, closing(sqlite3.connect(target)) as destination:
            source.backup(destination)
        return target

    def audit(self, venue_id):
        with self.connect() as db:
            return [dict(row) for row in db.execute('SELECT event,details,created_at FROM audit_events WHERE venue_id=? ORDER BY id DESC LIMIT 100', (venue_id,))]
