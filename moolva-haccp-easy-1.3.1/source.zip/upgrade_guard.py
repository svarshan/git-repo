"""Pre-upgrade SQLite backup, before any schema migration occurs."""
from pathlib import Path
import sqlite3
from contextlib import closing
from storage import app_data_dir

VERSION = '0.4.2'


def backup_before_upgrade(database=None, version=VERSION):
    path = Path(database) if database is not None else app_data_dir() / 'haccp.sqlite3'
    if not path.exists():
        return None
    backupdir = path.parent / 'upgrade_backups'
    backupdir.mkdir(parents=True, exist_ok=True)
    target = backupdir / ('before_' + version + '.sqlite3')
    if target.exists():
        with closing(sqlite3.connect(target)) as db:
            if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise RuntimeError('Найдена повреждённая резервная копия обновления: ' + str(target))
        return target
    temp=backupdir / ('before_' + version + '.temporary')
    try:
        with closing(sqlite3.connect(path)) as src, closing(sqlite3.connect(temp)) as dest:
            if src.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise RuntimeError('База повреждена; обновление остановлено')
            src.backup(dest)
            if dest.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise RuntimeError('Не удалось проверить резервную копию')
        temp.replace(target)
    finally:
        temp.unlink(missing_ok=True)
    return target
