"""Визуальный редактор индивидуальных блок-схем для Easy 1.3."""
from __future__ import annotations
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

from flowchart_core import (DIAGRAM_TYPES,CCP_STATUSES,list_diagrams,get_diagram,diagram_details,create_diagram,
    update_diagram,delete_diagram,duplicate_diagram,create_node,update_node,delete_node,add_edge,delete_edge,
    auto_layout,build_from_venue,build_from_haccp_plan,validate_diagram,export_bundle)
from staff_store import list_employees
from exports import get_templates
from haccp_core import HACCPPlans

BG='#1C2026';NAV='#272C33';CARD='#2D323A';CARD2='#343A43';EDGE='#454C57';INK='#F1F4F6';SOFT='#BBC4CC';MUTED='#89949F';LIME='#D7E500';CYAN='#4DA8BE';GREEN='#83C99B';DANGER='#E88989';WARN='#E5C064';ENTRY='#3A414B';FONT='Segoe UI'


def _label(parent,text='',size=10,fg=INK,bg=None,bold=False,**kw):
    return tk.Label(parent,text=text,font=(FONT,size,'bold' if bold else 'normal'),fg=fg,bg=bg or parent.cget('bg'),**kw)

def _button(parent,text,cmd,primary=False,padx=10,pady=8):
    bg=LIME if primary else CARD2;fg=NAV if primary else INK
    return tk.Button(parent,text=text,command=cmd,bg=bg,fg=fg,activebackground='#E7F158' if primary else '#46515F',activeforeground=fg,relief='flat',bd=0,cursor='hand2',font=(FONT,9,'bold'),padx=padx,pady=pady)

def _entry(parent,var):
    return tk.Entry(parent,textvariable=var,bg=ENTRY,fg=INK,insertbackground=INK,relief='flat',highlightthickness=1,highlightbackground=EDGE,font=(FONT,10))


class FlowchartPane(tk.Frame):
    def __init__(self,parent,store,venue_id,on_change=None):
        super().__init__(parent,bg=BG)
        self.store=store;self.venue_id=venue_id;self.on_change=on_change or (lambda:None)
        self.diagram_id=None;self.selected_node=None;self.selected_edge=None;self.connect_from=None;self.drag=None
        self.node_items={};self.item_nodes={};self.edge_items={};self._build();self.refresh_diagrams()

    def _build(self):
        top=tk.Frame(self,bg=BG);top.pack(fill='x',pady=(0,9))
        _label(top,'Схема:',size=9,fg=SOFT).pack(side='left',padx=(0,7))
        self.combo=ttk.Combobox(top,state='readonly',width=30);self.combo.pack(side='left');self.combo.bind('<<ComboboxSelected>>',self._select_combo)
        _button(top,'+ Новая',self.new_diagram,primary=True).pack(side='left',padx=5)
        _button(top,'Копия',self.copy_diagram).pack(side='left',padx=2)
        _button(top,'Удалить',self.remove_diagram).pack(side='left',padx=2)
        _button(top,'Проверить',self.check_diagram).pack(side='right',padx=2)
        _button(top,'Экспорт',self.export_dialog).pack(side='right',padx=2)

        tools=tk.Frame(self,bg=CARD,highlightthickness=1,highlightbackground=EDGE);tools.pack(fill='x',pady=(0,9))
        _button(tools,'+ Этап',self.add_node,primary=True).pack(side='left',padx=(8,3),pady=7)
        _button(tools,'Соединить этапы',self.start_connect).pack(side='left',padx=3,pady=7)
        _button(tools,'Автораскладка',self.layout_nodes).pack(side='left',padx=3,pady=7)
        _button(tools,'Авто из предприятия',self.auto_venue).pack(side='left',padx=3,pady=7)
        _button(tools,'Из плана ХАССП',self.auto_haccp).pack(side='left',padx=3,pady=7)
        self.status=_label(tools,'Выберите или создайте схему',size=8,fg=CYAN,bg=CARD)
        self.status.pack(side='right',padx=10)

        panes=ttk.Panedwindow(self,orient='horizontal');panes.pack(fill='both',expand=True)
        left=tk.Frame(panes,bg=CARD,width=190);center=tk.Frame(panes,bg=BG);right=tk.Frame(panes,bg=CARD,width=350)
        panes.add(left,weight=0);panes.add(center,weight=1);panes.add(right,weight=0)
        _label(left,'ЭТАПЫ',size=8,fg=MUTED,bg=CARD,bold=True).pack(anchor='w',padx=12,pady=(12,5))
        self.node_list=tk.Listbox(left,bg=ENTRY,fg=INK,selectbackground='#37566B',selectforeground=INK,bd=0,highlightthickness=0,font=(FONT,9),exportselection=False)
        self.node_list.pack(fill='both',expand=True,padx=10);self.node_list.bind('<<ListboxSelect>>',self._list_node_select)
        _label(left,'СВЯЗИ',size=8,fg=MUTED,bg=CARD,bold=True).pack(anchor='w',padx=12,pady=(10,5))
        self.edge_list=tk.Listbox(left,bg=ENTRY,fg=SOFT,selectbackground='#5D4B52',bd=0,highlightthickness=0,font=(FONT,8),height=7,exportselection=False)
        self.edge_list.pack(fill='x',padx=10);self.edge_list.bind('<<ListboxSelect>>',self._list_edge_select)
        _button(left,'Удалить связь',self.remove_edge,padx=8,pady=6).pack(fill='x',padx=10,pady=(5,10))

        # canvas with local scrollbars
        cvwrap=tk.Frame(center,bg=BG);cvwrap.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(cvwrap,bg='#22272E',highlightthickness=1,highlightbackground=EDGE,scrollregion=(0,0,2600,1800))
        sx=ttk.Scrollbar(cvwrap,orient='horizontal',command=self.canvas.xview);sy=ttk.Scrollbar(cvwrap,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=sx.set,yscrollcommand=sy.set)
        sy.pack(side='right',fill='y');sx.pack(side='bottom',fill='x');self.canvas.pack(side='left',fill='both',expand=True)
        self.canvas.bind('<ButtonPress-1>',self._canvas_press);self.canvas.bind('<B1-Motion>',self._canvas_drag);self.canvas.bind('<ButtonRelease-1>',self._canvas_release)

        _label(right,'СВОЙСТВА ЭТАПА',size=8,fg=MUTED,bg=CARD,bold=True).pack(anchor='w',padx=12,pady=(12,5))
        self.props=ttk.Notebook(right);self.props.pack(fill='both',expand=True,padx=8,pady=(0,8))
        self.p_main=tk.Frame(self.props,bg=CARD);self.p_risk=tk.Frame(self.props,bg=CARD);self.p_haccp=tk.Frame(self.props,bg=CARD)
        self.props.add(self.p_main,text='Этап');self.props.add(self.p_risk,text='Риски');self.props.add(self.p_haccp,text='ХАССП')
        self.vars={k:tk.StringVar() for k in ('name','equipment','responsible','ccp_status','critical_limit','journal_code')}
        self._field(self.p_main,'Название',self.vars['name'])
        self._field(self.p_main,'Оборудование',self.vars['equipment'])
        self._combo_field(self.p_main,'Ответственный',self.vars['responsible'],[],'responsible_combo')
        self.description=self._text_field(self.p_main,'Описание',4)
        self.bio=self._text_field(self.p_risk,'Биологические опасности',3)
        self.chem=self._text_field(self.p_risk,'Химические опасности',3)
        self.phys=self._text_field(self.p_risk,'Физические опасности',3)
        self.allergen=self._text_field(self.p_risk,'Аллергены',3)
        self.control=self._text_field(self.p_haccp,'Меры управления',3)
        self._combo_field(self.p_haccp,'Статус ККТ',self.vars['ccp_status'],CCP_STATUSES,'ccp_combo')
        self._field(self.p_haccp,'Критический предел',self.vars['critical_limit'])
        self.monitoring=self._text_field(self.p_haccp,'Мониторинг',3)
        self.corrective=self._text_field(self.p_haccp,'Корректирующие действия',3)
        self._combo_field(self.p_haccp,'Связанный журнал',self.vars['journal_code'],[],'journal_combo')
        actions=tk.Frame(right,bg=CARD);actions.pack(fill='x',padx=8,pady=(0,10))
        _button(actions,'Сохранить этап',self.save_node,primary=True).pack(side='left',fill='x',expand=True,padx=(0,3))
        _button(actions,'Удалить',self.remove_node,padx=8).pack(side='left')
        self._set_props_state(False)

    def _field(self,parent,title,var):
        _label(parent,title,size=8,fg=SOFT,bg=CARD).pack(anchor='w',padx=9,pady=(9,3));_entry(parent,var).pack(fill='x',padx=9,ipady=6)
    def _combo_field(self,parent,title,var,values,attr):
        _label(parent,title,size=8,fg=SOFT,bg=CARD).pack(anchor='w',padx=9,pady=(9,3));c=ttk.Combobox(parent,textvariable=var,state='readonly',values=list(values));c.pack(fill='x',padx=9);setattr(self,attr,c)
    def _text_field(self,parent,title,height):
        _label(parent,title,size=8,fg=SOFT,bg=CARD).pack(anchor='w',padx=9,pady=(9,3));t=tk.Text(parent,height=height,bg=ENTRY,fg=INK,insertbackground=INK,relief='flat',highlightthickness=1,highlightbackground=EDGE,font=(FONT,9),wrap='word',width=30);t.pack(fill='x',padx=9);return t
    def _set_props_state(self,enabled):
        state='normal' if enabled else 'disabled'
        for child in (self.p_main,self.p_risk,self.p_haccp):
            for w in child.winfo_children():
                try:w.configure(state=state)
                except tk.TclError:pass

    def refresh_diagrams(self,select_id=None):
        rows=list_diagrams(self.store,self.venue_id);self.diagrams=rows
        self.combo['values']=[f"{r['title']}  ·  {r['node_count']} этапов" for r in rows]
        if rows:
            if select_id is None and self.diagram_id in [r['id'] for r in rows]:select_id=self.diagram_id
            idx=next((i for i,r in enumerate(rows) if r['id']==select_id),0);self.combo.current(idx);self.load_diagram(rows[idx]['id'])
        else:
            self.diagram_id=None;self.combo.set('');self._clear_canvas();self.status.configure(text='Создайте первую индивидуальную схему')
    def _select_combo(self,event=None):
        i=self.combo.current()
        if 0<=i<len(self.diagrams):self.load_diagram(self.diagrams[i]['id'])

    def new_diagram(self):
        dlg=tk.Toplevel(self);dlg.title('Новая блок-схема');dlg.configure(bg=CARD);dlg.transient(self.winfo_toplevel());dlg.grab_set();dlg.geometry('520x260')
        title=tk.StringVar(value='Новая блок-схема');dtype=tk.StringVar(value=DIAGRAM_TYPES[0])
        _label(dlg,'Название схемы',bg=CARD).pack(anchor='w',padx=20,pady=(18,4));_entry(dlg,title).pack(fill='x',padx=20,ipady=7)
        _label(dlg,'Тип',bg=CARD).pack(anchor='w',padx=20,pady=(14,4));ttk.Combobox(dlg,textvariable=dtype,state='readonly',values=DIAGRAM_TYPES).pack(fill='x',padx=20)
        def create():
            try:i=create_diagram(self.store,self.venue_id,title.get(),dtype.get())
            except Exception as e:messagebox.showerror('Не удалось создать',str(e),parent=dlg);return
            dlg.destroy();self.refresh_diagrams(i);self.on_change()
        _button(dlg,'Создать схему',create,primary=True).pack(pady=20)
    def copy_diagram(self):
        if not self.diagram_id:return
        try:i=duplicate_diagram(self.store,self.diagram_id)
        except Exception as e:messagebox.showerror('Копирование',str(e));return
        self.refresh_diagrams(i);self.on_change()
    def remove_diagram(self):
        if not self.diagram_id:return
        d=get_diagram(self.store,self.diagram_id)
        if not messagebox.askyesno('Удалить схему?',f"Удалить «{d['title']}»?\nЭтапы и связи этой схемы будут удалены."):return
        delete_diagram(self.store,self.diagram_id);self.diagram_id=None;self.refresh_diagrams();self.on_change()

    def load_diagram(self,diagram_id):
        self.diagram_id=diagram_id;self.selected_node=None;self.connect_from=None;self._refresh_people_journals();self.redraw()
    def _refresh_people_journals(self):
        people=list_employees(self.store,self.venue_id);self.people=people;self.people_by_label={'— Не назначен —':None}
        for e in people:self.people_by_label[f"{e['full_name']} · {e['position_name']}"]=e['id']
        self.responsible_combo['values']=list(self.people_by_label)
        self.journals={t.title:t.code for t in get_templates(self.store)};self.journal_by_code={v:k for k,v in self.journals.items()};self.journal_combo['values']=['— Не привязан —']+list(self.journals)

    def _clear_canvas(self):
        self.canvas.delete('all');self.node_items={};self.item_nodes={};self.edge_items={};self.node_list.delete(0,'end');self.edge_list.delete(0,'end');self._set_props_state(False)
    def redraw(self):
        self._clear_canvas()
        if not self.diagram_id:return
        data=diagram_details(self.store,self.diagram_id);self.data=data;nodes=data['nodes'];edges=data['edges'];byid={n['id']:n for n in nodes}
        # grid
        for x in range(0,2601,50):self.canvas.create_line(x,0,x,1800,fill='#292F36')
        for y in range(0,1801,50):self.canvas.create_line(0,y,2600,y,fill='#292F36')
        for e in edges:
            a=byid.get(e['source_node_id']);b=byid.get(e['target_node_id'])
            if not a or not b:continue
            x1=a['x']+a['width']/2;y1=a['y']+a['height']/2;x2=b['x']+b['width']/2;y2=b['y']+b['height']/2
            item=self.canvas.create_line(x1,y1,x2,y2,fill='#73808B',width=2,arrow='last',arrowshape=(10,12,5),tags=(f"edge:{e['id']}",))
            self.edge_items[item]=e['id']
            self.edge_list.insert('end',f"{a['name']} → {b['name']}")
        for i,n in enumerate(nodes):
            self.node_list.insert('end',n['name']);self._draw_node(n,selected=n['id']==self.selected_node)
        self.status.configure(text=f"{len(nodes)} этапов · {len(edges)} связей")
        if self.selected_node:self._load_props(self.selected_node)

    def _draw_node(self,n,selected=False):
        x=n['x'];y=n['y'];w=n['width'];h=n['height'];haz=any(str(n[k]).strip() for k in ('hazard_biological','hazard_chemical','hazard_physical','hazard_allergen'))
        fill='#563A3D' if n['ccp_status']=='ККТ' else ('#4A4730' if haz else CARD2);outline=LIME if selected else (DANGER if n['ccp_status']=='ККТ' else (WARN if haz else CYAN));width=3 if selected else 2
        rect=self.canvas.create_rectangle(x,y,x+w,y+h,fill=fill,outline=outline,width=width,tags=(f"node:{n['id']}",'node'))
        name=self.canvas.create_text(x+12,y+13,text=n['name'],anchor='nw',fill=INK,font=(FONT,10,'bold'),width=w-24,tags=(f"node:{n['id']}",'node'))
        badge='ККТ' if n['ccp_status']=='ККТ' else ('РИСКИ' if haz else 'ЭТАП')
        badgeitem=self.canvas.create_text(x+12,y+h-11,text=badge,anchor='sw',fill=outline,font=(FONT,8,'bold'),tags=(f"node:{n['id']}",'node'))
        self.node_items[n['id']]=(rect,name,badgeitem)
        for item in (rect,name,badgeitem):self.item_nodes[item]=n['id']

    def _node_at(self,event):
        x=self.canvas.canvasx(event.x);y=self.canvas.canvasy(event.y);items=self.canvas.find_overlapping(x-2,y-2,x+2,y+2)
        for item in reversed(items):
            if item in self.item_nodes:return self.item_nodes[item]
        return None
    def _canvas_press(self,event):
        nid=self._node_at(event)
        if nid is None:return
        if self.connect_from:
            if nid==self.connect_from:self.status.configure(text='Выберите другой этап для соединения');return
            try:add_edge(self.store,self.diagram_id,self.connect_from,nid)
            except Exception as e:messagebox.showerror('Связь',str(e))
            self.connect_from=None;self.redraw();self.on_change();return
        self.select_node(nid)
        n=next(x for x in self.data['nodes'] if x['id']==nid);cx=self.canvas.canvasx(event.x);cy=self.canvas.canvasy(event.y);self.drag=(nid,cx-n['x'],cy-n['y'])
    def _canvas_drag(self,event):
        if not self.drag:return
        nid,ox,oy=self.drag;x=max(10,int(self.canvas.canvasx(event.x)-ox));y=max(10,int(self.canvas.canvasy(event.y)-oy))
        items=self.node_items.get(nid,())
        n=next((a for a in self.data['nodes'] if a['id']==nid),None)
        if not n:return
        dx=x-n['x'];dy=y-n['y'];n['x']=x;n['y']=y
        for item in items:self.canvas.move(item,dx,dy)
        # redraw edges live cheaply by full redraw only on release
    def _canvas_release(self,event):
        if not self.drag:return
        nid,_,_=self.drag;self.drag=None;n=next((a for a in self.data['nodes'] if a['id']==nid),None)
        if n:
            update_node(self.store,self.diagram_id,nid,x=n['x'],y=n['y']);self.redraw();self.on_change()
    def select_node(self,nid):
        self.selected_node=nid;self.redraw();
        try:i=[n['id'] for n in self.data['nodes']].index(nid);self.node_list.selection_clear(0,'end');self.node_list.selection_set(i);self.node_list.see(i)
        except ValueError:pass
    def _list_node_select(self,event=None):
        sel=self.node_list.curselection()
        if sel and self.diagram_id:
            data=diagram_details(self.store,self.diagram_id);nodes=data['nodes']
            if sel[0]<len(nodes):self.select_node(nodes[sel[0]]['id'])
    def _list_edge_select(self,event=None):
        sel=self.edge_list.curselection();self.selected_edge=None
        if sel and self.diagram_id:
            edges=diagram_details(self.store,self.diagram_id)['edges']
            if sel[0]<len(edges):self.selected_edge=edges[sel[0]]['id']

    def _set_text(self,w,value):w.configure(state='normal');w.delete('1.0','end');w.insert('1.0',value or '')
    def _load_props(self,nid):
        n=next((x for x in self.data['nodes'] if x['id']==nid),None)
        if not n:return
        self._set_props_state(True);self.vars['name'].set(n['name']);self.vars['equipment'].set(n['equipment']);self.vars['ccp_status'].set(n['ccp_status']);self.vars['critical_limit'].set(n['critical_limit'])
        emp=next((e for e in self.people if e['id']==n.get('responsible_employee_id')),None);self.vars['responsible'].set(f"{emp['full_name']} · {emp['position_name']}" if emp else '— Не назначен —')
        self.vars['journal_code'].set(self.journal_by_code.get(n.get('journal_code',''),'— Не привязан —'))
        for w,k in ((self.description,'description'),(self.bio,'hazard_biological'),(self.chem,'hazard_chemical'),(self.phys,'hazard_physical'),(self.allergen,'hazard_allergen'),(self.control,'control_measure'),(self.monitoring,'monitoring'),(self.corrective,'corrective_action')):self._set_text(w,n.get(k,''))
    def save_node(self):
        if not self.selected_node:return
        try:update_node(self.store,self.diagram_id,self.selected_node,name=self.vars['name'].get(),equipment=self.vars['equipment'].get(),description=self.description.get('1.0','end-1c'),responsible_employee_id=self.people_by_label.get(self.vars['responsible'].get()),hazard_biological=self.bio.get('1.0','end-1c'),hazard_chemical=self.chem.get('1.0','end-1c'),hazard_physical=self.phys.get('1.0','end-1c'),hazard_allergen=self.allergen.get('1.0','end-1c'),control_measure=self.control.get('1.0','end-1c'),ccp_status=self.vars['ccp_status'].get(),critical_limit=self.vars['critical_limit'].get(),monitoring=self.monitoring.get('1.0','end-1c'),corrective_action=self.corrective.get('1.0','end-1c'),journal_code=self.journals.get(self.vars['journal_code'].get(),''))
        except Exception as e:messagebox.showerror('Сохранение этапа',str(e));return
        self.redraw();self.status.configure(text='Этап сохранён');self.on_change()
    def add_node(self):
        if not self.diagram_id:messagebox.showinfo('Сначала схема','Создайте схему.');return
        name=simpledialog.askstring('Новый этап','Название этапа:',parent=self)
        if not name:return
        n=len(diagram_details(self.store,self.diagram_id)['nodes']);x=90+(n%4)*245;y=90+(n//4)*165
        try:nid=create_node(self.store,self.diagram_id,name,x=x,y=y)
        except Exception as e:messagebox.showerror('Этап',str(e));return
        self.redraw();self.select_node(nid);self.on_change()
    def remove_node(self):
        if not self.selected_node:return
        n=next((x for x in self.data['nodes'] if x['id']==self.selected_node),None)
        if not messagebox.askyesno('Удалить этап?',f"Удалить «{n['name']}» и все его связи?"):return
        delete_node(self.store,self.diagram_id,self.selected_node);self.selected_node=None;self.redraw();self.on_change()
    def start_connect(self):
        if not self.selected_node:
            self.status.configure(text='Сначала выберите исходный этап');return
        self.connect_from=self.selected_node;self.status.configure(text='Теперь щёлкните по этапу назначения')
    def remove_edge(self):
        if not self.selected_edge:messagebox.showinfo('Связь','Выберите связь в списке слева.');return
        delete_edge(self.store,self.diagram_id,self.selected_edge);self.selected_edge=None;self.redraw();self.on_change()
    def layout_nodes(self):
        if not self.diagram_id:return
        auto_layout(self.store,self.diagram_id);self.redraw();self.on_change()
    def _confirm_replace(self):
        count=len(diagram_details(self.store,self.diagram_id)['nodes'])
        return count==0 or messagebox.askyesno('Заменить этапы?',f'В схеме уже {count} этапов. Автопостроение заменит их. Продолжить?')
    def auto_venue(self):
        if not self.diagram_id:return
        if not self._confirm_replace():return
        try:build_from_venue(self.store,self.diagram_id)
        except Exception as e:messagebox.showerror('Автопостроение',str(e));return
        self.redraw();self.status.configure(text='Черновая схема построена по процессам предприятия');self.on_change()
    def auto_haccp(self):
        if not self.diagram_id:return
        plans=HACCPPlans(self.store).list_plans(self.venue_id)
        if not plans:messagebox.showinfo('Планы ХАССП','Для предприятия ещё нет плана ХАССП.');return
        win=tk.Toplevel(self);win.title('Выберите план ХАССП');win.configure(bg=CARD);win.transient(self.winfo_toplevel());win.grab_set();win.geometry('620x350')
        lb=tk.Listbox(win,bg=ENTRY,fg=INK,selectbackground='#37566B',bd=0,font=(FONT,10),exportselection=False);lb.pack(fill='both',expand=True,padx=15,pady=15)
        for p in plans:lb.insert('end',f"{p['title']} · {p['product']} · ред. {p['revision']}")
        def apply():
            sel=lb.curselection()
            if not sel:return
            if not self._confirm_replace():return
            try:build_from_haccp_plan(self.store,self.diagram_id,plans[sel[0]]['id'])
            except Exception as e:messagebox.showerror('План ХАССП',str(e),parent=win);return
            win.destroy();self.redraw();self.status.configure(text='Схема построена из сохранённого плана ХАССП');self.on_change()
        _button(win,'Построить по плану',apply,primary=True).pack(pady=(0,14))
    def check_diagram(self):
        if not self.diagram_id:return
        issues=validate_diagram(self.store,self.diagram_id)
        win=tk.Toplevel(self);win.title('Проверка блок-схемы');win.configure(bg=CARD);win.geometry('800x540');win.transient(self.winfo_toplevel())
        _label(win,'Проверка полноты схемы',size=16,bold=True,bg=CARD).pack(anchor='w',padx=18,pady=(15,5))
        _label(win,'Это подсказки по структуре, а не автоматическое заключение о соответствии ХАССП.',size=9,fg=MUTED,bg=CARD).pack(anchor='w',padx=18)
        box=tk.Text(win,bg=ENTRY,fg=INK,wrap='word',font=(FONT,10),relief='flat');box.pack(fill='both',expand=True,padx=18,pady=14)
        if not issues:box.insert('end','✓ Структурных замечаний не найдено.\n')
        for x in issues:box.insert('end',f"[{x['level'].upper()}] {x['text']}\n\n")
        box.configure(state='disabled')
    def export_dialog(self):
        if not self.diagram_id:return
        folder=filedialog.askdirectory(title='Папка для экспорта блок-схемы')
        if not folder:return
        try:files=export_bundle(self.store,self.diagram_id,folder,('png','docx','pdf'))
        except Exception as e:messagebox.showerror('Экспорт схемы',str(e));return
        messagebox.showinfo('Готово','Созданы:\n'+'\n'.join(str(p) for p in files))
