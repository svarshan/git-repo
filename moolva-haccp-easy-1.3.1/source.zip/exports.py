"""Экспорт в редактируемые Word и печатные PDF. Никаких вымышленных показаний."""
from pathlib import Path
from datetime import datetime
from xml.sax.saxutils import escape
import json
import re

from catalog import Template, TEMPLATES, applicability


def get_templates(store):
    items = list(TEMPLATES)
    for row in store.list_custom_templates():
        items.append(Template(
            row['code'], row['title'], 'Мои журналы',
            tuple(tuple(col) for col in json.loads(row['columns_json'])),
            '', 'Добавлен пользователем',
            'Пользовательская форма. Не имеет самостоятельного нормативного статуса.'
        ))
    return items


def is_selected(store, venue, template):
    override = store.get_override(venue['id'], template.code)
    if template.code.startswith('custom_') and override is None:
        return False, 'Мой журнал; включите его в комплект вручную'
    return applicability(template, venue, override)


def columns_for(store, venue_id, template):
    labels = store.get_labels(venue_id, template.code)
    result = [(k, labels.get(k, v)) for k, v in template.columns]
    for k, v in labels.items():
        if k not in dict(template.columns) and v.strip():
            result.append((k, v))
    return result


def safe_name(text):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', text).strip(' .')[:80] or 'Журнал'


def document_meta(venue, template):
    fields = [
        ('Организация', venue.get('legal_name', '')),
        ('Объект', venue.get('venue_name', '')),
        ('Адрес объекта', venue.get('address', '')),
        ('Юридический адрес', venue.get('legal_address', '')),
        ('ИНН', venue.get('inn', '')),
        ('ОГРН / ОГРНИП', venue.get('ogrn', '')),
        ('Руководитель', venue.get('director', '')),
        ('Ответственный', venue.get('responsible', '')),
        ('Телефон', venue.get('phone', '')),
        ('Электронная почта', venue.get('email', '')),
    ]
    fields += [(str(k), str(v)) for k, v in venue.get('extra', {}).items()]
    return [(k, str(v).strip() or '—') for k, v in fields]


def _row_values(columns, record):
    status = ('ОТМЕНЕНА: ' + (record.get('void_reason') or '')) if record.get('voided_at') else 'Действует'
    return [str(record['data'].get(k, '')) for k, _ in columns] + [status]


def _blank_count(records):
    return 9 if not records else 0


def export_docx(output, venue, template, columns, records, staff_config=None, staff_appendix=None, ack_employees=None, layout=None, widths=None):
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor
    from docx.enum.section import WD_ORIENT
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    document = Document()
    section = document.sections[0]
    count = len(columns) + 1
    mode=(layout or {}).get("page_mode", "auto")
    if mode == "a3land" or (mode == "auto" and count > 9):
        section.page_width, section.page_height = Cm(42), Cm(29.7)  # A3 альбомный
    elif mode == "a4land" or (mode == "auto" and count > 5):
        section.page_width, section.page_height = Cm(29.7), Cm(21)  # A4 альбомный
    else:
        section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin = section.bottom_margin = Cm(1.3)
    section.left_margin = section.right_margin = Cm(1.2)

    styles = document.styles
    norm = styles['Normal']
    norm.font.name = 'Arial'
    norm.font.size = Pt(9)
    norm.paragraph_format.space_after = Pt(4)
    title = document.add_paragraph(style='Title')
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.add_run(template.title).bold = True
    document.add_paragraph('MoOLVa ХАССП • журнал производственного контроля', style='Subtitle')
    document.add_paragraph('Сведения о предприятии').runs[0].bold = True

    meta = document.add_table(rows=0, cols=2)
    meta.style = 'Table Grid'
    for name, value in document_meta(venue, template):
        cells = meta.add_row().cells
        cells[0].text, cells[1].text = name, value
        cells[0].width, cells[1].width = Cm(4.5), Cm(15)
    document.add_paragraph('Основание / статус формы: ' + template.basis)
    if template.note:
        document.add_paragraph('Примечание: ' + template.note)
    from doc_staff_export import add_docx_signatories
    add_docx_signatories(document,staff_config or {})
    document.add_paragraph('Записи журнала').runs[0].bold = True
    document.add_paragraph('Сформировано: ' + datetime.now().strftime('%d.%m.%Y %H:%M') + '. ' +
                           'Исторические записи сохраняются при смене реквизитов.')

    tbl = document.add_table(rows=1, cols=count)
    if widths and len(widths)==count:
        available=section.page_width-section.left_margin-section.right_margin
        for i,weight in enumerate(widths):tbl.columns[i].width=int(available*weight/sum(widths))
    tbl.style = 'Table Grid'
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    headers = [v for _, v in columns] + ['Статус записи']
    for i, name in enumerate(headers):
        cell = tbl.rows[0].cells[i]
        cell.text = name
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        tcpr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement('w:shd')
        shd.set(qn('w:fill'), 'E7EEF6')
        tcpr.append(shd)
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
                run.font.size = Pt(7 if count > 6 else 8)
    trPr = tbl.rows[0]._tr.get_or_add_trPr()
    repeat = OxmlElement('w:tblHeader')
    repeat.set(qn('w:val'), 'true')
    trPr.append(repeat)

    rows = [_row_values(columns, r) for r in records]
    rows.extend([[''] * count for _ in range(min(int(layout["blank_rows"]),3) if staff_appendix else int(layout["blank_rows"]))] if layout is not None else [[''] * count for _ in range(min(_blank_count(records),3) if staff_appendix else _blank_count(records))])
    for values in rows:
        cells = tbl.add_row().cells
        for i, value in enumerate(values):
            cells[i].text = value
            cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
            for par in cells[i].paragraphs:
                for run in par.runs:
                    run.font.size = Pt(7 if count > 6 else 8)
    from doc_staff_export import add_docx_appendix,add_docx_ack_sheet
    add_docx_ack_sheet(document,ack_employees or [])
    add_docx_appendix(document,staff_appendix or [])
    document.save(str(output))
    return output


def _register_pdf_font():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    if 'MoolvaCyr' in pdfmetrics.getRegisteredFontNames():
        return 'MoolvaCyr'
    from pathlib import Path
    paths = (
        r'C:\Windows\Fonts\arial.ttf',
        r'C:\Windows\Fonts\segoeui.ttf',
        r'C:\Windows\Fonts\calibri.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
    )
    for path in paths:
        if Path(path).is_file():
            pdfmetrics.registerFont(TTFont('MoolvaCyr', path))
            return 'MoolvaCyr'
    raise RuntimeError('Для PDF не найден системный шрифт с кириллицей (Arial / Segoe UI / DejaVu).')


def export_pdf(output, venue, template, columns, records, staff_config=None, staff_appendix=None, ack_employees=None, layout=None, widths=None):
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer, KeepTogether
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.colors import HexColor
    from reportlab.lib.pagesizes import A3, A4, landscape
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.units import mm

    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    font = _register_pdf_font()
    count = len(columns) + 1
    mode=(layout or {}).get("page_mode", "auto")
    paper = landscape(A3) if mode=="a3land" or (mode=="auto" and count>9) else (landscape(A4) if mode=="a4land" or (mode=="auto" and count>5) else A4)
    doc = SimpleDocTemplate(str(output), pagesize=paper,
                            topMargin=14*mm, bottomMargin=15*mm,
                            leftMargin=12*mm, rightMargin=12*mm)
    base = ParagraphStyle('base', fontName=font, fontSize=8.5, leading=11, spaceAfter=3)
    head = ParagraphStyle('title', parent=base, alignment=TA_CENTER,
                          fontSize=14, leading=17, spaceAfter=10)
    col_style = ParagraphStyle('col', parent=base, fontSize=6.5 if count >= 8 else 7.2,
                               leading=8 if count >= 8 else 9, wordWrap='CJK', spaceAfter=0)
    cell_style = ParagraphStyle('cell', parent=col_style, fontSize=7 if count < 8 else 6.3)
    meta_style = ParagraphStyle('meta', parent=base, fontSize=8, leading=10, spaceAfter=2)
    P = lambda s, style=base: Paragraph(escape(str(s)).replace('\n', '<br/>'), style)
    story = [P(template.title, head), P('MoOLVa ХАССП • журнал производственного контроля', meta_style), Spacer(1, 5)]
    meta = [[P(k, meta_style), P(v, meta_style)] for k, v in document_meta(venue, template)]
    mt = Table(meta, colWidths=[doc.width*0.23, doc.width*0.77], hAlign='LEFT')
    mt.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), HexColor('#E7EEF6')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('LINEBELOW', (0, 0), (-1, -1), 0.35, HexColor('#D2DCE7')),
    ]))
    story += [mt, Spacer(1, 6), P('Основание / статус формы: ' + template.basis, meta_style)]
    if template.note:
        story.append(P('Примечание: ' + template.note, meta_style))
    story.append(Spacer(1, 6))
    headers = [v for _, v in columns] + ['Статус записи']
    values = [[P(x, col_style) for x in headers]]
    rows = [_row_values(columns, r) for r in records]
    rows.extend([[''] * count for _ in range(min(int(layout["blank_rows"]),3) if staff_appendix else int(layout["blank_rows"]))] if layout is not None else [[''] * count for _ in range(min(_blank_count(records),3) if staff_appendix else _blank_count(records))])
    values += [[P(s or ' ', cell_style) for s in row] for row in rows]
    col_widths = [doc.width * w / sum(widths) for w in widths] if widths and len(widths)==count else [doc.width/count]*count
    if not widths and count >= 10:
        # Чуть больше места для тяжёлых текстовых граф.
        weights = [1.35 if len(name) > 35 else 1 for name in headers]
        col_widths = [doc.width * x / sum(weights) for x in weights]
    table = Table(values, colWidths=col_widths, repeatRows=1, hAlign='LEFT')
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), HexColor('#DFEAF4')),
        ('GRID', (0, 0), (-1, -1), 0.3, HexColor('#9DAFC0')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 3),
        ('RIGHTPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#FFFFFF'), HexColor('#F7F9FC')]),
    ]))
    story.append(table)
    story += [Spacer(1, 8),
              P('Подготовлено: ' + datetime.now().strftime('%d.%m.%Y %H:%M'), meta_style),
              P('Записи подтверждаются реальными действиями. Указанное ФИО не является электронной подписью.', meta_style)]

    from doc_staff_export import pdf_staff_additions
    pdf_staff_additions(story, staff_config or {}, staff_appendix or [], doc, base, P, ack_employees)

    def footer(canvas, pdf):
        canvas.saveState()
        canvas.setFont(font, 7)
        canvas.setFillColor(HexColor('#667588'))
        canvas.drawString(12*mm, 8*mm, 'MoOLVa ХАССП • ' + (venue.get('venue_name') or 'Объект'))
        canvas.drawRightString(paper[0] - 12*mm, 8*mm, f'Стр. {pdf.page}')
        canvas.restoreState()
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return output


def export_journal(store, venue_id, template, output, fmt):
    venue = store.get_venue(venue_id)
    if not venue:
        raise ValueError('Заведение не найдено')
    from dataclasses import replace
    from studio_core import layout_export_spec
    layout, cols, widths = layout_export_spec(store, venue_id, template)
    if not cols:raise ValueError('В редакторе необходимо оставить хотя бы одну видимую графу')
    template = replace(template, title=layout['title'] or template.title,
                       note=(template.note + '\n' + layout['note']).strip() if layout['note'] else template.note)
    records = store.list_records(venue_id, template.code)
    from staff_store import get_assignments, appendix_rows, list_acknowledgements
    key='journal:'+template.code
    config=get_assignments(store,venue_id,key)
    appendix=appendix_rows(store,venue_id,key)
    ack=list_acknowledgements(store,venue_id,key)
    if fmt == 'docx':
        return export_docx(output, venue, template, cols, records,config,appendix,ack,layout,widths)
    if fmt == 'pdf':
        return export_pdf(output, venue, template, cols, records,config,appendix,ack,layout,widths)
    raise ValueError('Формат должен быть docx или pdf')


def export_pack(store, venue_id, directory, formats=('docx', 'pdf')):
    venue = store.get_venue(venue_id)
    if not venue:
        raise ValueError('Заведение не найдено')
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    out = []
    selected = [(t, why) for t in get_templates(store) if (flag := is_selected(store, venue, t))[0] for why in [flag[1]]]
    for template, _ in selected:
        for fmt in formats:
            path = directory / (safe_name(template.code + '_' + template.title) + '.' + fmt)
            out.append(export_journal(store, venue_id, template, path, fmt))
    index_path = directory / 'О_комплекте_журналов.txt'
    index_path.write_text(
        f'MoOLVa ХАССП. Комплект для {venue["venue_name"]}\n'
        f'Создан: {datetime.now():%d.%m.%Y %H:%M}\n'
        f'Общая основа для пищевых производств: ТР ТС 021/2011, ст. 10.\n'
        f'Для объектов общепита дополнительно проверить СанПиН 2.3/2.4.4282-26 с 01.09.2026.\n\n'
        'Подбор — первичная рекомендация по процессам, не юридическое заключение.\n'
        'Рекомендуемые образцы СанПиН и внутренние формы ППК / ХАССП не равнозначны обязательным журналам.\n'
        'Для всех отраслей применимость форм, периодичность и пределы контролей подтверждает специалист ППК/ХАССП.\n'
        'Исторические выгрузки не обновляются при изменении реквизитов.\n\n' +
        '\n'.join(f'• {t.title} — {why}' for t, why in selected),
        encoding='utf-8'
    )
    out.append(index_path)
    from assessment import export_assessment
    for fmt in formats:
        rpath = directory / ('Паспорт_подбора_журналов.' + fmt)
        out.append(export_assessment(store, venue_id, rpath, fmt))
    return out
