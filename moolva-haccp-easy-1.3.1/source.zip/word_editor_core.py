"""Conservative visual .docx editing; preserves unrelated Word content.

Only paragraphs and simple table cells are editable. Unsupported elements such as
pictures, charts, fields and page headers remain intact, but aren't editable here.
The original file is never overwritten by this editor.
"""
from __future__ import annotations
from pathlib import Path
import os
import shutil
import subprocess
from typing import NamedTuple

class Block(NamedTuple):
    kind: str
    index: int
    title: str


def open_word_document(path):
    from docx import Document
    file=Path(path)
    if file.suffix.lower()!='.docx' or not file.is_file():
        raise ValueError('Откройте файл Word в формате .docx')
    return Document(str(file))


def document_blocks(doc):
    """Headings/text/table sections in true source order."""
    from docx.oxml.ns import qn
    from docx.text.paragraph import Paragraph
    from docx.table import Table
    result=[]
    for e in doc.element.body.iterchildren():
        if e.tag==qn('w:p'):
            paragraph=Paragraph(e,doc)
            result.append(('paragraph',paragraph))
        elif e.tag==qn('w:tbl'):
            result.append(('table',Table(e,doc)))
    p_i=t_i=0
    blocks=[]
    for kind,obj in result:
        if kind=='paragraph':
            preview=obj.text.strip()[:70] or '(пустой абзац)'
            if obj.style and obj.style.name.startswith('Heading'):
                preview='◆ '+preview
            blocks.append(Block(kind,p_i,preview));p_i+=1
        else:
            first=' | '.join(c.text[:25] for c in obj.rows[0].cells[:3]) if obj.rows else ''
            blocks.append(Block(kind,t_i,'Таблица: '+(first or f'{len(obj.rows)} строк')));t_i+=1
    return blocks


def _keep_first_run_text(paragraph,new_text):
    """Retain paragraph OOXML, styles, alignment and first-run properties."""
    new_text=str(new_text)
    if len(new_text)>200000:raise ValueError('Слишком длинный текст абзаца')
    if paragraph.text==new_text:return
    from docx.oxml.ns import qn
    preserve={qn('w:drawing'),qn('w:pict'),qn('w:object'),qn('w:fldChar'),
              qn('w:instrText'),qn('w:hyperlink'),qn('w:footnoteReference'),
              qn('w:endnoteReference'),qn('w:sdt')}
    if any(e.tag in preserve for e in paragraph._p.iter()):
        raise ValueError('Этот абзац содержит изображение, поле, ссылку или сложный объект. Откройте документ в Word, чтобы изменить его без риска.')
    runs=list(paragraph.runs)
    if runs:
        first=runs[0]
        first.text=new_text
        for run in runs[1:]:
            paragraph._p.remove(run._r)
    else:
        paragraph.add_run(new_text)


def replace_paragraph(doc,index,text):
    p=doc.paragraphs[int(index)]
    _keep_first_run_text(p,text)


def replace_table_cell(doc,table_index,row_index,col_index,text):
    table=doc.tables[int(table_index)]
    cell=table.cell(int(row_index),int(col_index))
    if len(str(text))>15000:raise ValueError('Слишком длинный текст ячейки')
    _keep_first_run_text(cell.paragraphs[0],text)
    for extra in cell.paragraphs[1:]:
        # Keep structure of additional paragraphs if it exists; don't silently discard.
        if extra.text:extra.clear()


def save_word_copy(doc,source,destination):
    source=Path(source).resolve()
    dst=Path(destination).resolve()
    if dst.suffix.lower()!='.docx':raise ValueError('Нужно выбрать файл с расширением .docx')
    if source==dst:raise ValueError('Исходный файл защищён: выберите другое имя для новой копии')
    if not dst.parent.is_dir():raise ValueError('Папка сохранения не существует')
    doc.save(str(dst))
    return dst


def export_pdf_from_docx(docx_path,destination):
    """PDF requires installed Microsoft Word (Windows) or LibreOffice.
    Does not claim bit-perfect rendering; external office controls conversion.
    """
    source=Path(docx_path).resolve();dst=Path(destination).resolve()
    if source.suffix.lower()!='.docx' or dst.suffix.lower()!='.pdf':
        raise ValueError('Ожидается Word .docx и PDF .pdf')
    if not source.exists():raise FileNotFoundError(source)
    if os.name=='nt':
        # Use Word via COM when present, without third-party pywin32.
        script='''$ErrorActionPreference='Stop'; $word=$null; $doc=$null;
        try { $word=New-Object -ComObject Word.Application; $word.Visible=$false;
        $word.DisplayAlerts=0; $doc=$word.Documents.Open($args[0],$false,$true);
        $doc.ExportAsFixedFormat($args[1],17); }
        finally { if($doc){$doc.Close(0)}; if($word){$word.Quit()} }'''
        ps=shutil.which('powershell.exe')
        if ps:
            try:
                proc=subprocess.run([ps,'-NoProfile','-NonInteractive','-Command',script,str(source),str(dst)],
                   timeout=100,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                if proc.returncode==0 and dst.is_file() and dst.stat().st_size>0:return dst
            except (OSError,subprocess.TimeoutExpired):pass
    lo=shutil.which('soffice') or shutil.which('libreoffice')
    if not lo and os.name=='nt':
        for candidate in (r'C:\Program Files\LibreOffice\program\soffice.exe',
                          r'C:\Program Files (x86)\LibreOffice\program\soffice.exe'):
            if Path(candidate).is_file():lo=candidate;break
    if lo:
        tmp=dst.parent
        proc=subprocess.run([lo,'--headless','--convert-to','pdf','--outdir',str(tmp),str(source)],
                timeout=120,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        converted=tmp/(source.stem+'.pdf')
        if proc.returncode==0 and converted.exists():
            if converted!=dst:converted.replace(dst)
            return dst
    raise RuntimeError('Для экспорта редактируемого файла в PDF нужен Microsoft Word или LibreOffice. Файл DOCX можно сохранить без них.')
