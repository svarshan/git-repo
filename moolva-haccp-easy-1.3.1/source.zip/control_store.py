"""Additive 0.4 schema: does not rewrite existing data."""
from datetime import date
from storage import now

def migrate(store):
    with store.connect() as db:
        db.executescript("""CREATE TABLE IF NOT EXISTS control_tasks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          venue_id INTEGER NOT NULL REFERENCES venues(id),
          title TEXT NOT NULL,
          due_date TEXT NOT NULL,
          state TEXT NOT NULL DEFAULT 'open' CHECK(state IN ('open','done')),
          note TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL,
          done_at TEXT);
          CREATE INDEX IF NOT EXISTS idx_control_tasks_venue_date ON control_tasks(venue_id,due_date);
          CREATE TABLE IF NOT EXISTS doc_reviews (
          venue_id INTEGER NOT NULL REFERENCES venues(id),
          doc_code TEXT NOT NULL, reviewed_at TEXT NOT NULL,
          reviewer TEXT NOT NULL, PRIMARY KEY(venue_id,doc_code));""")

def list_tasks(store,venue_id):
    with store.connect() as db:
        return [dict(row) for row in db.execute('SELECT * FROM control_tasks WHERE venue_id=? ORDER BY state,due_date,id',(venue_id,))]

def create_task(store,venue_id,title,due_date,note=''):
    date.fromisoformat(due_date)
    title=title.strip()
    if not title:raise ValueError('Укажите задачу')
    with store.connect() as db:
        c=db.execute('INSERT INTO control_tasks(venue_id,title,due_date,note,created_at) VALUES(?,?,?,?,?)',(venue_id,title,due_date,note,now()))
        store._audit(db,venue_id,'control_task_created',{'id':c.lastrowid,'title':title})
        return c.lastrowid

def complete_task(store,venue_id,task_id):
    with store.connect() as db:
        c=db.execute("UPDATE control_tasks SET state='done',done_at=? WHERE id=? AND venue_id=? AND state='open'",(now(),task_id,venue_id))
        if c.rowcount!=1:raise ValueError('Задача не найдена или уже выполнена')
        store._audit(db,venue_id,'control_task_done',{'id':task_id})

def review_document(store,venue_id,code,reviewer):
    if not reviewer.strip():raise ValueError('Укажите проверившего')
    with store.connect() as db:
        db.execute('INSERT INTO doc_reviews VALUES(?,?,?,?) ON CONFLICT(venue_id,doc_code) DO UPDATE SET reviewed_at=excluded.reviewed_at,reviewer=excluded.reviewer',(venue_id,code,now(),reviewer.strip()))
        store._audit(db,venue_id,'document_reviewed',{'code':code,'reviewer':reviewer.strip()})

def reviewed_codes(store,venue_id):
    with store.connect() as db:
        return {x['doc_code'] for x in db.execute('SELECT doc_code FROM doc_reviews WHERE venue_id=?',(venue_id,))}
