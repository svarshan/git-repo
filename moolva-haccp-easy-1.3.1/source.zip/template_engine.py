"""Loss-minimizing DOCX placeholder detection and rendering.

Supported text: body paragraphs, nested tables, headers and footers, including
placeholders split across Word runs. Shapes/text boxes and tracked revisions
are not edited; DOCX sources are kept immutable.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
import re
import shutil
import subprocess
import os
import tempfile
from uuid import uuid4
from docx import Document

TOKEN = re.compile(r'\{\{\s*([^{}\r\n]{1,120}?)\s*\}\}')
VENUE_FIELDS = ('venue_name', 'legal_name', 'inn', 'ogrn', 'address',
                'legal_address', 'director', 'responsible', 'phone', 'email', 'kind')
FIELD_NAMES = {
    'venue_name': 'Название объекта', 'legal_name': 'Наименование организации',
    'inn': 'ИНН', 'ogrn': 'ОГРН/ОГРНИП', 'address': 'Адрес объекта',
    'legal_address': 'Юридический адрес', 'director': 'Руководитель',
    'responsible': 'Ответственный за ХАССП', 'phone': 'Телефон',
    'email': 'Электронная почта', 'kind': 'Тип предприятия',
    'date_today': 'Дата формирования',
}


def walk_paragraphs(doc):
    """Yield all supported paragraphs, de-duplicating linked headers and footers."""
    seen = set()
    def descend(container):
        for par in container.paragraphs:
            if par._p not in seen:
                seen.add(par._p)
                yield par
        for table in container.tables:
            yield from table_paragraphs(table)
    def table_paragraphs(table):
        for row in table.rows:
            for cell in row.cells:
                yield from descend(cell)
    yield from descend(doc)
    for section in doc.sections:
        for item in (section.header, section.footer, section.first_page_header,
                     section.first_page_footer, section.even_page_header,
                     section.even_page_footer):
            yield from descend(item)


def tokens_from_docx(source):
    doc = Document(str(source))
    unique = dict.fromkeys(match.group(1).strip() for par in walk_paragraphs(doc)
                           for match in TOKEN.finditer(par.text))
    return list(unique)


def default_mapping(token):
    if token in VENUE_FIELDS:
        return 'field:' + token
    if token == 'date_today':
        return 'today'
    if token.startswith('extra.') and token[6:]:
        return 'extra:' + token[6:]
    if token.startswith('staff.'):
        parts=token.split('.')
        if len(parts)==3 and parts[1] in ('developed','agreed','approved','responsible','checked') and parts[2] in ('name','position','department','qualification','phone'):
            return 'staff:'+parts[1]+':'+parts[2]
    return ''


def mapping_value(mapping, venue, now=None, staff=None):
    if mapping.startswith('staff:'):
        parts=mapping.split(':')
        from staff_store import ROLE_NAMES, ATTRS
        if len(parts)!=3 or parts[1] not in ROLE_NAMES or parts[2] not in ATTRS:
            raise ValueError('Некорректная привязка сотрудника: '+mapping)
        return str((staff or {}).get(parts[1],{}).get(parts[2],'') or '')
    if mapping == 'today':
        return (now or datetime.now()).strftime('%d.%m.%Y')
    if mapping.startswith('field:') and mapping[6:] in VENUE_FIELDS:
        return str(venue.get(mapping[6:], '') or '')
    if mapping.startswith('extra:') and mapping[6:]:
        return str((venue.get('extra') or {}).get(mapping[6:], '') or '')
    if mapping.startswith('literal:'):
        return mapping[8:]
    raise ValueError('Неподдерживаемая привязка поля: ' + mapping)


def _replace_range(par, begin, end, value):
    """Replace range across runs, keeping the first run's formatting.
    Other run formatting and all surrounding text is retained.
    """
    runs = par.runs
    starts = []
    total = 0
    for run in runs:
        starts.append(total)
        total += len(run.text)
    first = next(i for i, st in enumerate(starts) if st <= begin < st + len(runs[i].text))
    last = next(i for i, st in enumerate(starts) if st < end <= st + len(runs[i].text))
    a, b = begin - starts[first], end - starts[last]
    if first == last:
        r = runs[first]
        r.text = r.text[:a] + value + r.text[b:]
    else:
        prefix = runs[first].text[:a]
        suffix = runs[last].text[b:]
        runs[first].text = prefix + value
        for i in range(first + 1, last):
            runs[i].text = ''
        runs[last].text = suffix


def fill_docx(source, output, venue, mapping, *, now=None, staff=None):
    """Fill only mapped fields; return unresolved tokens as a review list."""
    doc = Document(str(source))
    unresolved = set()
    for par in walk_paragraphs(doc):
        text = ''.join(run.text for run in par.runs)
        for match in reversed(list(TOKEN.finditer(text))):
            token = match.group(1).strip()
            rule = mapping.get(token, '')
            if not rule:
                unresolved.add(token)
                continue
            value = mapping_value(rule, venue, now=now, staff=staff)
            _replace_range(par, match.start(), match.end(), value)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if Path(source).resolve() == output.resolve():
        raise ValueError('Нельзя перезаписывать исходный шаблон')
    doc.save(str(output))
    return sorted(unresolved)


def _find_soffice():
    exe = shutil.which('soffice') or shutil.which('libreoffice')
    if exe: return exe
    if os.name == 'nt':
        for root in (os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)')):
            if root:
                candidate = Path(root) / 'LibreOffice' / 'program' / 'soffice.exe'
                if candidate.is_file():return str(candidate)
    return None


def convert_docx_to_pdf(docx_file, pdf_file):
    """Offline conversion, using installed LibreOffice or MS Word.

    Word/LibreOffice are NOT required to import or export DOCX; only for
    exact-layout PDF conversion of arbitrary user-supplied templates.
    """
    docx_file = Path(docx_file).resolve()
    pdf_file = Path(pdf_file).resolve()
    pdf_file.parent.mkdir(parents=True, exist_ok=True)
    soffice = _find_soffice()
    with tempfile.TemporaryDirectory(prefix='moolva-pdf-') as td:
        work = Path(td)
        candidate = work / 'converted.pdf'
        if soffice:
            # Separate LibreOffice profile avoids conflicts with interactive sessions.
            profile = (work / 'lo-profile').as_uri()
            result = subprocess.run([soffice, '-env:UserInstallation=' + profile,
                     '--headless','--convert-to','pdf:writer_pdf_Export',
                     '--outdir',str(work),str(docx_file)],
                     capture_output=True,text=True,timeout=90)
            created = work / (docx_file.stem + '.pdf')
            if result.returncode or not created.exists():
                raise RuntimeError('LibreOffice не смог создать PDF: ' + (result.stderr or result.stdout)[-500:])
            shutil.copy2(created, candidate)
        elif os.name == 'nt':
            # Use locally installed Microsoft Word via COM without pywin32 dependency.
            powershell = shutil.which('powershell.exe') or shutil.which('powershell')
            if not powershell:
                raise RuntimeError('Для PDF по произвольному Word-шаблону нужен Microsoft Word или LibreOffice')
            import base64
            # Base64 UTF-8 paths prevent PowerShell escaping / injection problems.
            inp = base64.b64encode(str(docx_file).encode('utf-8')).decode('ascii')
            out = base64.b64encode(str(candidate).encode('utf-8')).decode('ascii')
            script = """$ErrorActionPreference='Stop'
$src=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('%s'))
$dst=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('%s'))
$word=$null; $doc=$null
try {
  $word=New-Object -ComObject Word.Application
  $word.Visible=$false; $word.DisplayAlerts=0
  $doc=$word.Documents.Open($src,$false,$true,$false)
  $doc.ExportAsFixedFormat($dst,17)
} finally {
  if($null -ne $doc){$doc.Close($false)}
  if($null -ne $word){$word.Quit()}
}
""" % (inp,out)
            script_path = work / 'convert.ps1'
            script_path.write_text(script,encoding='utf-8-sig')
            proc = subprocess.run([powershell,'-NoProfile','-NonInteractive','-File',str(script_path)],
                                  capture_output=True,text=True,timeout=100)
            if proc.returncode != 0 or not candidate.exists():
                raise RuntimeError('PDF требует установленного Microsoft Word или LibreOffice: ' + proc.stderr[-500:])
        else:
            raise RuntimeError('Для экспорта PDF по Word-шаблону установите LibreOffice')
        if candidate.stat().st_size < 50 or candidate.read_bytes()[:4] != b'%PDF':
            raise RuntimeError('PDF повреждён или не создан')
        os.replace(candidate, pdf_file) if pdf_file.parent==work else shutil.copy2(candidate,pdf_file)
    return pdf_file
