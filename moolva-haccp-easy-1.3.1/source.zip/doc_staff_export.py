"""Optional signatory and responsibility sections for built-in and imported DOCX/PDF."""
from roles_catalog import HACCP
from staff_store import ROLES


def add_docx_signatories(doc, config):
    persons=config.get('people',{})
    selected=[(label,persons.get(role)) for role,label in ROLES if persons.get(role)]
    if not selected:return
    doc.add_paragraph('Разработал / согласовал / утвердил').runs[0].bold=True
    tbl=doc.add_table(rows=0,cols=3)
    tbl.style='Table Grid'
    for label,person in selected:
        cells=tbl.add_row().cells
        cells[0].text=label
        cells[1].text=person['full_name'] + '\n' + person['position_name']
        cells[2].text='Подпись: __________    Дата: __________'




def add_docx_ack_sheet(doc,employees):
    if not employees:return
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    doc.add_page_break()
    title=doc.add_heading('Лист ознакомления с журналом',level=1)
    title.alignment=WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph('Работники, ознакомившиеся с настоящим журналом, подтверждают факт ознакомления личной подписью и указывают фактическую дату.')
    table=doc.add_table(rows=1,cols=6);table.style='Table Grid'
    labels=('№','ФИО сотрудника','Должность','Подразделение','Дата ознакомления','Личная подпись')
    for cell,label in zip(table.rows[0].cells,labels):cell.text=label
    trPr=table.rows[0]._tr.get_or_add_trPr();head=OxmlElement('w:tblHeader');head.set(qn('w:val'),'true');trPr.append(head)
    for idx,person in enumerate(employees,1):
        row=table.add_row().cells
        for cell,value in zip(row,[str(idx),person['full_name'],person['position_name'],person.get('department',''),'__________','____________']):cell.text=value
    for row in table.rows:
        for cell in row.cells:
            for par in cell.paragraphs:
                for run in par.runs:run.font.size=Pt(8)
    doc.add_paragraph('ФИО и должности заполнены автоматически из справочника сотрудников. Даты и подписи программа не подставляет.').runs[0].italic=True

def add_docx_appendix(doc,rows):
    if not rows:return
    doc.add_page_break()
    doc.add_heading('Приложение. Обязанности и требования по ХАССП',level=1)
    doc.add_paragraph('Информационные рекомендации для согласования с ответственным специалистом. '
        'Не являются утверждённой должностной инструкцией. Указанное ФИО не является подписью.')
    for x in rows:
        doc.add_heading(x['name']+' — '+x['position'],level=2)
        doc.add_paragraph('Назначение в документе: '+x['role'])
        if x['duties']:
            doc.add_paragraph('Типовые обязанности:').runs[0].bold=True
            for duty in x['duties']:doc.add_paragraph(duty,style='List Bullet')
        if x['requirements']:
            doc.add_paragraph('Требования по пищевой безопасности / ХАССП:').runs[0].bold=True
            for req in x['requirements']:doc.add_paragraph(req,style='List Bullet')
        doc.add_paragraph('Источник: '+x['source'][0]+(' — '+x['source'][1] if x['source'][1] else ''))
    doc.add_paragraph('Общая основа: ТР ТС 021/2011, ст. 10 — '+HACCP)


def append_docx_staff(path,config,rows,has_staff_fields=False,ack_employees=None):
    if not rows and not ack_employees and (has_staff_fields or not any(config.get('people',{}).values())):
        return path
    from docx import Document
    doc=Document(str(path))
    if not has_staff_fields:add_docx_signatories(doc,config)
    add_docx_ack_sheet(doc,ack_employees or [])
    add_docx_appendix(doc,rows)
    doc.save(str(path))
    return path


def pdf_staff_additions(story,config,rows,doc,style,P,ack_employees=None):
    from reportlab.platypus import Table, TableStyle, Spacer, PageBreak, KeepTogether
    from reportlab.lib.colors import HexColor
    people=config.get('people',{})
    selected=[(label,people.get(role)) for role,label in ROLES if people.get(role)]
    # Signatory section appended after main journal to avoid disrupting wide tables.
    if selected:
        story += [Spacer(1,8),P('Разработал / согласовал / утвердил')]
        data=[[P(lbl),P(emp['full_name']+'\n'+emp['position_name']),P('Подпись: ________  Дата: ________')]
              for lbl,emp in selected]
        tbl=Table(data,colWidths=[doc.width*.2,doc.width*.46,doc.width*.34],hAlign='LEFT')
        tbl.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.3,HexColor('#BDC7D0')),
                                 ('VALIGN',(0,0),(-1,-1),'TOP')]))
        story.append(tbl)
    if ack_employees:
        story.append(PageBreak())
        story.append(P('ЛИСТ ОЗНАКОМЛЕНИЯ С ЖУРНАЛОМ'))
        story.append(P('ФИО и должности заполнены из справочника. Даты и личные подписи указываются работниками.'))
        cols=['№','ФИО сотрудника','Должность','Подразделение','Дата ознакомления','Личная подпись']
        data=[[P(t) for t in cols]]
        for number,person in enumerate(ack_employees,1):
            data.append([P(str(number)),P(person['full_name']),P(person['position_name']),
                         P(person.get('department','')),P('________'),P('__________')])
        acktable=Table(data,colWidths=[doc.width*.05,doc.width*.23,doc.width*.24,doc.width*.18,doc.width*.15,doc.width*.15],repeatRows=1)
        acktable.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#DFEAF4')),
            ('GRID',(0,0),(-1,-1),.3,HexColor('#A4B4C2')),('VALIGN',(0,0),(-1,-1),'TOP'),
            ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        story.extend([Spacer(1,7),acktable])
    if rows:
        story.append(PageBreak())
        story.append(P('ПРИЛОЖЕНИЕ: ОБЯЗАННОСТИ И ТРЕБОВАНИЯ ПО ХАССП'))
        story.append(P('Информационные рекомендации, не утверждённые должностные инструкции.'))
        for item in rows:
            chunk=[P(item['name']+' — '+item['position']),P('Роль: '+item['role'])]
            if item['duties']:
                chunk.append(P('Типовые обязанности:'))
                for line in item['duties']:chunk.append(P('• '+line))
            if item['requirements']:
                chunk.append(P('Требования по ХАССП:'))
                for line in item['requirements']:chunk.append(P('• '+line))
            chunk.append(P('Источник: '+item['source'][0]+' — '+item['source'][1]))
            story.extend([KeepTogether(chunk[:2]),*chunk[2:],Spacer(1,8)])
        story.append(P('Основа: ТР ТС 021/2011, ст. 10 — '+HACCP))
