"""Редактируемый план ХАССП с изолированными редакциями и проверкой полноты.

Только специалист решает, является ли этап ККТ, и указывает верифицированные
критические пределы. Никаких автоматически «утверждённых» заключений.
"""
from copy import deepcopy
from datetime import datetime
import json
import sqlite3

from storage import now

PLAN_FIELDS = ('title','product','product_description','intended_use','materials','equipment',
               'packaging','storage_conditions','shelf_life','team','flow_verified_by',
               'flow_verified_at','validation','verification','prerequisites','notes')
STEP_FIELDS = ('name','inputs','outputs','equipment','description')
HAZARD_FIELDS = ('hazard_type','description','likelihood','severity','significant','justification',
                 'control_measure','ccp_status','ccp_reason','critical_limit','limit_basis',
                 'monitor_what','monitor_how','monitor_frequency','monitor_who',
                 'corrective_action','product_disposition','verification','journal_code')
DEFAULT_HAZARD = {'hazard_type':'Биологический','likelihood':0,'severity':0,
                  'significant':'Не оценено','ccp_status':'Не определено'}
HAZARD_TYPES = ('Биологический','Химический','Физический','Аллергенный','Другой')
SIGNIFICANCE = ('Не оценено','Да','Нет')
CCP_STATUSES = ('Не определено','ККТ','Не ККТ')

# Последовательность ориентировочная, без заданных параметров и автоматически назначенных ККТ.
TYPICAL_STEPS = (
    ('Входной контроль сырья и сопроводительных документов','receiving'),
    ('Приёмка сырого молока','raw_milk'),
    ('Приёмка сырья животного происхождения','meat'),
    ('Прослеживаемость партий сырья','trace'),
    ('Складирование сырья','storage'),
    ('Холодильное / морозильное хранение','cold'),
    ('Убой и первичная переработка','slaughter'),
    ('Разделка мяса / производство полуфабрикатов','meat_processing'),
    ('Подготовка мяса птицы','poultry'),
    ('Переработка яиц','egg'),
    ('Разделка и подготовка рыбы','fish'),
    ('Переработка морепродуктов','seafood'),
    ('Подготовка овощей / фруктов','fruit_veg'),
    ('Подготовка ингредиентов','allergens'),
    ('Просеивание / фильтрация','sieve'),
    ('Зернопереработка / помол','grain'),
    ('Приготовление теста / выпечка','bakery'),
    ('Расстойка / выпечка','bakery_oven'),
    ('Производство кондитерских изделий','confectionery'),
    ('Какао / шоколадные операции','chocolate'),
    ('Производство макаронных изделий','pasta'),
    ('Снеки / экструзия','snacks'),
    ('Производство молочной продукции','dairy'),
    ('Сыроделие / созревание','cheese'),
    ('Пастеризация','pasteurize'),
    ('Промышленная термообработка','heat_process'),
    ('Термическое приготовление блюд','cook'),
    ('Стерилизация / автоклавирование','sterilize'),
    ('Брожение / ферментация','ferment'),
    ('Копчение рыбы / мяса','fish_smoke'),
    ('Производство мороженого','icecream'),
    ('Производство напитков','beverage'),
    ('Производство соков','juice'),
    ('Пивоварение / изготовление кваса','brewing'),
    ('Соление / квашение / маринование','pickling'),
    ('Производство соусов','sauce'),
    ('Масложировые операции','oils'),
    ('Производство сахара','sugar'),
    ('Изготовление крахмала','starch'),
    ('Переработка орехов / семян','nuts'),
    ('Приёмка / переработка мёда','honey'),
    ('Приправы / специи','spices'),
    ('Пищевые добавки / ингредиенты','additives'),
    ('Производство специализированного питания','special_food'),
    ('Производство детского питания','baby_food'),
    ('Охлаждение продукции','cool_down'),
    ('Замораживание','freeze'),
    ('Сушка / обезвоживание','dry'),
    ('Контроль на металлодетекторе','metal'),
    ('Фасовка / упаковка','package'),
    ('Розлив / укупорка','bottling'),
    ('Маркировка','labels'),
    ('Контроль сроков годности / условий хранения','test_life'),
    ('Хранение / реализация продукции','retail'),
    ('Оптовое складирование','wholesale'),
    ('Хранение / отпуск горячих блюд','hot_hold'),
    ('Приготовление во фритюре','fryer'),
    ('Отгрузка / доставка продукции','delivery'),
)



def recommended_flow(flags):
    """Схема ДЛЯ УТОЧНЕНИЯ, не утверждённая технологическая схема."""
    flow = ['Приёмка сырья']
    if any(flags.get(k) for k in ('storage','cold')):
        flow.append('Хранение сырья')
    for name, key in TYPICAL_STEPS:
        if key in ('receiving','storage'):
            continue  # входной контроль и хранение добавляем отдельными основными этапами
        if name not in flow and flags.get(key):
            flow.append(name)
    if len(flow) == 1:
        flow.append('Основной технологический процесс (уточнить)')
    if not any('Отгрузка' in s or 'Транспортировка' in s for s in flow):
        flow.append('Передача готовой продукции / отгрузка (уточнить)')
    return flow


def _clean_text(v):
    return str(v or '').strip()


def _as_bool_int(v):
    try:
        v = int(v)
    except (ValueError, TypeError):
        raise ValueError('Оценка должна быть от 0 до 5')
    if not 0 <= v <= 5:
        raise ValueError('Оценка должна быть от 0 до 5')
    return v


class HACCPPlans:
    def __init__(self, store):
        self.store = store
        self._initialize()

    def _initialize(self):
        with self.store.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS haccp_plans (
                    id INTEGER PRIMARY KEY, venue_id INTEGER NOT NULL REFERENCES venues(id),
                    title TEXT NOT NULL, product TEXT NOT NULL DEFAULT '',
                    product_description TEXT NOT NULL DEFAULT '', intended_use TEXT NOT NULL DEFAULT '',
                    materials TEXT NOT NULL DEFAULT '', equipment TEXT NOT NULL DEFAULT '',
                    packaging TEXT NOT NULL DEFAULT '', storage_conditions TEXT NOT NULL DEFAULT '',
                    shelf_life TEXT NOT NULL DEFAULT '', team TEXT NOT NULL DEFAULT '',
                    flow_verified_by TEXT NOT NULL DEFAULT '', flow_verified_at TEXT NOT NULL DEFAULT '',
                    validation TEXT NOT NULL DEFAULT '', verification TEXT NOT NULL DEFAULT '',
                    prerequisites TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
                    revision INTEGER NOT NULL DEFAULT 1, state TEXT NOT NULL DEFAULT 'Черновик',
                    approved_by TEXT NOT NULL DEFAULT '', approved_at TEXT NOT NULL DEFAULT '',
                    approved_snapshot TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS haccp_steps (
                    id INTEGER PRIMARY KEY, plan_id INTEGER NOT NULL REFERENCES haccp_plans(id) ON DELETE CASCADE,
                    position INTEGER NOT NULL, name TEXT NOT NULL, inputs TEXT NOT NULL DEFAULT '',
                    outputs TEXT NOT NULL DEFAULT '', equipment TEXT NOT NULL DEFAULT '',
                    description TEXT NOT NULL DEFAULT '');
                CREATE INDEX IF NOT EXISTS idx_haccp_steps ON haccp_steps(plan_id,position,id);
                CREATE TABLE IF NOT EXISTS haccp_hazards (
                    id INTEGER PRIMARY KEY, step_id INTEGER NOT NULL REFERENCES haccp_steps(id) ON DELETE CASCADE,
                    hazard_type TEXT NOT NULL DEFAULT 'Биологический', description TEXT NOT NULL DEFAULT '',
                    likelihood INTEGER NOT NULL DEFAULT 0, severity INTEGER NOT NULL DEFAULT 0,
                    significant TEXT NOT NULL DEFAULT 'Не оценено', justification TEXT NOT NULL DEFAULT '',
                    control_measure TEXT NOT NULL DEFAULT '', ccp_status TEXT NOT NULL DEFAULT 'Не определено',
                    ccp_reason TEXT NOT NULL DEFAULT '', critical_limit TEXT NOT NULL DEFAULT '',
                    limit_basis TEXT NOT NULL DEFAULT '', monitor_what TEXT NOT NULL DEFAULT '',
                    monitor_how TEXT NOT NULL DEFAULT '', monitor_frequency TEXT NOT NULL DEFAULT '',
                    monitor_who TEXT NOT NULL DEFAULT '', corrective_action TEXT NOT NULL DEFAULT '',
                    product_disposition TEXT NOT NULL DEFAULT '', verification TEXT NOT NULL DEFAULT '',
                    journal_code TEXT NOT NULL DEFAULT '');
                CREATE TABLE IF NOT EXISTS haccp_plan_events (
                    id INTEGER PRIMARY KEY, plan_id INTEGER NOT NULL, event TEXT NOT NULL,
                    details TEXT NOT NULL, at TEXT NOT NULL);
            ''')
            # Инкрементальная добавка к БД v0.2: прежние таблицы не перестраиваются.
            if db.execute('PRAGMA user_version').fetchone()[0] < 3:
                db.execute('PRAGMA user_version=3')

    def _event(self, db, plan_id, event, details=None):
        db.execute('INSERT INTO haccp_plan_events(plan_id,event,details,at) VALUES (?,?,?,?)',
                   (plan_id, event, json.dumps(details or {}, ensure_ascii=False), now()))

    def list_plans(self, venue_id):
        with self.store.connect() as db:
            return [dict(r) for r in db.execute('''SELECT id,title,product,revision,state,updated_at
                 FROM haccp_plans WHERE venue_id=? ORDER BY id DESC''', (venue_id,))]

    def get_plan(self, plan_id):
        with self.store.connect() as db:
            row = db.execute('SELECT * FROM haccp_plans WHERE id=?', (plan_id,)).fetchone()
            return dict(row) if row else None

    def details(self, plan_id, *, frozen=False):
        plan = self.get_plan(plan_id)
        if not plan:
            raise ValueError('План не найден')
        if frozen and plan['state'] == 'Утверждён':
            return json.loads(plan['approved_snapshot'])
        with self.store.connect() as db:
            steps = []
            for row in db.execute('SELECT * FROM haccp_steps WHERE plan_id=? ORDER BY position,id', (plan_id,)):
                item = dict(row)
                item['hazards'] = [dict(x) for x in db.execute('SELECT * FROM haccp_hazards WHERE step_id=? ORDER BY id', (item['id'],))]
                steps.append(item)
        return {'plan':plan, 'venue':self.store.get_venue(plan['venue_id']), 'steps':steps}

    def _draft(self, plan_id):
        plan = self.get_plan(plan_id)
        if not plan:
            raise ValueError('План не найден')
        if plan['state'] != 'Черновик':
            raise ValueError('Утверждённая редакция защищена. Создайте новую редакцию.')
        return plan

    def create_plan(self, venue_id, title='Новый план ХАССП'):
        if not self.store.get_venue(venue_id):
            raise ValueError('Предприятие не найдено')
        title = _clean_text(title)
        if not title:
            raise ValueError('Укажите название плана')
        with self.store.connect() as db:
            cur = db.execute('''INSERT INTO haccp_plans(venue_id,title,created_at,updated_at)
                VALUES(?,?,?,?)''', (venue_id,title,now(),now()))
            plan_id=cur.lastrowid
            self._event(db,plan_id,'created')
            self.store._audit(db,venue_id,'haccp_plan_created',{'plan_id':plan_id})
        return plan_id

    def update_plan(self, plan_id, fields):
        p=self._draft(plan_id)
        allowed={k:_clean_text(v) for k,v in fields.items() if k in PLAN_FIELDS}
        if not allowed:
            return
        if 'title' in allowed and not allowed['title']:
            raise ValueError('Название плана не может быть пустым')
        with self.store.connect() as db:
            db.execute('UPDATE haccp_plans SET '+','.join(f'{k}=?' for k in allowed)+',updated_at=? WHERE id=?',
                       (*allowed.values(),now(),plan_id))
            self._event(db,plan_id,'plan_updated',{'fields':list(allowed)})

    def add_step(self, plan_id, name, **fields):
        self._draft(plan_id)
        name=_clean_text(name)
        if not name:
            raise ValueError('Укажите этап')
        fields={k:_clean_text(fields.get(k,'')) for k in STEP_FIELDS if k!='name'}
        with self.store.connect() as db:
            pos = db.execute('SELECT COALESCE(MAX(position),0)+1 FROM haccp_steps WHERE plan_id=?', (plan_id,)).fetchone()[0]
            cur=db.execute('''INSERT INTO haccp_steps(plan_id,position,name,inputs,outputs,equipment,description)
                            VALUES(?,?,?,?,?,?,?)''', (plan_id,pos,name,*fields.values()))
            self._event(db,plan_id,'step_created',{'id':cur.lastrowid,'name':name})
            return cur.lastrowid

    def update_step(self, plan_id, step_id, **fields):
        self._draft(plan_id)
        fields={k:_clean_text(v) for k,v in fields.items() if k in STEP_FIELDS}
        if not fields:
            return
        if fields.get('name') == '':
            raise ValueError('Название этапа не может быть пустым')
        with self.store.connect() as db:
            cur=db.execute('UPDATE haccp_steps SET '+','.join(f'{k}=?' for k in fields)+' WHERE plan_id=? AND id=?',
                           (*fields.values(),plan_id,step_id))
            if cur.rowcount != 1:
                raise ValueError('Этап не принадлежит плану')
            self._event(db,plan_id,'step_updated',{'id':step_id})

    def move_step(self, plan_id, step_id, direction):
        self._draft(plan_id)
        if direction not in (-1,1):
            raise ValueError('Неверное направление')
        with self.store.connect() as db:
            ids=[r['id'] for r in db.execute('SELECT id FROM haccp_steps WHERE plan_id=? ORDER BY position,id',(plan_id,))]
            if step_id not in ids:
                raise ValueError('Этап не найден')
            i=ids.index(step_id)
            j=i+direction
            if j<0 or j>=len(ids):
                return
            ids[i],ids[j]=ids[j],ids[i]
            for pos,sid in enumerate(ids,1):
                db.execute('UPDATE haccp_steps SET position=? WHERE id=?',(pos,sid))
            self._event(db,plan_id,'step_reordered',{'id':step_id,'direction':direction})

    def delete_step(self, plan_id, step_id):
        self._draft(plan_id)
        with self.store.connect() as db:
            cur=db.execute('DELETE FROM haccp_steps WHERE id=? AND plan_id=?',(step_id,plan_id))
            if not cur.rowcount:
                raise ValueError('Этап не найден')
            self._event(db,plan_id,'step_deleted',{'id':step_id})

    def seed_steps(self, plan_id):
        p=self._draft(plan_id)
        if self.details(plan_id)['steps']:
            raise ValueError('Чтобы загрузить пример схемы, этапы плана должны быть пустыми')
        flow=recommended_flow(self.store.get_venue(p['venue_id']).get('flags') or {})
        for name in flow:
            self.add_step(plan_id,name)
        return len(flow)

    def add_hazard(self, plan_id, step_id, fields):
        self._draft(plan_id)
        with self.store.connect() as db:
            step=db.execute('SELECT id FROM haccp_steps WHERE plan_id=? AND id=?',(plan_id,step_id)).fetchone()
            if not step:
                raise ValueError('Этап не принадлежит плану')
            values={k:fields.get(k,DEFAULT_HAZARD.get(k,'')) for k in HAZARD_FIELDS}
            values=self._validate_hazard(values)
            cur=db.execute('INSERT INTO haccp_hazards(step_id,'+','.join(values)+') VALUES(?,'+','.join('?' for _ in values)+')',
                           (step_id,*values.values()))
            self._event(db,plan_id,'hazard_added',{'id':cur.lastrowid,'step_id':step_id})
            return cur.lastrowid

    def _validate_hazard(self, fields):
        result={k:(_as_bool_int(fields[k]) if k in ('likelihood','severity') else _clean_text(fields[k]))
                for k in HAZARD_FIELDS}
        if result['hazard_type'] not in HAZARD_TYPES or result['significant'] not in SIGNIFICANCE or result['ccp_status'] not in CCP_STATUSES:
            raise ValueError('Некорректная категория опасности, значимость или статус ККТ')
        if not result['description']:
            raise ValueError('Опишите опасный фактор')
        return result

    def update_hazard(self,plan_id,hazard_id,fields):
        self._draft(plan_id)
        with self.store.connect() as db:
            r=db.execute('''SELECT h.* FROM haccp_hazards h JOIN haccp_steps s ON s.id=h.step_id
                          WHERE h.id=? AND s.plan_id=?''',(hazard_id,plan_id)).fetchone()
            if not r:
                raise ValueError('Опасный фактор не найден')
            data={k:fields.get(k,r[k]) for k in HAZARD_FIELDS}
            validated=self._validate_hazard(data)
            db.execute('UPDATE haccp_hazards SET '+','.join(f'{k}=?' for k in validated)+' WHERE id=?',
                       (*validated.values(),hazard_id))
            self._event(db,plan_id,'hazard_updated',{'id':hazard_id})

    def delete_hazard(self,plan_id,hazard_id):
        self._draft(plan_id)
        with self.store.connect() as db:
            cur=db.execute('DELETE FROM haccp_hazards WHERE id=? AND step_id IN (SELECT id FROM haccp_steps WHERE plan_id=?)',
                           (hazard_id,plan_id))
            if not cur.rowcount:
                raise ValueError('Опасный фактор не найден')
            self._event(db,plan_id,'hazard_deleted',{'id':hazard_id})

    def validation_errors(self, plan_id):
        data=self.details(plan_id)
        p=data['plan']
        errors=[]
        labels={'product':'Название продукта / группы продукции',
            'product_description':'Описание продукта', 'intended_use':'Назначение и потребитель',
            'materials':'Сырьё и ингредиенты','equipment':'Оборудование',
            'prerequisites':'Предварительные программы (GHP/PRP)',
            'team':'Состав группы ХАССП','flow_verified_by':'Кто проверил схему на месте',
            'flow_verified_at':'Дата проверки схемы','validation':'Обоснование / валидация мер',
            'verification':'Процедура проверки эффективности'}
        for key,label in labels.items():
            if not p[key].strip():
                errors.append('Заполните: '+label)
        if p['flow_verified_at'].strip():
            try:
                datetime.strptime(p['flow_verified_at'], '%d.%m.%Y')
            except ValueError:
                errors.append('Дата проверки схемы должна быть в формате ДД.ММ.ГГГГ')
        if not data['steps']:
            errors.append('Добавьте этапы технологической схемы')
        for step in data['steps']:
            if not step['hazards']:
                errors.append(f"Этап «{step['name']}»: оцените опасности (при отсутствии — зафиксируйте обоснование через запись)")
            for h in step['hazards']:
                label=f"Этап «{step['name']}», опасность «{h['description'][:45]}»"
                if not h['likelihood'] or not h['severity']:
                    errors.append(label+': оцените вероятность и тяжесть (1–5)')
                if h['significant']=='Не оценено' or not h['justification'].strip():
                    errors.append(label+': обоснуйте значимость опасности')
                if not h['control_measure'].strip():
                    errors.append(label+': укажите меры управления / причину отсутствия')
                if h['ccp_status']=='Не определено' or not h['ccp_reason'].strip():
                    errors.append(label+': вручную определите статус ККТ и обоснуйте')
                if h['ccp_status']=='ККТ' and h['significant']=='Нет':
                    errors.append(label+': нельзя помечать опасность как несущественную при решении «ККТ» без пересмотра оценки')
                if h['ccp_status']=='ККТ':
                    required={'critical_limit':'проверенный критический предел',
                      'limit_basis':'источник обоснования критического предела',
                      'monitor_what':'что контролировать','monitor_how':'метод мониторинга',
                      'monitor_frequency':'частоту мониторинга','monitor_who':'ответственного',
                      'corrective_action':'корректирующие действия',
                      'product_disposition':'действия с затронутой продукцией',
                      'verification':'верификацию ККТ'}
                    for key,label2 in required.items():
                        if not h[key].strip():
                            errors.append(label+': укажите '+label2)
        return errors

    def approve(self,plan_id,approver):
        p=self._draft(plan_id)
        approver=_clean_text(approver)
        if len(approver)<3:
            raise ValueError('Укажите ФИО утверждающего')
        errors=self.validation_errors(plan_id)
        if errors:
            raise ValueError('План нельзя утвердить:\n'+'\n'.join(errors[:18]))
        snapshot=self.details(plan_id)
        stamp=now()
        snapshot['plan']['state']='Утверждён'
        snapshot['plan']['approved_by']=approver
        snapshot['plan']['approved_at']=stamp
        snapshot['plan']['approved_snapshot']=''
        with self.store.connect() as db:
            db.execute('''UPDATE haccp_plans SET state='Утверждён',approved_by=?,approved_at=?,
                          approved_snapshot=?,updated_at=? WHERE id=?''',
                       (approver,stamp,json.dumps(snapshot,ensure_ascii=False),stamp,plan_id))
            self._event(db,plan_id,'approved',{'person':approver,'revision':p['revision']})
            self.store._audit(db,p['venue_id'],'haccp_plan_approved',{'plan_id':plan_id,'revision':p['revision']})

    def clone_revision(self,plan_id):
        p=self.get_plan(plan_id)
        if not p or p['state']!='Утверждён':
            raise ValueError('Новую редакцию можно создать только из утверждённой')
        original=self.details(plan_id,frozen=True)
        new_id=self.create_plan(p['venue_id'],p['title'])
        self.update_plan(new_id,{k:p[k] for k in PLAN_FIELDS})
        with self.store.connect() as db:
            db.execute('UPDATE haccp_plans SET revision=? WHERE id=?',(p['revision']+1,new_id))
            self._event(db,new_id,'revision_from',{'source_id':plan_id})
        for step in original['steps']:
            sid=self.add_step(new_id,step['name'],**{k:step[k] for k in STEP_FIELDS if k!='name'})
            for hazard in step['hazards']:
                self.add_hazard(new_id,sid,{k:hazard[k] for k in HAZARD_FIELDS})
        return new_id

    def events(self,plan_id):
        with self.store.connect() as db:
            return [dict(r) for r in db.execute('SELECT * FROM haccp_plan_events WHERE plan_id=? ORDER BY id',(plan_id,))]
