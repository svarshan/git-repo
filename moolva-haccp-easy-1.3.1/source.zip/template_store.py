"""Safe imported DOCX template registry, scoped to a single enterprise."""
from __future__ import annotations
from pathlib import Path
import hashlib
import json
import os
import shutil
import tempfile
import uuid
import zipfile
from template_engine import tokens_from_docx, default_mapping, fill_docx, convert_docx_to_pdf, mapping_value
from storage import app_data_dir, now

MAX_DOCX_SIZE = 32 * 1024 * 1024
MAX_UNCOMPRESSED = 130 * 1024 * 1024
MAX_ZIP_ITEMS = 2000


def migrate_templates(store):
    with store.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS word_templates (
          id TEXT PRIMARY KEY,
          venue_id INTEGER NOT NULL REFERENCES venues(id),
          name TEXT NOT NULL,
          file_name TEXT NOT NULL,
          sha256 TEXT NOT NULL,
          fields_json TEXT NOT NULL,
          mapping_json TEXT NOT NULL,
          created_at TEXT NOT NULL,
          is_active INTEGER NOT NULL DEFAULT 1);
        CREATE INDEX IF NOT EXISTS idx_word_templates_venue ON word_templates(venue_id,is_active);
        ''')


def validate_docx(path):
    path=Path(path)
    if path.suffix.lower()!='.docx':
        raise ValueError('Выберите файл Word формата .docx (не .doc и не .docm)')
    if not path.is_file() or not 100 <= path.stat().st_size <= MAX_DOCX_SIZE:
        raise ValueError('Файл не найден или превышает ограничение 32 МБ')
    try:
        with zipfile.ZipFile(path) as archive:
            files=archive.infolist()
            names={z.filename for z in files}
            if len(files)>MAX_ZIP_ITEMS or sum(z.file_size for z in files)>MAX_UNCOMPRESSED:
                raise ValueError('Слишком большой или подозрительный документ')
            if 'word/document.xml' not in names or '[Content_Types].xml' not in names:
                raise ValueError('Некорректная структура Word-документа')
            if any(z.filename.lower().endswith(('vbaproject.bin','.exe','.dll')) for z in files):
                raise ValueError('Документ содержит запрещённые исполняемые вложения')
            if archive.testzip() is not None:
                raise ValueError('Повреждённый архив DOCX')
    except zipfile.BadZipFile as e:
        raise ValueError('Файл не является корректным DOCX') from e
    return path


def _template_path(store, file_name):
    return store.path.parent / 'word_templates' / file_name


def list_templates(store, venue_id, include_inactive=False):
    migrate_templates(store)
    with store.connect() as db:
        sql='SELECT * FROM word_templates WHERE venue_id=?'
        if not include_inactive: sql+=' AND is_active=1'
        sql+=' ORDER BY created_at DESC,id DESC'
        rows=db.execute(sql,(venue_id,)).fetchall()
    return [dict(r,fields=json.loads(r['fields_json']),mapping=json.loads(r['mapping_json'])) for r in rows]


def get_template(store, venue_id, template_id):
    for item in list_templates(store,venue_id):
        if item['id']==template_id:return item
    raise ValueError('Шаблон не найден для текущего предприятия')


def import_template(store, venue_id, source, name=None):
    migrate_templates(store)
    if store.get_venue(venue_id) is None:
        raise ValueError('Предприятие не найдено')
    source=validate_docx(source)
    fields=tokens_from_docx(source)
    if len(fields)>200:
        raise ValueError('В шаблоне слишком много различных полей (более 200)')
    doc_id=uuid.uuid4().hex
    target_name=doc_id+'.docx'
    target=_template_path(store,target_name)
    target.parent.mkdir(parents=True,exist_ok=True)
    checksum=hashlib.sha256(source.read_bytes()).hexdigest()
    mapping={field:default_mapping(field) for field in fields}
    filename=str(name or source.stem).strip()[:180]
    if not filename: raise ValueError('Введите название шаблона')
    # Transactional-ish: copy to temp first, rename, then commit metadata; on SQL failure remove file.
    temp=target.with_suffix('.tmp')
    try:
        shutil.copy2(source,temp)
        os.replace(temp,target)
        with store.connect() as db:
            db.execute('''INSERT INTO word_templates
                (id,venue_id,name,file_name,sha256,fields_json,mapping_json,created_at)
                VALUES (?,?,?,?,?,?,?,?)''',
                (doc_id,venue_id,filename,target_name,checksum,
                 json.dumps(fields,ensure_ascii=False),
                 json.dumps(mapping,ensure_ascii=False),now()))
            store._audit(db,venue_id,'word_template_imported',{'template_id':doc_id,'title':filename})
    except Exception:
        target.unlink(missing_ok=True)
        temp.unlink(missing_ok=True)
        raise
    return get_template(store,venue_id,doc_id)


def update_mapping(store, venue_id, template_id, values):
    template=get_template(store,venue_id,template_id)
    if set(values) != set(template['fields']):
        raise ValueError('Недопустимый набор полей')
    venue=store.get_venue(venue_id)
    for value in values.values():
        if not isinstance(value,str) or len(value)>3000:
            raise ValueError('Значение поля слишком длинное')
        if value:
            mapping_value(value,venue)
    with store.connect() as db:
        db.execute('UPDATE word_templates SET mapping_json=? WHERE id=? AND venue_id=?',
                   (json.dumps(values,ensure_ascii=False),template_id,venue_id))
        store._audit(db,venue_id,'word_template_mapped',{'template_id':template_id,'fields':list(values)})


def archive_template(store,venue_id,template_id):
    get_template(store,venue_id,template_id)
    with store.connect() as db:
        db.execute('UPDATE word_templates SET is_active=0 WHERE id=? AND venue_id=?',(template_id,venue_id))
        store._audit(db,venue_id,'word_template_archived',{'template_id':template_id})
    # Keep original .docx to preserve historical provenance.


def export_template(store,venue_id,template_id,output,fmt='docx'):
    template=get_template(store,venue_id,template_id)
    source=_template_path(store,template['file_name'])
    if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest()!=template['sha256']:
        raise ValueError('Исходный шаблон отсутствует или изменён. Восстановите резервную копию')
    venue=store.get_venue(venue_id)
    if not venue:raise ValueError('Предприятие не найдено')
    if fmt not in ('docx','pdf'):raise ValueError('Неизвестный формат экспорта')
    output=Path(output)
    if output.suffix.lower()!='.'+fmt:raise ValueError('Неверное расширение выходного файла')
    from staff_store import get_assignments, appendix_rows, list_acknowledgements, ROLES, ATTRS
    from doc_staff_export import append_docx_staff
    doc_key='word:'+template_id
    assignments=get_assignments(store,venue_id,doc_key)
    staff={}
    for role,label in ROLES:
        person=assignments['people'].get(role) or {}
        staff[role]={attr: str(person.get({'name':'full_name','position':'position_name'}.get(attr,attr),'') or '') for attr in ATTRS}
    # Important: a missing signatory should not yield a deceptively complete document.
    for token,rule in template['mapping'].items():
        if rule.startswith('staff:'):
            parts=rule.split(':')
            if not staff.get(parts[1],{}).get(parts[2]):
                raise ValueError('Назначьте сотрудника для поля '+token+' (роль '+parts[1]+')')
    with tempfile.TemporaryDirectory(prefix='moolva-export-') as temp:
        tmp=Path(temp)/'rendered.docx'
        unresolved=fill_docx(source,tmp,venue,template['mapping'],staff=staff)
        if unresolved:
            # Never publish a document with silently unfilled fields.
            raise ValueError('Настройте незаполненные поля: '+', '.join(unresolved[:12]))
        append_docx_staff(tmp,assignments,appendix_rows(store,venue_id,doc_key),
                          has_staff_fields=any(field.startswith('staff.') for field in template['fields']),
                          ack_employees=list_acknowledgements(store,venue_id,doc_key))
        output.parent.mkdir(parents=True,exist_ok=True)
        if fmt=='docx':
            shutil.copy2(tmp,output)
        else:
            convert_docx_to_pdf(tmp,output)
    with store.connect() as db:
        store._audit(db,venue_id,'word_template_exported',{'template_id':template_id,'format':fmt,'file':output.name})
    return output


def backup_project(store, target):
    """Atomic project backup: a consistent SQLite snapshot and immutable DOCXs."""
    migrate_templates(store)
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    sourcedir = (store.path.parent / 'word_templates').resolve()
    if target.resolve().parent == sourcedir:
        raise ValueError('Сохраните архив вне папки импортированных шаблонов')
    working = target.with_name(target.name + '.partial')
    try:
        with tempfile.TemporaryDirectory(prefix='moolva-full-backup-') as tmp:
            snapshot = Path(tmp) / 'haccp.sqlite3'
            store.backup(snapshot)
            with zipfile.ZipFile(working, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
                archive.write(snapshot, 'haccp.sqlite3')
                with store.connect() as db:
                    rows = db.execute('SELECT file_name, sha256 FROM word_templates').fetchall()
                for row in rows:
                    doc = _template_path(store, row['file_name'])
                    if not doc.is_file() or hashlib.sha256(doc.read_bytes()).hexdigest() != row['sha256']:
                        raise ValueError('Шаблон отсутствует или изменён. Полная копия не создана')
                    archive.write(doc, 'word_templates/' + row['file_name'])
            with zipfile.ZipFile(working) as archive:
                if archive.testzip() is not None:
                    raise RuntimeError('Не удалось проверить резервную копию')
            os.replace(working, target)
    finally:
        working.unlink(missing_ok=True)
    return target
