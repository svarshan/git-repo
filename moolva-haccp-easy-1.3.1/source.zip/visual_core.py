"""Read-only visual summaries for MoOLVa HACCP Easy 1.2.

These helpers visualize what is actually stored in the local database. They do not
certify HACCP compliance and never invent measurements, signatures or hazard data.
"""
from __future__ import annotations

from easy_core import selected
from staff_store import list_employees, get_assignments, list_acknowledgements
from haccp_core import HACCPPlans


def completion_summary(store, venue_id):
    """Return a transparent completion score for data entered in the app.

    The score is intentionally about *data completeness*, not legal or HACCP
    conformity. Each item has its own weight so the UI can explain the score.
    """
    if not venue_id:
        return {"score": 0, "completed": 0, "total": 100, "items": []}
    venue = store.get_venue(venue_id)
    if not venue:
        return {"score": 0, "completed": 0, "total": 100, "items": []}

    staff = list_employees(store, venue_id)
    docs = selected(store, venue_id)
    flags = venue.get("flags") or {}

    items = []
    def add(code, title, weight, ok, hint, step):
        items.append({"code": code, "title": title, "weight": weight,
                      "ok": bool(ok), "hint": hint, "step": step})

    name = str(venue.get("venue_name") or "").strip()
    card_fields = ("legal_name", "address", "director", "responsible")
    card_done = sum(bool(str(venue.get(k) or "").strip()) for k in card_fields)
    add("venue", "Карточка предприятия", 15,
        bool(name) and card_done >= 2,
        "Добавьте название и основные реквизиты объекта.", 2)
    add("processes", "Процессы и оборудование", 15,
        any(bool(v) for v in flags.values()),
        "Отметьте фактические операции и оборудование.", 3)
    add("staff", "Сотрудники", 15, bool(staff),
        "Добавьте работников и их должности.", 4)
    add("journals", "Комплект журналов", 15, bool(docs),
        "Выберите применимые журналы.", 5)

    roles_ok = False
    acks_ok = False
    if docs:
        role_hits = 0
        ack_hits = 0
        for t in docs:
            key = "journal:" + t.code
            ass = get_assignments(store, venue_id, key)
            people = ass.get("people", {})
            if people.get("responsible") or people.get("approved"):
                role_hits += 1
            if list_acknowledgements(store, venue_id, key):
                ack_hits += 1
        roles_ok = role_hits == len(docs)
        acks_ok = ack_hits == len(docs) if staff else True
    add("roles", "Ответственные", 15, roles_ok,
        "Назначьте ответственных для каждого выбранного журнала.", 7)
    add("acks", "Листы ознакомления", 10, acks_ok,
        "Отметьте работников, которые должны ознакомиться с журналами.", 7)

    # Actual records are optional in the workflow, so this contributes less.
    records_ok = False
    if docs:
        records_ok = any(store.list_records(venue_id, t.code) for t in docs)
    add("records", "Фактические записи", 5, records_ok,
        "При необходимости внесите реальные записи или оставьте бланки пустыми.", 6)

    # Presence of at least one HACCP plan is a visual indicator only.
    plans = HACCPPlans(store).list_plans(venue_id)
    add("haccp", "План ХАССП", 10, bool(plans),
        "При необходимости сформируйте и оцените план ХАССП.", 8)

    completed = sum(x["weight"] for x in items if x["ok"])
    total = sum(x["weight"] for x in items)
    score = round(completed * 100 / total) if total else 0
    return {"score": score, "completed": completed, "total": total, "items": items}


def journal_cards(store, venue_id):
    """Summaries for selected journals without changing anything."""
    result = []
    for t in selected(store, venue_id):
        key = "journal:" + t.code
        ass = get_assignments(store, venue_id, key)
        people = ass.get("people", {})
        acks = list_acknowledgements(store, venue_id, key)
        missing = []
        if not (people.get("responsible") or people.get("approved")):
            missing.append("нет ответственного")
        if not acks:
            missing.append("нет подписантов")
        if missing:
            state = "attention"
            state_text = "Нужно настроить"
        else:
            state = "ready"
            state_text = "Настроен"
        result.append({
            "code": t.code,
            "title": t.title,
            "state": state,
            "state_text": state_text,
            "missing": missing,
            "ack_count": len(acks),
            "include_duties": bool(ass.get("include_duties")),
            "include_requirements": bool(ass.get("include_requirements")),
            "has_responsible": bool(people.get("responsible")),
            "has_approved": bool(people.get("approved")),
        })
    return result


def risk_summary(store, venue_id):
    """Aggregate existing HACCP hazard scores into a 5x5 matrix.

    likelihood/severity values outside 1..5 are treated as not evaluated.
    """
    if not venue_id:
        return {"matrix": {}, "hazards": [], "evaluated": 0, "unevaluated": 0,
                "ccp": 0, "significant": 0, "plans": 0}
    model = HACCPPlans(store)
    plans = model.list_plans(venue_id)
    hazards = []
    for p in plans:
        try:
            details = model.details(p["id"], frozen=p.get("state") == "Утверждён")
        except Exception:
            continue
        for step in details.get("steps", []):
            for h in step.get("hazards", []):
                item = dict(h)
                item["plan_id"] = p["id"]
                item["plan_title"] = p.get("title", "")
                item["step_name"] = step.get("name", "")
                hazards.append(item)
    matrix = {}
    evaluated = 0
    unevaluated = 0
    for h in hazards:
        try:
            l = int(h.get("likelihood") or 0)
            s = int(h.get("severity") or 0)
        except (TypeError, ValueError):
            l = s = 0
        if 1 <= l <= 5 and 1 <= s <= 5:
            evaluated += 1
            matrix.setdefault((l, s), []).append(h)
        else:
            unevaluated += 1
    return {
        "matrix": matrix,
        "hazards": hazards,
        "evaluated": evaluated,
        "unevaluated": unevaluated,
        "ccp": sum(h.get("ccp_status") == "ККТ" for h in hazards),
        "significant": sum(h.get("significant") == "Да" for h in hazards),
        "plans": len(plans),
    }
