"""A practical visual Word editor inside Easy, limited to paragraphs/table cells.

Existing pictures, sections and Word styles remain in the DOCX package; complex
Word layout is previewed approximately, not as a pixel-identical MS Word render.
"""
from __future__ import annotations
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from word_editor_core import (open_word_document,document_blocks,replace_paragraph,
                              replace_table_cell,save_word_copy,export_pdf_from_docx)

DARK='#282D36'; NAV='#171B22'; FG='#EDF3F7'; SECONDARY='#AAB8C5'; LIME='#CBDE26'; FIELD='#343B45'; WHITE='#FFFFFF'

class WordEditorPane(tk.Frame):
    def __init__(self,parent,on_exit=None):
        super().__init__(parent,bg=DARK)
        self.on_exit=on_exit
        self.doc=None;self.path=None;self.saved_path=None;self.blocks=[];self.active=None;self.dirty=False;self.pending=False
        header=tk.Frame(self,bg=DARK);header.pack(fill='x',padx=16,pady=(13,8))
        tk.Label(header,text='Редактор документов Word',bg=DARK,fg=FG,font=('Segoe UI',18,'bold')).pack(side='left')
        if on_exit:
            tk.Button(header,text='← В мастер',command=self.exit_editor,bg=FIELD,fg=FG,relief='flat',padx=15,pady=7).pack(side='right')
        bar=tk.Frame(self,bg=DARK);bar.pack(fill='x',padx=16,pady=(3,8))
        for t,cb in [('Открыть DOCX',self.open_file),('Сохранить копию Word',self.save_as),('Сохранить PDF',self.save_pdf)]:
            tk.Button(bar,text=t,command=cb,bg=LIME if 'копию' in t else FIELD,fg=NAV if 'копию' in t else FG,
                      font=('Segoe UI',10,'bold'),relief='flat',padx=13,pady=9).pack(side='left',padx=(0,9))
        self.file_label=tk.Label(self,text='Откройте документ формата .docx для редактирования',bg=DARK,fg=SECONDARY,
                                 font=('Segoe UI',10),anchor='w')
        self.file_label.pack(fill='x',padx=16,pady=(0,8))
        pane=tk.PanedWindow(self,orient='horizontal',bg=DARK,sashwidth=6,sashrelief='flat')
        pane.pack(fill='both',expand=True,padx=16,pady=(0,12))
        left=tk.Frame(pane,bg='#303743');right=tk.Frame(pane,bg=DARK)
        pane.add(left,minsize=200,width=260);pane.add(right,minsize=400)
        tk.Label(left,text='СОДЕРЖИМОЕ ДОКУМЕНТА',bg='#303743',fg=FG,font=('Segoe UI',10,'bold')).pack(anchor='w',padx=12,pady=(12,7))
        self.sections=ttk.Treeview(left,show='tree',selectmode='browse',height=20)
        self.sections.pack(fill='both',expand=True,padx=8,pady=(0,10))
        self.sections.bind('<<TreeviewSelect>>',self.choose_block)
        tk.Label(right,text='Предварительный вид',bg=DARK,fg=FG,font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(2,4))
        wrap=tk.Frame(right,bg='#BDC4CF',padx=12,pady=10,height=295);wrap.pack(fill='x');wrap.pack_propagate(False)
        self.preview=tk.Text(wrap,bg=WHITE,fg='#20232A',relief='flat',wrap='word',height=12,
                         font=('Arial',10),state='disabled',padx=22,pady=16)
        sb=ttk.Scrollbar(wrap,command=self.preview.yview)
        self.preview.configure(yscrollcommand=sb.set)
        sb.pack(side='right',fill='y');self.preview.pack(side='left',fill='both',expand=True)
        self.preview.tag_configure('heading',font=('Arial',14,'bold'),spacing3=10)
        self.preview.tag_configure('table',font=('Consolas',9),foreground='#31566D',spacing3=8)
        self.preview.tag_configure('normal',spacing3=5)
        editor=tk.Frame(right,bg=DARK);editor.pack(fill='x',pady=(9,0))
        self.editor_title=tk.Label(editor,text='Выберите абзац или таблицу слева для изменения',bg=DARK,fg=SECONDARY,font=('Segoe UI',10,'bold'))
        self.editor_title.pack(anchor='w',pady=(0,5))
        self.editor_text=tk.Text(editor,bg=FIELD,fg=FG,insertbackground=FG,relief='flat',wrap='word',height=4,font=('Segoe UI',11),padx=10,pady=10)
        self.editor_text.pack(fill='x')
        self.editor_text.bind('<<Modified>>',self._on_modified)
        self.table_area=tk.Frame(editor,bg=DARK)
        self.table_area.pack(fill='x',pady=(5,0))
        bottom=tk.Frame(editor,bg=DARK);bottom.pack(fill='x',pady=(7,0))
        self.apply=tk.Button(bottom,text='Применить изменение',command=self.apply_edit,bg=LIME,fg=NAV,
            font=('Segoe UI',10,'bold'),relief='flat',padx=12,pady=9)
        self.apply.pack(side='left')
        tk.Label(bottom,text='Исходный DOCX не перезаписывается; сохраняйте изменённую копию.',bg=DARK,
                 fg=SECONDARY,font=('Segoe UI',9)).pack(side='left',padx=12)
        tk.Label(self,text='Можно менять абзацы и ячейки таблиц. Сложная Word-верстка и рисунки сохраняются, но не редактируются здесь. '
                           'Предпросмотр приблизительный.',bg=DARK,fg=SECONDARY,anchor='w',font=('Segoe UI',9)).pack(fill='x',padx=16,pady=(0,8))

    def _on_modified(self,event=None):
        if self.editor_text.edit_modified():
            self.editor_text.edit_modified(False)
            if self.doc is not None and self.active is not None:self.dirty=True;self.pending=True

    def exit_editor(self):
        if self.dirty and not messagebox.askyesno('Несохранённые изменения','Есть несохранённые правки. Вернуться без сохранения?'):
            return
        if self.on_exit:self.on_exit()

    def open_file(self,path=None):
        if self.dirty and not messagebox.askyesno('Несохранённые изменения','Открыть другой документ без сохранения текущих правок?'):
            return
        if path is None:
            path=filedialog.askopenfilename(parent=self,title='Открыть документ Word',filetypes=[('Word DOCX','*.docx')])
        if not path:return
        try:
            doc=open_word_document(path)
            self.doc=doc;self.path=Path(path);self.saved_path=None;self.dirty=False;self.pending=False
            self.blocks=document_blocks(doc)
            self.file_label.configure(text=f'Файл: {self.path.name}   •   Разделов: {len(self.blocks)}')
            for item in self.sections.get_children():self.sections.delete(item)
            for idx,item in enumerate(self.blocks):
                self.sections.insert('','end',iid=str(idx),text=item.title)
            self.render_preview()
            if self.blocks:
                self.sections.selection_set('0')
                self.sections.focus('0')
                self.choose_block()
        except Exception as ex:messagebox.showerror('Word',str(ex),parent=self)

    def _widget_set(self,text):
        self.editor_text.delete('1.0','end');self.editor_text.insert('1.0',text)
        self.editor_text.edit_modified(False)

    def choose_block(self,event=None):
        if self.doc is None:return
        selection=self.sections.selection()
        if not selection:return
        target=int(selection[0])
        if self.pending and target!=self.active:
            # Explicit apply to avoid accidental loss of edits.
            if not messagebox.askyesno('Изменён текст','Текст ещё не применён к документу. Перейти и потерять правку?'):
                if self.active is not None:self.sections.selection_set(str(self.active))
                return
        self.pending=False;self.active=target
        block=self.blocks[target]
        for x in self.table_area.winfo_children():x.destroy()
        if block.kind=='paragraph':
            p=self.doc.paragraphs[block.index]
            self.editor_title.configure(text=f'Абзац {block.index+1} — измените текст ниже')
            self._widget_set(p.text)
            self.editor_text.configure(state='normal')
            self.apply.configure(state='normal')
        else:
            table=self.doc.tables[block.index]
            self.editor_title.configure(text=f'Таблица {block.index+1}: дважды нажмите на нужную ячейку')
            self._widget_set('Для редактирования ячейки дважды нажмите на строку таблицы ниже.')
            self.editor_text.configure(state='disabled');self.apply.configure(state='disabled')
            columns=[f'col_{i}' for i in range(len(table.columns))]
            tree=ttk.Treeview(self.table_area,columns=columns,show='headings',height=min(5,max(2,len(table.rows))))
            for col in columns:
                tree.heading(col,text=f'Графа {int(col[4:])+1}')
                tree.column(col,width=130,stretch=True)
            for idx,row in enumerate(table.rows):
                tree.insert('','end',iid=str(idx),values=[c.text[:70].replace('\n',' ') for c in row.cells])
            tree.pack(fill='x')
            tree.bind('<Double-Button-1>',lambda ev:self.edit_table_cell(block.index,tree,ev))

    def edit_table_cell(self,table_index,tree,event):
        rowid=tree.identify_row(event.y);column=tree.identify_column(event.x)
        if not rowid or not column:return
        r=int(rowid);c=int(column[1:])-1
        table=self.doc.tables[table_index]
        if c<0 or c>=len(table.columns):return
        top=tk.Toplevel(self);top.title(f'Ячейка {r+1} × {c+1}');top.configure(bg=DARK);top.geometry('520x325')
        top.transient(self);top.grab_set()
        tk.Label(top,text=f'Изменение содержимого ячейки ({r+1}, {c+1})',bg=DARK,fg=FG,
                 font=('Segoe UI',12,'bold')).pack(anchor='w',padx=20,pady=(15,8))
        field=tk.Text(top,height=7,wrap='word',bg=FIELD,fg=FG,insertbackground=FG,font=('Segoe UI',11))
        field.pack(fill='both',expand=True,padx=20)
        field.insert('1.0',table.cell(r,c).text)
        def submit():
            try:
                replace_table_cell(self.doc,table_index,r,c,field.get('1.0','end-1c'))
                tree.item(rowid,values=[cell.text[:70].replace('\n',' ') for cell in table.rows[r].cells])
                self.dirty=True;self.pending=False;self.render_preview();top.destroy()
            except Exception as ex:messagebox.showerror('Ячейка',str(ex),parent=top)
        tk.Button(top,text='Применить к ячейке',command=submit,bg=LIME,fg=NAV,relief='flat',padx=14,pady=9).pack(pady=15)

    def apply_edit(self):
        if self.doc is None or self.active is None:return
        block=self.blocks[self.active]
        if block.kind!='paragraph':return
        try:
            replace_paragraph(self.doc,block.index,self.editor_text.get('1.0','end-1c'))
            self.pending=False;self.dirty=True
            self.blocks=document_blocks(self.doc)
            self.sections.item(str(self.active),text=self.blocks[self.active].title)
            self.render_preview()
        except Exception as ex:messagebox.showerror('Word',str(ex),parent=self)

    def render_preview(self):
        if self.doc is None:return
        self.preview.configure(state='normal');self.preview.delete('1.0','end')
        blocks=document_blocks(self.doc)
        for block in blocks:
            if block.kind=='paragraph':
                item=self.doc.paragraphs[block.index]
                bold=bool(item.style and item.style.name.startswith('Heading'))
                self.preview.insert('end',(item.text or ' ')+'\n','heading' if bold else 'normal')
            else:
                item=self.doc.tables[block.index]
                for row in item.rows[:60]:
                    self.preview.insert('end','   │   '.join(c.text.replace('\n',' ')[:80] for c in row.cells)+'\n','table')
                if len(item.rows)>60:self.preview.insert('end','… дополнительные строки …\n','table')
                self.preview.insert('end','\n','normal')
        self.preview.configure(state='disabled')

    def _apply_pending(self):
        if self.doc is None:return False
        if self.active is not None and self.blocks[self.active].kind=='paragraph' and self.pending:
            self.apply_edit()
        return True

    def save_as(self):
        if self.doc is None:
            messagebox.showinfo('Word','Сначала откройте документ .docx',parent=self);return
        self._apply_pending()
        stem=(self.path.stem if self.path else 'Документ')+'_изменено.docx'
        output=filedialog.asksaveasfilename(parent=self,title='Сохранить изменённый Word',defaultextension='.docx',
                         initialfile=stem,filetypes=[('Документ Word','*.docx')])
        if not output:return
        try:
            self.saved_path=save_word_copy(self.doc,self.path,output)
            self.dirty=False;self.pending=False
            messagebox.showinfo('Сохранено',f'Новый документ Word сохранён:\n{self.saved_path}',parent=self)
        except Exception as ex:messagebox.showerror('Word',str(ex),parent=self)

    def save_pdf(self):
        if self.doc is None:
            messagebox.showinfo('PDF','Сначала откройте файл .docx',parent=self);return
        self._apply_pending()
        output=filedialog.asksaveasfilename(parent=self,defaultextension='.pdf',initialfile=(self.path.stem+'_изменено.pdf'),
                        filetypes=[('PDF','*.pdf')])
        if not output:return
        import tempfile
        try:
            # PDF built from the CURRENT in-memory document, even before saving DOCX.
            with tempfile.TemporaryDirectory(prefix='moolva_word_') as temp:
                src=Path(temp)/'Временный_Word.docx';self.doc.save(src)
                export_pdf_from_docx(src,output)
            messagebox.showinfo('PDF','PDF сохранён:\n'+str(output),parent=self)
        except Exception as ex:messagebox.showerror('Экспорт PDF',str(ex),parent=self)
