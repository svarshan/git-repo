"""MoOLVa HACCP Easy: a minimal orchestration layer over the existing audited data model.
The legacy Store is shared. This module never invents measurements or signatures.
"""
from __future__ import annotations
from pathlib import Path
from catalog import TYPES, FLAGS, defaults_for_type
from storage import Store, app_data_dir
from upgrade_guard import backup_before_upgrade
from staff_store import migrate_staff, list_employees, save_employee, archive_employee, get_assignments, save_assignments, save_acknowledgements
from template_store import migrate_templates
from control_store import migrate
from studio_core import migrate_studio, search_library, audit_enterprise
from flowchart_core import migrate_flowcharts
from exports import get_templates, is_selected
from studio_export import export_selected

STEPS = (
    ('Главная', 'Начните с нового комплекта или откройте существующий'),
    ('Тип предприятия', 'Выберите наиболее подходящую категорию'),
    ('Реквизиты', 'Заполните сведения об объекте'),
    ('Что есть на объекте', 'Отметьте фактические процессы и оборудование'),
    ('Сотрудники', 'Сформируйте список работников'),
    ('Подбор журналов', 'Оставьте только применимые формы'),
    ('Записи в журналы', 'По желанию внесите фактические записи'),
    ('Подписи и ответственные', 'Назначьте людей и подготовьте листы ознакомления'),
    ('Проверка комплекта', 'Просмотрите результат и замечания'),
    ('Сохранение и печать', 'Выберите Word, PDF или оба формата'),
)
FIELD_NAMES = (
    ('venue_name', 'Название объекта *'),('legal_name','Организация / ИП'),
    ('inn','ИНН'),('ogrn','ОГРН / ОГРНИП'),('address','Адрес объекта'),
    ('legal_address','Юридический адрес'),('director','Руководитель'),
    ('responsible','Ответственный за ХАССП'),('phone','Телефон'),('email','Электронная почта'),
)
TYPE_FAVOURITES = (
 'Столовая','Кафе','Ресторан','Школьная столовая','Детский сад (пищеблок)',
 'Пекарня','Кондитерская','Пищевое производство','Магазин продуктов',
 'Продуктовый склад','Доставка готовой еды','Другое',
)
FEATURED_FLAGS = ('staff','cold','storage','cook','receiving','fryer','delivery',
                  'children','bakery','meat','hot_hold','cool_down','thaw','dishes',
                  'allergens','lab','package','labels','trace','retail','water')


def init_store(path=None):
    # A verified one-time copy is created before migrations touch the legacy DB.
    db_path=Path(path) if path is not None else app_data_dir()/'haccp.sqlite3'
    backup_before_upgrade(db_path, version='easy_1_0')
    store = Store(db_path)
    migrate(store)
    migrate_staff(store)
    migrate_templates(store)
    migrate_studio(store)
    migrate_flowcharts(store)
    return store


def make_venue(store, kind='Столовая'):
    if kind not in TYPES:
        raise ValueError('Неизвестный тип предприятия')
    return store.create_venue(kind)


def venue_delete(store, venue_id, make_backup=True):
    if not store.get_venue(venue_id):
        raise ValueError('Предприятие не найдено')
    return store.delete_venue(venue_id, make_backup=make_backup)


def venue_update(store, venue_id, values=None, kind=None, flags=None):
    current=store.get_venue(venue_id)
    if not current: raise ValueError('Предприятие не найдено')
    values=values or {}
    if kind is not None:
        if kind not in TYPES:raise ValueError('Неизвестный тип предприятия')
        values['kind']=kind
    if flags is not None:values['flags']=flags
    store.update_venue(venue_id, values)
    return store.get_venue(venue_id)


def types_choice():
    return [x for x in TYPE_FAVOURITES if x in TYPES]


def flags_choice():
    m=dict(FLAGS)
    return [(k,m[k]) for k in FEATURED_FLAGS if k in m]


def recommended(store, venue_id, query=''):
    return search_library(store, venue_id, query)


def selected(store, venue_id):
    venue=store.get_venue(venue_id)
    if venue is None:return []
    return [x for x in get_templates(store) if is_selected(store,venue,x)[0]]


def toggle_journal(store, venue_id, code, selected_state):
    choices={t.code for t in get_templates(store)}
    if code not in choices:raise ValueError('Журнал отсутствует в каталоге')
    store.set_override(venue_id,code,bool(selected_state))


def apply_staff_to_documents(store,venue_id,codes,responsible=None,approved=None,acks=(),include_duties=None,include_requirements=None):
    staff=list_employees(store,venue_id)
    available={e['id'] for e in staff}
    if responsible is not None and responsible not in available:raise ValueError('Ответственный не найден')
    if approved is not None and approved not in available:raise ValueError('Утверждающий не найден')
    if not set(acks)<=available:raise ValueError('Сотрудник для ознакомления не найден')
    templates={t.code for t in get_templates(store)}
    for code in codes:
        if code not in templates:raise ValueError('Журнал отсутствует в каталоге')
    for code in codes:
        key='journal:'+code
        old=get_assignments(store,venue_id,key)
        people={role:(person['id'] if person else None) for role,person in old['people'].items()}
        people.update(responsible=responsible,approved=approved)
        save_assignments(store,venue_id,key,people,
            old['include_duties'] if include_duties is None else include_duties,
            old['include_requirements'] if include_requirements is None else include_requirements)
        save_acknowledgements(store,venue_id,key,list(acks))


def overview(store,venue_id):
    venue=store.get_venue(venue_id)
    if not venue:return {'journals':0,'staff':0,'processes':0,'title':'Не выбран объект'}
    return {'journals':len(selected(store,venue_id)),
            'staff':len(list_employees(store,venue_id)),
            'processes':sum(bool(v) for v in venue['flags'].values()),
            'title':venue['venue_name']}


def export_pack_easy(store, venue_id, folder, formats=('docx','pdf'), passport=True, audit=False):
    if not formats or not set(formats)<=set(('docx','pdf')):
        raise ValueError('Выберите Word и/или PDF')
    codes=['journal:'+t.code for t in selected(store,venue_id)]
    if not codes:raise ValueError('В комплекте нет выбранных журналов')
    return export_selected(store,venue_id,codes,Path(folder),formats,passport,audit)
