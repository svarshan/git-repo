"""Обоснование предварительного выбора форм по профилю предприятия.
Документ НЕ удостоверяет соответствие нормам и НЕ заменяет утверждённые ППК и ХАССП.
"""
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape
from sectors import sector_for, regulation_candidates, is_catering
from exports import get_templates, is_selected


def analyze(store, venue_id):
    venue = store.get_venue(venue_id)
    if not venue:
        raise ValueError('Предприятие не найдено')
    selected, omitted = [], []
    for t in get_templates(store):
        yes, why = is_selected(store, venue, t)
        (selected if yes else omitted).append((t, why))
    flags = venue.get('flags') or {}
    risks = []
    if venue['kind'] == 'Другое':
        risks.append('Общий профиль: заполните перечень технологических процессов вручную.')
    if not any(flags.values()):
        risks.append('Не отмечены процессы: рекомендации не могут быть полными.')
    if flags.get('slaughter'):
        risks.append('Убой и ветеринарный контроль требуют отдельной проверки ветеринарных требований и документации.')
    if flags.get('baby_food') or flags.get('children') or flags.get('special_food'):
        risks.append('Специальное / детское питание: перечень процедур и допусков нужно согласовать с профильным специалистом.')
    if flags.get('sterilize'):
        risks.append('Стерилизация: критические режимы, оценку отклонений и выпуск партий утверждает специалист по процессу.')
    if flags.get('retail') or flags.get('wholesale'):
        risks.append('В торговле и логистике не следует автоматически применять весь набор требований для изготовителя.')
    if flags.get('cook') and not is_catering(venue['kind']):
        risks.append('Готовые блюда на пищевом производстве: проверьте, применим ли режим общепита на конкретном объекте.')
    risks.append('Периодичность, критические пределы, методы контроля и журналы устанавливаются документами предприятия по анализу рисков и применимому праву.')
    risks.append('Формы каталога — предварительные адаптируемые шаблоны, а не подтверждение исполнения всех обязательных требований.')
    return {
        'venue': venue, 'sector': sector_for(venue['kind']), 'selected': selected,
        'omitted': omitted, 'regulations': regulation_candidates(venue['kind'], flags),
        'risks': risks, 'active_flags': [k for k, value in flags.items() if value],
    }


def assessment_lines(store, venue_id):
    r = analyze(store, venue_id)
    v = r['venue']
    lines = [
        'MoOLVa ХАССП — Паспорт предварительного подбора журналов',
        'Дата: ' + datetime.now().strftime('%d.%m.%Y %H:%M'),
        'Организация: ' + (v.get('legal_name') or 'Не указано'),
        'Объект: ' + v['venue_name'],
        'Тип: ' + v['kind'],
        'Отрасль: ' + r['sector'],
        'Адрес: ' + (v.get('address') or 'Не указан'),
        'Ответственный: ' + (v.get('responsible') or 'Не указан'),
        '', 'ПОДОБРАННЫЕ ЖУРНАЛЫ: ' + str(len(r['selected']))]
    lines.extend('• ' + t.title + ' — ' + why for t,why in r['selected'])
    lines += ['', 'НОРМАТИВНЫЕ АКТЫ ДЛЯ ПРОВЕРКИ ПРИМЕНИМОСТИ (НЕ АВТОМАТИЧЕСКАЯ ЮРИДИЧЕСКАЯ КВАЛИФИКАЦИЯ)']
    lines.extend('• ' + law + ' — ' + why for law,why in r['regulations'])
    lines += ['', 'ЧТО ПОДЛЕЖИТ РУЧНОЙ ПРОВЕРКЕ']
    lines.extend('• ' + item for item in r['risks'])
    lines += ['', 'Подбор не является заключением о соблюдении требований законодательства.',
              'Исключённые формы могут быть добавлены вручную после анализа опасностей и процессов.']
    return lines


def export_assessment(store, venue_id, path, fmt):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = assessment_lines(store, venue_id)
    if fmt == 'txt':
        path.write_text('\n'.join(lines), encoding='utf-8')
    elif fmt == 'docx':
        from docx import Document
        from docx.shared import Cm, Pt
        doc = Document()
        sec = doc.sections[0]
        sec.top_margin = sec.bottom_margin = Cm(1.9)
        sec.left_margin = sec.right_margin = Cm(1.8)
        style = doc.styles['Normal']
        style.font.name = 'Arial'
        style.font.size = Pt(9)
        for idx, line in enumerate(lines):
            if idx == 0:
                doc.add_heading(line, level=1)
            elif line and line.upper() == line and len(line)>14 and not line.startswith('• '):
                doc.add_heading(line, level=2)
            else:
                p = doc.add_paragraph(line)
                p.paragraph_format.space_after = Pt(3)
        doc.save(str(path))
    elif fmt == 'pdf':
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, KeepTogether
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import mm
        from exports import _register_pdf_font
        font = _register_pdf_font()
        doc = SimpleDocTemplate(str(path), pagesize=A4,
                                rightMargin=17*mm, leftMargin=17*mm,
                                topMargin=14*mm, bottomMargin=14*mm)
        style = ParagraphStyle('base', fontName=font, fontSize=8.6, leading=11.5, spaceAfter=2)
        heading = ParagraphStyle('head', parent=style, fontSize=11.5, leading=14, spaceBefore=7, spaceAfter=5)
        title = ParagraphStyle('title', parent=style, fontSize=14, leading=17, spaceAfter=9)
        story = []
        for idx, item in enumerate(lines):
            if item:
                heading_line = item.upper() == item and len(item)>14 and not item.startswith('• ')
                s = title if idx == 0 else (heading if heading_line else style)
                story.append(Paragraph(escape(item), s))
            else:
                story.append(Spacer(1, 3))
        doc.build(story)
    else:
        raise ValueError('Неизвестный формат')
    return path
