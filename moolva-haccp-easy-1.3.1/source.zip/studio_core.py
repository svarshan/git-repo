"""MoOLVa 0.5: scoped, reversible layout settings, library search, non-certifying audit."""
from __future__ import annotations
import json
from datetime import date
from pathlib import Path
from dataclasses import dataclass
from exports import get_templates, is_selected, columns_for
from smart_control import select_document_package
from control_store import list_tasks, reviewed_codes
from template_store import list_templates
from storage import now

MODES=('auto','a4','a4land','a3land')


def migrate_studio(store):
    with store.connect() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS studio_layouts (
          venue_id INTEGER NOT NULL REFERENCES venues(id),
          template_code TEXT NOT NULL, layout_json TEXT NOT NULL, updated_at TEXT NOT NULL,
          PRIMARY KEY(venue_id,template_code))''')


def _blank_layout():
    return {'title':'','note':'','blank_rows':9,'page_mode':'auto','columns':[]}


def get_layout(store, venue_id, template):
    migrate_studio(store)
    if store.get_venue(venue_id) is None:
        raise ValueError('Предприятие не найдено')
    with store.connect() as db:
        r=db.execute('SELECT layout_json FROM studio_layouts WHERE venue_id=? AND template_code=?',
                     (venue_id,template.code)).fetchone()
    saved=json.loads(r['layout_json']) if r else _blank_layout()
    result={**_blank_layout(),**saved}
    base=columns_for(store,venue_id,template)
    listed={c['key']:dict(c) for c in result['columns'] if isinstance(c,dict) and c.get('key')}
    columns=[]
    for c in result['columns']:
        if c.get('key') in dict(base):
            k=c['key']; columns.append(dict(key=k,label=c.get('label') or dict(base)[k],width=c.get('width',1),visible=c.get('visible',True)))
    for k,v in base:
        if k not in {c['key'] for c in columns}:
            columns.append(dict(key=k,label=v,width=1,visible=True))
    result['columns']=columns
    return result


def validate_layout(layout):
    if not isinstance(layout,dict):raise ValueError('Неверный формат макета')
    title=str(layout.get('title','')).strip()
    note=str(layout.get('note','')).strip()
    if len(title)>200 or len(note)>800:raise ValueError('Слишком длинное название или примечание')
    count=int(layout.get('blank_rows',9))
    if count<0 or count>40:raise ValueError('Число пустых строк должно быть 0–40')
    page_mode=layout.get('page_mode','auto')
    if page_mode not in MODES:raise ValueError('Неверный формат страницы')
    cols=layout.get('columns',[])
    if not isinstance(cols,list) or len(cols)>18:raise ValueError('Максимум 18 граф')
    seen=set();clean=[]
    for c in cols:
        k=str(c.get('key','')).strip();label=str(c.get('label','')).strip()
        if not k or len(k)>90 or k in seen or not label or len(label)>150:
            raise ValueError('Недопустимый или повторяющийся код/название графы')
        seen.add(k)
        w=float(c.get('width',1))
        if not 0.4<=w<=5: raise ValueError('Ширина графы 0,4–5')
        clean.append({'key':k,'label':label,'width':w,'visible':bool(c.get('visible',True))})
    if cols and not any(c['visible'] for c in clean):raise ValueError('Оставьте хотя бы одну видимую графу')
    return {'title':title,'note':note,'blank_rows':count,'page_mode':page_mode,'columns':clean}


def save_layout(store,venue_id,template,layout):
    if store.get_venue(venue_id) is None:raise ValueError('Предприятие не найдено')
    effective=get_layout(store,venue_id,template)
    allowed={c['key'] for c in effective['columns']}
    incoming=validate_layout(layout)
    if not set(c['key'] for c in incoming['columns'])<=allowed:
        raise ValueError('Добавьте новые графы штатной кнопкой «Изменить графы» в разделе журналов')
    labels=store.get_labels(venue_id,template.code)
    labels.update({c['key']:c['label'] for c in incoming['columns']})
    with store.connect() as db:
        db.execute('''INSERT INTO column_labels(venue_id,template_code,labels_json) VALUES(?,?,?)
          ON CONFLICT(venue_id,template_code) DO UPDATE SET labels_json=excluded.labels_json''',
          (venue_id,template.code,json.dumps(labels,ensure_ascii=False)))
        db.execute('''INSERT INTO studio_layouts(venue_id,template_code,layout_json,updated_at)
          VALUES(?,?,?,?) ON CONFLICT(venue_id,template_code) DO UPDATE SET
          layout_json=excluded.layout_json,updated_at=excluded.updated_at''',
          (venue_id,template.code,json.dumps(incoming,ensure_ascii=False),now()))
        store._audit(db,venue_id,'studio_layout_saved',{'code':template.code,'visible_columns':sum(c['visible'] for c in incoming['columns'])})
    return incoming


def layout_export_spec(store,venue_id,template):
    config=get_layout(store,venue_id,template)
    columns=[(c['key'],c['label']) for c in config['columns'] if c['visible']]
    weights=[c['width'] for c in config['columns'] if c['visible']]+[1]
    return config,columns,weights


def search_library(store,venue_id,query='',group='Все',suggested_only=False):
    venue=store.get_venue(venue_id)
    if not venue:return []
    q=query.strip().casefold()
    synonyms={'морозилка':('морозильн','холодильн'),
              'холодос':('холодильн',),'морозильник':('морозильн','холодильн'),
              'санобработка':('санитарн','дезинфекц'),
              'температура':('температур','термоконтрол'),
              'уборка':('уборк','санитарн'),
              'аллергия':('аллерген',),
              'бракераж':('бракераж',),
              'повар':('персонал','гигиеническ','готовых блюд')}
    queries=(q,)+synonyms.get(q,()) if q else ()
    found=[]
    for t in get_templates(store):
        selected,why=is_selected(store,venue,t)
        if group!='Все' and group!=t.group:continue
        if suggested_only and not selected:continue
        hay=' '.join((t.title,t.group,t.note,t.basis,why,' '.join(x[1] for x in t.columns))).casefold()
        if queries and not any(x in hay for x in queries):continue
        found.append(dict(template=t,selected=selected,reason=why))
    return sorted(found,key=lambda x:(not x['selected'],x['template'].group,x['template'].title))


def audit_enterprise(store,venue_id):
    venue=store.get_venue(venue_id)
    if not venue:raise ValueError('Предприятие не найдено')
    pkg=select_document_package(store,venue_id)
    reviewed=reviewed_codes(store,venue_id)
    docs=pkg['documents']; issues=[]
    def add(level,code,text,action):issues.append({'level':level,'code':code,'text':text,'action':action})
    if not venue.get('legal_name') or not venue.get('address'):
        add('Проверить','card','Не заполнены отдельные сведения об организации / объекте','Заполнить карточку предприятия')
    flags=venue.get('flags') or {}
    if not any(bool(v) for v in flags.values()):
        add('Проверить','flags','Не отмечены технологические процессы','Уточнить фактические операции')
    for t in get_templates(store):
        selected,_=is_selected(store,venue,t)
        if not selected:continue
        rec=store.list_records(venue_id,t.code)
        active=[r for r in rec if not r.get('voided_at')]
        if not active:
            add('Проверить','journal:'+t.code,'Нет действующих записей: '+t.title,'Уточнить необходимость и порядок ведения')
    for d in docs:
        if d['code'] not in reviewed:
            add('На согласование',d['code'],'Не подтверждена проверка: '+d['title'],'Проверить применимость и утвердить ответственным')
    for t in list_templates(store,venue_id):
        missing=[f for f in t['fields'] if not t['mapping'].get(f)]
        if missing:
            add('Настроить','word:'+t['id'],f"В Word-шаблоне «{t['name']}» есть поля без привязки ({len(missing)})",'Назначить источники данных')
    tasks=list_tasks(store,venue_id)
    today=date.today()
    for task in tasks:
        if task['state']=='open' and date.fromisoformat(task['due_date'])<today:
            add('Просрочено','task:'+str(task['id']),'Просрочена задача: '+task['title'],'Уточнить состояние и оформить фактическое выполнение')
    return {'venue':venue,'documents':docs,'issues':issues,'reviewed':len(set(d['code'] for d in docs)&reviewed),
            'open_tasks':sum(t['state']=='open' for t in tasks),
            'lines':audit_lines(venue,docs,issues)}


def audit_lines(venue,docs,issues):
    lines=['MoOLVa ХАССП Studio — предварительная проверка комплекта',
        'Объект: '+venue.get('venue_name',''), 'Организация: '+venue.get('legal_name',''),
        'Дата составления: '+date.today().strftime('%d.%m.%Y'),
        f'Предложено документов: {len(docs)}',f'Вопросов для проверки: {len(issues)}','',
        'ВОПРОСЫ ДЛЯ ПРОВЕРКИ']
    lines.extend('• ['+x['level']+'] '+x['text']+' → '+x['action'] for x in issues)
    if not issues:lines.append('По автоматическим признакам вопросов не найдено. Требуется экспертная проверка.')
    lines.extend(['','ВАЖНО','Отсутствие записи не доказывает нарушение; она может быть не нужна либо вестись вне программы.',
        'Отчёт не является сертификатом соответствия и не заменяет внутренний аудит специалиста ХАССП.',
        'Фактические измерения, даты ознакомления и подписи не генерируются автоматически.'])
    return lines
