"""Enterprise-isolated staff, named document responsibilities and optional appendices.
Migrations append only: existing records and journals stay untouched.
"""
import re
from roles_catalog import get_position, reference
from storage import now

ROLES = (('developed','Разработал'),('agreed','Согласовал'),
         ('approved','Утвердил'),('responsible','Ответственный'),('checked','Проверил'))
ROLE_NAMES=dict(ROLES)
ATTRS=('name','position','department','qualification','phone')

def migrate_staff(store):
    with store.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS employees (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          venue_id INTEGER NOT NULL REFERENCES venues(id),
          full_name TEXT NOT NULL, position_code TEXT NOT NULL DEFAULT '',
          position_name TEXT NOT NULL, department TEXT NOT NULL DEFAULT '',
          qualification TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '',
          notes TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_employees_venue ON employees(venue_id,active,full_name);
        CREATE TABLE IF NOT EXISTS document_staff (
          venue_id INTEGER NOT NULL REFERENCES venues(id), document_key TEXT NOT NULL,
          role_key TEXT NOT NULL, employee_id INTEGER REFERENCES employees(id),
          PRIMARY KEY(venue_id,document_key,role_key));
        CREATE TABLE IF NOT EXISTS document_acknowledgements (
          venue_id INTEGER NOT NULL REFERENCES venues(id), document_key TEXT NOT NULL,
          employee_id INTEGER NOT NULL REFERENCES employees(id), position_order INTEGER NOT NULL,
          PRIMARY KEY(venue_id,document_key,employee_id));
        CREATE INDEX IF NOT EXISTS idx_ack_doc ON document_acknowledgements(venue_id,document_key,position_order);
        CREATE TABLE IF NOT EXISTS document_staff_options (
          venue_id INTEGER NOT NULL REFERENCES venues(id),document_key TEXT NOT NULL,
          include_duties INTEGER NOT NULL DEFAULT 0,
          include_requirements INTEGER NOT NULL DEFAULT 0,
          PRIMARY KEY(venue_id,document_key));
        ''')

def _validate_venue(store,venue_id):
    if store.get_venue(venue_id) is None:raise ValueError('Предприятие не найдено')

def list_employees(store,venue_id,include_inactive=False):
    migrate_staff(store)
    sql='SELECT * FROM employees WHERE venue_id=?'
    if not include_inactive:sql+=' AND active=1'
    sql+=' ORDER BY full_name COLLATE NOCASE,id'
    with store.connect() as db:
        return [dict(row) for row in db.execute(sql,(venue_id,))]

def get_employee(store,venue_id,emp_id,active_only=True):
    if emp_id is None:return None
    for employee in list_employees(store,venue_id,not active_only):
        if employee['id']==int(emp_id):return employee
    return None

def save_employee(store,venue_id,full_name,position_code='',position_name='',department='',qualification='',phone='',notes='',employee_id=None):
    migrate_staff(store)
    _validate_venue(store,venue_id)
    full_name=' '.join(str(full_name).split())
    if not 2<=len(full_name)<=180:raise ValueError('Укажите ФИО (от 2 до 180 символов)')
    position=get_position(position_code) if position_code else None
    if position_code and not position:raise ValueError('Должность отсутствует в справочнике')
    if position: position_name=position.title
    position_name=str(position_name).strip()
    if not 2<=len(position_name)<=160:raise ValueError('Выберите должность или введите своё название')
    data=[full_name,position_code,position_name]
    for field in (department,qualification,phone,notes):
        field=str(field).strip()
        if len(field)>500:raise ValueError('Слишком длинное поле сотрудника')
        data.append(field)
    with store.connect() as db:
        if employee_id is None:
            cur=db.execute('''INSERT INTO employees
                (venue_id,full_name,position_code,position_name,department,qualification,phone,notes,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?)''',(venue_id,*data,now()))
            employee_id=cur.lastrowid
        else:
            if not get_employee(store,venue_id,employee_id,active_only=False):
                raise ValueError('Сотрудник не найден в текущем предприятии')
            db.execute('''UPDATE employees SET full_name=?,position_code=?,position_name=?,
                department=?,qualification=?,phone=?,notes=?,updated_at=? WHERE id=? AND venue_id=?''',
                (*data,now(),employee_id,venue_id))
        store._audit(db,venue_id,'employee_saved',{'employee_id':employee_id})
    return int(employee_id)

def archive_employee(store,venue_id,employee_id):
    if not get_employee(store,venue_id,employee_id):raise ValueError('Сотрудник не найден')
    with store.connect() as db:
        db.execute('UPDATE employees SET active=0,updated_at=? WHERE venue_id=? AND id=?',(now(),venue_id,employee_id))
        # Retain assigned historical links; export ignores inactive assignees rather than substituting a different person.
        store._audit(db,venue_id,'employee_archived',{'employee_id':employee_id})

def _key(document_key):
    key=str(document_key)
    if len(key)>220 or not re.fullmatch(r'(journal|word):[a-zA-Z0-9_-]{1,200}',key):
        raise ValueError('Неверный идентификатор документа')
    return key

def get_assignments(store,venue_id,document_key):
    migrate_staff(store)
    key=_key(document_key)
    with store.connect() as db:
        rows=db.execute('SELECT role_key,employee_id FROM document_staff WHERE venue_id=? AND document_key=?',(venue_id,key)).fetchall()
        opt=db.execute('SELECT * FROM document_staff_options WHERE venue_id=? AND document_key=?',(venue_id,key)).fetchone()
    people={r['role_key']:get_employee(store,venue_id,r['employee_id']) for r in rows}
    return {'people':people, 'include_duties':bool(opt['include_duties']) if opt else False,
            'include_requirements':bool(opt['include_requirements']) if opt else False}

def save_assignments(store,venue_id,document_key,people,include_duties=False,include_requirements=False):
    _validate_venue(store,venue_id)
    key=_key(document_key)
    if set(people)-set(ROLE_NAMES):raise ValueError('Неизвестная роль документа')
    for role,emp_id in people.items():
        if emp_id is not None and not get_employee(store,venue_id,emp_id):
            raise ValueError('Сотрудник не относится к этому предприятию или уже архивирован')
    with store.connect() as db:
        db.execute('DELETE FROM document_staff WHERE venue_id=? AND document_key=?',(venue_id,key))
        for role,emp_id in people.items():
            if emp_id is not None:
                db.execute('INSERT INTO document_staff VALUES (?,?,?,?)',(venue_id,key,role,emp_id))
        db.execute('''INSERT INTO document_staff_options VALUES(?,?,?,?)
            ON CONFLICT(venue_id,document_key) DO UPDATE SET
            include_duties=excluded.include_duties,include_requirements=excluded.include_requirements''',
            (venue_id,key,int(bool(include_duties)),int(bool(include_requirements))))
        store._audit(db,venue_id,'document_staff_changed',{'document_key':key,'roles':list(people),
                    'include_duties':bool(include_duties),'include_requirements':bool(include_requirements)})

def staff_value(store,venue_id,document_key,role,attr):
    if role not in ROLE_NAMES or attr not in ATTRS:raise ValueError('Неверное поле сотрудника')
    person=get_assignments(store,venue_id,document_key)['people'].get(role)
    if not person:return ''
    return str(person.get({'name':'full_name','position':'position_name'}.get(attr,attr),'') or '')

def appendix_rows(store,venue_id,document_key):
    """Role holders AND acknowledged workers, independently enabled per document."""
    conf=get_assignments(store,venue_id,document_key)
    if not (conf['include_duties'] or conf['include_requirements']):return []
    result=[];visited=set()
    people=[]
    for role,role_label in ROLES:
        person=conf['people'].get(role)
        if person:people.append((role_label,person))
    people.extend(('Ознакомление',e) for e in list_acknowledgements(store,venue_id,document_key))
    for role_label,employee in people:
        if employee['id'] in visited:continue
        visited.add(employee['id'])
        position=get_position(employee['position_code']) if employee.get('position_code') else None
        if not position:
            # Do not invent professional requirements for a custom position.
            continue
        result.append({'role':role_label,'name':employee['full_name'],'position':employee['position_name'],
            'duties':position.duties if conf['include_duties'] else (),
            'requirements':position.requirements if conf['include_requirements'] else (),
            'source':reference(position),'custom':False})
    return result


def suggested_column_value(store,venue_id,document_key,column_label):
    """Offer identity only; never infer measurement, signed status, or a signature."""
    name=' '.join(str(column_label).casefold().replace('ё','е').split())
    if 'подпись' in name or 'температур' in name or 'измерен' in name or 'показан' in name:
        return ''
    role='responsible'
    for text,key in [('разработ','developed'),('согласова','agreed'),('утверд','approved'),('проверил','checked')]:
        if text in name:role=key;break
    if any(k in name for k in ('фио','ф.и.о.','фамили','сотрудник','ответствен','разработ','согласова','утверд','проверил')):
        return staff_value(store,venue_id,document_key,role,'position' if 'должност' in name else 'name')
    if 'должност' in name or 'професси' in name:
        return staff_value(store,venue_id,document_key,role,'position')
    return ''


def save_acknowledgements(store, venue_id, document_key, employee_ids):
    """Replace the roster for one document only. No signatures/dates are fabricated."""
    migrate_staff(store)
    _validate_venue(store,venue_id)
    key=_key(document_key)
    ids=[int(x) for x in employee_ids]
    if len(set(ids))!=len(ids) or len(ids)>500:
        raise ValueError('Список ознакомления содержит повторения или слишком велик')
    for employee_id in ids:
        if not get_employee(store,venue_id,employee_id):
            raise ValueError('В списке сотрудник другого предприятия или из архива')
    with store.connect() as db:
        db.execute('DELETE FROM document_acknowledgements WHERE venue_id=? AND document_key=?',(venue_id,key))
        db.executemany('INSERT INTO document_acknowledgements (venue_id,document_key,employee_id,position_order) VALUES(?,?,?,?)',
                       [(venue_id,key,emp_id,idx) for idx,emp_id in enumerate(ids)])
        store._audit(db,venue_id,'acknowledgement_roster_changed',{'document_key':key,'employee_ids':ids})


def list_acknowledgements(store,venue_id,document_key):
    """Only active employees appear in newly generated forms. Archived links stay in SQLite."""
    migrate_staff(store)
    key=_key(document_key)
    with store.connect() as db:
        return [dict(row) for row in db.execute("""SELECT e.* FROM document_acknowledgements a
            JOIN employees e ON e.id=a.employee_id AND e.venue_id=a.venue_id
            WHERE a.venue_id=? AND a.document_key=? AND e.active=1
            ORDER BY a.position_order,e.id""",(venue_id,key))]


def restore_employee(store,venue_id,employee_id):
    migrate_staff(store)
    if not get_employee(store,venue_id,employee_id,active_only=False):
        raise ValueError('Сотрудник не найден')
    with store.connect() as db:
        db.execute('UPDATE employees SET active=1,updated_at=? WHERE venue_id=? AND id=?',(now(),venue_id,employee_id))
        store._audit(db,venue_id,'employee_restored',{'employee_id':employee_id})


def delete_employee(store,venue_id,employee_id):
    """Permanent deletion is allowed only if identity has no document references."""
    migrate_staff(store)
    if not get_employee(store,venue_id,employee_id,active_only=False):
        raise ValueError('Сотрудник не найден')
    with store.connect() as db:
        refs=db.execute('SELECT COUNT(*) FROM document_staff WHERE venue_id=? AND employee_id=?',(venue_id,employee_id)).fetchone()[0]
        refs+=db.execute('SELECT COUNT(*) FROM document_acknowledgements WHERE venue_id=? AND employee_id=?',(venue_id,employee_id)).fetchone()[0]
        if refs:
            raise ValueError('Сотрудник уже указан в документах. Переведите его в архив, чтобы сохранить историю.')
        db.execute('DELETE FROM employees WHERE venue_id=? AND id=?',(venue_id,employee_id))
        store._audit(db,venue_id,'employee_deleted',{'employee_id':employee_id})
