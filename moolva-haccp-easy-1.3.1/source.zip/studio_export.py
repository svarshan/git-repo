"""Selected-document export center: Word, PDF, both, audit and package passport."""
from __future__ import annotations
from pathlib import Path
from datetime import datetime
from xml.sax.saxutils import escape
from exports import export_journal, safe_name, _register_pdf_font
from template_store import export_template
from studio_core import audit_enterprise
from smart_control import package_lines


def export_text_report(lines, destination, fmt):
    destination=Path(destination)
    destination.parent.mkdir(parents=True,exist_ok=True)
    if fmt=='docx':
        from docx import Document
        from docx.shared import Pt
        d=Document(); d.styles['Normal'].font.name='Arial';d.styles['Normal'].font.size=Pt(9)
        for i,line in enumerate(lines):
            if i==0:d.add_heading(line,0)
            elif line.isupper() and len(line)>9:d.add_heading(line,2)
            else:d.add_paragraph(line)
        d.save(destination)
    elif fmt=='pdf':
        from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle
        font=_register_pdf_font(); style=ParagraphStyle('base',fontName=font,fontSize=8.5,leading=12,spaceAfter=5)
        SimpleDocTemplate(str(destination),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=38,bottomMargin=38).build(
            [Paragraph(escape(line),style) if line else Spacer(1,7) for line in lines])
    else:raise ValueError('Укажите Word (.docx) или PDF (.pdf)')
    return destination


def export_selected(store,venue_id,items,destination,formats=('docx','pdf'),passport=False,audit=False):
    from exports import get_templates
    from template_store import list_templates
    if store.get_venue(venue_id) is None:raise ValueError('Предприятие не найдено')
    if not formats or not set(formats)<={'docx','pdf'}:raise ValueError('Выберите Word или PDF')
    journal={x.code:x for x in get_templates(store)}
    custom={x['id']:x for x in list_templates(store,venue_id)}
    codes=list(dict.fromkeys(items))
    for code in codes:
        if (code.startswith('journal:') and code[8:] in journal) or (code.startswith('word:') and code[5:] in custom):
            continue
        raise ValueError('Документ не найден для текущего предприятия: '+code)
    if not codes and not passport and not audit:raise ValueError('Выберите хотя бы один документ')
    root=Path(destination)
    if not root.is_dir():raise ValueError('Укажите существующую папку для сохранения')
    name=safe_name(store.get_venue(venue_id)['venue_name'])[:35]
    base='MoOLVa_Комплект_'+name+'_'+datetime.now().strftime('%Y%m%d_%H%M%S')
    out=root/base;counter=1
    while out.exists():
        out=root/(base+'_'+str(counter));counter+=1
    out.mkdir()
    created=[]; errors=[]
    for code in codes:
        if code.startswith('journal:'):
            template=journal[code[8:]]
            label=safe_name('Журнал_'+template.code+'_'+template.title)
            runner=lambda filename,fmt:export_journal(store,venue_id,template,filename,fmt)
        else:
            template=custom[code[5:]]
            label=safe_name('Word_'+template['id'][:8]+'_'+template['name'])
            runner=lambda filename,fmt:export_template(store,venue_id,template['id'],filename,fmt)
        for fmt in formats:
            path=out/(label+'.'+fmt)
            try:
                runner(path,fmt);created.append(path)
            except Exception as exc:
                path.unlink(missing_ok=True)
                errors.append(f'{label} ({fmt}): {exc}')
    if passport:
        for fmt in formats:
            path=out/('Паспорт_комплекта.'+fmt)
            try: created.append(export_text_report(package_lines(store,venue_id),path,fmt))
            except Exception as exc:errors.append('Паспорт '+fmt+': '+str(exc))
    if audit:
        for fmt in formats:
            path=out/('Отчёт_предварительной_проверки.'+fmt)
            try:created.append(export_text_report(audit_enterprise(store,venue_id)['lines'],path,fmt))
            except Exception as exc:errors.append('Аудит '+fmt+': '+str(exc))
    index=['MoOLVa ХАССП Studio — комплект',
           'Объект: '+store.get_venue(venue_id)['venue_name'],
           'Сформировано: '+datetime.now().strftime('%d.%m.%Y %H:%M'),
           'Сохранено файлов: '+str(len(created)),
           'Ошибок: '+str(len(errors)),'',
           'Файлы:']+[p.name for p in created]+['','Ошибки:']+errors+['',
           'Подбор и аудит предварительные. Подписи и измерения вносятся по факту.']
    (out/'Состав_комплекта.txt').write_text('\n'.join(index),encoding='utf-8')
    with store.connect() as db:
        store._audit(db,venue_id,'studio_package_exported',{'files':len(created),'errors':len(errors),'formats':list(formats)})
    return {'folder':out,'files':created,'errors':errors}
