"""Индивидуальные блок-схемы предприятия и планов ХАССП.

Схемы хранятся отдельно для каждого предприятия. Автопостроение создаёт только
черновую технологическую последовательность. Оно НЕ назначает ККТ, критические
пределы или опасности, которых пользователь не вводил в план ХАССП.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime
import json
import math
import shutil

from storage import now

DIAGRAM_TYPES = (
    'Общая схема предприятия',
    'Производственный процесс',
    'Схема цеха',
    'Схема продукта',
    'Схема плана ХАССП',
    'Пустая схема',
)
CCP_STATUSES = ('Не определено', 'ККТ', 'Не ККТ')


def migrate_flowcharts(store):
    with store.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS flow_diagrams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            venue_id INTEGER NOT NULL REFERENCES venues(id),
            title TEXT NOT NULL,
            diagram_type TEXT NOT NULL DEFAULT 'Пустая схема',
            description TEXT NOT NULL DEFAULT '',
            haccp_plan_id INTEGER,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_flow_diagrams_venue ON flow_diagrams(venue_id,id);
        CREATE TABLE IF NOT EXISTS flow_nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            diagram_id INTEGER NOT NULL REFERENCES flow_diagrams(id) ON DELETE CASCADE,
            position INTEGER NOT NULL DEFAULT 0,
            name TEXT NOT NULL,
            x INTEGER NOT NULL DEFAULT 80,
            y INTEGER NOT NULL DEFAULT 80,
            width INTEGER NOT NULL DEFAULT 190,
            height INTEGER NOT NULL DEFAULT 92,
            description TEXT NOT NULL DEFAULT '',
            equipment TEXT NOT NULL DEFAULT '',
            responsible_employee_id INTEGER,
            hazard_biological TEXT NOT NULL DEFAULT '',
            hazard_chemical TEXT NOT NULL DEFAULT '',
            hazard_physical TEXT NOT NULL DEFAULT '',
            hazard_allergen TEXT NOT NULL DEFAULT '',
            control_measure TEXT NOT NULL DEFAULT '',
            ccp_status TEXT NOT NULL DEFAULT 'Не определено',
            critical_limit TEXT NOT NULL DEFAULT '',
            monitoring TEXT NOT NULL DEFAULT '',
            corrective_action TEXT NOT NULL DEFAULT '',
            journal_code TEXT NOT NULL DEFAULT '',
            source_step_id INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_flow_nodes_diagram ON flow_nodes(diagram_id,position,id);
        CREATE TABLE IF NOT EXISTS flow_edges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            diagram_id INTEGER NOT NULL REFERENCES flow_diagrams(id) ON DELETE CASCADE,
            source_node_id INTEGER NOT NULL REFERENCES flow_nodes(id) ON DELETE CASCADE,
            target_node_id INTEGER NOT NULL REFERENCES flow_nodes(id) ON DELETE CASCADE,
            label TEXT NOT NULL DEFAULT '',
            position INTEGER NOT NULL DEFAULT 0,
            UNIQUE(diagram_id,source_node_id,target_node_id)
        );
        CREATE INDEX IF NOT EXISTS idx_flow_edges_diagram ON flow_edges(diagram_id,position,id);
        ''')


def _clean(v):
    return str(v or '').strip()


def list_diagrams(store, venue_id):
    with store.connect() as db:
        return [dict(r) for r in db.execute(
            '''SELECT d.*, (SELECT COUNT(*) FROM flow_nodes n WHERE n.diagram_id=d.id) AS node_count,
                      (SELECT COUNT(*) FROM flow_edges e WHERE e.diagram_id=d.id) AS edge_count
               FROM flow_diagrams d WHERE d.venue_id=? ORDER BY d.updated_at DESC,d.id DESC''',
            (venue_id,))]


def get_diagram(store, diagram_id):
    with store.connect() as db:
        row=db.execute('SELECT * FROM flow_diagrams WHERE id=?',(diagram_id,)).fetchone()
        return dict(row) if row else None


def diagram_details(store, diagram_id):
    d=get_diagram(store,diagram_id)
    if not d:
        raise ValueError('Схема не найдена')
    with store.connect() as db:
        nodes=[dict(r) for r in db.execute('SELECT * FROM flow_nodes WHERE diagram_id=? ORDER BY position,id',(diagram_id,))]
        edges=[dict(r) for r in db.execute('SELECT * FROM flow_edges WHERE diagram_id=? ORDER BY position,id',(diagram_id,))]
    return {'diagram':d,'venue':store.get_venue(d['venue_id']),'nodes':nodes,'edges':edges}


def create_diagram(store, venue_id, title, diagram_type='Пустая схема', description='', haccp_plan_id=None):
    if not store.get_venue(venue_id):
        raise ValueError('Предприятие не найдено')
    title=_clean(title)
    if not title:
        raise ValueError('Укажите название схемы')
    if diagram_type not in DIAGRAM_TYPES:
        diagram_type='Пустая схема'
    with store.connect() as db:
        cur=db.execute('''INSERT INTO flow_diagrams(venue_id,title,diagram_type,description,haccp_plan_id,created_at,updated_at)
                          VALUES(?,?,?,?,?,?,?)''',
                       (venue_id,title,diagram_type,_clean(description),haccp_plan_id,now(),now()))
        did=cur.lastrowid
        store._audit(db,venue_id,'flow_diagram_created',{'diagram_id':did,'title':title,'type':diagram_type})
        return did


def update_diagram(store, diagram_id, **fields):
    d=get_diagram(store,diagram_id)
    if not d: raise ValueError('Схема не найдена')
    allowed={k:_clean(v) for k,v in fields.items() if k in ('title','diagram_type','description')}
    if 'title' in allowed and not allowed['title']: raise ValueError('Название схемы не может быть пустым')
    if 'diagram_type' in allowed and allowed['diagram_type'] not in DIAGRAM_TYPES: raise ValueError('Неизвестный тип схемы')
    if not allowed:return
    with store.connect() as db:
        db.execute('UPDATE flow_diagrams SET '+','.join(f'{k}=?' for k in allowed)+',updated_at=? WHERE id=?',
                   (*allowed.values(),now(),diagram_id))
        store._audit(db,d['venue_id'],'flow_diagram_updated',{'diagram_id':diagram_id,'fields':list(allowed)})


def delete_diagram(store, diagram_id):
    d=get_diagram(store,diagram_id)
    if not d: return False
    with store.connect() as db:
        db.execute('DELETE FROM flow_diagrams WHERE id=?',(diagram_id,))
        store._audit(db,d['venue_id'],'flow_diagram_deleted',{'diagram_id':diagram_id,'title':d['title']})
    return True


def duplicate_diagram(store, diagram_id, title=None):
    src=diagram_details(store,diagram_id)
    d=src['diagram']
    new_id=create_diagram(store,d['venue_id'],title or (d['title']+' — копия'),d['diagram_type'],d['description'],d.get('haccp_plan_id'))
    mapping={}
    for n in src['nodes']:
        data={k:n[k] for k in NODE_EDITABLE if k in n}
        nid=create_node(store,new_id,n['name'],x=n['x'],y=n['y'],**{k:v for k,v in data.items() if k not in ('name','x','y')})
        mapping[n['id']]=nid
    for e in src['edges']:
        if e['source_node_id'] in mapping and e['target_node_id'] in mapping:
            add_edge(store,new_id,mapping[e['source_node_id']],mapping[e['target_node_id']],e.get('label',''))
    return new_id


NODE_EDITABLE=('name','description','equipment','responsible_employee_id','hazard_biological','hazard_chemical',
               'hazard_physical','hazard_allergen','control_measure','ccp_status','critical_limit','monitoring',
               'corrective_action','journal_code','source_step_id','x','y','width','height','position')


def create_node(store, diagram_id, name, x=80, y=80, **fields):
    d=get_diagram(store,diagram_id)
    if not d: raise ValueError('Схема не найдена')
    name=_clean(name)
    if not name: raise ValueError('Укажите название этапа')
    values={k:fields.get(k) for k in NODE_EDITABLE if k in fields}
    values['name']=name;values['x']=int(x);values['y']=int(y)
    values.setdefault('ccp_status','Не определено')
    if values.get('ccp_status') not in CCP_STATUSES:values['ccp_status']='Не определено'
    with store.connect() as db:
        pos=fields.get('position')
        if pos is None:pos=db.execute('SELECT COALESCE(MAX(position),0)+1 FROM flow_nodes WHERE diagram_id=?',(diagram_id,)).fetchone()[0]
        columns=['diagram_id','position','name','x','y']
        params=[diagram_id,int(pos),name,int(x),int(y)]
        defaults={'width':190,'height':92,'description':'','equipment':'','responsible_employee_id':None,
                  'hazard_biological':'','hazard_chemical':'','hazard_physical':'','hazard_allergen':'',
                  'control_measure':'','ccp_status':'Не определено','critical_limit':'','monitoring':'',
                  'corrective_action':'','journal_code':'','source_step_id':None}
        for k,default in defaults.items():
            columns.append(k);v=values.get(k,default)
            if k not in ('responsible_employee_id','source_step_id','width','height'):v=_clean(v)
            params.append(v)
        q='INSERT INTO flow_nodes('+','.join(columns)+') VALUES('+','.join('?' for _ in columns)+')'
        cur=db.execute(q,params)
        db.execute('UPDATE flow_diagrams SET updated_at=? WHERE id=?',(now(),diagram_id))
        store._audit(db,d['venue_id'],'flow_node_created',{'diagram_id':diagram_id,'node_id':cur.lastrowid,'name':name})
        return cur.lastrowid


def update_node(store, diagram_id, node_id, **fields):
    d=get_diagram(store,diagram_id)
    if not d:raise ValueError('Схема не найдена')
    with store.connect() as db:
        exists=db.execute('SELECT id FROM flow_nodes WHERE id=? AND diagram_id=?',(node_id,diagram_id)).fetchone()
        if not exists:raise ValueError('Этап не принадлежит схеме')
        allowed={}
        for k,v in fields.items():
            if k not in NODE_EDITABLE:continue
            if k in ('x','y','width','height','position'):
                allowed[k]=int(v)
            elif k in ('responsible_employee_id','source_step_id'):
                allowed[k]=None if v in (None,'') else int(v)
            else:allowed[k]=_clean(v)
        if 'name' in allowed and not allowed['name']:raise ValueError('Название этапа не может быть пустым')
        if 'ccp_status' in allowed and allowed['ccp_status'] not in CCP_STATUSES:raise ValueError('Неверный статус ККТ')
        if not allowed:return
        db.execute('UPDATE flow_nodes SET '+','.join(f'{k}=?' for k in allowed)+' WHERE id=? AND diagram_id=?',
                   (*allowed.values(),node_id,diagram_id))
        db.execute('UPDATE flow_diagrams SET updated_at=? WHERE id=?',(now(),diagram_id))
        store._audit(db,d['venue_id'],'flow_node_updated',{'diagram_id':diagram_id,'node_id':node_id,'fields':list(allowed)})


def delete_node(store, diagram_id, node_id):
    d=get_diagram(store,diagram_id)
    if not d:return False
    with store.connect() as db:
        cur=db.execute('DELETE FROM flow_nodes WHERE id=? AND diagram_id=?',(node_id,diagram_id))
        db.execute('UPDATE flow_diagrams SET updated_at=? WHERE id=?',(now(),diagram_id))
        if cur.rowcount:store._audit(db,d['venue_id'],'flow_node_deleted',{'diagram_id':diagram_id,'node_id':node_id})
        return bool(cur.rowcount)


def add_edge(store, diagram_id, source_node_id, target_node_id, label=''):
    if int(source_node_id)==int(target_node_id):raise ValueError('Нельзя соединить этап с самим собой')
    d=get_diagram(store,diagram_id)
    if not d:raise ValueError('Схема не найдена')
    with store.connect() as db:
        ids={r['id'] for r in db.execute('SELECT id FROM flow_nodes WHERE diagram_id=?',(diagram_id,))}
        if source_node_id not in ids or target_node_id not in ids:raise ValueError('Этап не принадлежит схеме')
        pos=db.execute('SELECT COALESCE(MAX(position),0)+1 FROM flow_edges WHERE diagram_id=?',(diagram_id,)).fetchone()[0]
        try:
            cur=db.execute('INSERT INTO flow_edges(diagram_id,source_node_id,target_node_id,label,position) VALUES(?,?,?,?,?)',
                           (diagram_id,source_node_id,target_node_id,_clean(label),pos))
        except Exception as ex:
            if 'UNIQUE' in str(ex).upper():raise ValueError('Эти этапы уже соединены')
            raise
        db.execute('UPDATE flow_diagrams SET updated_at=? WHERE id=?',(now(),diagram_id))
        store._audit(db,d['venue_id'],'flow_edge_created',{'diagram_id':diagram_id,'edge_id':cur.lastrowid,'from':source_node_id,'to':target_node_id})
        return cur.lastrowid


def delete_edge(store, diagram_id, edge_id):
    d=get_diagram(store,diagram_id)
    if not d:return False
    with store.connect() as db:
        cur=db.execute('DELETE FROM flow_edges WHERE id=? AND diagram_id=?',(edge_id,diagram_id))
        db.execute('UPDATE flow_diagrams SET updated_at=? WHERE id=?',(now(),diagram_id))
        return bool(cur.rowcount)


def clear_diagram(store, diagram_id):
    d=get_diagram(store,diagram_id)
    if not d:raise ValueError('Схема не найдена')
    with store.connect() as db:
        db.execute('DELETE FROM flow_edges WHERE diagram_id=?',(diagram_id,))
        db.execute('DELETE FROM flow_nodes WHERE diagram_id=?',(diagram_id,))
        db.execute('UPDATE flow_diagrams SET updated_at=? WHERE id=?',(now(),diagram_id))


def auto_layout(store, diagram_id, columns=4):
    data=diagram_details(store,diagram_id)
    nodes=data['nodes']
    if not nodes:return
    columns=max(1,min(6,int(columns)))
    with store.connect() as db:
        for i,n in enumerate(nodes):
            row=i//columns;col=i%columns
            # alternate direction to keep sequential arrows shorter
            visual_col=col if row%2==0 else columns-1-col
            x=70+visual_col*245;y=70+row*165
            db.execute('UPDATE flow_nodes SET x=?,y=?,position=? WHERE id=?',(x,y,i+1,n['id']))
        db.execute('UPDATE flow_diagrams SET updated_at=? WHERE id=?',(now(),diagram_id))


def _sequential_fill(store, diagram_id, names, source_rows=None):
    clear_diagram(store,diagram_id)
    ids=[]
    source_rows=source_rows or [None]*len(names)
    for i,(name,row) in enumerate(zip(names,source_rows)):
        fields={}
        if row:
            fields.update(row)
        nid=create_node(store,diagram_id,name,position=i+1,**fields)
        ids.append(nid)
    for a,b in zip(ids,ids[1:]):add_edge(store,diagram_id,a,b)
    auto_layout(store,diagram_id)
    return ids


def build_from_venue(store, diagram_id):
    from haccp_core import recommended_flow
    d=get_diagram(store,diagram_id)
    if not d:raise ValueError('Схема не найдена')
    venue=store.get_venue(d['venue_id'])
    names=recommended_flow(venue.get('flags',{}))
    update_diagram(store,diagram_id,diagram_type='Общая схема предприятия')
    return _sequential_fill(store,diagram_id,names)


def _join(values):
    out=[]
    for v in values:
        v=_clean(v)
        if v and v not in out:out.append(v)
    return '\n'.join(out)


def build_from_haccp_plan(store, diagram_id, plan_id):
    from haccp_core import HACCPPlans
    plans=HACCPPlans(store)
    details=plans.details(plan_id)
    d=get_diagram(store,diagram_id)
    if not d or d['venue_id']!=details['plan']['venue_id']:
        raise ValueError('План ХАССП относится к другому предприятию')
    names=[];rows=[]
    for step in details['steps']:
        hazards=step.get('hazards',[])
        by_type={k:[] for k in ('Биологический','Химический','Физический','Аллергенный')}
        for h in hazards:
            if h.get('hazard_type') in by_type:by_type[h['hazard_type']].append(h.get('description',''))
        ccp='ККТ' if any(h.get('ccp_status')=='ККТ' for h in hazards) else ('Не ККТ' if hazards and all(h.get('ccp_status')=='Не ККТ' for h in hazards) else 'Не определено')
        rows.append({
            'description':step.get('description',''),'equipment':step.get('equipment',''),
            'hazard_biological':_join(by_type['Биологический']),
            'hazard_chemical':_join(by_type['Химический']),
            'hazard_physical':_join(by_type['Физический']),
            'hazard_allergen':_join(by_type['Аллергенный']),
            'control_measure':_join(h.get('control_measure','') for h in hazards),
            'ccp_status':ccp,
            'critical_limit':_join(h.get('critical_limit','') for h in hazards if h.get('ccp_status')=='ККТ'),
            'monitoring':_join(' / '.join(filter(None,[h.get('monitor_what',''),h.get('monitor_how',''),h.get('monitor_frequency',''),h.get('monitor_who','')])) for h in hazards),
            'corrective_action':_join(h.get('corrective_action','') for h in hazards),
            'journal_code':next((h.get('journal_code','') for h in hazards if _clean(h.get('journal_code',''))),''),
            'source_step_id':step.get('id'),
        })
        names.append(step['name'])
    if not names:raise ValueError('В плане ХАССП пока нет этапов')
    with store.connect() as db:
        db.execute('UPDATE flow_diagrams SET haccp_plan_id=?,diagram_type=?,updated_at=? WHERE id=?',
                   (plan_id,'Схема плана ХАССП',now(),diagram_id))
    return _sequential_fill(store,diagram_id,names,rows)


def validate_diagram(store, diagram_id):
    data=diagram_details(store,diagram_id);nodes=data['nodes'];edges=data['edges']
    issues=[]
    if not nodes:
        return [{'level':'error','code':'empty','text':'В схеме нет этапов. Добавьте этап или выполните автопостроение.','node_id':None}]
    ids={n['id'] for n in nodes};incoming={i:0 for i in ids};outgoing={i:0 for i in ids};adj={i:set() for i in ids}
    for e in edges:
        a=e['source_node_id'];b=e['target_node_id']
        if a in ids and b in ids:
            outgoing[a]+=1;incoming[b]+=1;adj[a].add(b);adj[b].add(a)
    starts=[i for i in ids if incoming[i]==0];ends=[i for i in ids if outgoing[i]==0]
    if not starts:issues.append({'level':'error','code':'no_start','text':'Не найден начальный этап: у каждого блока есть входящая связь.','node_id':None})
    if not ends:issues.append({'level':'error','code':'no_end','text':'Не найден конечный этап: у каждого блока есть исходящая связь.','node_id':None})
    if len(starts)>1:issues.append({'level':'warning','code':'multi_start','text':f'Обнаружено несколько начальных этапов: {len(starts)}. Проверьте, это намеренное ветвление?','node_id':None})
    # connectivity ignoring direction
    seen=set();stack=[next(iter(ids))]
    while stack:
        cur=stack.pop()
        if cur in seen:continue
        seen.add(cur);stack.extend(adj[cur]-seen)
    if seen!=ids:
        issues.append({'level':'error','code':'disconnected','text':f'Есть несвязанные этапы: {len(ids-seen)}.','node_id':next(iter(ids-seen))})
    for n in nodes:
        hazards=any(_clean(n[k]) for k in ('hazard_biological','hazard_chemical','hazard_physical','hazard_allergen'))
        if not hazards:issues.append({'level':'warning','code':'no_hazard','text':f'«{n["name"]}»: опасности не описаны.','node_id':n['id']})
        if hazards and not _clean(n['control_measure']):issues.append({'level':'warning','code':'no_control','text':f'«{n["name"]}»: есть опасность, но не указана мера управления.','node_id':n['id']})
        if n['ccp_status']=='ККТ' and not _clean(n['critical_limit']):issues.append({'level':'error','code':'ccp_limit','text':f'«{n["name"]}»: для ККТ не указан критический предел.','node_id':n['id']})
        if n['ccp_status']=='ККТ' and not _clean(n['monitoring']):issues.append({'level':'error','code':'ccp_monitor','text':f'«{n["name"]}»: для ККТ не описан мониторинг.','node_id':n['id']})
        if n['ccp_status']=='ККТ' and not _clean(n['corrective_action']):issues.append({'level':'error','code':'ccp_correct','text':f'«{n["name"]}»: для ККТ не указаны корректирующие действия.','node_id':n['id']})
        if n.get('responsible_employee_id') in (None,''):issues.append({'level':'info','code':'no_responsible','text':f'«{n["name"]}»: ответственный не назначен.','node_id':n['id']})
        if not _clean(n.get('journal_code')):issues.append({'level':'info','code':'no_journal','text':f'«{n["name"]}»: журнал контроля не привязан.','node_id':n['id']})
    return issues


def _font_path():
    candidates=(r'C:\Windows\Fonts\segoeui.ttf',r'C:\Windows\Fonts\arial.ttf',
                '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf')
    for p in candidates:
        if Path(p).is_file():return p
    return None


def render_png(store, diagram_id, output, scale=1.0):
    from PIL import Image, ImageDraw, ImageFont
    data=diagram_details(store,diagram_id);nodes=data['nodes'];edges=data['edges'];d=data['diagram']
    if not nodes:raise ValueError('Схема пуста')
    minx=min(n['x'] for n in nodes);miny=min(n['y'] for n in nodes)
    maxx=max(n['x']+n['width'] for n in nodes);maxy=max(n['y']+n['height'] for n in nodes)
    pad=70;title_h=90
    width=max(900,maxx-minx+pad*2);height=max(500,maxy-miny+pad*2+title_h)
    width=int(width*scale);height=int(height*scale)
    im=Image.new('RGB',(width,height),(28,32,38));draw=ImageDraw.Draw(im)
    fp=_font_path()
    try:
        font=ImageFont.truetype(fp,int(18*scale)) if fp else ImageFont.load_default()
        font_b=ImageFont.truetype(fp,int(21*scale)) if fp else font
        small=ImageFont.truetype(fp,int(13*scale)) if fp else font
    except Exception:
        font=font_b=small=ImageFont.load_default()
    def T(x):return int(x*scale)
    draw.text((T(35),T(24)),d['title'],fill=(241,244,246),font=font_b)
    draw.text((T(35),T(55)),f"{d['diagram_type']} · MoOLVa ХАССП Easy",fill=(137,148,159),font=small)
    pos={}
    for n in nodes:
        x=T(n['x']-minx+pad);y=T(n['y']-miny+pad+title_h);w=T(n['width']);h=T(n['height']);pos[n['id']]=(x,y,w,h)
    # edges first
    for e in edges:
        if e['source_node_id'] not in pos or e['target_node_id'] not in pos:continue
        ax,ay,aw,ah=pos[e['source_node_id']];bx,by,bw,bh=pos[e['target_node_id']]
        x1=ax+aw//2;y1=ay+ah//2;x2=bx+bw//2;y2=by+bh//2
        dx=x2-x1;dy=y2-y1;dist=max(1,math.hypot(dx,dy));ux=dx/dist;uy=dy/dist
        sx=x1+int(ux*aw*.45);sy=y1+int(uy*ah*.42);tx=x2-int(ux*bw*.45);ty=y2-int(uy*bh*.42)
        draw.line((sx,sy,tx,ty),fill=(109,125,139),width=max(2,T(2)))
        # arrow head
        al=T(11);ang=math.atan2(ty-sy,tx-sx)
        p1=(tx-int(al*math.cos(ang-math.pi/6)),ty-int(al*math.sin(ang-math.pi/6)))
        p2=(tx-int(al*math.cos(ang+math.pi/6)),ty-int(al*math.sin(ang+math.pi/6)))
        draw.polygon([(tx,ty),p1,p2],fill=(109,125,139))
    for n in nodes:
        x,y,w,h=pos[n['id']]
        ccp=n['ccp_status']=='ККТ';haz=any(_clean(n[k]) for k in ('hazard_biological','hazard_chemical','hazard_physical','hazard_allergen'))
        fill=(72,48,49) if ccp else ((61,57,39) if haz else (45,50,58))
        outline=(232,137,137) if ccp else ((229,192,100) if haz else (77,168,190))
        draw.rounded_rectangle((x,y,x+w,y+h),radius=T(12),fill=fill,outline=outline,width=max(2,T(2)))
        # simple wrapped title
        words=n['name'].split();lines=[];cur=''
        maxchars=max(12,int(n['width']/10))
        for word in words:
            trial=(cur+' '+word).strip()
            if len(trial)>maxchars and cur:lines.append(cur);cur=word
            else:cur=trial
        if cur:lines.append(cur)
        for j,line in enumerate(lines[:3]):draw.text((x+T(12),y+T(12+j*20)),line,fill=(241,244,246),font=font)
        tag='ККТ' if ccp else ('РИСКИ' if haz else 'ЭТАП')
        draw.text((x+T(12),y+h-T(22)),tag,fill=outline,font=small)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True);im.save(output,'PNG',optimize=True)
    return output


def export_docx(store, diagram_id, output):
    from tempfile import TemporaryDirectory
    from docx import Document
    from docx.shared import Cm, Pt
    from docx.enum.section import WD_ORIENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    data=diagram_details(store,diagram_id);d=data['diagram'];venue=data['venue'];issues=validate_diagram(store,diagram_id)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    with TemporaryDirectory() as td:
        png=render_png(store,diagram_id,Path(td)/'diagram.png')
        doc=Document();sec=doc.sections[0];sec.orientation=WD_ORIENT.LANDSCAPE;sec.page_width,sec.page_height=Cm(29.7),Cm(21)
        sec.left_margin=sec.right_margin=Cm(1.2);sec.top_margin=sec.bottom_margin=Cm(1.2)
        doc.styles['Normal'].font.name='Arial';doc.styles['Normal'].font.size=Pt(9)
        p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=p.add_run(d['title']);r.bold=True;r.font.size=Pt(18)
        doc.add_paragraph(f"Предприятие: {venue.get('venue_name','')} · Тип схемы: {d['diagram_type']}")
        if d.get('description'):doc.add_paragraph(d['description'])
        from PIL import Image as PILImage
        with PILImage.open(png) as img:
            iw,ih=img.size
        maxw,maxh=26.5,13.2
        ratio=min(maxw/max(iw,1),maxh/max(ih,1))
        doc.add_picture(str(png),width=Cm(iw*ratio),height=Cm(ih*ratio))
        doc.add_page_break()
        doc.add_heading('Этапы схемы',level=1)
        table=doc.add_table(rows=1,cols=6);table.style='Table Grid'
        for i,v in enumerate(('Этап','Опасности','Мера управления','ККТ','Критический предел','Мониторинг')):table.rows[0].cells[i].text=v
        for n in data['nodes']:
            hazards='; '.join(filter(None,[n['hazard_biological'],n['hazard_chemical'],n['hazard_physical'],n['hazard_allergen']]))
            vals=(n['name'],hazards,n['control_measure'],n['ccp_status'],n['critical_limit'],n['monitoring'])
            cells=table.add_row().cells
            for i,v in enumerate(vals):cells[i].text=str(v or '')
        doc.add_heading('Проверка полноты',level=1)
        if not issues:doc.add_paragraph('Замечаний по автоматической проверке структуры не найдено.')
        for x in issues:doc.add_paragraph(f"[{x['level'].upper()}] {x['text']}")
        doc.add_paragraph('Важно: блок-схема и автоматическая проверка являются рабочим инструментом. Решения о значимости опасностей, ККТ и критических пределах принимает специалист ХАССП.')
        doc.save(output)
    return output


def export_pdf(store, diagram_id, output):
    from tempfile import TemporaryDirectory
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image as RLImage,Table,TableStyle,PageBreak
    from reportlab.lib.pagesizes import A4,landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from exports import _register_pdf_font
    data=diagram_details(store,diagram_id);d=data['diagram'];venue=data['venue'];issues=validate_diagram(store,diagram_id)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True);font=_register_pdf_font()
    styles={'title':ParagraphStyle('t',fontName=font,fontSize=16,leading=20,spaceAfter=8),
            'h':ParagraphStyle('h',fontName=font,fontSize=12,leading=15,spaceBefore=8,spaceAfter=5),
            'p':ParagraphStyle('p',fontName=font,fontSize=8.5,leading=11)}
    with TemporaryDirectory() as td:
        png=render_png(store,diagram_id,Path(td)/'diagram.png')
        doc=SimpleDocTemplate(str(output),pagesize=landscape(A4),leftMargin=10*mm,rightMargin=10*mm,topMargin=10*mm,bottomMargin=10*mm)
        story=[Paragraph(d['title'],styles['title']),Paragraph(f"Предприятие: {venue.get('venue_name','')} · Тип схемы: {d['diagram_type']}",styles['p'])]
        if d.get('description'):story.append(Paragraph(d['description'],styles['p']))
        from PIL import Image as PILImage
        with PILImage.open(png) as img:
            iw,ih=img.size
        ratio=min(270/max(iw,1),130/max(ih,1))
        story += [Spacer(1,5*mm),RLImage(str(png),width=iw*ratio*mm,height=ih*ratio*mm),PageBreak(),Paragraph('Этапы схемы',styles['h'])]
        rows=[[Paragraph(x,styles['p']) for x in ('Этап','Опасности','Мера управления','ККТ','Критический предел','Мониторинг')]]
        for n in data['nodes']:
            hazards='; '.join(filter(None,[n['hazard_biological'],n['hazard_chemical'],n['hazard_physical'],n['hazard_allergen']]))
            vals=(n['name'],hazards,n['control_measure'],n['ccp_status'],n['critical_limit'],n['monitoring'])
            rows.append([Paragraph(str(v or ''),styles['p']) for v in vals])
        t=Table(rows,colWidths=[38*mm,56*mm,55*mm,20*mm,45*mm,55*mm],repeatRows=1)
        t.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),font),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E7EEF6')),('GRID',(0,0),(-1,-1),0.4,colors.HexColor('#AAB4BF')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3)]))
        story += [t,Spacer(1,5*mm),Paragraph('Проверка полноты',styles['h'])]
        story += [Paragraph((f"[{x['level'].upper()}] {x['text']}"),styles['p']) for x in issues] if issues else [Paragraph('Замечаний по автоматической проверке структуры не найдено.',styles['p'])]
        story += [Spacer(1,4*mm),Paragraph('Важно: решения о значимости опасностей, ККТ и критических пределах принимает специалист ХАССП.',styles['p'])]
        doc.build(story)
    return output


def export_bundle(store, diagram_id, folder, formats=('png','docx','pdf')):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    d=get_diagram(store,diagram_id)
    if not d:raise ValueError('Схема не найдена')
    safe=''.join(c if c.isalnum() or c in ' _-' else '_' for c in d['title']).strip()[:80] or 'Блок-схема'
    result=[]
    for fmt in formats:
        path=folder/f'{safe}.{fmt}'
        if fmt=='png':render_png(store,diagram_id,path)
        elif fmt=='docx':export_docx(store,diagram_id,path)
        elif fmt=='pdf':export_pdf(store,diagram_id,path)
        else:continue
        result.append(path)
    return result
