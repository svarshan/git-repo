"""MoOLVa 0.4: explainable document selection, schedules, checklists.
No invented measurement, signature or legal certainty.
"""
from datetime import date, timedelta
from pathlib import Path
import json
from assessment import analyze
from exports import safe_name

DOCUMENT_RULES = (
    ('haccp_plan', 'План ХАССП: опасности, ККТ и контроль', ('any',), 'Процедуры пищевой безопасности', 'Проект для утверждения'),
    ('prp', 'Программы предварительных условий: уборка, вредители, персонал', ('any',), 'Предпосылки управления рисками', 'Проект для утверждения'),
    ('production_control', 'Программа производственного контроля', ('any',), 'Анализ объектов и процессов контроля', 'Проверить применимость'),
    ('incoming_check', 'Процедура входного контроля сырья и материалов', ('receive', 'raw_materials', 'milk_receive', 'meat_receive', 'fish_receive'), 'Есть приемка сырья', 'Рекомендуется по процессам'),
    ('traceability', 'Порядок прослеживаемости партий и отзыва продукции', ('produce', 'pack', 'storage', 'transport', 'retail', 'wholesale'), 'Есть перемещение/производство партий', 'Проверить применимость'),
    ('equipment', 'План контроля и обслуживания оборудования', ('cook', 'bake', 'freeze', 'pasteurize', 'sterilize', 'equipment'), 'Используется технологическое оборудование', 'Рекомендуется по процессам'),
    ('cold_chain', 'Порядок контроля холодовой цепи', ('cold', 'freeze', 'frozen', 'refrigeration'), 'Используется охлаждение или заморозка', 'Рекомендуется по процессам'),
    ('sanitation', 'График санитарной обработки и верификации', ('any',), 'Санитарная обработка объектов и оборудования', 'Проект для утверждения'),
    ('allergens', 'План управления аллергенами и перекрестными контактами', ('cook','bake','confectionery','milk','nuts','baby_food','special_food'), 'Возможны аллергенные ингредиенты', 'Проверить применимость'),
    ('lab', 'План исследований/испытаний и верификации', ('any',), 'Проверка эффективности мер контроля', 'Проверить применимость'),
    ('staff', 'Инструкции и обучение персонала', ('any',), 'Работа сотрудников с пищевой продукцией', 'Проект для утверждения'),
    ('corrective', 'Порядок управления отклонениями и корректирующими действиями', ('any',), 'Необходим разбор и регистрация отклонений', 'Проект для утверждения'),
    ('supply', 'Порядок оценки поставщиков', ('receive','raw_materials','milk_receive','meat_receive','fish_receive'), 'Есть закупка и приемка сырья', 'Рекомендуется по процессам'),
    ('delivery', 'Процедура транспортировки/доставки продукции', ('transport', 'delivery', 'catering'), 'Отмечена доставка или транспортировка', 'Рекомендуется по процессам'),
    ('children', 'Дополнительная проверка процедур для питания детей', ('children','baby_food'), 'Производство/организация детского питания', 'Проверить специальные требования'),
    ('sterile', 'Валидация и контроль термических режимов', ('sterilize', 'pasteurize'), 'Указаны стерилизация/пастеризация', 'Требует специалиста'),
)

def select_document_package(store, venue_id):
    assessment=analyze(store, venue_id)
    flags=assessment['venue'].get('flags') or {}
    docs=[]
    for code,title,keys,reason,status in DOCUMENT_RULES:
        if 'any' in keys or any(flags.get(k) for k in keys):
            docs.append(dict(code=code,title=title,reason=reason,status=status))
    docs.extend(dict(code='journal:'+t.code,title=t.title,reason=why,status='Шаблон журнала — проверить') for t,why in assessment['selected'])
    from template_store import list_templates
    for template in list_templates(store, venue_id):
        blank=sum(not template['mapping'].get(token) for token in template['fields'])
        docs.append(dict(code='word:'+template['id'],title=template['name'],
                         reason='Импортированный Word-шаблон данного предприятия',
                         status=('Настроить поля: '+str(blank)) if blank else 'Проверить и утвердить'))
    return dict(venue=assessment['venue'],documents=docs,regulations=assessment['regulations'],risks=assessment['risks'])

def package_lines(store, venue_id):
    data=select_document_package(store,venue_id)
    v=data['venue']
    lines=['MoOLVa ХАССП 0.4 — Паспорт комплекта документов',
        'Объект: '+v.get('venue_name',''), 'Организация: '+v.get('legal_name',''),
        'Тип: '+v.get('kind',''), 'Дата формирования: '+date.today().strftime('%d.%m.%Y'),
        '', 'ПРЕДЛОЖЕННЫЙ КОМПЛЕКТ ('+str(len(data['documents']))+')']
    lines.extend(f"• {d['title']} | {d['status']} | Причина: {d['reason']}" for d in data['documents'])
    lines += ['', 'НОРМАТИВНЫЕ АКТЫ ДЛЯ ПРОВЕРКИ ПРИМЕНИМОСТИ']
    lines.extend(f'• {a} — {reason}' for a,reason in data['regulations'])
    lines += ['', 'ПРОВЕРИТЬ СПЕЦИАЛИСТУ']
    lines.extend('• '+s for s in data['risks'])
    lines += ['', 'Не является автоматическим юридическим заключением, утвержденной ППК или планом ХАССП.',
       'Рекомендации зависят от точности карточки предприятия и фактических процессов.',
       'Показания, критические пределы, даты исполнения и подписи не формируются автоматически.']
    return lines

def export_package_passport(store, venue_id, path, fmt):
    from assessment import export_assessment
    # Reuse battle-tested text/Word/PDF engine, without altering old assessment behavior.
    from docx import Document
    from docx.shared import Pt
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from xml.sax.saxutils import escape
    from exports import _register_pdf_font
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    lines=package_lines(store,venue_id)
    if fmt=='docx':
        d=Document(); d.styles['Normal'].font.name='Arial';d.styles['Normal'].font.size=Pt(9)
        for i,line in enumerate(lines):
            if i==0:d.add_heading(line,0)
            elif line.isupper() and len(line)>10:d.add_heading(line,2)
            else:d.add_paragraph(line)
        d.save(path)
    elif fmt=='pdf':
        font=_register_pdf_font()
        style=ParagraphStyle('base',fontName=font,fontSize=9,leading=13,spaceAfter=4)
        SimpleDocTemplate(str(path),pagesize=A4).build([Paragraph(escape(line),style) if line else Spacer(1,8) for line in lines])
    else: raise ValueError('Формат должен быть docx или pdf')
    return path

DEFAULT_TASKS=(
 ('Осмотреть и записать фактические показатели оборудования',1),
 ('Проверить выполнение графика санитарной обработки',7),
 ('Проверить комплектность и актуальность записей',30),
)

def schedule_status(task, today=None):
    today=today or date.today()
    due=date.fromisoformat(task['due_date'])
    return 'Просрочено' if due<today and task['state']!='done' else ('Сегодня' if due==today and task['state']!='done' else ('Выполнено' if task['state']=='done' else 'Запланировано'))
