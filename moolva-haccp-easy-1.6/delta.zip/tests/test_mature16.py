"""Regression tests for factual traceability and safe offline workflows."""
from __future__ import annotations
import json
import sqlite3
from contextlib import closing
import unittest
import zipfile
from datetime import date,timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from easy_core import init_store,make_venue
from mature16_core import (migrate16,add_schedule,list_schedules,workday,record_check,list_checks,
    list_capa,create_capa,advance_capa,trace_integrity,list_trace,search_all,register_asset,
    make_asset_qr,list_assets,read_table,import_employees_preview,local_advice,audit_package,
    create_user,list_users,authenticate,allowed,ensure_daily_backup,preview_template_update,install_template_update)

class Mature16Tests(unittest.TestCase):
    def setUp(self):
        tmp=TemporaryDirectory();self.addCleanup(tmp.cleanup)
        self.path=Path(tmp.name)
        self.store=init_store(self.path/'haccp.sqlite3')
        self.v1=make_venue(self.store);self.v2=make_venue(self.store)
        migrate16(self.store)

    def test_safe_additive_migration(self):
        self.store.add_record(self.v1,'sample',{'data':'kept'})
        migrate16(self.store)
        self.assertEqual(self.store.list_records(self.v1,'sample')[0]['data']['data'],'kept')
        self.assertEqual(len(self.store.list_venues()),2)

    def test_schedules_isolated_and_dates(self):
        id=add_schedule(self.store,self.v1,'Холодильник',resource='Шкаф №1',next_due=(date.today()-timedelta(days=2)).isoformat())
        self.assertEqual(len(workday(self.store,self.v1)['due']),1)
        self.assertEqual(list_schedules(self.store,self.v2),[])
        with self.assertRaises(ValueError):record_check(self.store,self.v2,id,3,'проверка')
        self.assertEqual(len(list_schedules(self.store,self.v1)),1)

    def test_exceeding_configured_limit_creates_capa_and_audit(self):
        sid=add_schedule(self.store,self.v1,'Измерение',min_value=1,max_value=5,resource='Шкаф')
        result=record_check(self.store,self.v1,sid,9,actor='Оператор')
        self.assertEqual(result['result'],'Отклонение')
        self.assertTrue(result['capa_id'])
        self.assertEqual(list_capa(self.store,self.v1)[0]['status'],'Открыто')
        self.assertEqual(len(list_capa(self.store,self.v2)),0)
        self.assertEqual(trace_integrity(self.store,self.v1)['valid'],True)

    def test_normal_reading_does_not_fake_capa(self):
        sid=add_schedule(self.store,self.v1,'Холод',min_value=-4,max_value=4)
        result=record_check(self.store,self.v1,sid,0,actor='Оператор')
        self.assertEqual(result['result'],'Без отклонения')
        self.assertEqual(len(list_capa(self.store,self.v1)),0)

    def test_unknown_without_observation_must_not_be_completed(self):
        sid=add_schedule(self.store,self.v1,'Осмотр')
        with self.assertRaises(ValueError):record_check(self.store,self.v1,sid)
        result=record_check(self.store,self.v1,sid,notes='Осмотрено без числовых показателей')
        self.assertEqual(result['result'],'Требует оценки')

    def test_nan_inf_refused(self):
        with self.assertRaises(ValueError):add_schedule(self.store,self.v1,'Нельзя',min_value=float('nan'))
        sid=add_schedule(self.store,self.v1,'Измерение')
        for value in ('nan','inf','-inf'):
            with self.subTest(value=value),self.assertRaises(ValueError):record_check(self.store,self.v1,sid,value)

    def test_explicit_capa_lifecycle_and_verification(self):
        cid=create_capa(self.store,self.v1,'Продукция требует проверки',owner='Иванов')
        with self.assertRaises(ValueError):advance_capa(self.store,self.v1,cid,'verify','Иванов',note='OK')
        with self.assertRaises(ValueError):advance_capa(self.store,self.v1,cid,'resolve','Иванов')
        advance_capa(self.store,self.v1,cid,'resolve','Иванов','Изолировали','Сбой','Устранили')
        advance_capa(self.store,self.v1,cid,'reopen','Специалист',note='Нужна дополнительная проверка')
        advance_capa(self.store,self.v1,cid,'resolve','Иванов','Изолировали','Сбой','Проверили повторно')
        advance_capa(self.store,self.v1,cid,'verify','Специалист',note='Проверено по факту')
        self.assertEqual(list_capa(self.store,self.v1)[0]['status'],'Проверено')
        self.assertTrue(trace_integrity(self.store,self.v1)['valid'])

    def test_trace_tamper_detection_and_trigger(self):
        sid=add_schedule(self.store,self.v1,'Событие')
        events=list_trace(self.store,self.v1)
        self.assertGreater(len(events),0)
        with self.store.connect() as db:
            with self.assertRaises(sqlite3.IntegrityError):db.execute('UPDATE easy16_trace SET actor="fake" WHERE id=?',(events[0]['id'],))
        with closing(sqlite3.connect(self.store.path)) as db:
            with db:
                db.execute('DROP TRIGGER easy16_trace_no_update')
                db.execute('UPDATE easy16_trace SET actor="fake" WHERE id=?',(events[0]['id'],))
        self.assertFalse(trace_integrity(self.store,self.v1)['valid'])

    def test_search_is_venue_scoped(self):
        register_asset(self.store,self.v1,'Холодильная камера Север')
        self.assertEqual(len(search_all(self.store,self.v1,'Север')),1)
        self.assertEqual(search_all(self.store,self.v2,'Север'),[])

    def test_staff_preview_never_auto_imports(self):
        sample=[['ФИО','Должность'],['Тест Иванов','Повар']]
        result=import_employees_preview(self.store,self.v1,sample)
        self.assertEqual(len(result),1)
        from staff_store import list_employees
        self.assertEqual(len(list_employees(self.store,self.v1)),0)
        import_employees_preview(self.store,self.v1,sample,True)
        self.assertEqual(len(list_employees(self.store,self.v1)),1)
        self.assertEqual(len(list_employees(self.store,self.v2)),0)

    def test_csv_import(self):
        path=self.path/'table.csv';path.write_text('ФИО;Должность\nИван Петров;Технолог\n',encoding='utf-8')
        self.assertEqual(read_table(path)[1][0],'Иван Петров')

    def test_xlsx_import_no_formula_execution(self):
        path=self.path/'table.xlsx';ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
        with zipfile.ZipFile(path,'w') as z:
            z.writestr('xl/worksheets/sheet1.xml',f'<worksheet xmlns="{ns}"><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>ФИО</t></is></c></row></sheetData></worksheet>')
        self.assertEqual(read_table(path)[0][0],'ФИО')

    def test_local_users_pbkdf_and_roles(self):
        with self.assertRaises(ValueError):create_user(self.store,'tech','Технолог','Сотрудник','LongPassword123')
        create_user(self.store,'admin','Админ','Администратор','LongPassword123')
        create_user(self.store,'worker','Оператор','Сотрудник','WorkerPassword123')
        self.assertIsNone(authenticate(self.store,'worker','wrong'))
        self.assertEqual(authenticate(self.store,'worker','WorkerPassword123')['role'],'Сотрудник')
        self.assertFalse(allowed('Сотрудник','verify'))
        self.assertEqual(len(list_users(self.store)),2)

    def test_audit_archive_with_real_rows_only(self):
        sid=add_schedule(self.store,self.v1,'Тест проверки',min_value=1,max_value=2)
        record_check(self.store,self.v1,sid,3,actor='Иванов')
        f=self.path/'audit.zip'
        output=audit_package(self.store,self.v1,f,date.today().isoformat(),date.today().isoformat())
        self.assertEqual(output['manifest']['checks'],1)
        with zipfile.ZipFile(f) as z:
            self.assertIn('06_Сводка_проверки.docx',z.namelist())
            self.assertIn('check_id',z.read('03_Корректирующие_действия.csv').decode('utf-8-sig'))
            self.assertEqual(json.loads(z.read('00_Информация.json'))['trace_integrity']['valid'],True)

    def test_qr_code_generation(self):
        asset=register_asset(self.store,self.v1,'Шкаф')
        target=self.path/'asset.png'
        make_asset_qr(self.store,self.v1,asset,target)
        self.assertGreater(target.stat().st_size,100)
        with self.assertRaises(ValueError):make_asset_qr(self.store,self.v2,asset,self.path/'not.png')

    def test_deleting_enterprise_keeps_original_backup_and_other_venue(self):
        add_schedule(self.store,self.v1,'Удаляемый объект')
        create_capa(self.store,self.v1,'Замечание')
        self.store.delete_venue(self.v1,make_backup=False)
        self.assertIsNone(self.store.get_venue(self.v1))
        self.assertIsNotNone(self.store.get_venue(self.v2))

    def test_verified_daily_backup_is_reusable(self):
        day=date.today().isoformat()
        first=ensure_daily_backup(self.store,day=day)
        self.assertEqual(ensure_daily_backup(self.store,day=day),first)
        self.assertTrue(first.is_file())
        with closing(sqlite3.connect(first)) as c:
            self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0],'ok')

    def test_template_updates_never_overwrite_approved_content(self):
        path=self.path/'template.json'
        path.write_text(json.dumps({'title':'Новая форма','columns':['Поле 1','Поле 2']},ensure_ascii=False),encoding='utf-8')
        preview=preview_template_update(path)
        self.assertEqual(preview['columns'],['Поле 1','Поле 2'])
        code=install_template_update(self.store,self.v1,path,'Специалист')
        self.assertTrue(code.startswith('custom_'))
        self.assertTrue(trace_integrity(self.store,self.v1)['valid'])
        self.assertEqual(len(self.store.list_custom_templates()),1)

    def test_local_advice_no_phantom_ai(self):
        self.assertIn('фактическое',local_advice('температура'))

if __name__=='__main__':unittest.main()
