"""Usable local GUI for daily checks, deviations, audit, staff import, global search.
Avoid silently saving real-world observations or asserting official compliance.
"""
from __future__ import annotations
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from datetime import date, timedelta
from pathlib import Path
from mature16_core import (migrate16,workday,add_schedule,list_schedules,record_check,list_checks,
    list_capa,create_capa,advance_capa,search_all,register_asset,list_assets,make_asset_qr,
    read_table,import_employees_preview,audit_package,trace_integrity,list_trace,local_advice,
    create_user,list_users,authenticate,allowed,ensure_daily_backup,preview_template_update,install_template_update)

BG='#111824';NAV='#142031';PANEL='#1A2739';CARD='#22334A';EDGE='#31445C'
INK='#F1F6FD';SOFT='#AFBDD0';MUTED='#8297AE';LIME='#D5E744';CYAN='#29BFD1';GREEN='#34C9AB';WARN='#FFBD5C'
FONT='Segoe UI'


def title(parent,value,subtitle=''):
    tk.Label(parent,text=value,font=(FONT,16,'bold'),bg=PANEL,fg=INK,anchor='w').pack(anchor='w')
    if subtitle:tk.Label(parent,text=subtitle,wraplength=880,justify='left',font=(FONT,9),bg=PANEL,fg=SOFT).pack(anchor='w',pady=(3,12))


def text(parent,value,accent=INK,wrap=900):
    w=tk.Label(parent,text=value,font=(FONT,10),wraplength=wrap,justify='left',bg=parent.cget('bg'),fg=accent)
    w.pack(anchor='w',pady=4);return w


def btn(parent,value,cmd,accent=False):
    w=tk.Button(parent,text=value,command=cmd,relief='flat',cursor='hand2',bg=LIME if accent else CARD,
         fg=NAV if accent else INK,font=(FONT,10,'bold'),padx=12,pady=9)
    return w


def field(parent,name,default='',width=58):
    text(parent,name,SOFT)
    var=tk.StringVar(value='' if default is None else str(default))
    tk.Entry(parent,textvariable=var,font=(FONT,11),bg='#253B52',fg=INK,insertbackground=INK,relief='flat',width=width).pack(anchor='w',pady=(0,7),ipady=6)
    return var


class Mature16Mixin:
    def _init_mature16(self):
        # The previous database remains in the same stable LOCALAPPDATA path.
        # Fail safely on backup errors instead of interrupting an emergency opening.
        try:self._daily_backup16=ensure_daily_backup(self.store)
        except (OSError,ValueError,ImportError) as e:self._daily_backup16=None
        migrate16(self.store)
        self._operator16=None
        # Additional nav rows fit existing dark sidebar and keep original tools.
        for key,ico,caption,action in (
            ('day16','◷','Проверки на сегодня',self.show_day16),
            ('capa16','!','Отклонения',self.show_capa16),
            ('audit16','▧','Подготовка к аудиту',self.show_audit16),
            ('search16','⌕','Поиск и оборудование',self.show_search16),
            ('admin16','⚿','Пользователи и импорт',self.show_admin16)):
            row=tk.Frame(self.sidebar,bg=NAV)
            row.pack(fill='x',padx=7,pady=1,before=self.side_meter)
            w=tk.Button(row,text=f'{ico}   {caption}',anchor='w',command=action,cursor='hand2',
                    relief='flat',bd=0,bg=NAV,fg=SOFT,activebackground=CARD,activeforeground=INK,
                    font=(FONT,9,'bold'),padx=11,pady=5)
            w.pack(fill='x');self.primary_buttons[key]=w

    def _begin16(self,key,page,description):
        if not self._need_venue():return None
        self._mode=key;self._activate_nav(key);self._clear();self._update_metrics()
        self.eyebrow.configure(text='MOOLVA · SMART CONTROL 1.6')
        self.heading.configure(text=page);self.subhead.configure(text=description)
        self._set_footer('←  Мой день',self.show_dashboard,
                         'Локальные фактические записи · без искусственных измерений',
                         'Подготовка к аудиту →',self.show_audit16,0)
        return self.content

    def _card16(self,container):
        outer=tk.Frame(container,bg=PANEL,highlightbackground=EDGE,highlightthickness=1)
        outer.pack(fill='x',pady=(2,11));inner=tk.Frame(outer,bg=PANEL)
        inner.pack(fill='x',padx=18,pady=16)
        return inner

    def _auth16(self,permission):
        users=list_users(self.store)
        if not users:return True  # Opt-in. No pretended protection on old databases.
        if self._operator16 and allowed(self._operator16['role'],permission):return True
        username=simpledialog.askstring('Локальный вход','Имя пользователя:',parent=self)
        if username is None:return False
        password=simpledialog.askstring('Локальный вход','Пароль:',show='*',parent=self)
        if password is None:return False
        user=authenticate(self.store,username,password)
        if not user:
            messagebox.showerror('Доступ','Неверный логин или пароль.',parent=self);return False
        self._operator16=user
        if not allowed(user['role'],permission):
            messagebox.showwarning('Права доступа','Для этого действия недостаточно прав.',parent=self)
            return False
        return True

    def _actor16(self):return self._operator16['display_name'] if self._operator16 else 'Локальный пользователь'

    def show_day16(self):
        body=self._begin16('day16','Проверки на сегодня','Настоящие задачи с ответственными и фактическими записями. Все пределы назначает специалист.')
        if body is None:return
        summary=workday(self.store,self.venue_id)
        card=self._card16(body)
        title(card,'Сегодня: '+str(summary['planned'])+' проверок к выполнению',
              f'Записано сегодня: {summary["completed_today"]} · Открытых отклонений: {summary["open_capa"]}')
        actions=tk.Frame(card,bg=PANEL);actions.pack(anchor='w')
        btn(actions,'+ Запланировать проверку',self._schedule_dialog16,True).pack(side='left')
        btn(actions,'Корректирующие действия',self.show_capa16).pack(side='left',padx=8)
        schedules=list_schedules(self.store,self.venue_id)
        if not schedules:text(card,'Пока нет расписаний. Нажмите «Запланировать проверку», чтобы добавить своё первое действие.',SOFT)
        for s in schedules:
            row=tk.Frame(card,bg=CARD);row.pack(fill='x',pady=5)
            content=tk.Frame(row,bg=CARD);content.pack(side='left',padx=12,pady=10,fill='x',expand=True)
            tl=f"{s['title']}  ·  {s['resource']}"
            tk.Label(content,text=tl,font=(FONT,10,'bold'),bg=CARD,fg=INK,anchor='w').pack(anchor='w')
            desc=f"Следующая дата: {s['next_due']} · каждые {s['every_days']} дн. · {s['responsible']}"
            tk.Label(content,text=desc,bg=CARD,fg=WARN if s['next_due']<=date.today().isoformat() else SOFT,font=(FONT,9)).pack(anchor='w',pady=(3,0))
            btn(row,'Записать факт →',lambda x=s:self._check_dialog16(x)).pack(side='right',padx=9)
        history=self._card16(body);title(history,'Недавние фактические проверки')
        for c in list_checks(self.store,self.venue_id,14):
            accent=WARN if c['result']=='Отклонение' else GREEN if c['result']=='Без отклонения' else SOFT
            text(history,f"{c['checked_at'][:16]} · {c['title']} · {c['measured_value'] if c['measured_value'] is not None else 'наблюдение'} {c['unit']} — {c['result']}",accent)

    def _schedule_dialog16(self):
        if not self._auth16('schedule'):return
        dlg=tk.Toplevel(self);dlg.configure(bg=PANEL);dlg.title('Плановая проверка');dlg.geometry('570x650');dlg.transient(self)
        f=tk.Frame(dlg,bg=PANEL);f.pack(padx=22,pady=15,fill='both')
        title(f,'Новая запланированная проверка','Пределы задаются ответственным специалистом на основе утверждённых процедур.')
        name=field(f,'Название (например: Контроль холодильника)')
        resource=field(f,'Оборудование / помещение')
        journal=field(f,'Код связанного журнала (если есть)')
        every=field(f,'Периодичность, дней','1')
        due=field(f,'Дата первого контроля (ГГГГ-ММ-ДД)',date.today().isoformat())
        minval=field(f,'Минимальный допустимый показатель (необязательно)')
        maxval=field(f,'Максимальный допустимый показатель (необязательно)')
        unit=field(f,'Единица измерения')
        owner=field(f,'Ответственный')
        def save():
            try:
                add_schedule(self.store,self.venue_id,name.get(),journal.get(),resource.get(),every.get(),due.get(),
                     float(minval.get().replace(',','.')) if minval.get() else None,
                     float(maxval.get().replace(',','.')) if maxval.get() else None,unit.get(),owner.get(),self._actor16())
                dlg.destroy();self.show_day16()
            except (ValueError,OverflowError) as e:messagebox.showerror('Не сохранено',str(e),parent=dlg)
        btn(f,'Сохранить график',save,True).pack(anchor='w',pady=12)

    def _check_dialog16(self,schedule):
        if not self._auth16('check'):return
        dlg=tk.Toplevel(self);dlg.configure(bg=PANEL);dlg.title('Фактическая проверка');dlg.geometry('610x480');dlg.transient(self)
        f=tk.Frame(dlg,bg=PANEL);f.pack(fill='both',padx=23,pady=20)
        title(f,schedule['title'],f"{schedule['resource']}  ·  {schedule['responsible']}")
        if schedule['min_value'] is not None or schedule['max_value'] is not None:
            text(f,f"Утверждённый диапазон: {schedule['min_value']} — {schedule['max_value']} {schedule['unit']}",CYAN)
        val=field(f,'ФАКТИЧЕСКОЕ измерение (оставьте пустым для качественного наблюдения)')
        note=field(f,'Фактическое наблюдение / комментарий')
        text(f,'Данные вводятся человеком после реальной проверки. Результаты не копируются из предыдущей записи.',SOFT)
        def save():
            try:
                result=record_check(self.store,self.venue_id,schedule['id'],val.get(),note.get(),self._actor16())
                dlg.destroy();self.show_day16()
                if result['capa_id']:
                    messagebox.showwarning('Отклонение','Показание вне настроенного диапазона. Создано корректирующее действие №'+str(result['capa_id'])+'.',parent=self)
            except ValueError as e:messagebox.showerror('Не сохранено',str(e),parent=dlg)
        btn(f,'Сохранить фактическую запись',save,True).pack(anchor='w',pady=15)

    def show_capa16(self):
        body=self._begin16('capa16','Отклонения и действия','Отклонение → меры для безопасности → исправление причины → проверка эффективности')
        if body is None:return
        p=self._card16(body);title(p,'Центр корректирующих действий')
        btn(p,'+ Зарегистрировать проблему',self._new_capa_dialog16,True).pack(anchor='w')
        for c in list_capa(self.store,self.venue_id):
            box=tk.Frame(p,bg=CARD);box.pack(fill='x',pady=6)
            line=tk.Frame(box,bg=CARD);line.pack(side='left',padx=12,pady=12,fill='both',expand=True)
            tk.Label(line,text=f"#{c['id']} · {c['problem']}",bg=CARD,fg=INK,font=(FONT,10,'bold'),wraplength=650,justify='left').pack(anchor='w')
            tk.Label(line,text=f"{c['status']} · {c['owner']} · срок {c['due_date'] or 'не указан'}",bg=CARD,fg=WARN if c['status']=='Открыто' else GREEN,font=(FONT,9)).pack(anchor='w',pady=4)
            if c['status']!='Проверено':btn(box,'Открыть →',lambda x=c:self._capa_dialog16(x)).pack(side='right',padx=7)

    def _new_capa_dialog16(self):
        if not self._auth16('capa'):return
        problem=simpledialog.askstring('Замечание','Опишите реальную проблему:',parent=self)
        if not problem:return
        owner=simpledialog.askstring('Ответственный','Укажите ответственного:',parent=self) or ''
        due=simpledialog.askstring('Срок','Дата в формате ГГГГ-ММ-ДД (необязательно):',parent=self) or ''
        try:create_capa(self.store,self.venue_id,problem,owner,due,self._actor16());self.show_capa16()
        except ValueError as e:messagebox.showerror('Ошибка',str(e),parent=self)

    def _capa_dialog16(self,c):
        step='resolve' if c['status']=='Открыто' else 'verify'
        if not self._auth16('capa' if step=='resolve' else 'verify'):return
        dlg=tk.Toplevel(self);dlg.configure(bg=PANEL);dlg.title('Корректирующее действие');dlg.geometry('630x500');dlg.transient(self)
        f=tk.Frame(dlg,bg=PANEL);f.pack(padx=22,pady=20,fill='both')
        title(f,c['problem'],'Текущий статус: '+c['status'])
        if step=='resolve':
            a=field(f,'Меры для предотвращения опасности продукции')
            b=field(f,'Предполагаемая причина')
            d=field(f,'Выполненное корректирующее действие')
        else:d=field(f,'Результат проверки эффективности')
        def commit():
            try:
                if step=='resolve':advance_capa(self.store,self.venue_id,c['id'],'resolve',self._actor16(),a.get(),b.get(),d.get())
                else:advance_capa(self.store,self.venue_id,c['id'],'verify',self._actor16(),note=d.get())
                dlg.destroy();self.show_capa16()
            except ValueError as e:messagebox.showerror('Ошибка',str(e),parent=dlg)
        btn(f,'Сохранить действие' if step=='resolve' else 'Подтвердить результат',commit,True).pack(anchor='w',pady=14)
        if step=='verify':
            def reopen():
                try:advance_capa(self.store,self.venue_id,c['id'],'reopen',self._actor16(),note=d.get());dlg.destroy();self.show_capa16()
                except ValueError as e:messagebox.showerror('Ошибка',str(e),parent=dlg)
            btn(f,'Результат неудовлетворителен — вернуть в работу',reopen).pack(anchor='w')

    def show_audit16(self):
        body=self._begin16('audit16','Подготовка к аудиту','Проверка полноты записей и экспорт доказательств. Не является подтверждением соответствия ХАССП.')
        if body is None:return
        card=self._card16(body);title(card,'Сформировать комплект документов')
        start=field(card,'Начало периода', (date.today()-timedelta(days=30)).isoformat())
        end=field(card,'Конец периода',date.today().isoformat())
        integrity=trace_integrity(self.store,self.venue_id)
        text(card,f"Цепочка локальных событий: {'целостна' if integrity['valid'] else 'ОБНАРУЖЕНО НАРУШЕНИЕ'} · {integrity['events']} событий",GREEN if integrity['valid'] else WARN)
        text(card,'Состав: графики, проверки, записи журналов, корректирующие действия, история изменений, документ Word.',SOFT)
        def export():
            if not self._auth16('export'):return
            path=filedialog.asksaveasfilename(parent=self,title='Комплект для внутреннего аудита',defaultextension='.zip',filetypes=[('Архив ZIP','*.zip')])
            if not path:return
            try:
                result=audit_package(self.store,self.venue_id,path,start.get(),end.get())
                messagebox.showinfo('Экспорт завершён','Файлы сохранены:\n'+str(result['path']),parent=self)
            except (ValueError,OSError,FileExistsError) as e:messagebox.showerror('Ошибка выгрузки',str(e),parent=self)
        btn(card,'Сформировать ZIP с Word и журналами',export,True).pack(anchor='w',pady=9)
        h=self._card16(body);title(h,'История изменений и подтверждений')
        for e in list_trace(self.store,self.venue_id,30):
            text(h,f"{e['happened_at'][:16]}  · {e['actor']}  · {e['event']}",SOFT)

    def show_search16(self):
        body=self._begin16('search16','Поиск и оборудование','Найдите сотрудника, график проверки, запись или зарегистрированное оборудование')
        if body is None:return
        p=self._card16(body);title(p,'Поиск по предприятию')
        q=field(p,'Введите слово или часть названия')
        results=tk.Frame(p,bg=PANEL);results.pack(fill='x')
        def find():
            for c in results.winfo_children():c.destroy()
            try:
                hits=search_all(self.store,self.venue_id,q.get())
                if not hits:text(results,'Совпадений не найдено.',MUTED)
                for h in hits:text(results,f"{h['category']}: {h['title']}",INK)
            except ValueError as e:messagebox.showerror('Поиск',str(e),parent=self)
        btn(p,'Найти',find,True).pack(anchor='w',pady=8)
        assets=self._card16(body);title(assets,'Оборудование и локальные QR-коды','QR содержит только идентификатор оборудования. Он не открывает чужие данные через интернет.')
        btn(assets,'+ Добавить оборудование',self._asset_dialog16).pack(anchor='w',pady=5)
        for a in list_assets(self.store,self.venue_id):
            row=tk.Frame(assets,bg=CARD);row.pack(fill='x',pady=3)
            tk.Label(row,text=f"{a['display_name']} · {a['location']}",bg=CARD,fg=INK,font=(FONT,10)).pack(side='left',padx=10,pady=10)
            btn(row,'QR в PNG',lambda x=a:self._asset_qr16(x)).pack(side='right',padx=6)
        helper=self._card16(body);title(helper,'Справка по ХАССП (полностью локальная)')
        ask=field(helper,'Например: Что такое ККТ?')
        answer=tk.StringVar(value='Подскажу, как начать работу. Специализированные решения подтверждает специалист.')
        tk.Label(helper,textvariable=answer,fg=SOFT,bg=PANEL,wraplength=850,justify='left').pack(anchor='w',pady=10)
        btn(helper,'Показать подсказку',lambda:answer.set(local_advice(ask.get()))).pack(anchor='w')

    def _asset_dialog16(self):
        if not self._auth16('schedule'):return
        name=simpledialog.askstring('Оборудование','Название:',parent=self)
        if not name:return
        loc=simpledialog.askstring('Оборудование','Помещение:',parent=self) or ''
        code=simpledialog.askstring('Оборудование','Код журнала (необязательно):',parent=self) or ''
        try:register_asset(self.store,self.venue_id,name,loc,code,self._actor16());self.show_search16()
        except ValueError as e:messagebox.showerror('Ошибка',str(e),parent=self)

    def _asset_qr16(self,asset):
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.png',initialfile='MoOLVa_Equipment_'+str(asset['id'])+'.png',filetypes=[('PNG','*.png')])
        if not path:return
        try:make_asset_qr(self.store,self.venue_id,asset['id'],path);messagebox.showinfo('QR','Файл сохранён:\n'+path,parent=self)
        except (ImportError,ValueError,OSError) as e:messagebox.showerror('Ошибка',str(e),parent=self)

    def show_admin16(self):
        body=self._begin16('admin16','Пользователи и импорт','Опциональные локальные роли и перенос сотрудников из CSV/XLSX без автоматического утверждения документов')
        if body is None:return
        users=self._card16(body);title(users,'Пользователи этого компьютера','Роли ограничивают действия в интерфейсе. Администратор самого ПК может изменить локальную базу.')
        for u in list_users(self.store):text(users,f"{u['display_name']} · {u['username']} · {u['role']}",SOFT)
        btn(users,'Создать пользователя',self._user_dialog16).pack(anchor='w',pady=7)
        imports=self._card16(body);title(imports,'Импорт сотрудников','Первый столбец: ФИО. Второй: должность. Сначала всегда просмотр, затем подтверждение.')
        btn(imports,'Выбрать XLSX или CSV',self._import_staff16,True).pack(anchor='w')
        forms=self._card16(body)
        title(forms,'Центр обновления шаблонов','Только вручную: проверить JSON, подтвердить и создать НОВЫЙ шаблон. Подписанные формы не перезаписываются.')
        btn(forms,'Просмотреть и импортировать шаблон',self._import_template16).pack(anchor='w')
        text(forms,'Автоматического скачивания нормативов нет. Источник и актуальность формы проверяет специалист.',SOFT)
        copies=self._card16(body);title(copies,'Автоматические резервные копии')
        text(copies,'Папка: '+str(Path(self.store.path).parent/'automatic_backups16'),SOFT)
        text(copies,'Копия проверяется средствами SQLite и хранится отдельно от основной базы. Восстановление выполняется через настройки.',SOFT)

    def _user_dialog16(self):
        if list_users(self.store) and not self._auth16('users'):return
        dialog=tk.Toplevel(self);dialog.configure(bg=PANEL);dialog.title('Новая учётная запись');dialog.geometry('520x490')
        f=tk.Frame(dialog,bg=PANEL);f.pack(fill='both',padx=20,pady=20)
        title(f,'Учётная запись','Первый пользователь обязательно должен иметь роль «Администратор».')
        username=field(f,'Логин латиницей')
        display=field(f,'Имя пользователя')
        role=ttk.Combobox(f,values=['Администратор','Специалист ХАССП','Сотрудник','Наблюдатель'],state='readonly',width=44)
        role.set('Администратор' if not list_users(self.store) else 'Сотрудник');role.pack(anchor='w',pady=8)
        pw=field(f,'Пароль (не менее 12 символов)')
        for widget in f.winfo_children():
            if isinstance(widget,tk.Entry) and str(widget.cget('textvariable'))==str(pw):widget.configure(show='*')
        def save():
            try:create_user(self.store,username.get(),display.get(),role.get(),pw.get());dialog.destroy();self.show_admin16()
            except Exception as e:messagebox.showerror('Не создан',str(e),parent=dialog)
        btn(f,'Создать учётную запись',save,True).pack(anchor='w',pady=12)

    def _import_staff16(self):
        if not self._auth16('import'):return
        path=filedialog.askopenfilename(parent=self,filetypes=[('Excel и CSV','*.xlsx *.csv')])
        if not path:return
        try:
            rows=read_table(path);preview=import_employees_preview(self.store,self.venue_id,rows)
            details='\n'.join(f'{x[0]} — {x[1]}' for x in preview[:12])
            if not preview:messagebox.showinfo('Нет данных','Не найдено строк сотрудников.',parent=self);return
            if not messagebox.askyesno('Подтвердить импорт',f'Подготовлено сотрудников: {len(preview)}\n\n{details}\n\nСоздать эти карточки?',parent=self):return
            import_employees_preview(self.store,self.venue_id,rows,True,self._actor16());self.show_admin16()
        except (ValueError,OSError,KeyError) as e:messagebox.showerror('Импорт не выполнен',str(e),parent=self)

    def _import_template16(self):
        if not self._auth16('import'):return
        path=filedialog.askopenfilename(parent=self,filetypes=[('JSON шаблона','*.json')])
        if not path:return
        try:
            data=preview_template_update(path)
            body=(f"Название: {data['title']}\nКоличество граф: {len(data['columns'])}\n\n"+
                  '\n'.join('• '+v for v in data['columns'])+"\n\nНе является подтверждённым нормативным шаблоном. Создать новую форму?")
            if not messagebox.askyesno('Проверка шаблона',body,parent=self):return
            install_template_update(self.store,self.venue_id,path,self._actor16())
            messagebox.showinfo('Новый шаблон','Создана отдельная пользовательская форма. Старые формы не изменены.',parent=self)
            self.show_admin16()
        except (ValueError,OSError,TypeError,KeyError) as e:messagebox.showerror('Импорт отменён',str(e),parent=self)
