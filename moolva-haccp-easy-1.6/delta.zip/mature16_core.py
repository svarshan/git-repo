"""MoOLVa HACCP Easy 1.6 — local operational quality control.

Safety boundary: no fabricated readings, signatures, authorisations, CCP decisions
or declarations of legal compliance. SQLite roles are local workflow safeguards,
NOT protection against a computer administrator editing the database.
"""
from __future__ import annotations
import csv
import hashlib
import hmac
import io
import math
import json
import os
import re
import secrets
import tempfile
import zipfile
from datetime import date, timedelta, datetime
from pathlib import Path
from xml.etree import ElementTree as ET
from storage import now

ROLES = ('Администратор', 'Специалист ХАССП', 'Сотрудник', 'Наблюдатель')
PERMISSIONS = {
    'Администратор': {'schedule','check','capa','verify','audit','users','import','export','settings'},
    'Специалист ХАССП': {'schedule','check','capa','verify','audit','import','export'},
    'Сотрудник': {'check','capa','export'},
    'Наблюдатель': {'export'},
}


def migrate16(store):
    """Idempotent additive migration: preserves databases from 1.4 and 1.5."""
    with store.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS easy16_schedules (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          title TEXT NOT NULL, journal_code TEXT NOT NULL DEFAULT '', resource TEXT NOT NULL DEFAULT '',
          every_days INTEGER NOT NULL CHECK(every_days BETWEEN 1 AND 366),
          next_due TEXT NOT NULL, min_value REAL,max_value REAL,unit TEXT NOT NULL DEFAULT '',
          responsible TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_easy16_schedule_due ON easy16_schedules(venue_id,active,next_due);
        CREATE TABLE IF NOT EXISTS easy16_checks (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          schedule_id INTEGER NOT NULL REFERENCES easy16_schedules(id),
          measured_value REAL, notes TEXT NOT NULL DEFAULT '',
          result TEXT NOT NULL CHECK(result IN ('Без отклонения','Отклонение','Требует оценки')),
          record_id INTEGER,actor TEXT NOT NULL, checked_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_easy16_check ON easy16_checks(venue_id,schedule_id,id);
        CREATE TABLE IF NOT EXISTS easy16_capa (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          check_id INTEGER REFERENCES easy16_checks(id),problem TEXT NOT NULL,
          containment TEXT NOT NULL DEFAULT '',root_cause TEXT NOT NULL DEFAULT '',
          corrective TEXT NOT NULL DEFAULT '',owner TEXT NOT NULL DEFAULT '',
          due_date TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'Открыто',
          verification_note TEXT NOT NULL DEFAULT '',verified_by TEXT NOT NULL DEFAULT '',
          verified_at TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_easy16_capa ON easy16_capa(venue_id,status,id);
        CREATE TABLE IF NOT EXISTS easy16_trace (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          actor TEXT NOT NULL, event TEXT NOT NULL, details TEXT NOT NULL,
          happened_at TEXT NOT NULL,previous_hash TEXT NOT NULL,event_hash TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_easy16_trace ON easy16_trace(venue_id,id);
        CREATE TRIGGER IF NOT EXISTS easy16_trace_no_update BEFORE UPDATE ON easy16_trace
          BEGIN SELECT RAISE(ABORT,'Журнал событий нельзя менять'); END;
        DROP TRIGGER IF EXISTS easy16_trace_no_delete;
        CREATE TABLE IF NOT EXISTS easy16_users (
          id INTEGER PRIMARY KEY,username TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
          role TEXT NOT NULL,salt TEXT NOT NULL,secret_hash TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS easy16_assets (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          display_name TEXT NOT NULL,location TEXT NOT NULL DEFAULT '',journal_code TEXT NOT NULL DEFAULT '');
        CREATE TABLE IF NOT EXISTS easy16_template_versions (
          id INTEGER PRIMARY KEY,venue_id INTEGER NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
          name TEXT NOT NULL,digest TEXT NOT NULL, reviewed_by TEXT NOT NULL,
          imported_at TEXT NOT NULL);
        ''')


def _venue(store, vid):
    if not isinstance(vid,int) or not store.get_venue(vid): raise ValueError('Выберите существующее предприятие')


def _date(s, allow_empty=False):
    if s == '' and allow_empty:return ''
    try:return date.fromisoformat(str(s)).isoformat()
    except ValueError:raise ValueError('Дата должна иметь формат ГГГГ-ММ-ДД')


def _short(s,n=240):
    s=str(s or '').strip()
    if len(s)>n:raise ValueError('Поле превышает допустимую длину')
    return s


def _trace(db,vid,actor,event,payload):
    previous=db.execute('SELECT event_hash FROM easy16_trace WHERE venue_id=? ORDER BY id DESC LIMIT 1',(vid,)).fetchone()
    prev=previous['event_hash'] if previous else '0'*64
    stamp=now(); detail=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'))
    body=json.dumps([vid,actor,event,detail,stamp,prev],ensure_ascii=False,separators=(',',':'))
    digest=hashlib.sha256(body.encode('utf-8')).hexdigest()
    db.execute('INSERT INTO easy16_trace(venue_id,actor,event,details,happened_at,previous_hash,event_hash) VALUES(?,?,?,?,?,?,?)',
               (vid,actor,event,detail,stamp,prev,digest))


def trace_integrity(store,vid):
    _venue(store,vid); migrate16(store)
    previous='0'*64
    with store.connect() as db:
        rows=db.execute('SELECT * FROM easy16_trace WHERE venue_id=? ORDER BY id',(vid,)).fetchall()
        for r in rows:
            expected=hashlib.sha256(json.dumps([vid,r['actor'],r['event'],r['details'],r['happened_at'],previous],
                         ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
            if r['previous_hash']!=previous or not hmac.compare_digest(expected,r['event_hash']):
                return {'valid':False,'events':len(rows),'broken_at':r['id']}
            previous=r['event_hash']
    return {'valid':True,'events':len(rows),'broken_at':None}


def list_trace(store,vid,limit=100):
    _venue(store,vid);migrate16(store)
    with store.connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM easy16_trace WHERE venue_id=? ORDER BY id DESC LIMIT ?',
                    (vid,max(1,min(1000,int(limit)))))]


def add_schedule(store,vid,title,journal_code='',resource='',every_days=1,next_due=None,min_value=None,max_value=None,unit='',responsible='',actor='Пользователь'):
    _venue(store,vid);migrate16(store)
    title=_short(title);resource=_short(resource);unit=_short(unit,30);responsible=_short(responsible)
    if not title:raise ValueError('Укажите название проверки')
    days=int(every_days)
    if days<1 or days>366:raise ValueError('Частота: от 1 до 366 дней')
    due=_date(next_due or date.today().isoformat())
    if min_value is not None:min_value=float(min_value)
    if max_value is not None:max_value=float(max_value)
    if (min_value is not None and not math.isfinite(min_value)) or (max_value is not None and not math.isfinite(max_value)):
        raise ValueError('Укажите конечные числа для допустимого диапазона')
    if min_value is not None and max_value is not None and min_value>max_value:raise ValueError('Минимум больше максимума')
    with store.connect() as db:
        cur=db.execute('''INSERT INTO easy16_schedules(venue_id,title,journal_code,resource,every_days,next_due,min_value,max_value,unit,responsible,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', (vid,title,_short(journal_code,70),resource,days,due,min_value,max_value,unit,responsible,now(),now()))
        sid=cur.lastrowid;_trace(db,vid,actor,'schedule_added',{'id':sid,'title':title,'due':due})
    return sid


def list_schedules(store,vid,active_only=True):
    _venue(store,vid);migrate16(store)
    with store.connect() as db:
        return [dict(x) for x in db.execute('SELECT * FROM easy16_schedules WHERE venue_id=?'+(' AND active=1' if active_only else '')+' ORDER BY next_due,id',(vid,))]


def workday(store,vid,day=None):
    today=_date(day or date.today().isoformat())
    scheduled=list_schedules(store,vid)
    due=[x for x in scheduled if x['next_due']<=today]
    with store.connect() as db:
        done=db.execute('''SELECT COUNT(*) FROM easy16_checks WHERE venue_id=? AND substr(checked_at,1,10)=?''',(vid,today)).fetchone()[0]
        open_capa=db.execute('SELECT COUNT(*) FROM easy16_capa WHERE venue_id=? AND status!=?',(vid,'Проверено')).fetchone()[0]
    return {'due':due,'planned':len(due),'completed_today':done,'open_capa':open_capa,'as_of':today}


def record_check(store,vid,schedule_id,reading=None,notes='',actor='Сотрудник'):
    """Explicit user-entered reading. None means observation awaiting human evaluation."""
    _venue(store,vid);migrate16(store);notes=_short(notes,2000);actor=_short(actor,100)
    measured=None if reading in (None,'') else float(str(reading).replace(',','.'))
    if measured is not None and not math.isfinite(measured):raise ValueError('Недопустимое значение измерения')
    with store.connect() as db:
        r=db.execute('SELECT * FROM easy16_schedules WHERE venue_id=? AND id=? AND active=1',(vid,int(schedule_id))).fetchone()
        if r is None:raise ValueError('Проверка не найдена в выбранном предприятии')
        if measured is None:result='Требует оценки'
        elif ((r['min_value'] is not None and measured<r['min_value']) or (r['max_value'] is not None and measured>r['max_value'])):result='Отклонение'
        elif r['min_value'] is None and r['max_value'] is None:result='Требует оценки'
        else:result='Без отклонения'
        if result=='Требует оценки' and not notes:
            raise ValueError('Для проверки без числового предела или показания укажите фактическое наблюдение')
        cur=db.execute('''INSERT INTO easy16_checks(venue_id,schedule_id,measured_value,notes,result,actor,checked_at)
            VALUES(?,?,?,?,?,?,?)''',(vid,schedule_id,measured,notes,result,actor,now()))
        cid=cur.lastrowid
        due=date.fromisoformat(r['next_due']);today=date.today()
        # Catch up overdue tasks to the next upcoming due date.
        while due<=today:due+=timedelta(days=r['every_days'])
        db.execute('UPDATE easy16_schedules SET next_due=?,updated_at=? WHERE id=? AND venue_id=?',(due.isoformat(),now(),schedule_id,vid))
        _trace(db,vid,actor,'check_recorded',{'id':cid,'schedule_id':schedule_id,'result':result,'reading':measured,'notes':notes})
        capa_id=None
        if result=='Отклонение':
            problem=f'Отклонение от заданного диапазона: {r["title"]} ({r["resource"]})'
            action=db.execute('''INSERT INTO easy16_capa(venue_id,check_id,problem,owner,status,created_at,updated_at)
                VALUES(?,?,?,?,'Открыто',?,?)''',(vid,cid,problem,r['responsible'],now(),now()))
            capa_id=action.lastrowid
            _trace(db,vid,actor,'capa_opened',{'id':capa_id,'check_id':cid,'problem':problem})
    return {'id':cid,'result':result,'capa_id':capa_id,'next_due':due.isoformat()}


def list_checks(store,vid,limit=120):
    _venue(store,vid);migrate16(store)
    with store.connect() as db:
        return [dict(x) for x in db.execute('''SELECT c.*,s.title,s.resource,s.unit FROM easy16_checks c
            JOIN easy16_schedules s ON s.id=c.schedule_id WHERE c.venue_id=? ORDER BY c.id DESC LIMIT ?''',(vid,max(1,min(500,limit))))]


def list_capa(store,vid,include_verified=True):
    _venue(store,vid);migrate16(store)
    with store.connect() as db:
        return [dict(x) for x in db.execute('SELECT * FROM easy16_capa WHERE venue_id=?'+('' if include_verified else " AND status!='Проверено'")+' ORDER BY id DESC',(vid,))]


def create_capa(store,vid,problem,owner='',due_date='',actor='Пользователь'):
    _venue(store,vid);migrate16(store);problem=_short(problem,1000)
    if not problem:raise ValueError('Опишите обнаруженную проблему')
    due=_date(due_date,True)
    with store.connect() as db:
        cur=db.execute('''INSERT INTO easy16_capa(venue_id,problem,owner,due_date,status,created_at,updated_at)
                          VALUES(?,?,?,?,'Открыто',?,?)''',(vid,problem,_short(owner),due,now(),now()))
        cid=cur.lastrowid;_trace(db,vid,actor,'capa_opened',{'id':cid,'problem':problem})
    return cid


def advance_capa(store,vid,capa_id,step,actor,containment='',cause='',corrective='',note=''):
    """State machine requires documented action + independent confirmation."""
    _venue(store,vid);migrate16(store);actor=_short(actor,100)
    if not actor:raise ValueError('Укажите, кто выполнил действие')
    with store.connect() as db:
        r=db.execute('SELECT * FROM easy16_capa WHERE venue_id=? AND id=?',(vid,int(capa_id))).fetchone()
        if not r:raise ValueError('Несоответствие не найдено')
        if step=='resolve' and r['status']=='Открыто':
            containment=_short(containment,1500);cause=_short(cause,1500);corrective=_short(corrective,1500)
            if not containment or not corrective:raise ValueError('Укажите защитные и корректирующие действия')
            db.execute('''UPDATE easy16_capa SET containment=?,root_cause=?,corrective=?,status='Ожидает проверки',updated_at=? WHERE id=?''',
                       (containment,cause,corrective,now(),capa_id))
        elif step=='verify' and r['status']=='Ожидает проверки':
            note=_short(note,1000)
            if not note:raise ValueError('Укажите результат проверки')
            db.execute('''UPDATE easy16_capa SET status='Проверено',verification_note=?,verified_by=?,verified_at=?,updated_at=? WHERE id=?''',
                       (note,actor,now(),now(),capa_id))
        elif step=='reopen' and r['status']=='Ожидает проверки':
            note=_short(note,1000)
            if not note:raise ValueError('Укажите причину повторного открытия')
            db.execute("UPDATE easy16_capa SET status='Открыто',verification_note=?,updated_at=? WHERE id=?",(note,now(),capa_id))
        else:raise ValueError('Недопустимый переход состояния')
        _trace(db,vid,actor,'capa_'+step,{'id':capa_id,'note':note,'corrective':corrective})
    return True


def _pass_hash(password,salt):
    return hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),bytes.fromhex(salt),310000).hex()


def list_users(store):
    migrate16(store)
    with store.connect() as db:
        return [dict(x) for x in db.execute('SELECT id,username,display_name,role,active FROM easy16_users ORDER BY id')]


def create_user(store,username,display_name,role,password):
    """Opt-in operator roles. DB tamper protection is out of scope for an offline app."""
    migrate16(store)
    username=_short(username,60).lower(); display_name=_short(display_name,120)
    if not re.fullmatch(r'[a-z0-9_.-]{3,60}',username):raise ValueError('Логин: от 3 символов, латиница и цифры')
    if role not in ROLES:raise ValueError('Неизвестная роль')
    if len(password)<12:raise ValueError('Пароль должен быть не короче 12 символов')
    salt=secrets.token_hex(24)
    with store.connect() as db:
        if db.execute('SELECT count(*) FROM easy16_users').fetchone()[0]==0 and role!='Администратор':
            raise ValueError('Первую учётную запись создают с ролью Администратор')
        db.execute('INSERT INTO easy16_users(username,display_name,role,salt,secret_hash) VALUES(?,?,?,?,?)',
                   (username,display_name,role,salt,_pass_hash(password,salt)))
    return username


def authenticate(store,username,password):
    migrate16(store)
    with store.connect() as db:
        r=db.execute('SELECT * FROM easy16_users WHERE username=? AND active=1',(str(username).lower(),)).fetchone()
    if not r:return None
    if not hmac.compare_digest(_pass_hash(password,r['salt']),r['secret_hash']):return None
    return {'username':r['username'],'display_name':r['display_name'],'role':r['role']}


def allowed(role,action):return action in PERMISSIONS.get(role,set())


def search_all(store,vid,query,limit=60):
    _venue(store,vid);migrate16(store)
    needle=_short(query,150).lower()
    if len(needle)<2:return []
    hits=[]
    for table,fields,title,cat in (
       ('easy16_schedules',('title','resource','responsible'),'title','График'),
       ('easy16_capa',('problem','owner','corrective'),'problem','Отклонение'),
       ('easy16_assets',('display_name','location'),'display_name','Оборудование')):
        with store.connect() as db:
            for r in db.execute('SELECT * FROM '+table+' WHERE venue_id=?',(vid,)):
                if any(needle in str(r[f] or '').lower() for f in fields):
                    hits.append({'category':cat,'title':str(r[title]),'id':r['id']})
    with store.connect() as db:
        for r in db.execute('SELECT * FROM journal_records WHERE venue_id=? ORDER BY id DESC LIMIT 2000',(vid,)):
            if needle in (r['data'] or '').lower() or needle in r['template_code'].lower():
                hits.append({'category':'Журнал','title':r['template_code']+' / запись №'+str(r['id']),'id':r['id']})
    try:
        from staff_store import list_employees
        for x in list_employees(store,vid):
            if needle in (x['full_name']+' '+(x.get('position_name') or '')).lower():
                hits.append({'category':'Сотрудник','title':x['full_name'],'id':x['id']})
    except (ImportError, KeyError):pass
    return hits[:max(1,min(200,limit))]


def register_asset(store,vid,name,location='',journal_code='',actor='Пользователь'):
    _venue(store,vid);migrate16(store)
    name=_short(name)
    if not name:raise ValueError('Укажите оборудование')
    with store.connect() as db:
        x=db.execute('INSERT INTO easy16_assets(venue_id,display_name,location,journal_code) VALUES(?,?,?,?)',
                     (vid,name,_short(location),_short(journal_code,70)))
        ident=x.lastrowid;_trace(db,vid,actor,'asset_added',{'id':ident,'name':name})
    return ident


def list_assets(store,vid):
    _venue(store,vid);migrate16(store)
    with store.connect() as db:return [dict(x) for x in db.execute('SELECT * FROM easy16_assets WHERE venue_id=? ORDER BY id',(vid,))]


def make_asset_qr(store,vid,asset_id,destination):
    """QR holds only opaque local ID. NOT a web link, it does not reveal private data."""
    import qrcode
    if not any(x['id']==asset_id for x in list_assets(store,vid)):raise ValueError('Оборудование не найдено')
    text=f'moolva-haccp://asset/{vid}/{asset_id}'
    path=Path(destination);path.parent.mkdir(parents=True,exist_ok=True)
    if path.suffix.lower()!='.png':raise ValueError('Выберите PNG для QR-кода')
    qrcode.make(text).save(path)
    return path


def read_table(path,max_rows=2000):
    """Preview-only simple XLSX and CSV, no macros, external links or formula evaluation."""
    path=Path(path)
    if path.stat().st_size>5_000_000:raise ValueError('Файл импорта слишком велик')
    if path.suffix.lower()=='.csv':
        content=path.read_text(encoding='utf-8-sig')
        if '\x00' in content:raise ValueError('Недопустимый CSV')
        return list(csv.reader(io.StringIO(content),delimiter=';' if content.count(';')>content.count(',') else ','))[:max_rows+1]
    if path.suffix.lower()!='.xlsx':raise ValueError('Поддерживаются CSV и XLSX')
    with zipfile.ZipFile(path) as z:
        if sum(x.file_size for x in z.infolist())>40_000_000:raise ValueError('Слишком большой XLSX')
        strings=[];ns='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
        if 'xl/sharedStrings.xml' in z.namelist():
            rt=ET.fromstring(z.read('xl/sharedStrings.xml'))
            strings=[''.join(t.text or '' for t in si.iter(ns+'t')) for si in rt.findall(ns+'si')]
        files=sorted([x for x in z.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',x)])
        if not files:raise ValueError('Не найден лист Excel')
        root=ET.fromstring(z.read(files[0]));rows=[]
        for row in root.iter(ns+'row'):
            cells={}
            for cell in row.findall(ns+'c'):
                col=re.match(r'[A-Z]+',cell.attrib.get('r','A')).group()
                index=0
                for letter in col:index=index*26+ord(letter)-64
                if index>60:continue
                value=cell.find(ns+'v')
                inline=cell.find(ns+'is')
                raw=value.text if value is not None else ''
                if cell.attrib.get('t')=='s' and raw:raw=strings[int(raw)]
                if cell.attrib.get('t')=='inlineStr' and inline is not None:
                    raw=''.join(n.text or '' for n in inline.iter(ns+'t'))
                cells[index-1]=raw or ''
            if cells:rows.append([cells.get(i,'') for i in range(min(60,max(cells)+1))])
            if len(rows)>max_rows:break
    return rows


def import_employees_preview(store,vid,rows,apply=False,actor='Администратор'):
    """Nothing inserted until user confirms. No signatures imported."""
    _venue(store,vid)
    entries=[]
    for row in rows[1:]:
        if not row:continue
        full=' '.join(str(row[0] or '').split())
        if len(full)<2:continue
        pos=str(row[1] if len(row)>1 else '')[:180]
        entries.append((full,pos))
    if len(entries)>500:raise ValueError('Импорт не более 500 сотрудников за раз')
    if apply:
        from staff_store import save_employee
        for full,pos in entries:save_employee(store,vid,full,position_name=pos)
        migrate16(store)
        with store.connect() as db:_trace(db,vid,actor,'staff_imported',{'count':len(entries)})
    return entries


def local_advice(text):
    low=str(text).lower()
    if 'ккт' in low:return 'ККТ и её пределы определяет ответственная группа ХАССП. В программе можно связать этап, журнал и мониторинг; самостоятельно утверждать ККТ программа не должна.'
    if 'температур' in low:return 'Введите фактическое показание. Программа сопоставит его только с явно заданным для предприятия диапазоном и создаст задачу при отклонении.'
    if 'журнал' in low:return 'Откройте «Заполнить журнал», выберите форму и сохраните фактическую запись. Черновик не считается выполненной проверкой.'
    if 'провер' in low or 'аудит' in low:return 'Откройте «Подготовка к аудиту», выберите период и выгрузите пакет. Итоговое соответствие оценивает специалист.'
    if 'сотруд' in low:return 'Сотрудников добавляют в одноимённом разделе. Подписант назначается отдельно; программа не создаёт настоящие подписи.'
    return 'Могу подсказать по ККТ, журналам, температурным проверкам, сотрудникам и подготовке к аудиту. Помощник полностью локальный и не заменяет специалиста ХАССП.'


def audit_package(store,vid,destination,start_date,end_date):
    """Reproducible offline ZIP: HTML overview + CSV raw records, schedules, CAPA, audit chain.

    Does not assert compliance, does not include fake signatures.
    """
    _venue(store,vid);migrate16(store)
    start=_date(start_date);end=_date(end_date)
    if start>end:raise ValueError('Начало периода позже окончания')
    destination=Path(destination)
    if destination.suffix.lower()!='.zip':raise ValueError('Файл должен иметь расширение .zip')
    if destination.exists():raise FileExistsError('Комплект уже существует; выберите новое имя')
    v=store.get_venue(vid)
    def _rows(sql,params):
        with store.connect() as db:return [dict(x) for x in db.execute(sql,params)]
    checks=_rows('SELECT * FROM easy16_checks WHERE venue_id=? AND substr(checked_at,1,10) BETWEEN ? AND ?',(vid,start,end))
    capa=_rows('SELECT * FROM easy16_capa WHERE venue_id=? AND substr(created_at,1,10) BETWEEN ? AND ?',(vid,start,end))
    records=_rows('SELECT * FROM journal_records WHERE venue_id=? AND substr(created_at,1,10) BETWEEN ? AND ?',(vid,start,end))
    chain=_rows('SELECT * FROM easy16_trace WHERE venue_id=? AND substr(happened_at,1,10) BETWEEN ? AND ?',(vid,start,end))
    schedules=list_schedules(store,vid,False)
    integrity=trace_integrity(store,vid)
    manifest={'program':'MoOLVa HACCP Easy 1.6','enterprise':v['venue_name'],'venue_id':vid,
              'period':[start,end],'created_at':now(),'checks':len(checks),'journal_records':len(records),
              'corrective_actions':len(capa),'audit_events':len(chain),'trace_integrity':integrity,
              'disclaimer':'Автоматическая подборка записей. Не является свидетельством соответствия законодательству.'}
    def _csv(rows):
        out=io.StringIO();fields=list(rows[0]) if rows else ['Нет записей']
        writer=csv.DictWriter(out,fieldnames=fields,delimiter=';',extrasaction='ignore');writer.writeheader()
        for r in rows:
            writer.writerow({k:('\''+str(v) if str(v).startswith(('=','+','-','@')) else v) for k,v in r.items()})
        return '\ufeff'+out.getvalue()
    with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('00_Информация.json',json.dumps(manifest,ensure_ascii=False,indent=2))
        for f,rows in [('01_Графики.csv',schedules),('02_Проверки.csv',checks),('03_Корректирующие_действия.csv',capa),
                       ('04_Журналы.csv',records),('05_История_изменений.csv',chain)]:z.writestr(f,_csv(rows))
        # Readable report for Microsoft Word; no external office dependency.
        from docx import Document
        doc=Document();doc.add_heading('Комплект внутренней проверки ХАССП',0)
        doc.add_paragraph(v['venue_name']);doc.add_paragraph(f'Период: {start} — {end}')
        doc.add_paragraph('Материалы представлены для анализа специалистом. Автоматическая выгрузка не является заключением о соответствии.')
        for title,rows in [('Проверки',checks),('Журнальные записи',records),('Корректирующие действия',capa)]:
            doc.add_heading(title,level=1);doc.add_paragraph(f'Записей за период: {len(rows)}')
        doc.add_paragraph('Целостность локальной цепочки изменений: '+('прошла' if integrity['valid'] else 'ОШИБКА ПРОВЕРКИ'))
        output=io.BytesIO();doc.save(output);z.writestr('06_Сводка_проверки.docx',output.getvalue())
    return {'path':destination,'manifest':manifest}


def ensure_daily_backup(store,keep=10,day=None):
    """One verified transactional snapshot per local day. Does not overwrite copies."""
    from backup15 import create_database_backup
    day=_date(day or date.today().isoformat())
    folder=Path(store.path).parent/'automatic_backups16'
    folder.mkdir(parents=True,exist_ok=True)
    dest=folder/('MoOLVa_'+day+'.sqlite3')
    if not dest.exists():create_database_backup(store,dest)
    versions=sorted(folder.glob('MoOLVa_????-??-??.sqlite3'))
    for older in versions[:-max(2,min(90,int(keep)))]:older.unlink()
    return dest


def preview_template_update(path):
    """Offline manual template package. Digest is for consistency, not publisher trust."""
    p=Path(path)
    if p.stat().st_size>160_000 or p.suffix.lower()!='.json':
        raise ValueError('Выберите JSON-файл шаблона не больше 160 КБ')
    data=json.loads(p.read_text(encoding='utf-8-sig'))
    if not isinstance(data,dict):raise ValueError('Ожидается объект JSON')
    title=_short(data.get('title',''),180)
    columns=data.get('columns')
    if not title or not isinstance(columns,list) or not (2<=len(columns)<=18):
        raise ValueError('Название и от 2 до 18 граф обязательны')
    names=[_short(name,120) for name in columns]
    if any(not name for name in names):raise ValueError('Названия граф обязательны')
    digest=hashlib.sha256(json.dumps({'title':title,'columns':names},ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    return {'title':title,'columns':names,'digest':digest,'warning':'Происхождение файла не подтверждено. Проверьте содержание перед добавлением.'}


def install_template_update(store,vid,path,reviewed_by):
    _venue(store,vid);migrate16(store)
    preview=preview_template_update(path)
    # Always NEW template; never overwrite an approved form or signed journal.
    code=store.add_custom_template(preview['title'],preview['columns'])
    with store.connect() as db:
        db.execute('INSERT INTO easy16_template_versions(venue_id,name,digest,reviewed_by,imported_at) VALUES(?,?,?,?,?)',
            (vid,preview['title'],preview['digest'],_short(reviewed_by,100),now()))
        _trace(db,vid,reviewed_by,'template_imported',{'name':preview['title'],'code':code,'sha256':preview['digest']})
    return code
